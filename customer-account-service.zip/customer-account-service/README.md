customer-account-service
----
![Screen_Shot_2016-09-03_at_3.13.10_PM](/uploads/be3c35e80257436e18a92820451a9c58/Screen_Shot_2016-09-03_at_3.13.10_PM.png)
This project serves as an orchestration layer for the management of the following customer information
- Profile
- Identity 
- Address
- Payment Cards
- Preferences
- Ratings & Reviews

Responsibilities
--- 
- User Registration, payment cards, address and user profile management for all channels (full site + mobile + tablet + consumer apps)
- Integration with SVOC APIs for user profile and address. 
- Integration with ProX APIs for payment cards and xRef
- Integration with IAM APIs for Identity and Session management
- Integration with Acxiom for user preferences
- Integration with Bazaar voice for user ratings & reviews
- Ensure appropriate hd.com validations and rules for all incoming requests
- Orchestrate and aggregate various use cases. Registration flow, Link Accounts, Payment cards, Forgot password, etc
- Build client specific responses and functionalities (i.e. pagination, additional data, etc)

Tech stack
----
- Java 8
- Spring Boot
- Spring Cloud
- Embedded Tomcat
- Hystrix
- Maven
- SonarQube
- TestNG & Mockito framework
- Apache utils
- Lombok
- Swagger

High Level Flows
---
https://confluence.homedepot.com/display/Aurora/Customer+Account+Service

API Reference
---
http://origin-www.gcp-dev.homedepot.com/customer/account/v1/swagger-ui.html

Dev Installation
---
TODO

Contact
-----
OLT_MyAccount_Customer@homedepot.com

Contribute
--- 

License
---
