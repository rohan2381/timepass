#!/bin/bash

export PROJECT=$(/usr/share/google/get_metadata_value project-id)
export ZONE=$(/usr/share/google/get_metadata_value zone | cut -d '/' -f 4)
export NETWORK=$(/usr/share/google/get_metadata_value network-interfaces/0/network | cut -d '/' -f 4)

export APP_NAME=$(/usr/share/google/get_metadata_value attributes/application)
export APP_VERSION=$(/usr/share/google/get_metadata_value attributes/version)
export APP_RELEASE=$(/usr/share/google/get_metadata_value attributes/release)
