package com.homedepot.customer.config;

import static springfox.documentation.builders.PathSelectors.any;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

/**
 * Created by rxb1809 on Jun 14, 2016 This class is used to configure swagger
 */
@Configuration
public class ApiDocConfig {
    
    @Autowired
    private Environment environment;
    
    private static final String PROD = "prod";
    private static final String BETA = "beta";
    private static final String SWAGGER_GROUP = "customer-account-service-v1";
    private static final String SWAGGER_BASE_PACKAGE = "com.homedepot.customer.controller";

    @Bean
    public Docket newsApi() {
        
        boolean enableSwagger = true;
        
        if(Arrays.stream(environment.getActiveProfiles())
                .anyMatch(env -> PROD.equalsIgnoreCase(env) || BETA.equalsIgnoreCase(env))) {
            enableSwagger = false;
        }
        
        return new Docket(DocumentationType.SWAGGER_2).groupName(SWAGGER_GROUP).apiInfo(apiInfo())
                .enable(enableSwagger)
                .select().paths(any()).apis(RequestHandlerSelectors.basePackage(SWAGGER_BASE_PACKAGE))
                .build();
    }

    @SuppressWarnings("deprecation")
    private ApiInfo apiInfo() {
        return new ApiInfoBuilder().title("Customer Account Service Sepcification").version("V1")
                //.description("Test Accounts - https://confluence.homedepot.com/display/Aurora/Aurora+Customer+-+Test+Users")
                .contact("OLT_MyAccount_Customer@homedepot.com").version("1.0").build();
    }
}
