package com.homedepot.customer.config;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.CollectionUtils;

import com.homedepot.customer.integration.registry.RegistryServiceFacade;
import com.homedepot.customer.integration.registry.dto.Feature;
import com.homedepot.customer.integration.registry.dto.RegistryServiceResponse;
import com.homedepot.customer.util.GlobalConstants;

/**
 * Created by vxg6469 on 12/14/16.
 */
@Configuration
@Slf4j
public class FeatureSwitchConfig {
    
    @Autowired
    RegistryServiceFacade registryServiceFacade;
    
    // Registry Service call to load the Feature Keys
    @Bean(name="registryFeaturesMap" )
    public HashMap<String, Feature> getAllFeatures () {
        RegistryServiceResponse response  = registryServiceFacade.getFeatures();
        
        HashMap<String, Feature> featuresMap = new HashMap();
        if(null != response) {
            List<Feature> features = response.getFeature();
            if(! CollectionUtils.isEmpty(features)){
                featuresMap = (HashMap<String, Feature>) features.stream()
                        .collect(Collectors.toMap(opt -> opt.getFeatureName(), opt -> opt));
            }            
        }

        // load cart feature switch for migrateCart
        response  = registryServiceFacade.getCartFeatures();

        if (null != response) {
            List<Feature> features = response.getFeature();
            if (!CollectionUtils.isEmpty(features)) {
                Optional<Feature> featureOptional = features.stream().filter(feature -> feature.getFeatureName().equals(GlobalConstants.MCC_CART_MIGRATE_GCP_FEATURE)).findAny();
                if (featureOptional.isPresent()) {
                    Feature cartFeature = featureOptional.get();
                    log.debug("found cart feature switch: {}", cartFeature);
                    featuresMap.put(cartFeature.getFeatureName(), cartFeature);
                }
            }
        }

        // load mylist feature switch for migrateGuestList
        response  = registryServiceFacade.getListFeatures();

        if (null != response) {
            List<Feature> features = response.getFeature();
            if (!CollectionUtils.isEmpty(features)) {
                Optional<Feature> featureOptional = features.stream().filter(feature -> feature.getFeatureName().equals(GlobalConstants.GUEST_LIST_MIGRATE_GCP_FEATURE)).findAny();
                if (featureOptional.isPresent()) {
                    Feature listFeature = featureOptional.get();
                    log.debug("found list feature switch: {}", listFeature);
                    featuresMap.put(listFeature.getFeatureName(), listFeature);
                }
            }
        }

        return featuresMap;
    }

}
