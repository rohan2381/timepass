package com.homedepot.customer.config;

import org.springframework.context.annotation.Configuration;

/**
 * @author rxb1809
 * This class is to config hystrix command and properties
 */
@Configuration
public class HystrixConfig {

}
