package com.homedepot.customer.config;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Configuration;

import java.net.InetAddress;

/**
 * Created by axb4725 on 7/28/17.
 */
@Slf4j
@Configuration
@Data
public class InstanceConfiguration {
    private String hostName = null;
    private String region = null;
    private String deployment = null;
    private String template = null;

    public InstanceConfiguration() {
        try {
            String rawHostName = InetAddress.getLocalHost().getHostName();

            if (!StringUtils.isEmpty(rawHostName)) {
                parseHostName(rawHostName);
            }
        } catch (Exception e) {
            log.error("Exception while locating the hostname", e);
        }
    }


    protected void parseHostName(String rawHostName) {
        try {

            String[] filteredHostName = StringUtils.split(rawHostName, ".");
            String[] instance = StringUtils.splitByWholeSeparator(filteredHostName[0], "-us-");
            hostName = instance[instance.length - 1];
            template = instance[0];

            String[] hostArray = hostName.split("-");
            region = hostArray[0] + "-" + hostArray[1];
            deployment = hostArray[2];

        } catch (Exception e) {
            log.error("Exception while finding/parsing the hostname", e);
        }

    }
}
