package com.homedepot.customer.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;

/**
 * Created by rxb1809 on Aug 7, 2016 This class is used to config message
 * resource bundles
 */
@Configuration
public class MessageResourceConfig {

    @Bean(name = "errorMessageResource")
    public ResourceBundleMessageSource resourceBundleMessageSource() {
        ResourceBundleMessageSource source = new ResourceBundleMessageSource();
        source.setBasename("error-messages");
        source.setUseCodeAsDefaultMessage(true);
        return source;
    }

    @Bean(name = "rulesMessageResource")
    public ResourceBundleMessageSource rulesResourceBundleMessageSource() {
        ResourceBundleMessageSource source = new ResourceBundleMessageSource();
        source.setBasename("rules");
        source.setUseCodeAsDefaultMessage(true);
        return source;
    }
}
