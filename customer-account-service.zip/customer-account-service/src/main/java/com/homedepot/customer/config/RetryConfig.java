package com.homedepot.customer.config;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;

/**
 * Created by rxb1809 on Oct 22, 2016
 * This is to configure various retry template/policies 
 */
@Configuration
public class RetryConfig {

    @Bean(name="dataSyncRetryTemplate")
    public RetryTemplate retryTemplate() {
        Map<Class<? extends Throwable>, Boolean> exceptionMap = new HashMap<>();
        
        exceptionMap.put(RestClientException.class, true);  
        exceptionMap.put(ResourceAccessException.class, true);  
        exceptionMap.put(IOException.class, true); 
        
        SimpleRetryPolicy retryPolicy = new SimpleRetryPolicy(3, exceptionMap);
   
        FixedBackOffPolicy backOffPolicy = new FixedBackOffPolicy();
        backOffPolicy.setBackOffPeriod(5000); 
   
        RetryTemplate template = new RetryTemplate();
        template.setRetryPolicy(retryPolicy);
        template.setBackOffPolicy(backOffPolicy);
   
        return template;
    }
}
