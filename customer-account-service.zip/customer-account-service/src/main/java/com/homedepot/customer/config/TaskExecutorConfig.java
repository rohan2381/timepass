package com.homedepot.customer.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
@EnableAsync
@PropertySources({
        @PropertySource(value = "classpath:task-executor.properties", ignoreResourceNotFound = true) })

/**
 * Task Executor configuration class
 * 
 * @author pxk3659
 *
 */

public class TaskExecutorConfig {

    @Value("${default.max.pool.size:20}")
    private int defaultMaxPoolSize;
    @Value("${default.core.pool.size:5}")
    private int defaultCorePoolSize;
    @Value("${default.queue.capacity:100}")
    private int defaultQueueCapacity;

    @Value("${payment.max.pool.size:20}")
    private int paymentMaxPoolSize;
    @Value("${payment.core.pool.size:5}")
    private int paymentCorePoolSize;
    @Value("${payment.queue.capacity:100}")
    private int paymentQueueCapacity;

    @Value("${address.max.pool.size:20}")
    private int addressMaxPoolSize;
    @Value("${address.core.pool.size:5}")
    private int addressCorePoolSize;
    @Value("${address.queue.capacity:100}")
    private int addressQueueCapacity;

    @Value("${profile.max.pool.size:20}")
    private int profileMaxPoolSize;
    @Value("${profile.core.pool.size:5}")
    private int profileCorePoolSize;
    @Value("${profile.queue.capacity:100}")
    private int profileQueueCapacity;

    @Value("${identity.max.pool.size:20}")
    private int identityMaxPoolSize;
    @Value("${identity.core.pool.size:5}")
    private int identityCorePoolSize;
    @Value("${identity.queue.capacity:100}")
    private int identityQueueCapacity;

    @Value("${email.max.pool.size:20}")
    private int emailMaxPoolSize;
    @Value("${email.core.pool.size:5}")
    private int emailCorePoolSize;
    @Value("${email.queue.capacity:100}")
    private int emailQueueCapacity;

    @Value("${cart.max.pool.size:20}")
    private int cartMaxPoolSize;
    @Value("${cart.core.pool.size:5}")
    private int cartCorePoolSize;
    @Value("${cart.queue.capacity:100}")
    private int cartQueueCapacity;

    @Value("${list.max.pool.size:20}")
    private int listMaxPoolSize;
    @Value("${list.core.pool.size:5}")
    private int listCorePoolSize;
    @Value("${list.queue.capacity:100}")
    private int listQueueCapacity;
    
    /**
     * Method to initialize default task executor
     * 
     * @return TaskExecutor
     */
    @Bean(name = "taskExecutor")
    public TaskExecutor getTaskExecutor() {
        ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
        taskExecutor.setMaxPoolSize(defaultMaxPoolSize);
        taskExecutor.setCorePoolSize(defaultCorePoolSize);
        taskExecutor.setQueueCapacity(defaultQueueCapacity);
        taskExecutor.afterPropertiesSet();
        taskExecutor.setThreadNamePrefix("DefaultExecutor-");
        return taskExecutor;
    }

    /**
     * Method to initialize payment sync task executor
     * 
     * @return TaskExecutor
     */
    @Bean(name = "paymentTaskExecutor")
    public TaskExecutor getPaymentTaskExecutor() {
        ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
        taskExecutor.setMaxPoolSize(paymentMaxPoolSize);
        taskExecutor.setCorePoolSize(paymentCorePoolSize);
        taskExecutor.setQueueCapacity(paymentQueueCapacity);
        taskExecutor.afterPropertiesSet();
        taskExecutor.setThreadNamePrefix("PaymentTaskExecutor-");
        return taskExecutor;
    }

    /**
     * Method to initialize address sync task executor
     * 
     * @return TaskExecutor
     */

    @Bean(name = "addressTaskExecutor")
    public TaskExecutor getAddressTaskExecutor() {
        ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
        taskExecutor.setMaxPoolSize(addressMaxPoolSize);
        taskExecutor.setCorePoolSize(addressCorePoolSize);
        taskExecutor.setQueueCapacity(addressQueueCapacity);
        taskExecutor.afterPropertiesSet();
        taskExecutor.setThreadNamePrefix("AddressTaskExecutor-");
        return taskExecutor;
    }

    /**
     * Method to initialize profile sync task executor
     * 
     * @return TaskExecutor
     */

    @Bean(name = "profileTaskExecutor")
    public TaskExecutor getProfileTaskExecutor() {
        ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
        taskExecutor.setMaxPoolSize(profileMaxPoolSize);
        taskExecutor.setCorePoolSize(profileCorePoolSize);
        taskExecutor.setQueueCapacity(profileQueueCapacity);
        taskExecutor.afterPropertiesSet();
        taskExecutor.setThreadNamePrefix("ProfileTaskExecutor-");
        return taskExecutor;
    }
    
    /**
     * Method to initialize profile sync task executor
     * 
     * @return TaskExecutor
     */

    @Bean(name = "identityTaskExecutor")
    public TaskExecutor getIdentityTaskExecutor() {
        ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
        taskExecutor.setMaxPoolSize(identityMaxPoolSize);
        taskExecutor.setCorePoolSize(identityCorePoolSize);
        taskExecutor.setQueueCapacity(identityQueueCapacity);
        taskExecutor.afterPropertiesSet();
        taskExecutor.setThreadNamePrefix("IdentityTaskExecutor-");
        return taskExecutor;
    }
    
    
    /**
     * Method to initialize profile sync task executor
     * 
     * @return TaskExecutor
     */

    @Bean(name = "emailTaskExecutor")
    public TaskExecutor getEmailTaskExecutor() {
        ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
        taskExecutor.setMaxPoolSize(emailMaxPoolSize);
        taskExecutor.setCorePoolSize(emailCorePoolSize);
        taskExecutor.setQueueCapacity(emailQueueCapacity);
        taskExecutor.afterPropertiesSet();
        taskExecutor.setThreadNamePrefix("EmailTaskExecutor-");
        return taskExecutor;
    }

    /**
     * Method to initialize migrate cart task executor
     *
     * @return TaskExecutor
     */

    @Bean(name = "cartTaskExecutor")
    public TaskExecutor getCartTaskExecutor() {
        ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
        taskExecutor.setMaxPoolSize(cartMaxPoolSize);
        taskExecutor.setCorePoolSize(cartCorePoolSize);
        taskExecutor.setQueueCapacity(cartQueueCapacity);
        taskExecutor.afterPropertiesSet();
        taskExecutor.setThreadNamePrefix("CartTaskExecutor-");
        return taskExecutor;
    }

    /**
     * Method to initialize migrate cart task executor
     *
     * @return TaskExecutor
     */

    @Bean(name = "listTaskExecutor")
    public TaskExecutor getListTaskExecutor() {
        ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
        taskExecutor.setMaxPoolSize(listMaxPoolSize);
        taskExecutor.setCorePoolSize(listCorePoolSize);
        taskExecutor.setQueueCapacity(listQueueCapacity);
        taskExecutor.afterPropertiesSet();
        taskExecutor.setThreadNamePrefix("ListTaskExecutor-");
        return taskExecutor;
    }

}
