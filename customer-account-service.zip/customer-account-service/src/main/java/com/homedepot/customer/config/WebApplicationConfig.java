package com.homedepot.customer.config;

import org.apache.catalina.valves.AccessLogValve;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.homedepot.customer.framework.CustomerServiceRequestInterceptor;

/**
 * Created by rxb1809 on Aug 11, 2016
 *
 */
@Configuration
public class WebApplicationConfig extends WebMvcConfigurerAdapter implements EmbeddedServletContainerCustomizer {

    @Autowired
    ServerProperties serverProperties;

    private static final String[] API_REQUEST_PATHS = { "/*/addresses*", "/*/addresses/**", "/*/profile*",
            "/*/profile/**", "/*/paymentcards*", "/*/paymentcards/**", "/login*", "/register*", "/*Password*",
            "/session/*", "/*/identity*","/checkEmailExists","/checkCustomerExists", "/signIn*","/signUp*"};

    @Bean
    public CustomerServiceRequestInterceptor customerServiceRequestInterceptor() {
        return new CustomerServiceRequestInterceptor();
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(customerServiceRequestInterceptor()).addPathPatterns(API_REQUEST_PATHS);
    }

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        //
    }

    // Customize Tomcat access logs for additional settings not available in
    // application yml
    @Override
    public void customize(ConfigurableEmbeddedServletContainer container) {
        if (container instanceof TomcatEmbeddedServletContainerFactory) {

            final TomcatEmbeddedServletContainerFactory tcContainer = (TomcatEmbeddedServletContainerFactory) container;
            ServerProperties.Tomcat.Accesslog accessLog = serverProperties.getTomcat().getAccesslog();

            AccessLogValve accessLogValve = new AccessLogValve();
            accessLogValve.setPattern(accessLog.getPattern());
            accessLogValve.setDirectory(accessLog.getDirectory());
            accessLogValve.setPrefix(accessLog.getPrefix());
            accessLogValve.setSuffix(accessLog.getSuffix());
            accessLogValve.setRenameOnRotate(true);

            tcContainer.addContextValves(accessLogValve);
        }
    }
}
