package com.homedepot.customer.controller;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.SwaggerDefinition;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.model.Address;
import com.homedepot.customer.model.Addresses;
import com.homedepot.customer.model.PaginationInfo;
import com.homedepot.customer.request.AddressRequest;
import com.homedepot.customer.response.AddressResponse;
import com.homedepot.customer.response.builder.impl.AddressResponseBuilderImpl;
import com.homedepot.customer.service.IAddressService;
import com.homedepot.customer.util.AccountRequestHelper;

/**
 * Created by rxb1809 on Apr 27, 2016
 * Controller to handle address management requests for a registered user
 */
@SwaggerDefinition
@Api(tags={"Customer Address"}, description="Address management")
@RestController
@RequestMapping("/{custAccountId}/addresses")
@Slf4j
public class AddressController {

    @Autowired
    IAddressService addressService;
    
    @Autowired
    AddressResponseBuilderImpl responseBuilder;
    
    @Autowired
    AccountRequestHelper accountRequestHelper;

    
    @ApiOperation(value = "Gets all addresses for a registered customer", nickname = "getAllAddresses")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp", allowableValues = "1,2,3,4,5,6", defaultValue = "1", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Authorization", value = "Users Auth Token. Supports both WCS or IAM token. The clients need to pass in appropriate value and relevant cookies depending on which authentication they are using", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Cookie", value = "THD_USER Cookie. The client need to pass appropriate THD_USER cookie value in 'THD_USER=Cookie Value' format",  defaultValue = "THD_USER=eyJzdm9jQ3VzdG9tZXJBY2NvdW50SWQiOiIwM0Y4NDg1R", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "custAccountId", value = "Customers account id. Supports both SVOC Id and WCS member id", defaultValue = "03D7788C5E9BB8D00S", required = true, dataType = "string", paramType = "path")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 401, message = "User Un-Authorized"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public AddressResponse getAllAddresses(@PathVariable(value="custAccountId") String customerAccountId, @RequestParam(value="pageSize", required = false) String pageSize, @RequestParam(value="pageNumber", required = false) String pageNumber) throws CustomerAccountServiceException {
        log.debug("getAllAddresses for {}", customerAccountId);
        AddressRequest request = new AddressRequest();
        PaginationInfo paginationInfo = new PaginationInfo();
        paginationInfo.setPageNumber(pageNumber);
        paginationInfo.setPageSize(pageSize);
        request.setPaginationInfo(paginationInfo);

        Map<String, Object> allAddressesMap = addressService.getAllUserAddresses(request, customerAccountId);
        Addresses addresses = (Addresses) allAddressesMap.get("addresses");
        return responseBuilder.buildResponse(addresses.getAddress(), (PaginationInfo) allAddressesMap.get("paginationInfo"), null);
    }

    @ApiOperation(value = "Creates an address for a registered customer", nickname = "createAddress")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp", allowableValues = "1,2,3,4,5,6", defaultValue = "1", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Authorization", value = "Users Auth Token. Supports both WCS or IAM token. The clients need to pass in appropriate value and relevant cookies depending on which authentication they are using", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Cookie", value = "THD_USER Cookie. The client need to pass appropriate THD_USER cookie value in 'THD_USER=Cookie Value' format",  defaultValue = "THD_USER=eyJzdm9jQ3VzdG9tZXJBY2NvdW50SWQiOiIwM0Y4NDg1R", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "custAccountId", value = "Customers account id. Supports both SVOC Id and WCS member id", defaultValue = "03D7788C5E9BB8D00S", required = true, dataType = "string", paramType = "path")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 401, message = "User Un-Authorized"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(method=RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public AddressResponse createAddress(@RequestBody AddressRequest addressRequest, @PathVariable(value="custAccountId") String customerAccountId ) throws CustomerAccountServiceException {
        List<Address> addressList = addressService.createUserAddress(addressRequest,customerAccountId);
        
        return responseBuilder.buildResponse(addressList, null, null);
    }


    @ApiOperation(value = "Gets an address by address ID for a registered customer", nickname = "getAddressByAddressId")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp", allowableValues = "1,2,3,4,5,6", defaultValue = "1", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Authorization", value = "Users Auth Token. Supports both WCS or IAM token. The clients need to pass in appropriate value and relevant cookies depending on which authentication they are using", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Cookie", value = "THD_USER Cookie. The client need to pass appropriate THD_USER cookie value in 'THD_USER=Cookie Value' format",  defaultValue = "THD_USER=eyJzdm9jQ3VzdG9tZXJBY2NvdW50SWQiOiIwM0Y4NDg1R", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "custAccountId", value = "Customers account id. Supports both SVOC Id and WCS member id", defaultValue = "03D7788C5E9BB8D00S", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "addressId", value = "Address Id to be retrieved", defaultValue = "2", required = true, dataType = "string", paramType = "path")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 401, message = "User Un-Authorized"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(value="/{addressId}", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public AddressResponse getAddressByAddressId(@PathVariable(value="custAccountId") String customerAccountId,
                                                 @PathVariable(value = "addressId") Integer addressId)
                                                         throws CustomerAccountServiceException{
        log.debug("getting address detail for customer: {}, addressId: {}", customerAccountId, addressId);
        accountRequestHelper.setRequestTypeForAddrId(String.valueOf(addressId));
        List<Address> addressList = addressService.getUserAddressById(customerAccountId, addressId);
        
        return responseBuilder.buildResponse(addressList, null, null);
    }


    @ApiOperation(value = "Updates an address for a registered customer", nickname = "updateAddress")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp", allowableValues = "1,2,3,4,5,6", defaultValue = "1", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Authorization", value = "Users Auth Token. Supports both WCS or IAM token. The clients need to pass in appropriate value and relevant cookies depending on which authentication they are using", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Cookie", value = "THD_USER Cookie. The client need to pass appropriate THD_USER cookie value in 'THD_USER=Cookie Value' format",  defaultValue = "THD_USER=eyJzdm9jQ3VzdG9tZXJBY2NvdW50SWQiOiIwM0Y4NDg1R", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "custAccountId", value = "Customers account id. Supports both SVOC Id and WCS member id", defaultValue = "03D7788C5E9BB8D00S", required = true, dataType = "string", paramType = "path"),
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 401, message = "User Un-Authorized"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(method=RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public AddressResponse updateAddress(@PathVariable(value="custAccountId") String customerAccountId, @RequestBody AddressRequest addressRequest)
            throws CustomerAccountServiceException{

        log.debug("Entering update method for customerId: {}", customerAccountId);
        for(Address address : addressRequest.getAddress()){
            log.debug("Address: " + address);
        }

        accountRequestHelper.setRequestTypeForAddrId(String.valueOf(
                                                addressRequest.getAddress()
                                                        .stream()
                                                        .map(a -> a.getAddrIdentifier())
                                                        .filter(Objects::nonNull)
                                                        .findFirst()
                                                        .orElse(0)));

        return responseBuilder.buildResponse(addressService.updateUserAddress(addressRequest,customerAccountId), null, null);
    }


    @ApiOperation(value = "Deletes an address by address ID for a registered customer", nickname = "deleteAddress")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp", allowableValues = "1,2,3,4,5,6", defaultValue = "1", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Authorization", value = "Users Auth Token. Supports both WCS or IAM token. The clients need to pass in appropriate value and relevant cookies depending on which authentication they are using", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Cookie", value = "THD_USER Cookie. The client need to pass appropriate THD_USER cookie value in 'THD_USER=Cookie Value' format",  defaultValue = "THD_USER=eyJzdm9jQ3VzdG9tZXJBY2NvdW50SWQiOiIwM0Y4NDg1R", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "custAccountId", value = "Customers account id. Supports both SVOC Id and WCS member id", defaultValue = "03D7788C5E9BB8D00S", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "lastModifiedDate", value = "Last modified date of the address to be deleted", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "addressId", value = "Address Id to be deleted", required = true, dataType = "string", paramType = "path")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 401, message = "User Un-Authorized"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(value="/{addressId}", method=RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
    public AddressResponse deleteAddress(@PathVariable(value="custAccountId") String customerAccountId,
                                         @PathVariable(value = "addressId") Integer addressId,
                                         @RequestParam(value="lastModifiedDate") long lastModifiedDate)
            throws CustomerAccountServiceException{

        log.debug("deleting address detail for customer: {}, addressId: {}, lastModifiedDate: {}", customerAccountId, addressId, lastModifiedDate);

        // put address data in model object to fit existing interface
        Address address = new Address();
        address.setAddrIdentifier(addressId);
        address.setLastModifiedDate(new Date(lastModifiedDate));
        AddressRequest addressRequest = new AddressRequest();
        addressRequest.setAddress(Collections.singletonList(address));
        
        accountRequestHelper.setRequestTypeForAddrId(String.valueOf(addressId));

        return responseBuilder.buildResponse(addressService.deleteUserAddressById(customerAccountId, addressRequest), null, null);
    }

}
