package com.homedepot.customer.controller;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.model.PaginationInfo;
import com.homedepot.customer.model.PaymentCard;
import com.homedepot.customer.model.PaymentCards;
import com.homedepot.customer.request.PaymentCardRequest;
import com.homedepot.customer.response.PaymentResponse;
import com.homedepot.customer.response.builder.impl.PaymentResponseBuilderImpl;
import com.homedepot.customer.service.IPaymentService;
import com.homedepot.customer.util.*;

import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Created by rxb1809 on Apr 27, 2016
 *
 */
@Api(tags = { "Customer Payment Cards" }, description = "Payment cards management")
@RestController
@RequestMapping("/{custAccountId}/paymentcards")
@Slf4j
public class PaymentController {

    @Autowired
    IPaymentService paymentService;

    @Autowired
    PaymentResponseBuilderImpl responseBuilder;
    
    @Autowired
    private EnvPropertyUtil envProperty;
    
    @Autowired
    private CustomerAccountRequestContext requestContext;

    @Autowired
    AccountRequestHelper accountRequestHelper;

    @ApiOperation(value = "Gets all payment cards for a registered customer", nickname = "getAllPaymentCards")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp", allowableValues = "1,2,3,4,5,6", defaultValue = "1", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Authorization", value = "Users Auth Token. Supports both WCS or IAM token. The clients need to pass in appropriate value and relevant cookies depending on which authentication they are using", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Cookie", value = "THD_USER Cookie. The client need to pass appropriate THD_USER cookie value in 'THD_USER=Cookie Value' format",  defaultValue = "THD_USER=eyJzdm9jQ3VzdG9tZXJBY2NvdW50SWQiOiIwM0Y4NDg1R", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "custAccountId", value = "Customers account id. Supports both SVOC Id and WCS member id", defaultValue = "03D7788C5E9BB8D00S", required = true, dataType = "string", paramType = "path")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 401, message = "User Un-Authorized"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public PaymentResponse getAllPaymentCards(@PathVariable(value = "custAccountId") String customerAccountId,
            @RequestParam(value = "pageNumber", required = false) String pageNumber,
            @RequestParam(value = "pageSize", required = false) String pageSize,
            @RequestParam(value = "sortType", required = false) String sort) throws CustomerAccountServiceException {
        
        // This is to cater eReceipts till the enterprise payment services become available for use
        if(envProperty.getPaymentSource().equalsIgnoreCase(GlobalConstants.WCS)){
            requestContext.setWCSRequest(true);
        }

        PaymentCardRequest paymentCardRequest = new PaymentCardRequest();
        PaginationInfo paginationInfo = new PaginationInfo();
        paginationInfo.setPageNumber(pageNumber);
        paginationInfo.setPageSize(pageSize);
        paymentCardRequest.setPaginationInfo(paginationInfo);
        paymentCardRequest.setSortType(sort);
        Map<String, Object> paymentResponse = null;
        if(envProperty.getPaymentSource().equalsIgnoreCase(GlobalConstants.XREF))
            paymentResponse = paymentService.getAllPaymentCardsWithFallback(paymentCardRequest, customerAccountId);
        else
            paymentResponse = paymentService.getAllPaymentCards(paymentCardRequest, customerAccountId);
        
        return responseBuilder.buildResponse((List<PaymentCard>) paymentResponse.get("paymentCards"),
                (PaginationInfo) paymentResponse.get("paginationInfo"), null );
    }

    @ApiOperation(value = "Creates a payment card for a registered customer", nickname = "createPaymentCard")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp", allowableValues = "1,2,3,4,5,6", defaultValue = "1", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Authorization", value = "Users Auth Token. Supports both WCS or IAM token. The clients need to pass in appropriate value and relevant cookies depending on which authentication they are using", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Cookie", value = "THD_USER Cookie. The client need to pass appropriate THD_USER cookie value in 'THD_USER=Cookie Value' format",  defaultValue = "THD_USER=eyJzdm9jQ3VzdG9tZXJBY2NvdW50SWQiOiIwM0Y4NDg1R", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "custAccountId", value = "Customers account id. Supports both SVOC Id and WCS member id", defaultValue = "03D7788C5E9BB8D00S", required = true, dataType = "string", paramType = "path")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 401, message = "User Un-Authorized"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public PaymentResponse createPaymentCard(@PathVariable(value = "custAccountId") String customerAccountId,
            @RequestBody PaymentCards paymentCards) throws CustomerAccountServiceException {

        paymentCards.getPaymentCard().stream().findAny().ifPresent(paymentCard ->  accountRequestHelper.setRequestTypeForAddrId(String.valueOf(paymentCard.getBillingAddress().getAddrIdentifier())));

        List<PaymentCard> savedCards = paymentService.createUserPaymentCard(customerAccountId, paymentCards);

        return responseBuilder.buildResponse(savedCards, null, null);
    }

    @ApiOperation(value = "Gets a payment card record by payment id for a registered customer", nickname = "getPaymentCardByPaymentId")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp", allowableValues = "1,2,3,4,5,6", defaultValue = "1", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Authorization", value = "Users Auth Token. Supports both WCS or IAM token. The clients need to pass in appropriate value and relevant cookies depending on which authentication they are using", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Cookie", value = "THD_USER Cookie. The client need to pass appropriate THD_USER cookie value in 'THD_USER=Cookie Value' format",  defaultValue = "THD_USER=eyJzdm9jQ3VzdG9tZXJBY2NvdW50SWQiOiIwM0Y4NDg1R", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "custAccountId", value = "Customers account id. Supports both SVOC Id and WCS member id", defaultValue = "03D7788C5E9BB8D00S", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "paymentId", value = "Payment Card Id", required = true, dataType = "string", paramType = "path")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 401, message = "User Un-Authorized"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(value = "/{paymentId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public PaymentResponse getPaymentCardByPaymentId(@PathVariable(value = "custAccountId") String customerAccountId,
            @PathVariable(value = "paymentId") String paymentId) throws CustomerAccountServiceException {

        List<PaymentCard> paymentCardsList = paymentService.getUserPaymentCardById(customerAccountId, paymentId);

        return responseBuilder.buildResponse(paymentCardsList, null, null);
    }

    @ApiOperation(value = "Updates a payment card record by payment card id for a registered customer", nickname = "updatePaymentCard")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp", allowableValues = "1,2,3,4,5,6", defaultValue = "1", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Authorization", value = "Users Session Token", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Cookie", value = "THD_USER Cookie. The client need to pass appropriate THD_USER cookie value in 'THD_USER=Cookie Value' format",  defaultValue = "THD_USER=eyJzdm9jQ3VzdG9tZXJBY2NvdW50SWQiOiIwM0Y4NDg1R", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "custAccountId", value = "Customers account id. Supports both SVOC Id and WCS member id", defaultValue = "03D7788C5E9BB8D00S", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "paymentId", value = "Payment Card Id", required = true, dataType = "string", paramType = "path")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 401, message = "User Un-Authorized"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public PaymentResponse updatePaymentCard(@PathVariable(value = "custAccountId") String customerAccountId,
            @RequestBody PaymentCards paymentCards) throws CustomerAccountServiceException {

        if(paymentCards.getPaymentCard().stream().findAny().filter(p -> (null != p.getIsReqServedFromWCS() && p.getIsReqServedFromWCS().equals(true))).isPresent()){
            requestContext.setWCSRequest(true);
        }

        paymentCards.getPaymentCard().stream().findAny().ifPresent(paymentCard ->  accountRequestHelper.setRequestTypeForAddrId(String.valueOf(paymentCard.getBillingAddress().getAddrIdentifier())));

        List<PaymentCard> savedCards = paymentService.updateUserPaymentCard(customerAccountId, paymentCards);

        return responseBuilder.buildResponse(savedCards, null, null);
    }

    @ApiOperation(value = "Deletes a payment card as per given PaymentCardId for a registered customer", nickname = "deletePaymentCard")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp", allowableValues = "1,2,3,4,5,6", defaultValue = "1", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Authorization", value = "Users Session Token", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Cookie", value = "THD_USER Cookie. The client need to pass appropriate THD_USER cookie value in 'THD_USER=Cookie Value' format",  defaultValue = "THD_USER=eyJzdm9jQ3VzdG9tZXJBY2NvdW50SWQiOiIwM0Y4NDg1R", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "custAccountId", value = "Customers account id. Supports both SVOC Id and WCS member id", defaultValue = "03D7788C5E9BB8D00S", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "paymentId", value = "Payment Card Id", required = true, dataType = "string", paramType = "path")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 401, message = "User Un-Authorized"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })

    @RequestMapping(value = "/{paymentId}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean deletePaymentCard(@RequestParam(value="isReqServedFromWCS",required = false) boolean isRequestWcs ,@PathVariable(value = "custAccountId") String customerAccountId,
            @PathVariable(value = "paymentId") String paymentId ) throws CustomerAccountServiceException {
        log.debug("Start PaymentController.deletePaymentCard, customerAccountId: {}, paymentCardId: {}",
                customerAccountId, paymentId);
        requestContext.setReqServedFromWCS(isRequestWcs);
        requestContext.setWCSRequest(isRequestWcs);
        return paymentService.deleteUserPaymentCardById(customerAccountId, paymentId);

    }


}
