package com.homedepot.customer.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.SwaggerDefinition;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.response.PostalResponse;
import com.homedepot.customer.response.builder.impl.PostalResponseBuilderImpl;
import com.homedepot.customer.service.IAddressService;

/**
 * Created by jirapat on 10/14/16.
 */
@SwaggerDefinition
@Api(tags={"Postal Details"}, description="Verazip lookup for Postal Details")
@RestController
@CrossOrigin
@Slf4j
public class PostalController {

    @Autowired
    IAddressService addressService;

    @Autowired
    PostalResponseBuilderImpl postalResponseBuilder;

    @ApiOperation(value = "Looks up City and State list from Zip Code", nickname = "getCityStates")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "zipCode", value = "Zip Code to find list of City and State", required = true, dataType = "string", paramType = "path")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(value = "/zipCode/{zipCode}", method= RequestMethod.GET, produces = {MediaType.APPLICATION_JSON_VALUE})
    public PostalResponse getCityStates(@PathVariable(value="zipCode") String zipCode) throws CustomerAccountServiceException {
        log.debug("getCityStates(), zipCode: {}", zipCode);

        return postalResponseBuilder.buildResponse(addressService.getCityStates(zipCode), null, null);
    }
}
