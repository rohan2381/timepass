package com.homedepot.customer.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.SwaggerDefinition;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.model.Preferences;
import com.homedepot.customer.response.PreferencesResponse;
import com.homedepot.customer.service.IPreferencesService;

/**
 * Created by axb4725 on 9/26/16.
 */
@SwaggerDefinition
@Api(tags={"Customer Preferences"}, description="Email Preferences management")
@RestController
@CrossOrigin
@RequestMapping("/{custAccountId}/preferences")
@Slf4j
public class PreferencesController {

    @Autowired
    IPreferencesService preferencesService;

    @ApiOperation(value = "Gets customer preferences", nickname = "getPreferences")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp", allowableValues = "1,2,3,4,5,6", defaultValue = "1", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "auth-token", value = "Users Session Token", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Cookie", value = "THD_USER Cookie. The client need to pass appropriate THD_USER cookie value in 'THD_USER=Cookie Value' format",  defaultValue = "THD_USER=eyJzdm9jQ3VzdG9tZXJBY2NvdW50SWQiOiIwM0Y4NDg1R", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "custAccountId", value = "Customers SVOC Account Id", defaultValue = "03D7788C5E9BB8D00S", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "email", value = "Customers email address", required = true, dataType = "string", paramType = "query")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(method= RequestMethod.GET, produces = {MediaType.APPLICATION_JSON_VALUE})
    public PreferencesResponse getSubscriptions(@PathVariable(value="custAccountId") String customerAccountId,
                                                @RequestParam(value="email") String email)
            throws CustomerAccountServiceException {
            return new PreferencesResponse(preferencesService.getPreferences(email));
    }

    @ApiOperation(value = "Adds/updates customer preferences", nickname = "setPreferences")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp", allowableValues = "1,2,3,4,5,6", defaultValue = "1", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "auth-token", value = "Users Session Token", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Cookie", value = "THD_USER Cookie. The client need to pass appropriate THD_USER cookie value in 'THD_USER=Cookie Value' format",  defaultValue = "THD_USER=eyJzdm9jQ3VzdG9tZXJBY2NvdW50SWQiOiIwM0Y4NDg1R", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "custAccountId", value = "Customers SVOC Account Id", defaultValue = "03D7788C5E9BB8D00S", required = true, dataType = "string", paramType = "path"),
            @ApiImplicitParam(name = "email", value = "Customers email address", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "zipCode", value = "Customers zipcode", required = true, dataType = "string", paramType = "query")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public PreferencesResponse setSubscriptions(@PathVariable(value="custAccountId") String customerAccountId,
                                                @RequestParam(value="email") String email,
                                                @RequestParam(value="zipCode") String zipCode,
                                                @RequestBody Preferences preferences) throws CustomerAccountServiceException {
                                                       
        log.debug("Add/update preferences for {}, email {}, zipCode {}, preferences {}", customerAccountId, email, zipCode, preferences);
        Preferences respPreferences = preferencesService.setPreferences(email, zipCode, preferences);
        return new PreferencesResponse(respPreferences);
    }
}
