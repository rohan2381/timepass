package com.homedepot.customer.controller;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.model.Account;
import com.homedepot.customer.model.Identity;
import com.homedepot.customer.request.IdentityRequest;
import com.homedepot.customer.request.ProfileRequest;
import com.homedepot.customer.response.IdentityResponse;
import com.homedepot.customer.response.ProfileResponse;
import com.homedepot.customer.response.builder.impl.ProfileResponseBuilderImpl;
import com.homedepot.customer.service.IIdentityService;
import com.homedepot.customer.service.IProfileService;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

/**
 * Created by rxb1809 on Apr 27, 2016
 *
 */
@Api(tags = { "Customer Profile" }, description = "Profile management")
@RestController
@RequestMapping("/{custAccountId}/profile")
@Slf4j
public class ProfileController {

    @Autowired
    IProfileService profileService;

    @Autowired
    IIdentityService identityService;

    @Autowired
    ProfileResponseBuilderImpl profileResponseBuilder;

    @Autowired
    CustomerAccountRequestContext reqContext;

    @ApiOperation(value = "Gets customer profile", nickname = "getProfileById")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp", allowableValues = "1,2,3,4,5,6", defaultValue = "1", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Authorization", value = "Users Auth Token. Supports both WCS or IAM token. The clients need to pass in appropriate value and relevant cookies depending on which authentication they are using", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Cookie", value = "THD_USER Cookie. The client need to pass appropriate THD_USER cookie value in 'THD_USER=Cookie Value' format",  defaultValue = "THD_USER=eyJzdm9jQ3VzdG9tZXJBY2NvdW50SWQiOiIwM0Y4NDg1R", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "custAccountId", value = "Customers account id. Supports both SVOC Id and WCS member id", defaultValue = "03D7788C5E9BB8D00S", required = true, dataType = "string", paramType = "path") })
    @ApiResponses(value = { 
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 401, message = "User Un-Authorized"),
            @ApiResponse(code = 500, message = "Internal Server Error") })
    @RequestMapping(method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
    public ProfileResponse getProfileById(@PathVariable(value = "custAccountId") String customerAccountId)
            throws CustomerAccountServiceException {
        log.debug("getProfileById(), customerAccountId: {}", customerAccountId);

        return profileResponseBuilder.buildResponse(profileService.retrieveProfile(customerAccountId), null, null);
    }

    @ApiOperation(value = "Updates customer profile", nickname = "updateProfile")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp", allowableValues = "1,2,3,4,5,6", defaultValue = "1", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Authorization", value = "Users Auth Token. Supports both WCS or IAM token. The clients need to pass in appropriate value and relevant cookies depending on which authentication they are using", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Cookie", value = "THD_USER Cookie. The client need to pass appropriate THD_USER cookie value in 'THD_USER=Cookie Value' format",  defaultValue = "THD_USER=eyJzdm9jQ3VzdG9tZXJBY2NvdW50SWQiOiIwM0Y4NDg1R", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "custAccountId", value = "Customers account id. Supports both SVOC Id and WCS member id", defaultValue = "03D7788C5E9BB8D00S", required = true, dataType = "string", paramType = "path"), })
    @ApiResponses(value = { 
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 401, message = "User Un-Authorized"),
            @ApiResponse(code = 500, message = "Internal Server Error") })
    @RequestMapping(method = RequestMethod.PUT, consumes = { MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
    public ProfileResponse updateProfile(@PathVariable(value = "custAccountId") String customerAccountId,
            @RequestBody Account account) throws CustomerAccountServiceException {
        log.debug("updateProfile(), customerAccountId: {}", customerAccountId);
        if(account.getIsReqServedFromWCS() && StringUtils.isEmpty(account.getProfile().getTradeType())){
            reqContext.setWCSRequest(true);
        }

        Account accountResp = profileService.updateProfile(customerAccountId, new ProfileRequest(account));
        return profileResponseBuilder.buildResponse(accountResp, null, null);
    }



    @ApiOperation(value = "Update user name(email id) and/or password of a registered customer", nickname = "updateIdentity")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp", allowableValues = "1,2,3,4,5,6", defaultValue = "1", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Authorization", value = "Users Auth Token. Supports both WCS or IAM token. The clients need to pass in appropriate value and relevant cookies depending on which authentication they are using", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Cookie", value = "THD_USER Cookie. The client need to pass appropriate THD_USER cookie value in 'THD_USER=Cookie Value' format",  defaultValue = "THD_USER=eyJzdm9jQ3VzdG9tZXJBY2NvdW50SWQiOiIwM0Y4NDg1R", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "custAccountId", value = "Customers account id. Supports both SVOC Id and WCS member id", defaultValue = "03D7788C5E9BB8D00S", required = true, dataType = "string", paramType = "path") })
    @ApiResponses(value = { 
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 401, message = "User Un-Authorized"),
            @ApiResponse(code = 500, message = "Internal Server Error") })
    @RequestMapping(value = "/identity", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public IdentityResponse updateIdentity(@RequestBody IdentityRequest updateIdenityRequest,
            @PathVariable(value = "custAccountId") String customerAccountId) throws CustomerAccountServiceException {
        Identity identity = identityService.updateIdentity(updateIdenityRequest, customerAccountId);
        return new IdentityResponse(identity);
    }
}
