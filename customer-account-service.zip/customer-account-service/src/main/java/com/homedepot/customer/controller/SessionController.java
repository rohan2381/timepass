package com.homedepot.customer.controller;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.model.Identity;
import com.homedepot.customer.model.LogoutInfo;
import com.homedepot.customer.response.builder.impl.LogoutResponseBuilderImpl;
import com.homedepot.customer.service.IIdentityService;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.util.SessionHelper;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;

/**
 * Created by rxb1809 on Apr 27, 2016 Controller for session management
 * operations.
 */
@Api(tags = { "Customer Session" }, description = "Session Management")
@RestController
@CrossOrigin
@RequestMapping("/session")
@Slf4j
public class SessionController {

    @Autowired
    IIdentityService identityService;

    @Autowired
    LogoutResponseBuilderImpl responseBuilder;

    @Autowired
    SessionHelper sessionHelper;

    @ApiOperation(value = "logout registered customer from session", nickname = "logout")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp", allowableValues = "1,2,3,4,5,6", defaultValue = "1", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Authorization", value = "IAM Auth Token. The clients need to pass in appropriate value and relevant WCS cookies", required = true, dataType = "string", paramType = "header"),
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(value="/logout", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean logoutSession(@RequestHeader(value = GlobalConstants.THD_AUTH_TOKEN, required = false) String thdAuthToken, HttpServletResponse response) throws CustomerAccountServiceException {

        LogoutInfo logoutInfo = identityService.logOutUser();
        responseBuilder.buildResponse(logoutInfo.getIamLogoutInfo(), logoutInfo.getWcsLogoutInfo(), response);
        return true;
    }

    @ApiOperation(value = "validate a user session (Supports both IAM and WCS token validation", nickname = "validate")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp", allowableValues = "1,2,3,4,5,6", defaultValue = "1", required = true, dataType = "string", paramType = "header"),            
            @ApiImplicitParam(name = "Authorization", value = "Users Auth Token. Supports both WCS or IAM token. The clients need to pass in appropriate value and relevant cookies depending on which authentication they are using", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "Cookie", value = "THD_USER Cookie. The client need to pass appropriate THD_USER cookie value in 'THD_USER=Cookie Value' format",  defaultValue = "THD_USER=eyJzdm9jQ3VzdG9tZXJBY2NvdW50SWQiOiIwM0Y4NDg1R", required = true, dataType = "string", paramType = "header"),
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 401, message = "User Un-Authorized"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(value = "/validate", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Identity validateSession(@RequestHeader(value=GlobalConstants.THD_AUTH_TOKEN) String thdAuthToken) 
                                                    throws CustomerAccountServiceException {

        return identityService.validateUserSession();
    }

}
