package com.homedepot.customer.controller.guest;

import com.homedepot.customer.exception.AuthenticationException;
import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.model.Identity;
import com.homedepot.customer.model.AuthEntity;
import com.homedepot.customer.response.builder.impl.LogoutResponseBuilderImpl;
import com.homedepot.customer.service.IIdentityService;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.util.SessionHelper;
import com.homedepot.customer.request.ClientAuthRequest;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

import java.util.Enumeration;

/**
 * Created by txp1012 on June 12, 2017 Controller for identity management
 * operations.
 */
@Api(tags = {"Customer Identity Handshake"}, description = "Identity Management")
@RestController
@CrossOrigin
@RequestMapping("/auth")
@Slf4j
public class AuthController {

    @Autowired
    IIdentityService identityService;

    @Autowired
    LogoutResponseBuilderImpl responseBuilder;

    @Autowired
    SessionHelper sessionHelper;

    @ApiOperation(value = "validate a user auth token (HMAC Token Validator", nickname = "validateAuth")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "clientId", value = "Client Id", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "timestamp", value = "Client supplied timestamp. The clients need to pass in appropriate value to generate the auth token on both client and server side to do a proper handshake", required = true, dataType = "string", paramType = "header"),
            @ApiImplicitParam(name = "clientToken", value = "HMAC Token. The client need to pass appropriate HMAC token generated at their end in 'REQUEST_LEVEL_AUTH' header", required = true, dataType = "string", paramType = "header"),
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 401, message = "User Un-Authorized"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(value = "/validatetoken", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public AuthEntity validateAuthToken(@RequestHeader(value = GlobalConstants.CLIENT_AUTH_TOKEN, required = true ) String clientAuthToken,
                                      @RequestHeader(value = "timestamp", required = true) String timestamp,
                                      @RequestHeader(value = "clientId", required = false) String clientId,
                                      @RequestHeader(value = "clientDelay", required = false) String clientDelayForTokenValidation
                                      )
            throws AuthenticationException, CustomerAccountServiceException {

        ClientAuthRequest clientAuthRequest = new ClientAuthRequest();
        clientAuthRequest.setClientAuthToken(clientAuthToken);
        clientAuthRequest.setTimestamp(timestamp);
        clientAuthRequest.setClientId(clientId);
        clientAuthRequest.setClientDelayForTokenValidation(clientDelayForTokenValidation);

        return identityService.validateClientAuth(clientAuthRequest);
    }

    @ApiOperation(value = "get a user auth token (Supports HMAC token generation", nickname = "auth")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "timestamp", value = "Client supplied timestamp. The clients need to pass in appropriate value to generate the auth token on both client and server side to do a proper handshake", required = true, dataType = "string", paramType = "header"),
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(value = "/getauthtoken", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public AuthEntity getClientToken(@RequestHeader(value = GlobalConstants.CLIENT_SUPPLIED_TIMESTAMP) String timestamp,
                                     @RequestHeader(value = "clientId", required = true) String clientId,
                                     HttpServletRequest request)
            throws CustomerAccountServiceException {

        log.debug("Entering getAuthToken " + timestamp);

        ClientAuthRequest clientAuthRequest = new ClientAuthRequest();
        clientAuthRequest.setTimestamp(timestamp);
        clientAuthRequest.setClientId(clientId);

        return identityService.getClientToken(clientAuthRequest);
    }
}