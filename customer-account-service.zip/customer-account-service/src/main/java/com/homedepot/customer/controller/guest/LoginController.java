package com.homedepot.customer.controller.guest;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.model.UserIdentity;
import com.homedepot.customer.request.IdentityRequest;
import com.homedepot.customer.response.IdentityResponse;
import com.homedepot.customer.response.builder.impl.LoginResponseBuilderImpl;
import com.homedepot.customer.service.IIdentityService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;

/**
 * Created by sxp2991 on Aug 1, 2016
 *
 */
@Api(tags={"User Login"},description="Login")
@CrossOrigin
@RestController
@Slf4j
public class LoginController {

    @Autowired
    IIdentityService identityService;

    @Autowired
    LoginResponseBuilderImpl responseBuilder;

    /**
     * User login
     * @param authRequest
     * @return
     */
    @ApiOperation(value = "Registered User Login",
                notes = "This endpoint will call both IAM and WCS till we completely retire WCS. "
                        + "If both calls succeed, response will have both svoc customer id and wcs member id. "
                        + "For IAM token please refer THD_USER_SESSION cookie. For WCS token please refer C45 crumb in the THD_PERSIST cookie. "
                        + "You can find the svoc customer account id in the THD_USER cookie. It is Base64 encoded and persitent in nature. "
                        + "If either of the calls fail, it will provide a success response with appropriate details(e.g. SVOC id and/or WCS member id) on the call which was successful. "
                        + "If both calls fail, it will provide an error response.")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "channelId",
                            value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp",
                            allowableValues = "1,2,3,4,5,6",
                            defaultValue = "1",
                            required = true,
                            dataType = "string",
                            paramType = "header")
    })
    @RequestMapping(value = "/login",
                    method = RequestMethod.POST,
                    consumes = MediaType.APPLICATION_JSON_VALUE,
                    produces = MediaType.APPLICATION_JSON_VALUE)
    public IdentityResponse logIn(@RequestBody IdentityRequest authRequest, HttpServletResponse response)
                                    throws CustomerAccountServiceException {
        log.debug("Auth request: {}", authRequest);
        UserIdentity userIdentity = identityService.authenticateUser(authRequest);
        return responseBuilder.buildResponse(userIdentity, userIdentity.getWcsUserIdentity(), response);
    }
    
    
    /**
     * This is a newer login API which will perform the HMAC validations. Goal is to retire the above login API once all 
     * clients start consuming the newer one
     * @param authRequest
     * @return
     */
    @ApiOperation(value = "Registered User Login",
                notes = "This endpoint will call both IAM and WCS till we completely retire WCS. "
                        + "If both calls succeed, response will have both svoc customer id and wcs member id. "
                        + "For IAM token please refer THD_USER_SESSION cookie. For WCS token please refer C45 crumb in the THD_PERSIST cookie. "
                        + "You can find the svoc customer account id in the THD_USER cookie. It is Base64 encoded and persitent in nature. "
                        + "If either of the calls fail, it will provide a success response with appropriate details(e.g. SVOC id and/or WCS member id) on the call which was successful. "
                        + "If both calls fail, it will provide an error response.")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "channelId",
                            value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp",
                            allowableValues = "1,2,3,4,5,6",
                            defaultValue = "1",
                            required = true,
                            dataType = "string",
                            paramType = "header")
    })
    @RequestMapping(value = "/signIn",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public IdentityResponse signIn(@RequestBody IdentityRequest authRequest, HttpServletResponse response)
                                throws CustomerAccountServiceException {
        log.debug("Secured Auth request: {}", authRequest);
        UserIdentity userIdentity = identityService.authenticateUser(authRequest);
        return responseBuilder.buildResponse(userIdentity, userIdentity.getWcsUserIdentity(), response);
    }

}