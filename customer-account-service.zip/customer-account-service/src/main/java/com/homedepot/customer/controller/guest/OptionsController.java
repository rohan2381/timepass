package com.homedepot.customer.controller.guest;

import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;
import springfox.documentation.annotations.ApiIgnore;

/**
 * Created by rxb1809 on Mar 1, 2017
 *
 */
@RestController
@ApiIgnore
@Slf4j
public class OptionsController {
    
    /**
     *  This is sample method and its sole purpose is to send back 200 response for the pre-flight CORS request 
     *  The browser first executes an OPTIONS request with the same URL as the target request to check that it has the rights 
     *  to execute the request. This OPTIONS request returns headers that identify what is possible to do for the URL. 
     *  If rights match, the browser executes the request.
     */
    @CrossOrigin
    @RequestMapping(value = {"/checkEmailExists","/login","/register","/session/logout","/zipCode/{zipCode}","/{custAccountId}/preferences"}, method = RequestMethod.OPTIONS)
    public ResponseEntity<Boolean> handle(HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Headers", "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers, channelId");
        return new ResponseEntity<Boolean>(HttpStatus.OK);
    }

    /**
     *  This is new method and its sole purpose is to send back 200 response for the pre-flight CORS request
     *  The browser first executes an OPTIONS request with the same URL as the target request to check that it has the rights
     *  to execute the request. This OPTIONS request returns headers that identify what is possible to do for the URL.
     *  If rights match, the browser executes the request.
     *  Once all clients migrate to this new api, we will retire the checkEmailExists method
     */
    @CrossOrigin
    @RequestMapping(value = {"/checkCustomerExists","/signIn","/signUp"}, method = RequestMethod.OPTIONS)
    public ResponseEntity<Boolean> preHandle(HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Headers", "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers, channelId");
        return new ResponseEntity<Boolean>(HttpStatus.OK);
    }
}
