package com.homedepot.customer.controller.guest;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.request.PasswordRequest;
import com.homedepot.customer.service.IPasswordService;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

/**
 * Created by rxb1809 on Aug 9, 2016 Controller for password management
 */
@Api(tags = { "User Password" }, description = "Password Management")
@CrossOrigin
@RestController
@Slf4j
public class PasswordController {

    @Autowired
    IPasswordService passwordService;

    /**
     * User Password Reset
     * @param email
     * @return
     */
    @ApiOperation(value = "generate reset password email notification of registered customer", nickname = "resetPasswordEmail")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "email", value = "Customers email address", required = true, dataType = "string", paramType = "query"),
            @ApiImplicitParam(name = "channelId",
                    value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp",
                    allowableValues = "1,2,3,4,5,6",
                    defaultValue = "1",
                    required = true,
                    dataType = "string",
                    paramType = "header")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(value = "/resetPasswordEmail", method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean resetPasswordEmail(@RequestParam(value="email") String email) throws CustomerAccountServiceException {
        log.debug("Reset Pwd Email: {}", email);
        PasswordRequest resetPwdEmailRequest = new PasswordRequest();
        resetPwdEmailRequest.setEmail(email);
        passwordService.resetUserPasswordEmail(resetPwdEmailRequest);
        return true;
    }

    /**
     * User Password Reset
     * @param resetPwdRequest
     * @return
     */
    @ApiOperation(value = "reset password of registered customer", nickname = "resetPassword",
            notes = "Values required in request body: svocId, password, confirmPassword, token")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId",
                    value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp",
                    allowableValues = "1,2,3,4,5,6",
                    defaultValue = "1",
                    required = true,
                    dataType = "string",
                    paramType = "header")
    })
    @RequestMapping(value = "/resetPassword", method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean resetPassword(@RequestBody PasswordRequest resetPwdRequest) throws CustomerAccountServiceException {
        log.debug("Reset Pwd Request: {}", resetPwdRequest);
        passwordService.resetUserPassword(resetPwdRequest);
        return true;
    }

    /**
     * Set Password email
     * @param email
     * @return
     */
    @ApiOperation(value = "send password set email", nickname = "setPasswordEmail")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId",
                    value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp",
                    allowableValues = "1,2,3,4,5,6",
                    defaultValue = "1",
                    required = true,
                    dataType = "string",
                    paramType = "header")
    })
    @RequestMapping(value = "/setPasswordEmail", method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean setPasswordEmail(@RequestParam(value="email") String email)
            throws CustomerAccountServiceException {
        log.debug("Set Pwd Email: {}", email);
        PasswordRequest setPwdEmailRequest = new PasswordRequest();
        setPwdEmailRequest.setEmail(email);
        passwordService.setPasswordEmail(setPwdEmailRequest);
        return true;
    }

    /**
     * Set Password
     * @param setPasswordRequest
     * @return
     */
    @ApiOperation(value = "set password of registered customer", nickname = "setPassword",
            notes = "Values required in request body: svocId, password, confirmPassword")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 409, message = "Conflict"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId",
                    value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp",
                    allowableValues = "1,2,3,4,5,6",
                    defaultValue = "1",
                    required = true,
                    dataType = "string",
                    paramType = "header")
    })
    @RequestMapping(value = "/setPassword", method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean setPassword(@RequestBody PasswordRequest setPasswordRequest)
            throws CustomerAccountServiceException {
        log.debug("Set Pwd Request: {}", setPasswordRequest);
        passwordService.setPassword(setPasswordRequest);
        return true;
    }
}
