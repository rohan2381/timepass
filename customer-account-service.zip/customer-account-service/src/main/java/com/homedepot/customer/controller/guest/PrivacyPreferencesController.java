package com.homedepot.customer.controller.guest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.SwaggerDefinition;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.model.pvcypreferences.PrivacyPrefRequest;
import com.homedepot.customer.service.IPreferencesService;

/**
 * Created by sxp8711 on 06/07/2017.
 * Controller for Customer's Privacy Preferences
 */
@SwaggerDefinition
@Api(tags={"Customer Privacy Preferences"}, description="Update Customer's Privacy Preferences")
@RestController
@CrossOrigin
@RequestMapping("/preferences/privacy")
@Slf4j
public class PrivacyPreferencesController {
    
    @Autowired
    IPreferencesService preferencesService;
    
    @ApiOperation(value = "updates customer's Privacy Preferences", nickname = "updatePrivacyPreferences")
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public boolean updatePreferences(@RequestBody PrivacyPrefRequest request) 
                                                    throws CustomerAccountServiceException {
                                                       
        log.debug("In PrivacyPreferencesController: [{}]", request.toString());
        
        return preferencesService.updatePrivacyPreferences(request);
    }

}
