package com.homedepot.customer.controller.guest;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.model.Account;
import com.homedepot.customer.model.UserIdentity;
import com.homedepot.customer.request.UserRegistrationRequest;
import com.homedepot.customer.response.ProfileResponse;
import com.homedepot.customer.response.builder.impl.RegistrationResponseBuilderImpl;
import com.homedepot.customer.service.IRegistrationService;
import com.homedepot.customer.util.GlobalConstants;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Apr 27, 2016
 *
 */
@Api(tags={"User Registration"}, description="User Registration")
@CrossOrigin
@RestController
@Slf4j
public class RegistrationController {

    @Autowired
    IRegistrationService registrationService;

    @Autowired
    RegistrationResponseBuilderImpl responseBuilder;

    @ApiOperation(value = "Registers a user in homedepot.com", nickname = "registerAccount",
            notes="This endpoint registers user in all 3 systems (SVOC, IAM and WCS) till we completely retire WCS. "
                        + "If all 3 calls succeed, response will have both svoc customer id and wcs member id. "
                        + "For IAM token please refer THD_USER_SESSION cookie. For WCS token please refer C45 crumb in the THD_PERSIST cookie. "
                        + "You can find the svoc customer account id in the THD_USER cookie. It is Base64 encoded and persitent in nature. "
                        + "If only either of IAM or WCS is successful, it will provide a success response with appropriate details(e.g. SVOC id and/or WCS member id) on the call which was successful. "
                        + "If the user gets created in SVOC but not in IAM, we will still give success. The user can use the set password flow to set the password in IAM at a later stage. "
                        + "If all 3 calls fail, then the user will get an error response. ")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp",
                                allowableValues = "1,2,3,4,5,6", defaultValue = "1",
                                required = true, dataType = "string", paramType = "header")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(value="/register", method=RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ProfileResponse registerAccount(@RequestBody UserRegistrationRequest registerRequest, HttpServletResponse response) throws CustomerAccountServiceException {

        log.info("Registration info --> {}", registerRequest);
        Map<String, Object> registerRespMap = registrationService.registerUser(registerRequest);

        return responseBuilder.buildResponse((Account) registerRespMap.get(GlobalConstants.ACCOUNT),
                (UserIdentity) registerRespMap.get(GlobalConstants.IDENTITY), response);
    }
    
    /**
     * This is a newer register API which will perform the HMAC validations. Goal is to retire the above register API once all 
     * clients start consuming the newer one
     * @param registerRequest
     * @param response
     * @return
     * @throws CustomerAccountServiceException
     */
    @ApiOperation(value = "Registers a user in homedepot.com", nickname = "registerAccount",
            notes="This endpoint registers user in all 3 systems (SVOC, IAM and WCS) till we completely retire WCS. "
                        + "If all 3 calls succeed, response will have both svoc customer id and wcs member id. "
                        + "For IAM token please refer THD_USER_SESSION cookie. For WCS token please refer C45 crumb in the THD_PERSIST cookie. "
                        + "You can find the svoc customer account id in the THD_USER cookie. It is Base64 encoded and persitent in nature. "
                        + "If only either of IAM or WCS is successful, it will provide a success response with appropriate details(e.g. SVOC id and/or WCS member id) on the call which was successful. "
                        + "If the user gets created in SVOC but not in IAM, we will still give success. The user can use the set password flow to set the password in IAM at a later stage. "
                        + "If all 3 calls fail, then the user will get an error response. ")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp",
                                allowableValues = "1,2,3,4,5,6", defaultValue = "1",
                                required = true, dataType = "string", paramType = "header")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(value="/signUp", method=RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ProfileResponse signUp(@RequestBody UserRegistrationRequest registerRequest, HttpServletResponse response) throws CustomerAccountServiceException {

        log.info("Secured Registration info --> {}", registerRequest);
        Map<String, Object> registerRespMap = registrationService.registerUser(registerRequest);

        return responseBuilder.buildResponse((Account) registerRespMap.get(GlobalConstants.ACCOUNT),
                (UserIdentity) registerRespMap.get(GlobalConstants.IDENTITY), response);
    }

    @ApiOperation(value = "Verify email already exists", nickname = "emailAlreadyExists")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp", allowableValues = "1,2,3,4,5,6", defaultValue = "1", required = true, dataType = "string", paramType = "header")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(value="/checkEmailExists",method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Boolean emailAlreadyExists(@RequestParam(value="emailId")String emailId) throws
            CustomerAccountServiceException {
        return registrationService.emailAlreadyExists(emailId);
    }

    @ApiOperation(value = "Verify customer email already exists", nickname = "checkCustomerExists")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "channelId", value = "Channel Id, 1:Desktop, 2:Mobile, 3:Tablet, 4:ProX, 5:ConsumerApp, 6:ProApp", allowableValues = "1,2,3,4,5,6", defaultValue = "1", required = true, dataType = "string", paramType = "header")
    })
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Invalid Request"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @RequestMapping(value="/checkCustomerExists",method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public Boolean customerAlreadyExists(@RequestParam(value="emailId")String emailId) throws
            CustomerAccountServiceException {
            return registrationService.emailAlreadyExists(emailId);
    }
}
