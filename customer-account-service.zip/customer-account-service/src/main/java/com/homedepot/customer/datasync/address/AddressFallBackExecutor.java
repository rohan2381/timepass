package com.homedepot.customer.datasync.address;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.LamdaExceptionWrapper;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.integration.wcs.WCSAddressServiceFacade;
import com.homedepot.customer.integration.wcs.WCSCrossRefServiceFacade;
import com.homedepot.customer.integration.wcs.dto.crossref.CrossRefInfo;
import com.homedepot.customer.model.Address;
import com.homedepot.customer.util.CrossReferenceHelper;
import com.homedepot.customer.util.SessionHelper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Created by rxb1809 on Nov 30, 2016
 * This class has methods to call WCS address operations in a synchronous manner using the registered users session
 */
@Service
@Slf4j
public class AddressFallBackExecutor {
    
    @Autowired
    WCSAddressServiceFacade wcsAddressFacade;
    
    @Autowired
    CustomerAccountRequestContext reqContext;
    
    @Autowired
    WCSCrossRefServiceFacade wcsCrossRefServiceFacade;
    
    @Autowired
    SessionHelper sessionHelper;
    
    @Autowired
    AddressHelper addressHelper;
    
    @Autowired
    CrossReferenceHelper crossRefHelper;
    @SuppressWarnings("squid:MethodCyclomaticComplexity")
    public List<Address> getCustomerAddressFromWCS(String reqSvocAddressId) throws IntegrationException{
        List<Address> respSvocAddresses = new ArrayList<Address>();
        try {
            // Step 1: Extract the wcsUserToken
            String wcsUserToken = sessionHelper.extractWCSTokenFromCookie(reqContext.getRequest().getCookies());
            
            // Step 2: If the request does not have relevant WCS ids then call cross Ref and initialize 
            String reqWcsAddressId = null;
            CrossRefInfo crossRefInfo = null; 
            if(reqSvocAddressId!=null && !reqContext.isWCSRequest()){ 
                // Check in the request context first if available
                crossRefInfo = reqContext.getCrossRefInfo(); 
                if(crossRefInfo==null){
                    crossRefInfo = wcsCrossRefServiceFacade.getCrossRefInfoForSVOCCustAcctId(reqContext.getSvocCustomerAccountId());
                }
                
                reqWcsAddressId = crossRefHelper.getMappedWCSAddressId(reqSvocAddressId, crossRefInfo);                
            }else{
                reqWcsAddressId = reqSvocAddressId;
            }
               
            // Step 3: Retrieve customer address from WCS
            List<Address> wcsRespAddresses = wcsAddressFacade.getCustomerAddressWCSFallBack(reqWcsAddressId, wcsUserToken);
            
            // Step 4: Map WCS request models to SVOC request models 
            if( wcsRespAddresses != null) {
                wcsRespAddresses.forEach(wcsRespAddress -> {
                    Address svocRespAddress = new Address();
                    addressHelper.mapWCSToSvocModel(wcsRespAddress, svocRespAddress);
                    respSvocAddresses.add(svocRespAddress);
                });

                // Step 5: Sort the results
                respSvocAddresses.sort(new Comparator<Address>() {
                    @Override
                    public int compare(Address addr1, Address addr2) {
                        if (addr1.getIsDefault()) {
                            return -1;
                        } else if (addr2.getIsDefault()) {
                            return 1;
                        } else {
                            return addr2.getLastModifiedDate().compareTo(addr1.getLastModifiedDate());
                        }
                    }
                });
            }
            
        } catch (UnsupportedEncodingException uEx) {
            addressHelper.throwGenericIntegrationException(uEx);
        }
        
        return respSvocAddresses;
    }

    public List<Address> createCustomerAddressInWCS(List<Address> reqSvocAddresses) throws IntegrationException{
        List<Address> svocRespAddresses = new ArrayList<Address>();
        try {
            // Step 1: Extract the wcsUserToken
            String wcsUserToken = sessionHelper.extractWCSTokenFromCookie(reqContext.getRequest().getCookies());
            
            // Step 2: Map SVOC request models to WCS request models
            List<Address> reqWcsAddresses = new ArrayList<>();
            reqSvocAddresses.forEach(reqSvocAddress -> {
                Address reqWcsAddress = new Address();
                addressHelper.mapSvocToWCSModel(reqSvocAddress, reqWcsAddress);
                reqWcsAddresses.add(reqWcsAddress);
            });
            
            // Step 3: Create customer address in WCS (the response objects just have address id)
            List<Address> wcsRespAddresses = wcsAddressFacade.createCustomerAddressWCSFallBack(reqWcsAddresses, wcsUserToken);
            
            // Step 4: Retrieve full address from WCS for the newly created ones above
            List<Address> wcsFullRespAddresses = new ArrayList<>();
            wcsRespAddresses.forEach(wcsRespAddress -> {
                try {
                    wcsFullRespAddresses.addAll(wcsAddressFacade.getCustomerAddressWCSFallBack(
                                        String.valueOf(wcsRespAddress.getAddrIdentifier()),wcsUserToken));
                } catch (IntegrationException iEx) {
                    throw new LamdaExceptionWrapper(iEx);
                }
            });
            
            // Step 5: Map WCS request models to SVOC request models 
            wcsFullRespAddresses.forEach(wcsFullRespAddress -> {
                Address svocRespAddress = new Address();
                addressHelper.mapWCSToSvocModel(wcsFullRespAddress, svocRespAddress);
                svocRespAddresses.add(svocRespAddress);
            });
        } catch (UnsupportedEncodingException uEx) {
            addressHelper.throwGenericIntegrationException(uEx);
        }catch (LamdaExceptionWrapper lEx) {// NOSONAR
            if (lEx.getCause() instanceof IntegrationException) {
                throw (IntegrationException) lEx.getCause();
            }
        }
        
        return svocRespAddresses;       
    }
    
    public List<Address> updateCustomerAddressInWCS(List<Address> reqSvocAddresses) throws IntegrationException{
        List<Address> respSvocAddresses = new ArrayList<Address>();
        try {
            // Step 1: Extract the wcsUserToken
            String wcsUserToken = sessionHelper.extractWCSTokenFromCookie(reqContext.getRequest().getCookies());
            
            // Step 2: If the request does not have relevant WCS ids then call cross Ref and initialize 
            CrossRefInfo crossRefInfo = null;
            if(!reqContext.isWCSRequest()){ 
                // Check in the request context first if available
                crossRefInfo = reqContext.getCrossRefInfo(); 
                if(crossRefInfo==null){
                    crossRefInfo = wcsCrossRefServiceFacade.getCrossRefInfoForSVOCCustAcctId(reqContext.getSvocCustomerAccountId());
                }
            }
            
            // Step 3: Map SVOC request models to WCS request models
            List<Address> reqWcsAddresses = new ArrayList<>();
            final CrossRefInfo crossRefInfoFinal = crossRefInfo; // To work around java 8 mandate of using only final variables inside lambda expressions
            reqSvocAddresses.forEach(reqSvocAddress -> {
                Address reqWcsAddress = new Address();
                addressHelper.mapSvocToWCSModel(reqSvocAddress, reqWcsAddress);
                // Map the ids if required based on the cross Ref initialized earlier
                if(!reqContext.isWCSRequest()){ 
                    reqWcsAddress.setAddrIdentifier(
                            Integer.valueOf(
                                    crossRefHelper.getMappedWCSAddressId(String.valueOf(reqSvocAddress.getAddrIdentifier()), crossRefInfoFinal)));
                }
                    reqWcsAddresses.add(reqWcsAddress);
            });
            
            // Step 4: Update customer address in WCS
            List<Address> wcsUpdRespAddresses = wcsAddressFacade.updateCustomerAddressWCSFallBack(reqWcsAddresses, wcsUserToken);
            
            // Step 5: Retrieve the full updated addresses
            List<Address> wcsRespAddresses = new ArrayList<>();
            wcsUpdRespAddresses.forEach(wcsUpdAddress -> {
                try {
                    wcsRespAddresses.addAll(wcsAddressFacade.getCustomerAddressWCSFallBack
                            (String.valueOf(wcsUpdAddress.getAddrIdentifier()), wcsUserToken));
                } catch (IntegrationException iEx) {
                    throw new LamdaExceptionWrapper(iEx);
                }
            });
            
            // Step 6: Map WCS request models to SVOC request models 
            wcsRespAddresses.forEach(wcsRespAddress -> {
                Address svocRespAddress = new Address();
                addressHelper.mapWCSToSvocModel(wcsRespAddress, svocRespAddress);
                respSvocAddresses.add(svocRespAddress);
            });
        } catch (UnsupportedEncodingException uEx) {
            addressHelper.throwGenericIntegrationException(uEx);
        } catch (LamdaExceptionWrapper lEx) {// NOSONAR
            if (lEx.getCause() instanceof IntegrationException) {
                throw (IntegrationException) lEx.getCause();               
            }
        }
        
        return respSvocAddresses;      
    }
    
    
    public boolean deleteCustomerAddressInWCS(String reqSvocAddressId) throws IntegrationException{
        boolean success = false;
        try {
            // Step 1: Extract the wcsUserToken
            String wcsUserToken = sessionHelper.extractWCSTokenFromCookie(reqContext.getRequest().getCookies());
            
            // Step 2: If the request does not have relevant WCS ids then call cross Ref and initialize 
            CrossRefInfo crossRefInfo = null;
            String reqWcsAddressId = null;
            if(!reqContext.isWCSRequest()){ 
                // Check in the request context first if available
                crossRefInfo = reqContext.getCrossRefInfo(); 
                if(crossRefInfo==null){
                    crossRefInfo = wcsCrossRefServiceFacade.getCrossRefInfoForSVOCCustAcctId(reqContext.getSvocCustomerAccountId());
                }
                
                reqWcsAddressId = crossRefHelper.getMappedWCSAddressId(reqSvocAddressId, crossRefInfo);
            }else{
                reqWcsAddressId = reqSvocAddressId;
            }
            
            // Step 4: Delete customer address in WCS
            success = wcsAddressFacade.deleteCustomerAddressWCSFallBack(reqWcsAddressId, wcsUserToken);
            
        } catch (UnsupportedEncodingException uEx) {
            addressHelper.throwGenericIntegrationException(uEx);
        }
        
        return success;       
    }
    
}
