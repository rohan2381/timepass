package com.homedepot.customer.datasync.address;

import java.util.Arrays;

import org.apache.commons.lang3.text.WordUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.model.Address;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;
import com.homedepot.customer.model.Name;
import com.homedepot.customer.model.Phone;
import com.homedepot.customer.model.PostalDetails;

/**
 * Created by rxb1809 on Oct 19, 2016
 *
 */
@Component
public class AddressHelper {

    public void mapSvocToWCSModel(Address svocAddress, Address wcsAddress){
        wcsAddress.setAddrIdentifier(svocAddress.getAddrIdentifier());
        wcsAddress.setIsDefault(svocAddress.getIsDefault());
        wcsAddress.setNickName(svocAddress.getNickName());
               
        if(svocAddress.getName()!=null){
            Name name = new Name();
            wcsAddress.setName(name);
            name.setFirstName(WordUtils.capitalizeFully(svocAddress.getName().getFirstName()));
            name.setLastName(WordUtils.capitalizeFully(svocAddress.getName().getLastName()));
        }
        
        wcsAddress.setEmailId(svocAddress.getEmailId());
       
        if(svocAddress.getPostalDetails()!=null){
            PostalDetails postalDetails = new PostalDetails();
            wcsAddress.setPostalDetails(postalDetails);
            BeanUtils.copyProperties(svocAddress.getPostalDetails(), wcsAddress.getPostalDetails(), new String[]{"addressLine1","addressLine2"});
            wcsAddress.getPostalDetails().setAddressLine1(WordUtils.capitalizeFully(svocAddress.getPostalDetails().getAddressLine1()));
            wcsAddress.getPostalDetails().setAddressLine2(WordUtils.capitalizeFully(svocAddress.getPostalDetails().getAddressLine2()));
        }       
        
        Phone primaryPhone = new Phone();
        primaryPhone.setNumber(svocAddress.getPrimaryPhone()!=null?svocAddress.getPrimaryPhone().getNumber():null);
        wcsAddress.setPrimaryPhone(primaryPhone);

        if (svocAddress.getAlternatePhone() != null) {
            // only create the secondary phone object when there is alternate phone in the original svocAddress
            // otherwise wcs will complain about empty secondary phone object
            Phone secondaryPhone = new Phone();
            secondaryPhone.setNumber(svocAddress.getAlternatePhone() != null ? svocAddress.getAlternatePhone().getNumber() : null);
            wcsAddress.setAlternatePhone(secondaryPhone);
        }
    }
    
    public void mapWCSToSvocModel(Address wcsAddress, Address svocAddress){       
        svocAddress.setAddrIdentifier(wcsAddress.getAddrIdentifier());
        svocAddress.setIsDefault(wcsAddress.getIsDefault());
        svocAddress.setLastModifiedDate(wcsAddress.getLastModifiedDate());
        
        Name name = new Name();
        svocAddress.setName(name);
        BeanUtils.copyProperties(wcsAddress.getName(), svocAddress.getName());                   
        svocAddress.setEmailId(wcsAddress.getEmailId());
        
        PostalDetails postalDetails = new PostalDetails();
        svocAddress.setPostalDetails(postalDetails);
        BeanUtils.copyProperties(wcsAddress.getPostalDetails(), svocAddress.getPostalDetails());
        
        Phone primaryPhone = new Phone();
        primaryPhone.setNumber(wcsAddress.getPrimaryPhone()!=null?wcsAddress.getPrimaryPhone().getNumber():null);
        svocAddress.setPrimaryPhone(primaryPhone);
        
        if (wcsAddress.getAlternatePhone() != null) {
            Phone secondaryPhone = new Phone();
            secondaryPhone.setNumber(wcsAddress.getAlternatePhone() != null ? wcsAddress.getAlternatePhone().getNumber() : null);
            svocAddress.setAlternatePhone(secondaryPhone);
        }
    }
    
    public void throwGenericIntegrationException(Exception uEx) throws IntegrationException{
        Errors errors = new Errors();
        Error error = new Error();
        errors.setErrors(Arrays.asList(error));
        error.setErrorCode(ErrorCode.SYSTEM_ERROR);
        throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, uEx);
    }
    
}
