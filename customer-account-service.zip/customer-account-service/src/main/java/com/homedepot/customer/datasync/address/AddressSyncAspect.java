package com.homedepot.customer.datasync.address;

import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.homedepot.customer.datasync.util.DataSyncUtil;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.model.Address;
import com.homedepot.customer.request.AddressRequest;

/**
 * Created by rxb1809 on Aug 30, 2016
 * This class controls and triggers the WCS sync up of all CUD operations on the address component.  
 * It uses Spring AOP for execution
 */
//@Aspect
@Component
public class AddressSyncAspect {
    
    @Autowired
    AddressSyncExecutor addressExecutor;
    
    @Autowired
    CustomerAccountRequestContext reqContext;
  
    @Autowired
    private DataSyncUtil dataSyncUtil;
    
    /**
     * This method is used to invoke the wcs address creation thread
     * @param jp
     * @param addressRequest
     * @param customerAccountId
     */
    @AfterReturning(pointcut="execution(* com.homedepot.customer.service.IAddressService.createUserAddress(..)) && args(addressRequest,customerAccountId)", 
                        returning="svocSavedAddresses")
    public void createUserAddressInWCS(JoinPoint jp, AddressRequest addressRequest, String customerAccountId, List<Address> svocSavedAddresses){
        if(!reqContext.isReqServedFromWCS()){
            addressExecutor.syncCreateAddress(addressRequest, customerAccountId, svocSavedAddresses);
            dataSyncUtil.pauseAroundDataSync();            
        }       
    }
    
    /**
     * This method is used to invoke the wcs address update thread
     * @param jp
     * @param addressRequest
     * @param customerAccountId
     */
    @AfterReturning(pointcut="execution(* com.homedepot.customer.service.IAddressService.updateUserAddress(..)) && args(addressRequest,customerAccountId)",
            returning="svocSavedAddresses")
    public void updateUserAddressInWCS(JoinPoint jp, AddressRequest addressRequest, String customerAccountId, List<Address> svocSavedAddresses) {
        if(!reqContext.isReqServedFromWCS()){
            addressExecutor.syncUpdateAddress(addressRequest, customerAccountId, svocSavedAddresses);
            dataSyncUtil.pauseAroundDataSync();  
        }      
    }
    
    /**
     * This method is used to invoke the wcs address delete thread
     * @param jp
     * @param addressRequest
     * @param customerAccountId
     */
    @AfterReturning("execution(* com.homedepot.customer.service.IAddressService.deleteUserAddressById(..)) && args(customerAccountId,addressRequest)")
    public void deleteUserAddressInWCS(JoinPoint jp, AddressRequest addressRequest, String customerAccountId){
        if(!reqContext.isReqServedFromWCS()){
            addressExecutor.syncDeleteAddress(customerAccountId, addressRequest);
            dataSyncUtil.pauseAroundDataSync();  
        }        
    }
}
