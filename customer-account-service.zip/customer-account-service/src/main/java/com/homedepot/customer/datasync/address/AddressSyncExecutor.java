package com.homedepot.customer.datasync.address;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.LamdaExceptionWrapper;
import com.homedepot.customer.integration.passport.THDPassportServiceFacade;
import com.homedepot.customer.integration.wcs.WCSAddressServiceFacade;
import com.homedepot.customer.integration.wcs.WCSCrossRefServiceFacade;
import com.homedepot.customer.integration.wcs.dto.crossref.Address;
import com.homedepot.customer.integration.wcs.dto.crossref.Addresses;
import com.homedepot.customer.integration.wcs.dto.crossref.CrossRefInfo;
import com.homedepot.customer.request.AddressRequest;
import com.homedepot.customer.util.GlobalConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

/**
 * Created by rxb1809 on Aug 24, 2016 This class is used to do a near real-time calls to WCS to sync address info in an
 * asynchronous fashion. The data will be synced using CSR user
 */
@Service
@Slf4j
@SuppressWarnings({"squid:S1481","squid:S1188","squid:S1141"})
public class AddressSyncExecutor {

    @Autowired
    private WCSAddressServiceFacade wcsAddressFacade;

    @Autowired
    private THDPassportServiceFacade passportServiceFacade;

    @Autowired
    private WCSCrossRefServiceFacade wcsCrossRefServiceFacade;

    @Autowired
    private AddressHelper addrHelper;
    
    public static final String EXCEPTION_DETAILS = "Exception details --> HTTP_STATUS={}, ERROR_MESSAGE={}, ERROR_CAUSE={}";

    @Async("addressTaskExecutor")
    public void syncCreateAddress(AddressRequest addressRequest, String customerAccountId,
            List<com.homedepot.customer.model.Address> svocSavedAddresses) {
        log.debug("BEGIN: Synching up address creation in WCS for customer {} : Address details {}", customerAccountId,
                addressRequest.toString());

        try {
            // STE2 1 >>> LOOK up WCS member Id
            CrossRefInfo crossRefInfo = wcsCrossRefServiceFacade.getCrossRefInfoForSVOCCustAcctId(customerAccountId);

            if (crossRefInfo != null) {
                // STEP 2 >>> GET Token for the CSR account
                String ssoToken = passportServiceFacade.getToken();

                String wcsMemberId = crossRefInfo.getWcsMemberId();

                CrossRefInfo crossRefInfoUpdateRequest = new CrossRefInfo();
                List<Address> addrCrosRefUpdateList = new ArrayList<>();
                Addresses addresses = new Addresses();
                addresses.setAddress(addrCrosRefUpdateList);
                crossRefInfoUpdateRequest.setAddresses(addresses);

                svocSavedAddresses.forEach(svocAddress -> {
                    com.homedepot.customer.model.Address wcsAddress = new com.homedepot.customer.model.Address();

                    addrHelper.mapSvocToWCSModel(svocAddress, wcsAddress);
                    wcsAddress.setAddrIdentifier(null);

                    // STEP 3 >>> Call WCS MAML CSR API
                    List<com.homedepot.customer.model.Address> addrCrosRefResponseList;
                    try {
                        addrCrosRefResponseList = wcsAddressFacade.createCustomerAddressCSR(wcsMemberId,
                                Arrays.asList(wcsAddress), ssoToken);
                    } catch (IntegrationException iEx) {
                        throw new LamdaExceptionWrapper(iEx);
                    }

                    Address addressCrossRefUpd = new Address(String.valueOf(customerAccountId),
                            String.valueOf(wcsMemberId), String.valueOf(svocAddress.getAddrIdentifier()),
                            String.valueOf(addrCrosRefResponseList.get(0).getAddrIdentifier()),
                            GlobalConstants.APPLICATION_ID, null);

                    crossRefInfoUpdateRequest.getAddresses().getAddress().add(addressCrossRefUpd);

                });

                // STEP 4: >>> UPDATE address Mapping table in DB2                
                CrossRefInfo crossRefInfoUpdateResp = wcsCrossRefServiceFacade
                        .saveCrossRefInfo(crossRefInfoUpdateRequest, ssoToken);

                log.debug("END: Synching up address creation in WCS for customer {} : Address details {}",
                        customerAccountId, addressRequest.toString());
            }

        } catch (LamdaExceptionWrapper lEx) {
            log.error("ERROR: Synching up address creation in WCS for customer {}", customerAccountId,
                    ExceptionUtils.getRootCause(lEx));
        } catch (IntegrationException iEx) {
            log.error("ERROR: Synching up address creation in WCS for customer {} : Address details {}",
                    customerAccountId, addressRequest.toString() + " , Root Cause:" + ExceptionUtils.getRootCause(iEx));
            log.error(EXCEPTION_DETAILS, iEx.getHttpStatus(),
                    iEx.getMessage(), iEx);
        } catch (Exception ex) {
            log.error("ERROR: Synching up address creation in WCS for customer {} : Address details {}",
                    customerAccountId, addressRequest.toString() + " , Root Cause:" + ExceptionUtils.getRootCause(ex));
        }
    }

    @Async("addressTaskExecutor")
    public void syncUpdateAddress(AddressRequest addressRequest, String customerAccountId,
            List<com.homedepot.customer.model.Address> svocSavedAddresses) {
        log.debug("BEGIN: Synching up address updates in WCS for customer {} : Address details {}", customerAccountId,
                addressRequest.toString());
        try {
            // STE2 1 >>> LOOK up WCS member Id
            CrossRefInfo crossRefInfo = wcsCrossRefServiceFacade.getCrossRefInfoForSVOCCustAcctId(customerAccountId);

            if (crossRefInfo != null) {
                // STEP 2 >>> GET Token for the CSR account
                String ssoToken = passportServiceFacade.getToken();

                String wcsMemberId = crossRefInfo.getWcsMemberId();

                CrossRefInfo crossRefInfoUpdateRequest = new CrossRefInfo();
                List<Address> addrCrosRefUpdateList = new ArrayList<>();
                Addresses addresses = new Addresses();
                addresses.setAddress(addrCrosRefUpdateList);
                crossRefInfoUpdateRequest.setAddresses(addresses);

                svocSavedAddresses.forEach(svocAddress -> {
                    com.homedepot.customer.model.Address wcsAddress = new com.homedepot.customer.model.Address();
                    Optional<Integer> optWcsAddressId = findWcsAddressId(crossRefInfo.getAddresses(),
                            "" + svocAddress.getAddrIdentifier());
                    if (optWcsAddressId.isPresent()) {
                        log.debug("svoc addressId {}:{} is currently mapping to wcs addressId {}", customerAccountId,
                                svocAddress.getAddrIdentifier(), optWcsAddressId.get());       
                        addrHelper.mapSvocToWCSModel(svocAddress, wcsAddress);
                        wcsAddress.setAddrIdentifier(optWcsAddressId.get());

                        // STEP 3 >>> Call WCS MAML CSR API
                        List<com.homedepot.customer.model.Address> addrCrosRefResponseList = updateAddressInWCS(
                                ssoToken, wcsMemberId, wcsAddress);

                        Address addressCrossRefUpd = new Address(String.valueOf(customerAccountId),
                                String.valueOf(wcsMemberId), String.valueOf(svocAddress.getAddrIdentifier()),
                                String.valueOf(addrCrosRefResponseList.get(0).getAddrIdentifier()),
                                GlobalConstants.APPLICATION_ID, null);

                        log.debug("svoc addressId {}:{} is now mapping to NEW wcs addressId {}", customerAccountId,
                                svocAddress.getAddrIdentifier(), addressCrossRefUpd.getWcsAddressId());
                        crossRefInfoUpdateRequest.getAddresses().getAddress().add(addressCrossRefUpd);
                    } else {
                        log.warn("could not find correspondent wcs address xref for svoc address Id {}:{}",
                                customerAccountId, svocAddress.getAddrIdentifier());
                    }
                });

                log.debug("END: Synching up address updates in WCS for customer {} : Address details {}",
                        customerAccountId, addressRequest.toString());
            }
        } catch (LamdaExceptionWrapper e) {
            log.error("ERROR: Synching up address updates in WCS for customer {}", customerAccountId,
                    ExceptionUtils.getRootCause(e));
        } catch (IntegrationException e) {
            log.error("ERROR: Synching up address updates in WCS for customer {} : Address details {}, Root Cause:",
                    customerAccountId, addressRequest.toString(), ExceptionUtils.getRootCause(e));
            log.error(EXCEPTION_DETAILS, e.getHttpStatus(),e.getMessage(), e);
        } catch (Exception e) {
            log.error("ERROR: Synching up address creation in WCS for customer {} : Address details {}, Root Cause:",
                    customerAccountId, addressRequest.toString(), ExceptionUtils.getRootCause(e));
        }
    }

    private List<com.homedepot.customer.model.Address> updateAddressInWCS(String ssoToken, String wcsMemberId,
            com.homedepot.customer.model.Address wcsAddress) {
        List<com.homedepot.customer.model.Address> addrCrosRefResponseList;
        try {
            addrCrosRefResponseList = wcsAddressFacade.updateCustomerAddressCSR(wcsMemberId, Arrays.asList(wcsAddress),
                    ssoToken);
        } catch (IntegrationException e) {
            throw new LamdaExceptionWrapper(e);
        }
        return addrCrosRefResponseList;
    }

    private boolean deleteAddressInWCS(String ssoToken, String wcsMemberId, Integer wcsAddressID) {
       Boolean requestResponse;
        try {
            requestResponse = wcsAddressFacade.deleteCustomerAddressCSR(wcsMemberId,String.valueOf(wcsAddressID), ssoToken);
        }
        catch (IntegrationException e) {
            throw new LamdaExceptionWrapper(e);
        }
        return requestResponse;
    }

    @Async("addressTaskExecutor")
    public void syncDeleteAddress(String customerAccountId, AddressRequest addressRequest) {
        log.debug("BEGIN: Synching up address deletion in WCS for customer {} : Address details {}",customerAccountId, addressRequest.toString());
        try {
            // STE2 1 >>> LOOK up WCS member Id
            CrossRefInfo crossRefInfo = wcsCrossRefServiceFacade.getCrossRefInfoForSVOCCustAcctId(customerAccountId);

            if (crossRefInfo != null) {
                // STEP 2 >>> GET Token for the CSR account
                String ssoToken = passportServiceFacade.getToken();

                String wcsMemberId = crossRefInfo.getWcsMemberId();

                CrossRefInfo crossRefInfoDeleteRequest = new CrossRefInfo();
                List<Address> addrCrosRefUpdateList = new ArrayList<>();
                Addresses addresses = new Addresses();
                addresses.setAddress(addrCrosRefUpdateList);
                crossRefInfoDeleteRequest.setAddresses(addresses);
                addressRequest.getAddress().forEach(svocAddress -> {
                    Optional<Integer> optWcsAddressId = findWcsAddressId(crossRefInfo.getAddresses(), "" + svocAddress.getAddrIdentifier());
                    if (optWcsAddressId.isPresent()) {
                        log.debug("svoc addressId {}:{} is currently mapping to wcs addressId {}", customerAccountId, svocAddress.getAddrIdentifier(), optWcsAddressId.get());

                        // STEP 3 >>> Call WCS MAML CSR API
                        boolean addrCrosRefResponseList = deleteAddressInWCS(ssoToken, wcsMemberId, optWcsAddressId.get());

                        Address addressCrossRefUpd = new Address(String.valueOf(customerAccountId), String.valueOf(wcsMemberId),
                                String.valueOf(svocAddress.getAddrIdentifier()), String.valueOf(optWcsAddressId.get()),
                                GlobalConstants.APPLICATION_ID, null);

                        log.debug("svoc addressId {}:{} is now mapping to NEW wcs addressId {}", customerAccountId, svocAddress.getAddrIdentifier(), addressCrossRefUpd.getWcsAddressId());
                        crossRefInfoDeleteRequest.getAddresses().getAddress().add(addressCrossRefUpd);
                    }
                    else {
                        log.warn("could not find correspondent wcs address xref for svoc address Id {}:{}", customerAccountId, svocAddress.getAddrIdentifier());
                    }
                });
                boolean crossRefInfoUpdateResp = wcsCrossRefServiceFacade.deleteCrossRefInfo(crossRefInfoDeleteRequest, ssoToken);

                log.debug("END: Synching up address updates in WCS for customer {} : Address details {}", customerAccountId, addressRequest.toString());
            }
        }
        catch (LamdaExceptionWrapper e) {
            log.error("ERROR: Synching up address deletion in WCS for customer {}", customerAccountId, ExceptionUtils.getRootCause(e));
        }
        catch (IntegrationException e) {
            log.error("ERROR: Synching up address deletion in WCS for customer {} : Address details {}, Root Cause:",
                    customerAccountId, addressRequest.toString(), ExceptionUtils.getRootCause(e));
            log.error(EXCEPTION_DETAILS, e.getHttpStatus(), e.getMessage(), e);
        }
        catch (Exception e) {
            log.error("ERROR: Synching up address creation in WCS for customer {} : Address details {}, Root Cause:",
                    customerAccountId, addressRequest.toString(), ExceptionUtils.getRootCause(e));
        }
        
        log.debug("END: Synching up address deletion in WCS for customer {} : Address details {}",customerAccountId, addressRequest.toString());
    
    }

    private Optional<Integer> findWcsAddressId(Addresses addresses, String svocAddressId) {
        return Optional.ofNullable(addresses)
                .map(Addresses::getAddress)
                .orElse(new ArrayList<>())
                .stream()
                .filter(address -> svocAddressId.equals(address.getSvocAddressId()))
                .findFirst()
                .map(Address::getWcsAddressId)
                .map(Integer::parseInt);
    }
}
