package com.homedepot.customer.datasync.payment;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.integration.wcs.dto.crossref.CrossRefInfo;
import com.homedepot.customer.integration.wcs.dto.crossref.Payment;
import com.homedepot.customer.integration.wcs.dto.crossref.Payments;
import com.homedepot.customer.model.*;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.util.PaymentCardBrand;
import com.homedepot.customer.util.PaymentCardType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * Helper class for WCS Payment Card sync
 * 
 * @author pxk3659
 *
 */

@Component
@Slf4j
public class PaymentCardHelper {
    
    /**
     * Method to populate payment card for WCS sync using new card, used during WCS fallback.
     * 
     * @param crossRefInfo
     * @param savedCard
     * @return PaymentCard
     */
    public PaymentCard convertToWCSPaymentCard(CrossRefInfo crossRefInfo, PaymentCard savedCard) {
        log.debug(">> convertToWCSPaymentCard()");
        PaymentCard wcsCard = new PaymentCard();
        BeanUtils.copyProperties(savedCard, wcsCard, new String[] { "billingAddress" , "isReqServedFromWCS", "cardNumberLast4"});
        // Set XRef card number to card number and XRef= true to call create payment card by XRef card number
        wcsCard.setCardNumber(savedCard.getCardNumber());
        wcsCard.setIsXREF(Boolean.FALSE);
        wcsCard.setPieEncryption(savedCard.getPieEncryption());
        wcsCard.setPaymentId(null);
        wcsCard.setCardType(null);
        PaymentCardType cardType = PaymentCardType.getByCardBrand(savedCard.getCardBrand());
        wcsCard.setCardBrand(cardType.getWCSCardBrand().name());
        wcsCard.setXrefCardNumber(null);
        wcsCard.setIsCardExpired(null);
        wcsCard.setLastModifiedDate(null);
        wcsCard.setMaskedCardNumber(null);

        // Set Billing Address
        Address wcsBillingAddress = convertToWCSAddress(crossRefInfo, savedCard.getBillingAddress());
        wcsCard.setBillingAddress(wcsBillingAddress);

        return wcsCard;
    }

    /**
     * Method to populate payment card for WCS sync using request card and saved card, used during WCS sync.
     *
     * @param crossRefInfo
     * @param requestCard
     * @param savedCard
     * @return PaymentCard
     */
    public PaymentCard convertToWCSPaymentCard(CrossRefInfo crossRefInfo, PaymentCard requestCard, PaymentCard savedCard) {
        log.debug(">> convertToWCSPaymentCard()");
        PaymentCard wcsCard = new PaymentCard();
        BeanUtils.copyProperties(savedCard, wcsCard, new String[] { "billingAddress" , "isReqServedFromWCS", "cardNumberLast4"});
        // Set XRef card number to card number and XRef= true to call create payment card by XRef card number
        wcsCard.setCardNumber(requestCard.getCardNumber());
        wcsCard.setIsXREF(Boolean.FALSE);
        wcsCard.setPieEncryption(requestCard.getPieEncryption());
        wcsCard.setPaymentId(null);
        wcsCard.setCardType(null);
        PaymentCardType cardType = PaymentCardType.getByCardBrand(savedCard.getCardBrand());
        wcsCard.setCardBrand(cardType.getWCSCardBrand().name());
        wcsCard.setXrefCardNumber(null);
        wcsCard.setIsCardExpired(null);
        wcsCard.setLastModifiedDate(null);
        wcsCard.setMaskedCardNumber(null);

        // Set Billing Address
        Address wcsBillingAddress = convertToWCSAddress(crossRefInfo, savedCard.getBillingAddress());
        wcsCard.setBillingAddress(wcsBillingAddress);

        return wcsCard;
    }

    /**
     * Method to populate payment and address cross reference info
     * 
     * @param crossRefInfo
     * @param savedCard
     * @param syncedCard
     * @return CrossRefInfo
     */

    public CrossRefInfo populatePaymentAndAddressCrossRef(CrossRefInfo crossRefInfo, PaymentCard savedCard,
                                                          PaymentCard syncedCard) {
        log.debug(">> populatePaymentAndAddressCrossRef()");

        CrossRefInfo newCrossRef = new CrossRefInfo();
        // crossRefInfo.setWcsMemberId(wcsMemberId);

        Payment wcsPayment = new Payment();
        wcsPayment.setLastUpdUser(GlobalConstants.APPLICATION_ID);
        wcsPayment.setSvocCustAcctId(crossRefInfo.getSvocCustAcctId());
        wcsPayment.setWcsMemberId(crossRefInfo.getWcsMemberId());
        wcsPayment.setSvocAddressId(String.valueOf(savedCard.getBillingAddress().getAddrIdentifier()));
        wcsPayment.setXrefPaymentId(savedCard.getPaymentId());
        wcsPayment.setWcsPaymentId(syncedCard.getProfileOrderId());

        Payments wcsPayments = new Payments();
        wcsPayments.setPayment(Collections.singletonList(wcsPayment));
        newCrossRef.setPayments(wcsPayments);

        // Add address cross reference if not exists
        if (!addressCressRefExists(crossRefInfo, savedCard.getBillingAddress())) {

            com.homedepot.customer.integration.wcs.dto.crossref.Address wcsAddess = new com.homedepot.customer.integration.wcs.dto.crossref.Address();
            wcsAddess.setLastUpdUser(GlobalConstants.APPLICATION_ID);
            wcsAddess.setSvocCustAcctId(crossRefInfo.getSvocCustAcctId());
            wcsAddess.setWcsMemberId(crossRefInfo.getWcsMemberId());
            wcsAddess.setSvocAddressId(String.valueOf(savedCard.getBillingAddress().getAddrIdentifier()));
            wcsAddess.setWcsAddressId(String.valueOf(syncedCard.getBillingAddress().getAddrIdentifier()));

            com.homedepot.customer.integration.wcs.dto.crossref.Addresses wcsAddesses = new com.homedepot.customer.integration.wcs.dto.crossref.Addresses();
            wcsAddesses.setAddress(Collections.singletonList(wcsAddess));
            newCrossRef.setAddresses(wcsAddesses);
        }
        return newCrossRef;
    }

    /**
     * Method to get address cross reference info for a given address
     * 
     * @param crossRefInfo
     * @param address
     * @return Address
     */

    private com.homedepot.customer.integration.wcs.dto.crossref.Address getAddressCressRef(CrossRefInfo crossRefInfo,
            Address address) {
        log.debug(">> getAddressCressRef()");
        com.homedepot.customer.integration.wcs.dto.crossref.Address wcsAddress = null;
        if (null != crossRefInfo && crossRefInfo.getAddresses() != null
                && CollectionUtils.isNotEmpty(crossRefInfo.getAddresses().getAddress())) {
            List<com.homedepot.customer.integration.wcs.dto.crossref.Address> list = crossRefInfo.getAddresses()
                    .getAddress();
            String svocAddressId = String.valueOf(address.getAddrIdentifier());          
            wcsAddress = list.stream().filter(element -> svocAddressId.equals(element.getSvocAddressId())).findAny()
                    .orElse(null);
        }
        return wcsAddress;
    }

    /**
     * Method to check if address cross reference info exist for a given address
     * 
     * @param crossRefInfo
     * @param address
     * @return true if address cross reference exist
     */

    private boolean addressCressRefExists(CrossRefInfo crossRefInfo, Address address) {
        log.debug(">> addressCressRefExists()");
        return getAddressCressRef(crossRefInfo, address) != null ? true : false;
    }

    /**
     * Method to populate billing address for WCS sync using saved card address
     * 
     * @param crossRefInfo
     * @param address
     * @return Address
     */

    private Address convertToWCSAddress(CrossRefInfo crossRefInfo, Address address) {
        log.debug(">> convertToWCSAddress()");
        Address wcsBillingAddress = new Address();
        BeanUtils.copyProperties(address, wcsBillingAddress, new String[] { "name", "lastModifiedDate"});
        if(null != wcsBillingAddress.getAddrIdentifier()) {
            String addrIDType = getRequestTypeForAddrId(String.valueOf(address.getAddrIdentifier()));
            if (addrIDType.equals(GlobalConstants.SVOC)) {
                com.homedepot.customer.integration.wcs.dto.crossref.Address wcsAddress = getAddressCressRef(crossRefInfo, address);
                if (wcsAddress != null) {
                    wcsBillingAddress.setAddrIdentifier(Integer.parseInt(wcsAddress.getWcsAddressId()));
                } else {
                    wcsBillingAddress.setAddrIdentifier(null);
                }
            }
        }

        if(address.getName()!=null){
            Name name = new Name();
            wcsBillingAddress.setName(name);
            name.setFirstName(WordUtils.capitalizeFully(address.getName().getFirstName()));
            name.setLastName(WordUtils.capitalizeFully(address.getName().getLastName()));
        }

        if(address.getPostalDetails()!=null){
            PostalDetails postalDetails = new PostalDetails();
            wcsBillingAddress.setPostalDetails(postalDetails);
            BeanUtils.copyProperties(address.getPostalDetails(), wcsBillingAddress.getPostalDetails(), new String[]{"addressLine1","addressLine2"});
            wcsBillingAddress.getPostalDetails().setAddressLine1(WordUtils.capitalizeFully(address.getPostalDetails().getAddressLine1()));
            wcsBillingAddress.getPostalDetails().setAddressLine2(WordUtils.capitalizeFully(address.getPostalDetails().getAddressLine2()));
        }

        if(address.getPrimaryPhone()!=null) {
            Phone primaryPhone = new Phone();
            primaryPhone.setNumber(address.getPrimaryPhone().getNumber());
            wcsBillingAddress.setPrimaryPhone(primaryPhone);
        }

        if (address.getAlternatePhone() != null) {
            // only create the secondary phone object when there is alternate phone in the original svocAddress
            // otherwise wcs will complain about empty secondary phone object
            Phone secondaryPhone = new Phone();
            secondaryPhone.setNumber(address.getAlternatePhone() != null ? address.getAlternatePhone().getNumber() : null);
            wcsBillingAddress.setAlternatePhone(secondaryPhone);
        }
        return wcsBillingAddress;
    }

    public CrossRefInfo populateDeletePaymentCardCrossRef(String xrefPaymentId, String wcsPaymentId) {
        CrossRefInfo crossRefInfo = new CrossRefInfo();
        Payments payments = new Payments();
        List<Payment> paymentList = new ArrayList<>();
        Payment payment = new Payment();
        payment.setWcsPaymentId(wcsPaymentId);
        payment.setXrefPaymentId(xrefPaymentId);
        paymentList.add(payment);
        payments.setPayment(paymentList);
        crossRefInfo.setPayments(payments);
        return crossRefInfo;
    }
    
    public void mapWCSToXRefModel(PaymentCard wcsPaymentCard, PaymentCard xRefPaymentCard){
        log.debug("In mapWCSToXRefModel");
        BeanUtils.copyProperties(wcsPaymentCard, xRefPaymentCard, new String[] { "cardNumber", "billingAddress" , "cardBrand"});
        xRefPaymentCard.setMaskedCardNumber(wcsPaymentCard.getCardNumber());
        xRefPaymentCard.setPaymentId(wcsPaymentCard.getProfileOrderId());
        xRefPaymentCard.setProfileOrderId(null);
        PaymentCardType cardType = PaymentCardType.getByWCSCardBrand(wcsPaymentCard.getCardBrand());
        xRefPaymentCard.setCardType(cardType.getShortDesc());
        xRefPaymentCard.setCardBrand(cardType.getCardBrand().name());
        if(PaymentCardBrand.HDCOM.equals(cardType.getCardBrand()) || PaymentCardBrand.HDCON.equals(cardType.getCardBrand()))
            xRefPaymentCard.setIsCardExpired(false);
        else
            xRefPaymentCard.setIsCardExpired(
                    isCardExpired(wcsPaymentCard.getCardExpiryMonth(), wcsPaymentCard.getCardExpiryYear()));
    }

    public boolean isCardExpired(String expiryMonth, String expiryYear) {

        if (StringUtils.isBlank(expiryMonth) || StringUtils.isBlank(expiryYear)) {
            return true;
        }

        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        // Java month starts at 0 (eg. Month of January = 0)
        int currentMonth = cal.get(Calendar.MONTH) + 1;
        int currentYear = cal.get(Calendar.YEAR);
        return (currentMonth > Integer.parseInt(expiryMonth)) && (currentYear >= Integer.parseInt(expiryYear));
    }
    
    public void throwGenericIntegrationException(Exception uEx) throws IntegrationException{
        Errors errors = new Errors();
        Error error = new Error();
        errors.setErrors(Arrays.asList(error));
        error.setErrorCode(ErrorCode.SYSTEM_ERROR);
        throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, uEx);
    }

    public String getRequestTypeForAddrId(String addressIdFromRequest){
        return addressIdFromRequest.length() >= 5 ? GlobalConstants.WCS : GlobalConstants.SVOC;
    }

}
