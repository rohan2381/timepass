package com.homedepot.customer.datasync.payment;

import com.homedepot.customer.datasync.address.AddressHelper;
import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.LamdaExceptionWrapper;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.integration.passport.THDPassportServiceFacade;
import com.homedepot.customer.integration.wcs.WCSCrossRefServiceFacade;
import com.homedepot.customer.integration.wcs.WCSPaymentServiceFacade;
import com.homedepot.customer.integration.wcs.dto.PaymentAccount;
import com.homedepot.customer.integration.wcs.dto.crossref.CrossRefInfo;
import com.homedepot.customer.model.Address;
import com.homedepot.customer.model.Addresses;
import com.homedepot.customer.model.PaymentCard;
import com.homedepot.customer.model.PaymentCards;
import com.homedepot.customer.util.CrossReferenceHelper;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.util.SessionHelper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Created by rxb1809 on Apr 10, 2017
 * For fallback methods on payment cards in wcs
 */
@Service
@Slf4j
public class PaymentFallBackExecutor {

    @Autowired
    WCSPaymentServiceFacade wcsPaymentFacade;
    
    @Autowired
    CustomerAccountRequestContext reqContext;
    
    @Autowired
    WCSCrossRefServiceFacade wcsCrossRefServiceFacade;
    
    @Autowired
    SessionHelper sessionHelper;
    
    @Autowired
    PaymentCardHelper paymentHelper;
    
    @Autowired
    AddressHelper addressHelper;

    @Autowired
    CrossReferenceHelper crossRefHelper;

    @Autowired
    private THDPassportServiceFacade passportServiceFacade;

    @Autowired
    private EnvPropertyUtil envProperty;

    @SuppressWarnings("squid:MethodCyclomaticComplexity")
    public List<PaymentCard> getPaymentCardsFromWCS(String wcsUserToken) throws IntegrationException {
        List<PaymentCard> xRefRespPaymentCardsList = new ArrayList<>();
        try {
            // Step 1: Extract the wcsUserToken
            String token = wcsUserToken;
            if (token == null) {
                token = sessionHelper.extractWCSTokenFromCookie(reqContext.getRequest().getCookies());
            }

            // Step 2: Retrieve customer address from WCS
            final PaymentAccount paymentAccount;
            if(envProperty.getPaymentSource().equalsIgnoreCase(GlobalConstants.WCS)) {
                String ssoToken = passportServiceFacade.getToken();
                CrossRefInfo crossRefInfo = reqContext.getCrossRefInfo();
                if(crossRefInfo==null){
                    crossRefInfo = wcsCrossRefServiceFacade.getCrossRefInfoForSVOCCustAcctId(reqContext.getSvocCustomerAccountId());
                }
                String wcsMemberId = crossRefInfo.getWcsMemberId();
                paymentAccount = wcsPaymentFacade.getAllPaymentCardsCSR(wcsMemberId, ssoToken);
            } else {
                paymentAccount = wcsPaymentFacade.getAllPaymentCardsFallBack(null, token);
            }
            
            // Step 3: Map WCS request models to SVOC request models
            if(paymentAccount!=null && paymentAccount.getPaymentCards() != null && !paymentAccount.getPaymentCards().getPaymentCard().isEmpty()) {

                paymentAccount.getPaymentCards().getPaymentCard().forEach(wcsRespPaymentCard -> {
                    // Set payment card details
                    PaymentCard xRefRespPaymetCard = new PaymentCard();
                    paymentHelper.mapWCSToXRefModel(wcsRespPaymentCard, xRefRespPaymetCard);
                    
                    // Set billing address details
                    if(paymentAccount.getAddresses()!=null && !paymentAccount.getAddresses().getAddress().isEmpty() && wcsRespPaymentCard.getBillingAddress() != null){
                        Optional<Address> wcsRespAddressOptional = paymentAccount.getAddresses().getAddress()
                                                                    .stream()
                                                                    .filter(addr -> addr.getAddrIdentifier().equals(wcsRespPaymentCard.getBillingAddress().getAddrIdentifier()))
                                                                    .findFirst();
                        wcsRespAddressOptional.ifPresent( wcsRespAddress -> {
                            Address xRefRespAddress = new Address();
                            addressHelper.mapWCSToSvocModel(wcsRespAddress, xRefRespAddress);
                            xRefRespPaymetCard.setBillingAddress(xRefRespAddress);
                        });
                    }
                                        
                    xRefRespPaymentCardsList.add(xRefRespPaymetCard);
                });

                // Step 4: Sort the results
                // default card first, then newer update TS before older
                Collections.sort(xRefRespPaymentCardsList, (PaymentCard pay1, PaymentCard pay2) -> {
                    if (pay1.getIsDefault()) {
                        return -1;
                    }
                    else if (pay2.getIsDefault()) {
                        return 1;
                    }
                    else {
                        return pay2.getLastModifiedDate().compareTo(pay1.getLastModifiedDate());
                    }
                });
            }
            
        } catch (UnsupportedEncodingException uEx) {
            paymentHelper.throwGenericIntegrationException(uEx);
        }
        return xRefRespPaymentCardsList;
    }

    public List<PaymentCard> createPaymentCardInWCS(List<PaymentCard> paymentCards, String wcsUserToken) throws IntegrationException{
        List<PaymentCard> respSvocPayments = new ArrayList<>();
        try {
            // Step 1: Get Cross Ref for given Customer Account ID.
            CrossRefInfo crossRefInfo = reqContext.getCrossRefInfo();
            if(crossRefInfo==null){
                if( null != reqContext.getSvocCustomerAccountId())
                    crossRefInfo = wcsCrossRefServiceFacade.getCrossRefInfoForSVOCCustAcctId(reqContext.getSvocCustomerAccountId());
                else if( null != reqContext.getWcsMemberId()) {
                    try {
                        crossRefInfo = wcsCrossRefServiceFacade.getCrossRefInfoForWCSMemberId(reqContext.getWcsMemberId());
                    } catch (IntegrationException ex) {
                        log.debug("No Cross Ref found for WCS Member ID {} : , Root Cause: {}", reqContext.getWcsMemberId(), ExceptionUtils.getRootCauseMessage(ex));
                    }
                }
            }
            // Step 2: Extract the wcsUserToken
            String userToken = wcsUserToken;
            if (userToken == null) {
                userToken = sessionHelper.extractWCSTokenFromCookie(reqContext.getRequest().getCookies());
            }
            final String finalUserToken = userToken;
            final CrossRefInfo crossRefInfoFinal = crossRefInfo; // To work around java 8 mandate of using only final variables inside lambda expressions
            List<PaymentCard> wcsRespPayments = new ArrayList<>();
            // Step 3: Add/Save new payment card in WCS.
            paymentCards.forEach(paymentCard -> {
                PaymentCard wcsPaymentCard = paymentHelper.convertToWCSPaymentCard(crossRefInfoFinal, paymentCard);
                try {
                    PaymentCard wcsRespPaymentCard = wcsPaymentFacade.createPaymentCardFallBack(wcsPaymentCard, finalUserToken);
                    log.debug("In createPaymentCardInWCS(), after createPaymentCardFallBack.");
                    String cardNumberLast4 = StringUtils.right(paymentCard.getCardNumber(), 4);
                    PaymentAccount newWCSCardAccount = wcsPaymentFacade.getPaymentCardByBrandNLast4Digits(wcsRespPaymentCard.getCardBrand(), cardNumberLast4, finalUserToken);
                   log.debug("In createPaymentCardInWCS(), after getPaymentCardByBrandNLast4Digits. And number of cards are : "+ newWCSCardAccount.getPaymentCards().getPaymentCard().size());
                    Optional.of(newWCSCardAccount).ifPresent(wcsRespAccount ->{
                        PaymentCard newWCSCard = getPaymentCardByLastUpdDt(wcsRespAccount.getPaymentCards()).get();
                        Optional<Address> wcsPayBillingAddress = findWcsAddressByID(wcsRespAccount.getAddresses(), wcsRespPaymentCard.getBillingAddress().getAddrIdentifier());
                        wcsPayBillingAddress.ifPresent(newWCSCard::setBillingAddress);
                        wcsRespPayments.add(newWCSCard);
                    });
                } catch (IntegrationException iEx) {
                    throw new LamdaExceptionWrapper(iEx);
                }
            });
            log.debug("Map WCS request models to SVOC request models.");
            // Map WCS request models to SVOC request models
            wcsRespPayments.forEach(wcsRespPayment -> {
                PaymentCard xRefRespPaymetCard = new PaymentCard();
                paymentHelper.mapWCSToXRefModel(wcsRespPayment, xRefRespPaymetCard);
                Optional.ofNullable(wcsRespPayment.getBillingAddress()).ifPresent(wcsBillingAddress -> {
                    Address xRefRespAddress = new Address();
                    addressHelper.mapWCSToSvocModel(wcsRespPayment.getBillingAddress(), xRefRespAddress);
                    xRefRespPaymetCard.setBillingAddress(xRefRespAddress);
                });
                respSvocPayments.add(xRefRespPaymetCard);
            });

        } catch (UnsupportedEncodingException uEx) {
            paymentHelper.throwGenericIntegrationException(uEx);
        } catch (LamdaExceptionWrapper lEx) {// NOSONAR
            if (lEx.getCause() instanceof IntegrationException) {
                throw (IntegrationException) lEx.getCause();
            }
        }
        return respSvocPayments;
    }

    public List<PaymentCard> updatePaymentCardInWCS(List<PaymentCard> paymentCards, String wcsUserToken) throws IntegrationException{
        List<PaymentCard> respSvocPayments = new ArrayList<>();
        try {
            // Step 1: Get Cross Ref for given Customer Account ID.
            CrossRefInfo crossRefInfo = reqContext.getCrossRefInfo();
            if(crossRefInfo==null){
                if( null != reqContext.getSvocCustomerAccountId())
                    crossRefInfo = wcsCrossRefServiceFacade.getCrossRefInfoForSVOCCustAcctId(reqContext.getSvocCustomerAccountId());
                else if( null != reqContext.getWcsMemberId()) {
                    try {
                        crossRefInfo = wcsCrossRefServiceFacade.getCrossRefInfoForWCSMemberId(reqContext.getWcsMemberId());
                    } catch (IntegrationException ex) {
                        log.debug("No Cross Ref found for WCS Member ID {} : , Root Cause: {}", reqContext.getWcsMemberId(), ExceptionUtils.getRootCauseMessage(ex));
                    }
                }
            }
            // Step 2: Extract the wcsUserToken
            String userToken = wcsUserToken;
            if (userToken == null) {
                userToken = sessionHelper.extractWCSTokenFromCookie(reqContext.getRequest().getCookies());
            }
            final CrossRefInfo crossRefInfoFinal = crossRefInfo; // To work around java 8 mandate of using only final variables inside lambda expressions
            final String finalUserToken = userToken;
            List<PaymentCard> wcsRespPayments = new ArrayList<>();
            // Step 3: Update payment card in WCS.
            paymentCards.forEach(paymentCard -> {
                PaymentCard wcsPaymentCard = paymentHelper.convertToWCSPaymentCard(crossRefInfoFinal, paymentCard);
                if(paymentCard.getIsReqServedFromWCS()) {
                    wcsPaymentCard.setProfileOrderId(paymentCard.getPaymentId());
                } else {
                    wcsPaymentCard.setProfileOrderId(crossRefHelper.getMappedWCSPaymentId(paymentCard.getPaymentId(), crossRefInfoFinal));
                }
                try {
                    PaymentCard wcsRespPaymentCard = wcsPaymentFacade.updatePaymentCardFallBack(wcsPaymentCard, finalUserToken);
                    String cardNumberLast4 = StringUtils.right(paymentCard.getXrefCardNumber(), 4);
                    PaymentAccount newWCSCardAccount = wcsPaymentFacade.getPaymentCardByBrandNLast4Digits(wcsRespPaymentCard.getCardBrand(), cardNumberLast4, finalUserToken);
                    Optional.of(newWCSCardAccount).ifPresent(wcsRespAccount ->{
                        PaymentCard newWCSCard = getPaymentCardByLastUpdDt(wcsRespAccount.getPaymentCards()).get();
                        Optional<Address> wcsPayBillingAddress = findWcsAddressByID(wcsRespAccount.getAddresses(), wcsRespPaymentCard.getBillingAddress().getAddrIdentifier());
                        wcsPayBillingAddress.ifPresent(newWCSCard::setBillingAddress);
                        wcsRespPayments.add(newWCSCard);
                    });
                } catch (IntegrationException iEx) {
                    throw new LamdaExceptionWrapper(iEx);
                }
            });

            // Map WCS request models to SVOC request models
            wcsRespPayments.forEach(wcsRespPayment -> {
                PaymentCard xRefRespPaymetCard = new PaymentCard();
                paymentHelper.mapWCSToXRefModel(wcsRespPayment, xRefRespPaymetCard);
                Optional.ofNullable(wcsRespPayment.getBillingAddress()).ifPresent(wcsBillingAddress -> {
                    Address xRefRespAddress = new Address();
                    addressHelper.mapWCSToSvocModel(wcsRespPayment.getBillingAddress(), xRefRespAddress);
                    xRefRespPaymetCard.setBillingAddress(xRefRespAddress);
                });
                respSvocPayments.add(xRefRespPaymetCard);
            });

        } catch (UnsupportedEncodingException uEx) {
            paymentHelper.throwGenericIntegrationException(uEx);
        } catch (LamdaExceptionWrapper lEx) {// NOSONAR
            if (lEx.getCause() instanceof IntegrationException) {
                throw (IntegrationException) lEx.getCause();
            }
        }
        return respSvocPayments;
    }

    public boolean deletePaymentCardInWCS(String customerAccountId, String paymentId) throws IntegrationException {
        boolean isDeleteSuccess = false;
        final String lambdaPaymentId= paymentId;
        String paymentIDforCall = paymentId;
        try {
            //Check if CrossRefInfo is populated, if not get it from WCSCrossRefServiceFacade
            CrossRefInfo crossRefInfo = reqContext.getCrossRefInfo();
            if(crossRefInfo==null){
                if( null != reqContext.getSvocCustomerAccountId())
                    crossRefInfo = wcsCrossRefServiceFacade.getCrossRefInfoForSVOCCustAcctId(reqContext.getSvocCustomerAccountId());
                else if( null != reqContext.getWcsMemberId()) {
                    try {
                        crossRefInfo = wcsCrossRefServiceFacade.getCrossRefInfoForWCSMemberId(reqContext.getWcsMemberId());
                    } catch (IntegrationException ex) {
                        log.debug("No Cross Ref found for WCS Member ID {} : , Root Cause: {}", reqContext.getWcsMemberId(), ExceptionUtils.getRootCauseMessage(ex));
                    }
                }
            }
            if(!reqContext.isWCSRequest()){
                paymentIDforCall = crossRefHelper.getMappedWCSPaymentId(lambdaPaymentId, crossRefInfo);
            }
            String ssoToken = sessionHelper.extractWCSTokenFromCookie(reqContext.getRequest().getCookies());

            if (paymentId != null) {
                String wcsMemberId = (null != crossRefInfo) ? crossRefInfo.getWcsMemberId() : reqContext.getWcsMemberId();
                isDeleteSuccess = wcsPaymentFacade.deletePaymentCardFallBack(wcsMemberId, paymentIDforCall, ssoToken);
            }
        }

        catch (UnsupportedEncodingException uEx){
            paymentHelper.throwGenericIntegrationException(uEx);
        }
        return isDeleteSuccess;
    }


    private Optional<PaymentCard> getPaymentCardByLastUpdDt(PaymentCards paymentCards) {
        return Optional.ofNullable(paymentCards)
                .map(PaymentCards::getPaymentCard)
                .orElse(new ArrayList<>())
                .stream()
                .sorted((pay1, pay2) -> pay2.getLastModifiedDate().compareTo(pay1.getLastModifiedDate()))
                .findFirst();
    }

    private Optional<Address> findWcsAddressByID(Addresses addresses, Integer paymentAddressId) {
        return Optional.ofNullable(addresses)
                .map(Addresses::getAddress)
                .orElse(new ArrayList<>())
                .stream()
                .filter(address -> paymentAddressId.equals(address.getAddrIdentifier()))
                .findFirst();
    }
}
