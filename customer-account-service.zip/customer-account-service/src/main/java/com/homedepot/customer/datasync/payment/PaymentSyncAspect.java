package com.homedepot.customer.datasync.payment;

import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.homedepot.customer.datasync.util.DataSyncUtil;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.model.PaymentCard;
import com.homedepot.customer.model.PaymentCards;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Aug 31, 2016
 *
 */
//@Aspect
@Component
@Slf4j
public class PaymentSyncAspect {

    @Autowired
    PaymentSyncExecutor paymentExecutor;
    
    @Autowired
    private DataSyncUtil dataSyncUtil;

    @Autowired
    CustomerAccountRequestContext reqContext;

    @AfterReturning(
            pointcut = "execution(* com.homedepot.customer.service.IPaymentService.createUserPaymentCard(..)) && args(customerAccountId, paymentCards)",
            returning = "xrefSavedAddresses")
    public void createPaymentCardInWCS(JoinPoint jp, String customerAccountId, PaymentCards paymentCards, List<PaymentCard> xrefSavedAddresses) {
        if(!reqContext.isReqServedFromWCS()) {
            paymentExecutor.syncCreatePaymentCard(customerAccountId, paymentCards, xrefSavedAddresses);
            dataSyncUtil.pauseAroundDataSync();
        }
    }

    @AfterReturning(
            pointcut = "execution(* com.homedepot.customer.service.IPaymentService.updateUserPaymentCard(..)) && args(customerAccountId, paymentCards)",
            returning = "xrefSavedAddresses")
    public void updatePaymentCardInWCS(JoinPoint jp, String customerAccountId, PaymentCards paymentCards, List<PaymentCard> xrefSavedAddresses) {
        if(!reqContext.isReqServedFromWCS()) {
            paymentExecutor.syncUpdatePaymentCard(customerAccountId, paymentCards, xrefSavedAddresses);
            dataSyncUtil.pauseAroundDataSync();
        }
    }

    /**
     * This method is used to invoke the wcs payment card delete thread
     */
    @AfterReturning("execution(* com.homedepot.customer.service.IPaymentService.deleteUserPaymentCardById(..)) && args(customerAccountId, paymentId)")
    public void deletePaymentCardInWCS(JoinPoint jp, String paymentId, String customerAccountId) {
        if(!reqContext.isReqServedFromWCS()) {
            paymentExecutor.syncDeletePaymentCard(customerAccountId, paymentId);
            dataSyncUtil.pauseAroundDataSync();
        }
    }

}
