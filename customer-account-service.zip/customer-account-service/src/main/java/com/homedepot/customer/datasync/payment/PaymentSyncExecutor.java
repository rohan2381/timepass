package com.homedepot.customer.datasync.payment;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.LamdaExceptionWrapper;
import com.homedepot.customer.integration.passport.THDPassportServiceFacade;
import com.homedepot.customer.integration.wcs.WCSCrossRefServiceFacade;
import com.homedepot.customer.integration.wcs.WCSPaymentServiceFacade;
import com.homedepot.customer.integration.wcs.dto.crossref.CrossRefInfo;
import com.homedepot.customer.integration.wcs.dto.crossref.Payment;
import com.homedepot.customer.model.PaymentCard;
import com.homedepot.customer.model.PaymentCards;
import com.homedepot.customer.util.CrossReferenceHelper;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.*;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Created by rxb1809 on Aug 24, 2016 This class is used to do a near real-time calls to WCS to sync xRef info in an
 * asynchronous fashion
 */

@Service
@Slf4j

public class PaymentSyncExecutor {

    @Autowired
    private WCSPaymentServiceFacade wcsPaymentFacade;

    @Autowired
    private THDPassportServiceFacade passportServiceFacade;

    @Autowired
    WCSCrossRefServiceFacade wcsCrossRefServiceFacade;

    @Autowired
    PaymentCardHelper helper;

    @Autowired
    CrossReferenceHelper crossRefHelper;

    public static final String EXCEPTION_DETAILS = "Exception details --> HTTP_STATUS={}, ERROR_MESSAGE={}, ERROR_CAUSE={}";

    private static final String WCSPAYMENTIDSTRING = ", wcsPaymentId: ";
    private static final String CUSTOMERSTRING ="for customer: ";
    private static final String ROOT_CAUSE = " , Root Cause:";


    @Async("paymentTaskExecutor")
    public void syncCreatePaymentCard(String customerAccountId, PaymentCards paymentCards, List<PaymentCard> savedCards) {
        log.debug("BEGIN: Synching up payment card creation in WCS for customer {} : for xrefPaymentId {}",
                customerAccountId, savedCards.get(0).getPaymentId());
        String wcsMemberId = null;
        try {
            // STE2 1 >>> LOOK up CrossRef for Customer Account ID.
            CrossRefInfo crossRefInfo = wcsCrossRefServiceFacade.getCrossRefInfoForSVOCCustAcctId(customerAccountId);

            if (crossRefInfo != null) {

                wcsMemberId = crossRefInfo.getWcsMemberId();

                // STEP 2 >>> GET Token for the CSR account
                String ssoToken = passportServiceFacade.getToken();


                PaymentCard requestPaymentCard = paymentCards.getPaymentCard().get(0);

                //STEP 3 >>> Add/Save new Payment Card in WCS.
                String finalWcsMemberId = wcsMemberId;
                savedCards.forEach(savedCard -> {
                    PaymentCard wcsPaymentCard = helper.convertToWCSPaymentCard(crossRefInfo, requestPaymentCard, savedCard);
                    try {
                        PaymentCard syncedCard = wcsPaymentFacade.createPaymentCardCSR(finalWcsMemberId, wcsPaymentCard,
                                ssoToken);
                        CrossRefInfo paymentAndAddressCrossRef = helper.populatePaymentAndAddressCrossRef(crossRefInfo,
                                savedCard, syncedCard);
                        Payment newPaymentCrossRef = paymentAndAddressCrossRef.getPayments().getPayment().get(0);
                        String cardNumberLast4 = StringUtils.right(savedCard.getXrefCardNumber(), 4);
                        //Lookup newly created WCS payment by Brand and Last 4 digits.
                        PaymentCard newWCSCardObj = wcsPaymentFacade.getPaymentCardCSRByBrandNLast4Digits(finalWcsMemberId, syncedCard.getCardBrand(), cardNumberLast4, ssoToken);
                        Optional.of(newWCSCardObj).ifPresent(newWCSCard -> newPaymentCrossRef.setWcsPaymentId(newWCSCard.getProfileOrderId()));
                        // Add/Save payment and address cross reference
                        wcsCrossRefServiceFacade.saveCrossRefInfo(paymentAndAddressCrossRef, ssoToken);
                        log.debug("END: Synching up payment card creation in WCS for customer {} : for xrefPaymentId {}",
                                customerAccountId, savedCard.getPaymentId());
                    } catch (IntegrationException iEx) {
                        throw new LamdaExceptionWrapper(iEx);
                    }
                });
            }
        } catch (LamdaExceptionWrapper lEx) {
            log.error("ERROR: Synching up payment card creation in WCS for customer {}: for WCS member id {} : xrefPaymentId {} ",
                    customerAccountId, wcsMemberId, savedCards.get(0).getPaymentId() + ROOT_CAUSE + ExceptionUtils.getRootCause(lEx));
        } catch (IntegrationException iEx) {
            log.error("ERROR: Synching up payment card creation in WCS for customer {}: for WCS member id {} : xrefPaymentId {} ",
                    customerAccountId, wcsMemberId, savedCards.get(0).getPaymentId() + ROOT_CAUSE + ExceptionUtils.getRootCause(iEx));
            log.error(EXCEPTION_DETAILS, iEx.getHttpStatus(), iEx.getMessage(), iEx);
        } catch (Exception ex) {
            log.error("ERROR: Synching up payment card creation in WCS for customer {}: for WCS member id {} : xrefPaymentId {} ",
                    customerAccountId, wcsMemberId, savedCards.get(0).getPaymentId() + ROOT_CAUSE + ExceptionUtils.getRootCause(ex));
        }
    }

    @Async("paymentTaskExecutor")
    public Boolean syncDeletePaymentCard(String customerAccountId, String paymentId) {
        log.debug("BEGIN: Synching up payment card deletion in WCS for customer {} : for xrefPaymentId {}", customerAccountId, paymentId);
        boolean isDeleteSuccess = false;
        boolean isCrossRefDeleteSuccess = false;
        String wcsMemberId = null;
        try {
            CrossRefInfo crossRefInfo = wcsCrossRefServiceFacade.getCrossRefInfoForSVOCCustAcctId(customerAccountId);
            if (crossRefInfo != null) {
                String ssoToken = passportServiceFacade.getToken();
                String wcsPaymentId = null;
                wcsMemberId = crossRefInfo.getWcsMemberId();
                List<Payment> paymentList = crossRefInfo.getPayments().getPayment();
                for (Payment payment : paymentList) {
                    if (payment.getXrefPaymentId() != null && payment.getXrefPaymentId().equals(paymentId)) {
                        wcsPaymentId = payment.getWcsPaymentId();
                        break;
                    }
                }
                if (wcsPaymentId != null) {
                    isDeleteSuccess = wcsPaymentFacade.deletePaymentCardCSR(crossRefInfo.getWcsMemberId(), wcsPaymentId,
                            ssoToken);
                } else {
                    log.error("WCS profileOrderId is null. Unable to cross ref profileOrderId from xref paymentId: "
                            + paymentId + " for customer: " + customerAccountId);
                }
                if (isDeleteSuccess) {
                    isCrossRefDeleteSuccess = wcsCrossRefServiceFacade.deleteCrossRefInfo(
                            helper.populateDeletePaymentCardCrossRef(paymentId, wcsPaymentId), ssoToken);
                } else {
                    log.error("Unable to delete wcs payment card for xrefPaymentId: " + paymentId + WCSPAYMENTIDSTRING
                            + wcsPaymentId + CUSTOMERSTRING + customerAccountId);
                }
                if (isCrossRefDeleteSuccess)
                    log.debug("END: Synching up payment card deletion in WCS for customer {} : for xrefPaymentId {}", customerAccountId, paymentId);
                else
                    log.debug("ERROR: Synching up payment card deletion in WCS for customer {} : for xrefPaymentId {}, Unable to delete cross ref data", customerAccountId, paymentId);
            }

        } catch (IntegrationException iEx) {
            log.error("ERROR: Synching up payment card deletion in WCS for customer {}: for WCS member id {} : xrefPaymentId {} ",
                    customerAccountId, wcsMemberId, paymentId + ROOT_CAUSE + ExceptionUtils.getRootCause(iEx));
        } catch (Exception ex) {
            log.error("ERROR: Synching up payment card deletion in WCS for customer {}: for WCS member id {} : xrefPaymentId {} ",
                    customerAccountId, wcsMemberId, paymentId + ROOT_CAUSE + ExceptionUtils.getRootCause(ex));
        }
        return isDeleteSuccess && isCrossRefDeleteSuccess;
    }

    @Async("paymentTaskExecutor")
    public void syncUpdatePaymentCard(String customerAccountId, PaymentCards paymentCards, List<PaymentCard> savedCards) {
        log.debug("BEGIN: Synching up payment card updates in WCS for customer {} : for xrefPaymentId {}",
                customerAccountId, savedCards.get(0).getPaymentId());
        String wcsMemberId = null;
        try {
            // STE2 1 >>> LOOK up WCS member Id
            CrossRefInfo crossRefInfo = wcsCrossRefServiceFacade.getCrossRefInfoForSVOCCustAcctId(customerAccountId);

            if (crossRefInfo != null) {
                PaymentCard xrefPaymentCard = savedCards.get(0);

                PaymentCard requestPaymentCard = paymentCards.getPaymentCard().get(0);

                // STEP 2 >>> GET Token for the CSR account
                String ssoToken = passportServiceFacade.getToken();

                wcsMemberId = crossRefInfo.getWcsMemberId();
                PaymentCard wcsCard = helper.convertToWCSPaymentCard(crossRefInfo, requestPaymentCard, xrefPaymentCard);
                wcsCard.setProfileOrderId(crossRefHelper.getMappedWCSPaymentId(xrefPaymentCard.getPaymentId(), crossRefInfo));

                // STEP 3 >>> Update Payment Card in WCS.
                PaymentCard syncedCard = wcsPaymentFacade.updatePaymentCardCSR(wcsMemberId, wcsCard, ssoToken);
                CrossRefInfo payemntAndAddressCrossRef = helper.populatePaymentAndAddressCrossRef(crossRefInfo,
                        xrefPaymentCard, syncedCard);
                //Set WCS Payment ID from the request WCS Card Object.
                Payment newPaymentCrossRef = payemntAndAddressCrossRef.getPayments().getPayment().get(0);
                newPaymentCrossRef.setWcsPaymentId(wcsCard.getProfileOrderId());

                boolean isCrossRefDeleteSuccess = wcsCrossRefServiceFacade
                        .deleteCrossRefInfo(helper.populateDeletePaymentCardCrossRef(xrefPaymentCard.getPaymentId(),
                                wcsCard.getProfileOrderId()), ssoToken);

                if (!isCrossRefDeleteSuccess) {
                    log.error("Unable to delete cross ref data for xrefPaymentId: " + xrefPaymentCard.getPaymentId() + WCSPAYMENTIDSTRING + wcsCard.getProfileOrderId() + CUSTOMERSTRING + customerAccountId);
                }
                wcsCrossRefServiceFacade.saveCrossRefInfo(payemntAndAddressCrossRef, ssoToken);

                log.debug("END: Synching up payment card updates in WCS for customer {} : for xrefPaymentId {}",
                        customerAccountId, xrefPaymentCard.getPaymentId());
            }

        } catch (LamdaExceptionWrapper lEx) {
            log.error("ERROR: Synching up payment card updates in WCS for customer {}: for WCS member id {} : xrefPaymentId {} ",
                    customerAccountId, wcsMemberId, savedCards.get(0).getPaymentId() + ROOT_CAUSE + ExceptionUtils.getRootCause(lEx));
        } catch (IntegrationException iEx) {
            log.error("ERROR: Synching up payment card updates in WCS for customer {}: for WCS member id {} : xrefPaymentId {} ",
                    customerAccountId, wcsMemberId, savedCards.get(0).getPaymentId() + ROOT_CAUSE + ExceptionUtils.getRootCause(iEx));
            log.error(EXCEPTION_DETAILS, iEx.getHttpStatus(), iEx.getMessage(), iEx);
        } catch (Exception ex) {
            log.error("ERROR: Synching up payment card updates in WCS for customer {}: for WCS member id {} : xrefPaymentId {} ",
                    customerAccountId, wcsMemberId, savedCards.get(0).getPaymentId() + ROOT_CAUSE + ExceptionUtils.getRootCause(ex));
        }
    }

}
