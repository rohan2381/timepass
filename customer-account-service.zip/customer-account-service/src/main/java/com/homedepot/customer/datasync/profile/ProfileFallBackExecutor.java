package com.homedepot.customer.datasync.profile;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.integration.wcs.WCSCrossRefServiceFacade;
import com.homedepot.customer.integration.wcs.WCSProfileServiceFacade;
import com.homedepot.customer.model.Account;
import com.homedepot.customer.model.Identity;
import com.homedepot.customer.model.Name;
import com.homedepot.customer.model.Profile;
import com.homedepot.customer.request.IdentityRequest;
import com.homedepot.customer.util.CrossReferenceHelper;
import com.homedepot.customer.util.SessionHelper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;

/**
 * Created by hxg3585
 * This class has methods to call WCS profile operations in a synchronous manner using the registered users session
 */
@Service
@Slf4j
public class ProfileFallBackExecutor {
    @Autowired
    WCSProfileServiceFacade wcsProfileFacade;

    @Autowired
    CustomerAccountRequestContext reqContext;

    @Autowired
    WCSCrossRefServiceFacade wcsCrossRefServiceFacade;

    @Autowired
    SessionHelper sessionHelper;

    @Autowired
    ProfileHelper ProfileHelper;

    @Autowired
    CrossReferenceHelper crossRefHelper;

    public Account getUserInfoFromWCS(String wcsUserToken) throws IntegrationException{

        Account respSvocAccount = new Account();
        Profile svocProfile = new Profile();
        Name svocName = new Name();
        svocProfile.setName(svocName);
        respSvocAccount.setProfile(svocProfile);
        try {
            // Step 1: Extract the wcsUserToken
            String token = wcsUserToken;
            if (token == null) {
                token = sessionHelper.extractWCSTokenFromCookie(reqContext.getRequest().getCookies());
            }

            // Step 2: Retrieve customer profile from WCS
            Account respWcsAccount = wcsProfileFacade.getUserInfoWCSFallBack(token);

            // Step 3: Map WCS request models to SVOC request models

            ProfileHelper.mapWCSToSvocModel(respWcsAccount, respSvocAccount);

        } catch (UnsupportedEncodingException uEx) {
            ProfileHelper.throwGenericIntegrationException(uEx);
        }

        return respSvocAccount;
    }

    public Account updateUserProfileInWCS(Account reqSvocAccount) throws IntegrationException{
        Account respSvocAccount = new Account();
        Profile svocProfile = new Profile();
        respSvocAccount.setProfile(svocProfile);

        Account reqWcsAccount = new Account();
        Profile wcsProfile = new Profile();

        reqWcsAccount.setProfile(wcsProfile);
        try {
            // Step 1: Extract the wcsUserToken
            String wcsUserToken = sessionHelper.extractWCSTokenFromCookie(reqContext.getRequest().getCookies());

            ProfileHelper.mapSvocToWCSModel(reqSvocAccount, reqWcsAccount);

            // Step 2: Retrieve customer profile from WCS
            Account respWcsAccount = wcsProfileFacade.updateUserProfileWCSFallBack(reqWcsAccount, wcsUserToken);

            // Step 3: Map WCS request models to SVOC request models

            ProfileHelper.mapWCSToSvocModel(respWcsAccount, respSvocAccount);

        } catch (UnsupportedEncodingException uEx) {
            ProfileHelper.throwGenericIntegrationException(uEx);
        }

        return respSvocAccount;
    }


    public Identity updateIdentity(IdentityRequest identityRequest) throws IntegrationException{
        Identity identityRes = null;
        try {

            String wcsUserToken = sessionHelper.extractWCSTokenFromCookie(reqContext.getRequest().getCookies());
            Account reqWcsAccount = new Account();
            Profile wcsProfile = new Profile();
            if(isEmailUpdateReq(identityRequest)) {
                wcsProfile.setEmailId(identityRequest.getNewLogonId());
            }
            if(ArrayUtils.isNotEmpty(identityRequest.getNewPassword())){
                wcsProfile.setPassword(String.valueOf(identityRequest.getNewPassword()));
                wcsProfile.setConfirmPassword(String.valueOf(identityRequest.getNewPassword()));
            }
            reqWcsAccount.setProfile(wcsProfile);
            Account respWcsAccount = wcsProfileFacade.updateUserProfileWCSFallBack(reqWcsAccount, wcsUserToken);
            if(isEmailUpdateReq(identityRequest)){
                identityRes = new Identity();
                identityRes.setLogonId(respWcsAccount.getProfile().getEmailId());
            }


        } catch (UnsupportedEncodingException uEx) {
            ProfileHelper.throwGenericIntegrationException(uEx);
        }
        return identityRes;

    }

    private boolean isEmailUpdateReq(IdentityRequest req) {

        return StringUtils.isNotBlank(req.getLogonId()) &&
                StringUtils.isNotBlank(req.getNewLogonId()) &&
                !StringUtils.equalsIgnoreCase(req.getLogonId(), req.getNewLogonId());
    }

}
