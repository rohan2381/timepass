package com.homedepot.customer.datasync.profile;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.model.*;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.util.GlobalConstants;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Optional;

/**
 * Created by Nitin on 10/25/16.
 */
@Component
public class ProfileHelper {

    public void mapSvocToWCSModel(Account svocAaccount, Account wcsAccount) {

        Profile wcsProfile = wcsAccount.getProfile();
        Profile svocProfile = svocAaccount.getProfile();

        if(svocProfile.getName() != null) {
            Name wcsName = new Name();
            wcsProfile.setName(wcsName);
            Optional.ofNullable(svocProfile.getName().getFirstName()).ifPresent(fn -> wcsName.setFirstName(WordUtils.capitalizeFully(fn)));
            Optional.ofNullable(svocProfile.getName().getLastName()).ifPresent(ln -> wcsName.setLastName(WordUtils.capitalizeFully(ln)));
        }
        Optional.ofNullable(svocProfile.getEmailId()).ifPresent(wcsProfile::setEmailId);
        Optional.ofNullable(svocProfile.getPassword()).ifPresent(wcsProfile::setPassword);
        Optional.ofNullable(svocProfile.getConfirmPassword()).ifPresent(wcsProfile::setConfirmPassword);

        Optional.ofNullable(svocProfile.getZipCode()).ifPresent(wcsProfile::setZipCode);
        Optional.ofNullable(svocProfile.getTaxExemptId()).ifPresent(wcsProfile::setTaxExemptId);
        Optional.ofNullable(svocProfile.getLocalStoreId()).ifPresent(wcsProfile::setLocalStoreId);
        Optional.ofNullable(svocProfile.getMergeAcctOpt()).ifPresent(wcsProfile::setMergeAcctOpt);

        String loyaltyEnrollmentIndicator = svocProfile.getLoyaltyEnrollmentIndicator();
        if(StringUtils.isNotEmpty(loyaltyEnrollmentIndicator) &&
                (loyaltyEnrollmentIndicator.equals(GlobalConstants.STR_Y) || loyaltyEnrollmentIndicator.equals(GlobalConstants.STR_P))) {
            wcsProfile.setIsContractor(true);
            wcsProfile.setIsTradesman(true);
        }

        Optional.ofNullable(svocAaccount.getProfilePhones()).ifPresent(profilePhones -> {
            Phone mobilePhone = profilePhones.getPhone()
                                    .stream()
                                    .filter(profPhone -> profPhone.getType().equals(GlobalConstants.PHONE_TYPE_MOBILE))
                                    .map(mobPhone -> new Phone(mobPhone.getNumber(), GlobalConstants.WCS_PHONE_TYPE_MOBILE, null, mobPhone.getContactMethodEnumeration(), null, null, null))
                                    .findAny().orElse(null);

            Optional.ofNullable(mobilePhone).ifPresent(phone -> {
                if(StringUtils.isEmpty(phone.getNumber()) && !StringUtils.isEmpty(phone.getContactMethodEnumeration())) {
                    // Handle Delete Profile Phone Scenario
                    ProfilePhones profPhones = new ProfilePhones();
                    wcsAccount.setProfilePhones(profPhones);
                } else {
                    phone.setContactMethodEnumeration(null);
                    ProfilePhones profPhones = new ProfilePhones(Arrays.asList(phone));
                    wcsAccount.setProfilePhones(profPhones);
                }
            });
        });
    }

    public void mapWCSToSvocModel(Account wcsAccount, Account svocAaccount) {
        Name name = new Name();
        if(wcsAccount.getProfile() != null) {
            if(wcsAccount.getProfile().getName() != null) {
                name.setFirstName(wcsAccount.getProfile().getName().getFirstName());
                name.setLastName(wcsAccount.getProfile().getName().getLastName());
                if (("self").equalsIgnoreCase(wcsAccount.getProfile().getName().getFirstName())) {
                    wcsAccount.getProfile().getName().setFirstName(null);
                }
                
                if (("self").equalsIgnoreCase(wcsAccount.getProfile().getName().getLastName())) {
                    wcsAccount.getProfile().getName().setLastName(null);
                }
                
                if(wcsAccount.getProfile().getName().getFirstName()==null && wcsAccount.getProfile().getName().getLastName()==null){
                    name = null;
                }
                
                svocAaccount.getProfile().setName(name);
            }
            svocAaccount.getProfile().setZipCode(wcsAccount.getProfile().getZipCode());
            svocAaccount.getProfile().setTaxExemptId(wcsAccount.getProfile().getTaxExemptId());
            svocAaccount.getProfile().setLocalStoreId(wcsAccount.getProfile().getLocalStoreId());
            svocAaccount.getProfile().setPreferredLanguageDescription(wcsAccount.getProfile().getPreferredLanguageDescription());
            svocAaccount.getProfile().setPreferredLanguageId("en_US");
            svocAaccount.getProfile().setMergeAcctOpt(wcsAccount.getProfile().getMergeAcctOpt());
            if ((null != wcsAccount.getProfile().getIsContractor() && wcsAccount.getProfile().getIsContractor())
                    || (null != wcsAccount.getProfile().getIsTradesman() && wcsAccount.getProfile().getIsTradesman())) {
                svocAaccount.getProfile().setLoyaltyEnrollmentIndicator(GlobalConstants.STR_Y);
            } else {
                svocAaccount.getProfile().setLoyaltyEnrollmentIndicator(GlobalConstants.STR_N);
            }
        }
        ProfilePhones profilePhones = wcsAccount.getProfilePhones();
        if(null != profilePhones){
            for(Phone phone : profilePhones.getPhone()){
                if((GlobalConstants.WCS_PHONE_TYPE_MOBILE).equals(phone.getType())){
                    Phone svocPhone = new Phone();
                    svocPhone.setNumber(phone.getNumber());
                    svocPhone.setPrimaryFlag(GlobalConstants.STR_N);
                    svocPhone.setSecondaryFlag(GlobalConstants.STR_N);
                    svocPhone.setContactMethodEnumeration("PHN");

                    svocPhone.setType(GlobalConstants.PHONE_TYPE_MOBILE);
                    svocPhone.setLastModifiedDate(phone.getLastModifiedDate());
                    ProfilePhones svocProfPhones = new ProfilePhones(Arrays.asList(svocPhone));
                    svocAaccount.setProfilePhones(svocProfPhones);
                }
            }
        }
        svocAaccount.setLastModifiedDate(wcsAccount.getLastModifiedDate());
        svocAaccount.getProfile().setEmailId(wcsAccount.getProfile().getEmailId());

    }

    public void throwGenericIntegrationException(Exception uEx) throws IntegrationException {
        Errors errors = new Errors();
        Error error = new Error();
        errors.setErrors(Arrays.asList(error));
        error.setErrorCode(ErrorCode.SYSTEM_ERROR);
        throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, uEx);
    }

}
