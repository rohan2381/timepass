package com.homedepot.customer.datasync.profile;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.homedepot.customer.datasync.util.DataSyncUtil;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.model.Account;
import com.homedepot.customer.request.ProfileRequest;

/**
 * Created by rxb1809 on Aug 31, 2016
 * This class controls and triggers the WCS sync up of all CU operations on the profile component.  
 * It uses Spring AOP for execution
 */
//@Aspect
@Component
public class ProfileSyncAspect {

    @Autowired
    ProfileSyncExecutor profileExecutor;

    @Autowired
    CustomerAccountRequestContext reqContext;
    
    @Autowired
    private DataSyncUtil dataSyncUtil;
    
    @AfterReturning(pointcut="execution(* com.homedepot.customer.service.IProfileService.updateProfile(..)) && args(customerAccountId, profileRequest)", 
            returning="svocSavedProfile")
    public void updateUserProfileInWCS(JoinPoint jp, String customerAccountId, ProfileRequest profileRequest, Account svocSavedProfile){

        if(!reqContext.isReqServedFromWCS()) {
            Account svocSavedProfileNew = new Account();
            BeanUtils.copyProperties(svocSavedProfile, svocSavedProfileNew);
            profileExecutor.updateUserProfileAsync(customerAccountId, profileRequest, svocSavedProfileNew, false);
            dataSyncUtil.pauseAroundDataSync(); 
        }
    }
}
