package com.homedepot.customer.datasync.profile;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.Future;

import javax.servlet.http.Cookie;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.homedepot.customer.datasync.address.AddressSyncExecutor;
import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.integration.passport.THDPassportServiceFacade;
import com.homedepot.customer.integration.wcs.WCSCrossRefServiceFacade;
import com.homedepot.customer.integration.wcs.WCSProfileServiceFacade;
import com.homedepot.customer.integration.wcs.dto.WCSUserIdentity;
import com.homedepot.customer.integration.wcs.dto.crossref.CrossRefInfo;
import com.homedepot.customer.model.Account;
import com.homedepot.customer.model.Name;
import com.homedepot.customer.model.Phone;
import com.homedepot.customer.model.Profile;
import com.homedepot.customer.request.AddressRequest;
import com.homedepot.customer.request.IdentityRequest;
import com.homedepot.customer.request.ProfileRequest;
import com.homedepot.customer.request.UserRegistrationRequest;
import com.homedepot.customer.util.GlobalConstants;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Aug 24, 2016
 * This class is used to do a near real-time calls to WCS to sync profile info in an asynchronous fashion
 */
@Service
@Slf4j
public class ProfileSyncExecutor {

    @Autowired
    private WCSProfileServiceFacade wcsProfileFacade;

    @Autowired
    private THDPassportServiceFacade passportServiceFacade;

    @Autowired
    private WCSCrossRefServiceFacade wcsCrossRefServiceFacade;

    @Autowired
    ProfileHelper profileHelper;

    @Autowired
    AddressSyncExecutor addressSyncExecutor;

    @Async("profileTaskExecutor")
    public Account updateUserProfileAsync(String customerAccountId, ProfileRequest profileRequest,
            Account svocSavedProfile, boolean passwordSync) {

        return updateUserProfile(customerAccountId, profileRequest, svocSavedProfile, passwordSync);
    }

    public Account updateUserProfile(String customerAccountId, ProfileRequest profileRequest, Account svocSavedProfile, boolean passwordSync) {
        Account updateProfileAccountResp = null;
        try{
            log.debug("BEGIN: Synching up profile update in WCS for customer {} : Profile details {}",
                        customerAccountId, profileRequest.toString());

            // Step 1: Look up WCS member Id
            CrossRefInfo crossRefInfo = wcsCrossRefServiceFacade.getCrossRefInfoForSVOCCustAcctId(customerAccountId);
            if(crossRefInfo != null) {
                String wcsMemberId = crossRefInfo.getWcsMemberId();

                // Step 2: Get Token for the CSR account
                String ssoToken = passportServiceFacade.getToken();

                Account wcsAccount = new Account();
                Profile wcsProfile = new Profile();
                wcsAccount.setProfile(wcsProfile);
                profileHelper.mapSvocToWCSModel(profileRequest.getAccount(), wcsAccount);

                // Step 3: Call WCS MAML CSR API
                updateProfileAccountResp = wcsProfileFacade.updateUserProfileCSR(wcsMemberId, wcsAccount, ssoToken);
                log.debug("WCS profile successfully updated");

                // Step 4: update xref timestamp
                crossRefInfo.setAddresses(null);
                crossRefInfo.setPayments(null);
                crossRefInfo.setLastUpdUser(GlobalConstants.APPLICATION_ID);
                wcsCrossRefServiceFacade.updateCrossRefInfo(crossRefInfo, ssoToken);
                log.debug("CrossRef timestamp successfully updated");

                //Step 5: Create Address for Pro Upgrades
                if(("Y").equals(profileRequest.getAccount().getProfile().getLoyaltyEnrollmentIndicator()) &&
                    profileRequest.getAccount().getAddress() != null) {
                        AddressRequest addressRequest = new AddressRequest();
                        svocSavedProfile.getAddress().get(0).setName(profileRequest.getAccount().getProfile().getName());
                        List<Phone> phones = svocSavedProfile.getProfilePhones().getPhone();
                        phones.forEach(phone -> {
                            if("Y".equals(phone.getPrimaryFlag())) {
                                svocSavedProfile.getAddress().get(0).setPrimaryPhone(phone);
                            }
                        });
                    addressRequest.setAddress(profileRequest.getAccount().getAddress());
                    addressSyncExecutor.syncCreateAddress(addressRequest, customerAccountId, svocSavedProfile.getAddress());
                    log.debug("Address successfully created");
                }

                // Reset Password - Unlock the WCS user account.
                if(passwordSync)
                    wcsProfileFacade.unlockUser(wcsMemberId, ssoToken);

                log.debug("END: Synching up profile update in WCS for customer {} : Profile details {}",
                            customerAccountId, profileRequest.toString());
            }
        }catch(IntegrationException iEx){
            log.error("ERROR: Synching up profile update in WCS for customer {} : Profile details {}",
                        customerAccountId, profileRequest.toString() + " , Exception: "+ ExceptionUtils.getMessage(iEx));
            log.error("Exception details --> HTTP_STATUS={}, ERROR_MESSAGE={}, ERROR_CAUSE={}",iEx.getHttpStatus(),iEx.getMessage(),iEx);
        }catch(Exception ex){
            log.error("ERROR: Synching up profile update in WCS for customer {} : Profile details {}",
                        customerAccountId, profileRequest.toString()+" , Root Cause:"+ ExceptionUtils.getRootCause(ex));
        }
        return updateProfileAccountResp;
    }

    @Async("profileTaskExecutor")
    public Future<WCSUserIdentity> asyncWCSAuthenticateUser(IdentityRequest authRequest, Cookie[] cookies) throws CustomerAccountServiceException {
        WCSUserIdentity wcsUserIdentity = null;
        try {
            wcsUserIdentity = wcsProfileFacade.authenticateUser(authRequest.getLogonId(), authRequest.getPassword(), cookies);
            if(wcsUserIdentity!=null){
                Account account = getUserProfileFromWCS(wcsUserIdentity.getUserId());
                if(account!=null){
                    wcsUserIdentity.setAccount(account);
                }
            }
            
        } catch (IntegrationException ex) {
            throw new CustomerAccountServiceException(ex.getErrors(), ex.getHttpStatus(), ex);
        }
        return new AsyncResult<>(wcsUserIdentity);
    }
    
    public WCSUserIdentity wcsRegisterUser(UserRegistrationRequest request,
                                           String svocId, Account svocSavedProfile) throws CustomerAccountServiceException {
        WCSUserIdentity wcsUserIdentity;
        try {
            wcsUserIdentity = wcsProfileFacade.registerUser(request.getEmailId(),
                                                            request.getPassword(),
                                                            request.getConfirmPassword(),
                                                            request.getFirstName(),
                                                            request.getLastName(),
                                                            request.getZipCode(),
                                                            svocId);
            if(svocId != null) {
                createCrossRef(wcsUserIdentity, svocId);

                // Create Address for Pro Registration
                if (("Y").equals(request.getLoyaltyEnrollmentIndicator()) && request.getAddress() != null) {
                    AddressRequest addressRequest = new AddressRequest();
                    Name name = new Name();
                    name.setFirstName(request.getFirstName() != null ? request.getFirstName() : "self");
                    name.setLastName(request.getLastName() != null ? request.getLastName() : "self");

                    svocSavedProfile.getAddress().get(0).setName(name);
                    List<Phone> phones = svocSavedProfile.getProfilePhones().getPhone();
                    phones.forEach(phone -> {
                        if ("Y".equals(phone.getPrimaryFlag())) {
                            svocSavedProfile.getAddress().get(0).setPrimaryPhone(phone);
                        }
                    });
                    addressRequest.setAddress(Collections.singletonList(request.getAddress()));
                    addressSyncExecutor.syncCreateAddress(addressRequest, svocId, svocSavedProfile.getAddress());
                }
            }
        } catch (IntegrationException ex) {
            throw new CustomerAccountServiceException(ex.getErrors(), ex.getHttpStatus(), ex);
        }
        return wcsUserIdentity;
    }

    @Async("profileTaskExecutor")
    private void createCrossRef(WCSUserIdentity wcsUserIdentity, String svocId) {

        CrossRefInfo crossRefInfo = new CrossRefInfo();
        crossRefInfo.setSvocCustAcctId(svocId);
        crossRefInfo.setWcsMemberId(wcsUserIdentity.getUserId());
        crossRefInfo.setLastUpdUser(GlobalConstants.APPLICATION_ID);
        try {
            String ssoToken = passportServiceFacade.getToken();
            wcsCrossRefServiceFacade.saveCrossRefInfo(crossRefInfo, ssoToken);
        } catch (IntegrationException e) {
            log.error("Error while creating cross ref data for {}, exception {}", svocId +" : "+ wcsUserIdentity.getUserId(), ExceptionUtils.getRootCause(e));
        }
    }

    public Account getUserProfileFromWCS(String memberId) throws CustomerAccountServiceException {

        Account userProfile;
        try {
            String ssoToken = passportServiceFacade.getToken();
            userProfile = wcsProfileFacade.getUserInfoCSR(memberId, ssoToken);
        } catch (IntegrationException ex) {
            throw new CustomerAccountServiceException(ex.getErrors(), ex.getHttpStatus(), ex);
        }
        return userProfile;
    }

}
