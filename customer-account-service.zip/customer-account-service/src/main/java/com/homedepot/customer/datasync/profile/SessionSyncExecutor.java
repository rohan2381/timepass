package com.homedepot.customer.datasync.profile;

import java.io.UnsupportedEncodingException;

import javax.servlet.http.Cookie;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.repository.IIdentityRepository;
import com.homedepot.customer.util.SessionHelper;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Dec 24, 2016
 * This class is used to asynchronously perform wcs session operations
 */
@Service
@Slf4j
public class SessionSyncExecutor {
    
    @Autowired
    SessionHelper sessionHelper;
    
    @Autowired
    IIdentityRepository identityRepository;
   
    @Async("identityTaskExecutor")
    public void validateWCSTokenAsync(Cookie[] cookies){
        String errorMessage = "Async WCS token validation Error ";
        try {
            log.debug("Start Async WCS token validation");
            String wcsUserToken = sessionHelper.extractWCSTokenFromCookie(cookies);
            
            if(StringUtils.isNotBlank(wcsUserToken)){
                String wcsMemberId = identityRepository.validateWCSSession(wcsUserToken, true, cookies);
                if(wcsMemberId!=null){
                    log.debug("Async WCS token validation complete for wcs member Id "+wcsMemberId);
                }else{
                    log.error(errorMessage);
                }
            }else{
                log.error("WCS token missing in the request. Can not validate WCS session");
            }            
        } catch (RepositoryException rEx) {
            log.error(errorMessage+ExceptionUtils.getRootCause(rEx));
        } catch (UnsupportedEncodingException uEx) {
            log.error(errorMessage+ExceptionUtils.getRootCause(uEx));
        }
    }
}
