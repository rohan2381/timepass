package com.homedepot.customer.datasync.util;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.homedepot.customer.util.GlobalConstants;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Aug 31, 2016
 *
 */
@Component
@Slf4j
public class DataSyncUtil {
    
    @Autowired
    private Environment environment;

    /**
     * This artifical pause is induced to allow the request context to be available for subsequent async child threads. 
     * Failure to do this will send the response back and appropriate context will not be available. 
     * Currently the pause is for 3 seconds which is within the SLA for the async operations. 
     * *** Applicable for DEV Profile Only ***
     */
    public void pauseAroundDataSync(){
        if(Arrays.stream(environment.getActiveProfiles()).anyMatch(env -> GlobalConstants.SPRING_PFOFILE_DEV.equalsIgnoreCase(env))) {  
            ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if(requestAttributes!=null && requestAttributes.getRequest()!=null 
                    && requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV) !=null){
                log.debug(GlobalConstants.THREAD_SLEEP_DATA_SYNC_MSG);
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {                    
                    log.error("Error pausing during data sync");
                }
            }            
        }
    }
}
