package com.homedepot.customer.exception;

import org.springframework.http.HttpStatus;

import com.homedepot.customer.model.Errors;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Created by rxb1809 on Jul 31, 2016
 *
 */
@EqualsAndHashCode(callSuper = true)
public class AuthenticationException extends CustomerAccountServiceException {

    private static final long serialVersionUID = -2972131492213592761L;

    public AuthenticationException(Errors errors) {
        super(errors, HttpStatus.UNAUTHORIZED);
    }

}
