package com.homedepot.customer.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.http.HttpStatus;

import com.homedepot.customer.model.Errors;

/**
 * Created by rxb1809 on Jul 31, 2016
 * 
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class CustomerAccountServiceException extends Exception {

    private static final long serialVersionUID = 5073654202029216137L;
    private transient Errors errors; // NOSONAR
    private HttpStatus httpStatus; // NOSONAR
    private String errorMessage; // NOSONAR
    
    public CustomerAccountServiceException(Errors errors, HttpStatus httpStatus) {
        this.errors = errors;
        this.httpStatus = httpStatus;       
    }

    public CustomerAccountServiceException(Errors errors, HttpStatus httpStatus, String errorMessage) {
        super(errorMessage);
        this.errors = errors;
        this.httpStatus = httpStatus;       
    }

    public CustomerAccountServiceException(Errors errors, HttpStatus httpStatus, Throwable throwable) {
        super(throwable);
        this.errors = errors;
        this.httpStatus = httpStatus;
    }

    public CustomerAccountServiceException(Errors errors, HttpStatus httpStatus, String errorMessage, Throwable throwable) {
        super(errorMessage,throwable);
        this.errors = errors;
        this.httpStatus = httpStatus;
    }
    public CustomerAccountServiceException(HttpStatus httpStatus, Throwable throwable) {
        super(throwable);
        this.httpStatus = httpStatus;
    }

    public CustomerAccountServiceException(Errors errors, String errorMessage) {
        super(errorMessage);
        this.errors = errors;
    }

    public CustomerAccountServiceException(Errors errors, String errorMessage, Throwable throwable) {
        super(errorMessage, throwable);
        this.errors = errors;
    }

    public CustomerAccountServiceException(Errors errors, Throwable throwable) {
        super(throwable);
        this.errors = errors;
    }

    public CustomerAccountServiceException(HttpStatus httpStatus, String errorMessage, Throwable throwable) {
        super(errorMessage, throwable);
        this.httpStatus = httpStatus;
    }

    @Override
    public String getMessage() {
        if (errorMessage != null) {
            return errorMessage;
        } else {
            return super.getMessage();
        }
    }
}
