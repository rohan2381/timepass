package com.homedepot.customer.exception;

import org.springframework.http.HttpStatus;

import com.homedepot.customer.model.Errors;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Created by rxb1809 on Jul 31, 2016
 *
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class GenericSystemException extends CustomerAccountServiceException {

    private static final long serialVersionUID = 2122235913318909724L;

    public GenericSystemException(Errors errors) {
        super(errors, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    public GenericSystemException(HttpStatus httpStatus, Throwable throwable) {
        super(httpStatus, throwable);
    }

}
