package com.homedepot.customer.exception;

import org.springframework.http.HttpStatus;

import com.homedepot.customer.model.Errors;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Created by rxb1809 on Jul 31, 2016
 *
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class IntegrationException extends CustomerAccountServiceException {

    private static final long serialVersionUID = -8817904645795908838L;
    
    public IntegrationException(Errors errors, HttpStatus httpStatus) {
        super(errors, httpStatus);
    }

    public IntegrationException(Errors errors, HttpStatus httpStatus, String errorMessage) {
        super(errors, httpStatus, errorMessage);
    }
    
    public IntegrationException(Errors errors, HttpStatus httpStatus, String errorMessage, Throwable throwable) {
        super(errors, httpStatus, errorMessage, throwable);
    }

    public IntegrationException(Errors errors, HttpStatus httpStatus, Throwable throwable) {
        super(errors, httpStatus, throwable);
    }

    public IntegrationException(HttpStatus httpStatus, String errorMessage, Throwable throwable) {
        super(httpStatus, errorMessage, throwable);
    }

}
