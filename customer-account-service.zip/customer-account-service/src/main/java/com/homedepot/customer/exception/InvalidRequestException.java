package com.homedepot.customer.exception;

import org.springframework.http.HttpStatus;

import com.homedepot.customer.model.Errors;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Created by rxb1809 on Jul 31, 2016
 *
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class InvalidRequestException extends CustomerAccountServiceException {

    private static final long serialVersionUID = 347888595014642831L;

    public InvalidRequestException(Errors errors) {
        super(errors, HttpStatus.BAD_REQUEST);
    }

}
