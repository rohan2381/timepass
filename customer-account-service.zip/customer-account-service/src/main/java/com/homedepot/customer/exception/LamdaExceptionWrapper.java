package com.homedepot.customer.exception;

/**
 * Created by rxb1809 on Aug 22, 2016 This is a wrapper exception to get around
 * the limitation of Java 8 to be able to throw/catch checked exceptions from
 * lambda expressions
 */
public class LamdaExceptionWrapper extends RuntimeException {

    private static final long serialVersionUID = -6534663027450282710L;

    public LamdaExceptionWrapper(Throwable cause) {
        super(cause);
    }

}
