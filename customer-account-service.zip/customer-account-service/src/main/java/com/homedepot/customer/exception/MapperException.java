package com.homedepot.customer.exception;

import org.springframework.http.HttpStatus;

import com.homedepot.customer.model.Errors;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Created by rxb1809 on Jul 31, 2016
 *
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MapperException extends CustomerAccountServiceException {

    private static final long serialVersionUID = 7717842009546823078L;

    public MapperException(Errors errors, HttpStatus httpStatus, Throwable throwable) {
        super(errors, httpStatus, throwable);
    }

}
