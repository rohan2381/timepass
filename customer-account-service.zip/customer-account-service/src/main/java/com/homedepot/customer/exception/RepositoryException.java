package com.homedepot.customer.exception;

import org.springframework.http.HttpStatus;

import com.homedepot.customer.model.Errors;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Created by rxb1809 on Aug 10, 2016
 *
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class RepositoryException extends CustomerAccountServiceException {

    private static final long serialVersionUID = 6174226581502298459L;

    public RepositoryException(Errors errors, HttpStatus httpStatus, Throwable throwable) {
        super(errors, httpStatus, throwable);
    }
}
