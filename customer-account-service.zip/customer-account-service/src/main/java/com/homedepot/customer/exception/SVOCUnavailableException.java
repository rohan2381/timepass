package com.homedepot.customer.exception;

import org.springframework.http.HttpStatus;

import com.homedepot.customer.model.Errors;

/**
 * Created by rxb1809 on Dec 4, 2016
 * This exception class is used to capture 500 errors and resource access exceptions while connecting to SVOC
 */
public class SVOCUnavailableException extends CustomerAccountServiceException{

    private static final long serialVersionUID = 4010270666150595157L;

    public SVOCUnavailableException(Errors errors, HttpStatus httpStatus, Throwable throwable) {
        super(errors, httpStatus, throwable);
    }
}
