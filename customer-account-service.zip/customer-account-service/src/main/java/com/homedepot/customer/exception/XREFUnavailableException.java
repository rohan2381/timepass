package com.homedepot.customer.exception;

import org.springframework.http.*;

import com.homedepot.customer.model.*;

/**
 * Created by nxw6207
 * This exception class is used to capture 500 errors and resource access exceptions while connecting to SVOC
 */
public class XREFUnavailableException extends CustomerAccountServiceException{

    private static final long serialVersionUID = 4010270666150595157L;

    public XREFUnavailableException(Errors errors, HttpStatus httpStatus, Throwable throwable) {
        super(errors, httpStatus, throwable);
    }
}
