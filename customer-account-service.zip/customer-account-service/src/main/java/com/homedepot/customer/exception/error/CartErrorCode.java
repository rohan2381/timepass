package com.homedepot.customer.exception.error;

import org.springframework.http.*;

/**
 * Created by nxw6207 on 8/4/17.
 */
public enum CartErrorCode implements ErrorCode {

    ERROR_CODE_USERID_NOTFOUND("CART_ERR_100", HttpStatus.BAD_REQUEST),
    ERROR_CODE_CART_MIGRATE_EXP("CART_ERR_101", HttpStatus.INTERNAL_SERVER_ERROR),
    ERROR_CODE_ITEM_LIST_RESTRICT("CART_ERR_102", HttpStatus.BAD_REQUEST),
    SYSTEM_ERROR("GEN_ERR_500",HttpStatus.INTERNAL_SERVER_ERROR);

    private HttpStatus httpStatus;
    private String code;

    private CartErrorCode(String code, HttpStatus httpStatus) {
        this.code = code;
        this.httpStatus = httpStatus;
    }
    
    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public static CartErrorCode valueOfCode(String code) {
        for (CartErrorCode errorCode : values()) {
            if (errorCode.getCode().equalsIgnoreCase(code)) {
                return errorCode;
            }
        }
        throw new IllegalArgumentException("No enum const " + CartErrorCode.class + " defined for error code "
                + code);
    }

    @Override
    public String getCode() {
        return code;
    }

    public static HttpStatus valueOfHttpStatus(String code) {
        for (CartErrorCode errorCode : values()) {
            if (errorCode.getCode().equalsIgnoreCase(code)) {
                return errorCode.getHttpStatus();
            }
        }
        throw new IllegalArgumentException(
                "No enum const " + CartErrorCode.class + " defined for error code " + code);
    }
}
