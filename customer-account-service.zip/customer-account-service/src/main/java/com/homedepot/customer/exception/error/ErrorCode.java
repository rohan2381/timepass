package com.homedepot.customer.exception.error;

import org.springframework.stereotype.Component;

/**
 * Created by rxb1809 on Aug 02, 2016
 *
 */
@Component
public interface ErrorCode {

    public static final String SYSTEM_ERROR = "GEN_ERR_500";

    public String getCode();

}
