package com.homedepot.customer.exception.error;

import org.springframework.http.HttpStatus;

/**
 * Created by rxb1809 on Aug 13, 2016
 *
 */
public enum IdentityErrorCode implements ErrorCode {

    INVALID_CHANNEL_ID("AUTH_ERR_100",HttpStatus.BAD_REQUEST),
    MISSING_USER_TOKEN("AUTH_ERR_101",HttpStatus.UNAUTHORIZED),
    INVALID_CREDENTIALS("AUTH_ERR_102",HttpStatus.UNAUTHORIZED),
    ACCOUNT_LOCKED("AUTH_ERR_103",HttpStatus.UNAUTHORIZED),
    BAD_REQUEST("AUTH_ERR_104",HttpStatus.BAD_REQUEST),
    USER_NOT_FOUND("AUTH_ERR_106",HttpStatus.NOT_FOUND),
    AUTHORIZATION_FAILED("AUTH_ERR_112", HttpStatus.UNAUTHORIZED),
    SELF_SERVICE_RESOURCE_NOT_AVAILABLE("AUTH_ERR_113",HttpStatus.NOT_FOUND),
    SELF_SERVICE_EMAIL_MISSING("AUTH_ERR_114",HttpStatus.BAD_REQUEST),
    SELF_SERVICE_EMAIL_ALREADY_EXIST("AUTH_ERR_115",HttpStatus.BAD_REQUEST),
    USER_NOT_AUTHORIZED("AUTH_ERR_105",HttpStatus.UNAUTHORIZED),
    INVALID_USER_ID_MISSING("AUTH_ERR_107",HttpStatus.BAD_REQUEST),
    INVALID_PASSWORD_MISSING("AUTH_ERR_108",HttpStatus.BAD_REQUEST),
    INVALID_IDENTITY_MISSING("AUTH_ERR_109",HttpStatus.BAD_REQUEST),
    ACCOUNT_WILL_BE_LOCKED("AUTH_ERR_110",HttpStatus.UNAUTHORIZED),
    INVALID_RESET_PASSWORD_TOKEN_MISSING("AUTH_ERR_111",HttpStatus.BAD_REQUEST),
    INVALID_EMAIL("UREG_ERR_101",HttpStatus.BAD_REQUEST),
    INVALID_PASSWORD("UREG_ERR_103",HttpStatus.BAD_REQUEST),
    INVALID_CONFIRM_PASSWORD_MISSING("UREG_ERR_104",HttpStatus.BAD_REQUEST),
    USER_EXIST_IN_SVOC_IAM("UREG_ERR_158",HttpStatus.BAD_REQUEST),
    USER_EXIST_IN_SVOC_ONLY("UREG_ERR_159",HttpStatus.BAD_REQUEST),
    INVALID_PASSWORD_CONFIRMPASSWORD_MATCH("UREG_ERR_106",HttpStatus.BAD_REQUEST),
    PASSWORD_AND_EMAIL_MATCH("UREG_ERR_164",HttpStatus.BAD_REQUEST),
    PASSWORD_IN_DICTIONARY("UREG_ERR_165",HttpStatus.BAD_REQUEST),
    PASSWORD_REPEATING_CHAR("UREG_ERR_166",HttpStatus.BAD_REQUEST),
    PASSWORD_LENGTH_INVALID("UREG_ERR_167",HttpStatus.BAD_REQUEST),
    HOMEDEPOTID_NOT_ALLOWED_FOR_PRO_USER("UREG_ERR_169",HttpStatus.BAD_REQUEST),
    PASSWORD_EXIST_IN_HISTORY("AUTH_ERR_116",HttpStatus.BAD_REQUEST),
    UNEXPECTED_CHARACTER_IN_NUMERIC_VALUE("AUTH_ERR_117",HttpStatus.BAD_REQUEST),
    INVALID_NEW_EMAIL_ID("AUTH_ERR_118",HttpStatus.BAD_REQUEST),
    INVALID_NEW_EMAIL_MISSING("AUTH_ERR_119",HttpStatus.BAD_REQUEST),
    SYSTEM_ERROR("GEN_ERR_500",HttpStatus.INTERNAL_SERVER_ERROR),
    INVALID_EMAIL_DUPLICATE("UREG_ERR_143",HttpStatus.BAD_REQUEST),
    INVALID_THD_ENVIRONMENT("ENV_ERR_100",HttpStatus.BAD_REQUEST),
    ACCOUNT_FORCED_RESET("AUTH_ERR_PWD_RESET_120",HttpStatus.UNAUTHORIZED);

    private String code;

    private HttpStatus httpStatus;

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    private IdentityErrorCode(String code, HttpStatus httpStatus) {
        this.code = code;
        this.httpStatus = httpStatus;
    }


    private IdentityErrorCode(String code) {
        this.code = code;
    }

    @Override
    public String getCode() {
        return code;
    }

    public static IdentityErrorCode valueOfCode(String code) {
        for (IdentityErrorCode errorCode : values()) {
            if (errorCode.getCode().equalsIgnoreCase(code)) {
                return errorCode;
            }
        }
        throw new IllegalArgumentException("No enum const" + IdentityErrorCode.class + " defined for error code " + code);
    }
}
