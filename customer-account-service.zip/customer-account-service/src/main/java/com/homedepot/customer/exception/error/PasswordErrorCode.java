package com.homedepot.customer.exception.error;

/**
 * Created by rxm4390 on Jan 18, 2017
 *
 */
public enum PasswordErrorCode implements ErrorCode {

    PASSWORD_IN_DICTIONARY("PASS_ERR_003"),
    PASSWORD_REPEATING_CHAR("PASS_ERR_002"),
    PASSWORD_LENGTH_INVALID("PASS_ERR_001"),
    INVALID_PASSWORD_MISSING("PASS_ERR_000"),
    CUST_ID_NOT_FOUND_IN_SVOC("PASS_ERR_004"),//SVOC id required for set password
    INVALID_CUST_ID_MISSING("PASS_ERR_005"),//SVOC id required for set password
    INVALID_CONFIRM_PASSWORD_MISSING("PASS_ERR_006"),
    INVALID_PASSWORD_CONFIRMPASSWORD_MATCH("PASS_ERR_007"),
    PASSWORD_AND_EMAIL_MATCH("PASS_ERR_008"),
    INVALID_RESET_PASSWORD_TOKEN_MISSING("PASS_ERR_009"),
    INVALID_EMAIL("PASS_ERR_010"),
    CUST_ID_FOUND_IN_IAM("PASS_ERR_011"),
    CUST_ID_NOT_FOUND_IN_IAM("PASS_ERR_012"),
    INVALID_SVOC_ID_EMAIL_COMBO("PASS_ERR_013"),
    USER_QUALIFIES_FOR_SET_PASSWORD("UREG_ERR_159"),
    SYSTEM_ERROR("GEN_ERR_500");

    private String code;

    private PasswordErrorCode(String code) {
        this.code = code;
    }

    @Override
    public String getCode() {
        return code;
    }

    public static PasswordErrorCode valueOfCode(String code) {
        for (PasswordErrorCode errorCode : values()) {
            if (errorCode.getCode().equalsIgnoreCase(code)) {
                return errorCode;
            }
        }
        throw new IllegalArgumentException("No enum const" + PasswordErrorCode.class + "defined for error code " + code);
    }
}
