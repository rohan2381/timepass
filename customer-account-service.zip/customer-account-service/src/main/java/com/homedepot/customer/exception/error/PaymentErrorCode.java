package com.homedepot.customer.exception.error;

import org.springframework.http.HttpStatus;

/**
 * Created by rxb1809 on Aug 02, 2016 Error codes for payment cards operations
 */
public enum PaymentErrorCode implements ErrorCode {

    ERR_CODE_PROX_ADD_PAYMENT_CARD_INVALID_XREF_CARD("PYMTCRD_ERR_100",HttpStatus.BAD_REQUEST),
    INVALID_PAYMENT_PAGESIZE_MISSING("PYMTCRD_ERR_101",HttpStatus.BAD_REQUEST),
    INVALID_PAYMENT_PAGENUMBER_MISSING("PYMTCRD_ERR_102",HttpStatus.BAD_REQUEST),
    INVALID_PAYMENT_PAGENUMBER("PYMTCRD_ERR_103",HttpStatus.BAD_REQUEST),
    INVALID_PAYMENT_PAGESIZE("PYMTCRD_ERR_104",HttpStatus.BAD_REQUEST),
    ERRORCODE_PYMTCARD_INVALID_CARD_HOLDER_NAME("PYMTCRD_ERR_105",HttpStatus.BAD_REQUEST),
    ERRORCODE_PYMTCARD_INVALID_CARD_NUMBER("PYMTCRD_ERR_106",HttpStatus.BAD_REQUEST),
    ERRORCODE_PYMTCARD_INVALID_CARD_BRAND("PYMTCRD_ERR_107",HttpStatus.BAD_REQUEST),
    ERRORCODE_PYMTCARD_INVALID_CARD_EXPIRY_MONTH("PYMTCRD_ERR_108",HttpStatus.BAD_REQUEST),
    ERRORCODE_PYMTCARD_INVALID_CARD_EXPIRY_YEAR("PYMTCRD_ERR_109",HttpStatus.BAD_REQUEST),

    ERRORCODE_PYMTCARD_CARD_HOLDER_NAME_LENGTH_MAX("PYMTCRD_ERR_111",HttpStatus.BAD_REQUEST),
    INVALID_BILLING_ADDRESS_MISSING("PYMTCRD_ERR_113",HttpStatus.BAD_REQUEST),
    PAYMENT_ID_NOT_FOUND("PYMTCRD_ERR_115",HttpStatus.NOT_FOUND),
    ERRORCODE_PYMTCARD_ERRORS_EXPIRY_YEAR_NOT_APPL("PYMTCRD_ERR_116",HttpStatus.BAD_REQUEST),
    ERRORCODE_PYMTCARD_ERRORS_EXPIRY_MONTH_NOT_APPL("PYMTCRD_ERR_117",HttpStatus.BAD_REQUEST),
    ERRORCODE_PYMTCARD_ERRORS_EXPIRY_YEAR_EXCEED("PYMTCRD_ERR_118",HttpStatus.BAD_REQUEST),
    ERRORCODE_PROFILE_ID_NOT_FOUND("PYMTCRD_ERR_119",HttpStatus.BAD_REQUEST),
    ERRORCODE_PROFILE_ID_PRESENT("PYMTCRD_ERR_120",HttpStatus.BAD_REQUEST),
    ERRORCODE_PAYMENT_CARD_NOT_FOUND_FOR_PAYMENT_ID("PYMTCRD_ERR_121",HttpStatus.BAD_REQUEST),
    ERRORCODE_ADDR_PRIMARY_PHONE_NOT_FOUND("PYMTCRD_ERR_125",HttpStatus.BAD_REQUEST),
    ERRORCODE_PYMTCARD_ERROR_MULTIPLE_CARD( "PYMTCRD_ERR_126",HttpStatus.BAD_REQUEST),
    INVALID_PIE_ENCRYPTION_VALUES( "PYMTCRD_ERR_127",HttpStatus.BAD_REQUEST),
    ERROR_CODE_CARD_EXISTS("PYMTCRD_ERR_129",HttpStatus.BAD_REQUEST),
    ERROR_CODE_INVALID_NICK_NAME("PYMTCRD_ERR_130",HttpStatus.BAD_REQUEST),
    ERROR_CODE_ERRORS_NICK_NAME_EXCEED("PYMTCRD_ERR_131", HttpStatus.BAD_REQUEST),
    ERROR_CODE_INVALID_GSA_RANGE("PYMTCRD_ERR_132", HttpStatus.BAD_REQUEST),
    ERROR_CODE_INVALID_REQUEST("PYMTCRD_ERR_132", HttpStatus.BAD_REQUEST),
    ERROR_CODE_INVALID_XREF_NUMBER("PYMTCRD_ERR_133", HttpStatus.BAD_REQUEST),
    ERROR_CODE_GEN_ERR("PYMTCRD_GEN_ERR_500", HttpStatus.INTERNAL_SERVER_ERROR),
    ERROR_CODE_METHOD_NOT_ALLOWED("PYMTCRD_ERR_134", HttpStatus.METHOD_NOT_ALLOWED),
    ERROR_CODE_CARD_NOT_UPDATABLE("PYMTCRD_ERR_135",HttpStatus.BAD_REQUEST),
    ERROR_CODE_NO_CARD_FOUND("PYMTCRD_ERR_136",HttpStatus.NOT_FOUND),
    ERROR_CODE_CARD_NOT_FOUND("PYMTCRD_ERR_137",HttpStatus.NOT_FOUND),
    PYMTCARD_ERRORS_EXPIRY_MONTH_NOT_APPL("PYMTCRD_ERR_138",HttpStatus.BAD_REQUEST),
    USER_NOT_AUTHORIZED("AUTH_ERR_105",HttpStatus.UNAUTHORIZED),
    PYMTCARD_ERRORS_EXPIRY_YEAR_EXCEED("PYMTCRD_ERR_139",HttpStatus.BAD_REQUEST),
    INVALID_ADDRESS_ID_NOT_FOUND("ADDR_ERR_133",HttpStatus.BAD_REQUEST);

    private String code;

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    private HttpStatus httpStatus;

    private PaymentErrorCode(String code, HttpStatus httpStatus) {
        this.code = code;
        this.httpStatus = httpStatus;
    }

    @Override
    public String getCode() {
        return code;
    }

    public static PaymentErrorCode valueOfCode(String code) {
        for (PaymentErrorCode errorCode : values()) {
            if (errorCode.getCode().equalsIgnoreCase(code)) {
                return errorCode;
            }
        }
        throw new IllegalArgumentException(
                "No enum const " + PaymentErrorCode.class + " defined for error code " + code);
    }

    public static HttpStatus valueOfHttpStatus(String code) {
        for (PaymentErrorCode errorCode : values()) {
            if (errorCode.getCode().equalsIgnoreCase(code)) {
                return errorCode.getHttpStatus();
            }
        }
        throw new IllegalArgumentException(
                "No enum const " + PaymentErrorCode.class + " defined for error code " + code);
    }
}
