package com.homedepot.customer.exception.error;

import org.springframework.http.HttpStatus;

/**
 * Created by axb4725 on 9/30/16.
 */
public enum PreferencesErrorCode implements ErrorCode {

    IINVALID_EMAIL("PREF_ERR_205", HttpStatus.BAD_REQUEST),
    // Below codes used for Privacy Preferences
    INVALID_EMAIL_ID("PREF_ERR_203", HttpStatus.BAD_REQUEST),
    INVALID_REQUEST("PREF_ERR_204", HttpStatus.BAD_REQUEST),
    INVALID_PHONE("PREF_ERR_206",HttpStatus.BAD_REQUEST),
    INVALID_STATE("PREF_ERR_207",HttpStatus.BAD_REQUEST),
    INVALID_VALUE_SHARE_INFO("PREF_ERR_208",HttpStatus.BAD_REQUEST),
    INVALID_VALUE_SUBSCRIBE_EMAIL("PREF_ERR_210",HttpStatus.BAD_REQUEST),
    INVALID_VALUE_SUBSCRIBE_PHONE("PREF_ERR_211",HttpStatus.BAD_REQUEST),
    INVALID_VALUE_SUBSCRIBE_MAIL("PREF_ERR_212",HttpStatus.BAD_REQUEST),
    
    LINE_OF_BUSINESS_MISSING("PREF_ERR_213",HttpStatus.BAD_REQUEST),
    INVALID_LINE_OF_BUSINESS("PREF_ERR_214",HttpStatus.BAD_REQUEST),
    SOURCE_MISSING("PREF_ERR_215",HttpStatus.BAD_REQUEST),
    AS_OF_DATE_MISSING("PREF_ERR_216",HttpStatus.BAD_REQUEST),
    INVALID_EMAILID("PREF_ERR_217",HttpStatus.BAD_REQUEST),
    INVALID_PHONE_NO("PREF_ERR_218",HttpStatus.BAD_REQUEST),
    INVALID_ZIP_LENGTH("PREF_ERR_219",HttpStatus.BAD_REQUEST),
    INVALID_CONTRACTOR("PREF_ERR_220",HttpStatus.BAD_REQUEST),
    INVALID_TRADESMAN("PREF_ERR_221",HttpStatus.BAD_REQUEST),
    ACXIOM_UNMARSHALLING_ERROR("PREF_ERR_222",HttpStatus.BAD_REQUEST),
    UNDEFINED_ERROR("PREF_ERR_223",HttpStatus.BAD_REQUEST),
    INVALID_ZIP_CODE("PREF_ERR_224",HttpStatus.BAD_REQUEST),
    INVALID_SUBSCRIBE_MAIL("PREF_ERR_225",HttpStatus.BAD_REQUEST);
    

    private String code;
    private HttpStatus httpStatus;

    private PreferencesErrorCode(String code, HttpStatus httpStatus) {
        this.code = code;
        this.httpStatus = httpStatus;
    }

    @Override
    public String getCode() {
        return code;
    }
    
    public HttpStatus getHttpStatus() {
        return httpStatus;
    }


    public static PreferencesErrorCode valueOfCode(String code) {
        for (PreferencesErrorCode errorCode : values()) {
            if (errorCode.getCode().equalsIgnoreCase(code)) {
                return errorCode;
            }
        }
        throw new IllegalArgumentException(
                "No enum const " + PreferencesErrorCode.class + " defined for error code " + code);
    }
    
    public static HttpStatus valueOfHttpStatus(String code) {
        for (PreferencesErrorCode errorCode : values()) {
            if (errorCode.getCode().equalsIgnoreCase(code)) {
                return errorCode.getHttpStatus();
            }
        }
        throw new IllegalArgumentException(
                "No enum const " + PreferencesErrorCode.class + " defined for error code " + code);
    }
}

