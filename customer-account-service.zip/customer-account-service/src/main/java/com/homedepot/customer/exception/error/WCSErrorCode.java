package com.homedepot.customer.exception.error;

import org.springframework.http.HttpStatus;

/**
 * Created by hxg3585 on 1/3/17.
 */
public enum WCSErrorCode implements ErrorCode {
    ERROR_CODE_NO_ADDRESSES("ADDR_ERR_165",HttpStatus.OK);

    private String code;

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    private HttpStatus httpStatus;

    private WCSErrorCode(String code, HttpStatus httpStatus) {
        this.code = code;
        this.httpStatus = httpStatus;
    }

    @Override
    public String getCode() {
        return code;
    }

    public static WCSErrorCode valueOfCode(String code) {
        for (WCSErrorCode errorCode : values()) {
            if (errorCode.getCode().equalsIgnoreCase(code)) {
                return errorCode;
            }
        }
        throw new IllegalArgumentException(
                "No enum const " + WCSErrorCode.class + " defined for error code " + code);
    }

    public static HttpStatus valueOfHttpStatus(String code) {
        for (WCSErrorCode errorCode : values()) {
            if (errorCode.getCode().equalsIgnoreCase(code)) {
                return errorCode.getHttpStatus();
            }
        }
        throw new IllegalArgumentException(
                "No enum const " + WCSErrorCode.class + " defined for error code " + code);
    }
}
