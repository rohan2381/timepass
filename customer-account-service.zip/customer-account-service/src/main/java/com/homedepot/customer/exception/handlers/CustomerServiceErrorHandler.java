package com.homedepot.customer.exception.handlers;

import com.homedepot.customer.CustomerAccountService;
import com.homedepot.customer.config.InstanceConfiguration;
import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.exception.error.IdentityErrorCode;
import com.homedepot.customer.model.*;
import com.homedepot.customer.response.*;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.util.Resource;
import com.homedepot.customer.util.THDEnv;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.fluentd.logger.FluentLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cloud.sleuth.SpanAccessor;
import org.springframework.context.MessageSource;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Created by rxb1809 on Aug 11, 2016
 *
 */
@ControllerAdvice
@Slf4j
public class CustomerServiceErrorHandler {

	@Autowired
	@Qualifier("errorMessageResource")
	MessageSource messageSource;

    @Autowired
    private Environment environment;

    @Autowired
     EnvPropertyUtil envProperty;

	@Autowired
	private InstanceConfiguration instanceConfig;

	@Autowired
	SpanAccessor spanAccessor;

	@Autowired
	private HttpServletRequest request;

	private Map<String,Object> serviceContextData = new HashMap<>();

	private static  String appVersion = CustomerAccountService.class.getPackage().getImplementationVersion();

	private static final String ERROR_COMPONENT = "errors";

	private static final String SERVICE_COMPONENT= "service";

	private  static final String VERSION_COMPONENT="version";

	private static final String MESSAGE_COMPONENT ="message";

	private static final String SERVICE_CONTEXT_COMPONENT = "serviceContext";


    @ExceptionHandler(CustomerAccountServiceException.class)
    @ResponseBody
    public ResponseEntity<Object> handleError(CustomerAccountServiceException rEx) {

		try {
		    // Stack driver reporting
			report(rEx);
		}
		catch (Exception ex){
			log.error("Exception when reporting to Stackdriver  : "+ ExceptionUtils.getStackTrace(ex) );
		}

        ResponseEntity<Object> response;

        // Step 1: Log the error
        logError(rEx);

		// Step 2: Build the error response object
		BaseResponse responseObj = buildErrorResponse(rEx.getErrors());

		// Step 3: Set the response entity and http status code
		response = new ResponseEntity<>(responseObj, rEx.getHttpStatus());

		// Step 4: Return the response entity
		return response;
	}
	//This method will report error to stack driver
	public void report(Throwable ex) {
		FluentLogger ERRORS=FluentLogger.getLogger(envProperty.getAppName());
		CustomerAccountService.class.getPackage().getImplementationVersion();
		StringWriter exceptionWriter = new StringWriter();
		if(ExceptionUtils.getRootCause(ex)==null){
			ex.printStackTrace(new PrintWriter(exceptionWriter));
		}else {
			ExceptionUtils.getRootCause(ex).printStackTrace(new PrintWriter(exceptionWriter));
		}
		Map<String, Object> data = new HashMap<>();
		Optional<CustomerAccountServiceException> optCustomerAccountException = Optional.of((CustomerAccountServiceException) ex);
		Optional<InstanceConfiguration> opIns = Optional.ofNullable(instanceConfig);
		String stackTraceString = insertMessagePrefix(exceptionWriter.toString(), buildErrorContext((optCustomerAccountException),opIns));
		data.put(MESSAGE_COMPONENT, stackTraceString);
		serviceContextData.put(SERVICE_COMPONENT, (envProperty.getAppName()+":"+optCustomerAccountException.map(e->e.getErrors()).map(errors -> errors.getResource()).map(resource -> resource.toString().toLowerCase()).orElse(Resource.DEFAULT.toString().toLowerCase())));
		serviceContextData.put(VERSION_COMPONENT,appVersion);
		data.put(SERVICE_CONTEXT_COMPONENT, serviceContextData);
		ERRORS.log(ERROR_COMPONENT, data);
	}

	private String buildErrorContext(Optional<CustomerAccountServiceException> ex, Optional<InstanceConfiguration> optionalInstanceConfig){
		Optional<SpanAccessor> optionalSpanAccessor = Optional.of(spanAccessor);
		Optional<HttpServletRequest> optHttpServletRequest = Optional.of(request);
		StringBuilder messagePrefixBuilder =new StringBuilder();
		messagePrefixBuilder.append("Http status code : " + ex.map(e -> e.getHttpStatus().toString()).orElse("")+" | ");
		messagePrefixBuilder.append("Error code : "+ ex.map(e -> e.getErrors())
																			.map(errors -> errors
																			.getErrors()).map(errors -> errors.get(0))
																			.map(error -> error.getErrorCode()).orElse("")+" | ");
		messagePrefixBuilder.append("Error Message : "+ ExceptionUtils.getRootCauseMessage(ex.get())+ " | ");
		messagePrefixBuilder.append("Error root cause : "+ (ExceptionUtils.getRootCause(ex.get())==null ? ex.get(): ExceptionUtils.getRootCause(ex.get())) +" | ");
		messagePrefixBuilder.append("Trace Id : "+ Long.toHexString(optionalSpanAccessor.map(spanA->spanA.getCurrentSpan()).map(currentSpan->currentSpan.getTraceId()).orElse(new Long(0))) +" | ");
		messagePrefixBuilder.append("Instance Info : [" + optionalInstanceConfig.map(ins->ins.getHostName()).orElse("") + "] " + " | ");
		messagePrefixBuilder.append("Method : "+ optHttpServletRequest.map(r->r.getMethod()).orElse("") +" | ");
		messagePrefixBuilder.append("Url : "+ optHttpServletRequest.map(r->r.getRequestURI()).orElse("") +System.lineSeparator());
		return messagePrefixBuilder.toString();
	}

	private String insertMessagePrefix(String stackTraceString, String messagePrefix) {
		StringBuilder sb = new StringBuilder(stackTraceString);
		sb.insert(0, messagePrefix);
		return sb.toString();
	}

	private void logError(CustomerAccountServiceException ex ) {
	    try{
	        log.error("*** CustomerAccountServiceException ***");
	        log.error("Error Message --> {}", ExceptionUtils.getRootCauseMessage(ex));
	        log.error("Error Http status code --> {}", ex.getHttpStatus());
	        log.error("Error Code --> {}",ex.getErrors().getErrors().get(0).getErrorCode());
	        log.error("Error Root cause --> "+(ExceptionUtils.getRootCause(ex)==null ? ex: ExceptionUtils.getRootCause(ex)));
	    }catch(Exception e){
	        log.error("Error logging CustomerAccountServiceException " +e);
	    }
	}

	private BaseResponse buildErrorResponse(Errors errors) {
	    String wcsHostSecure = envProperty.getWcsHostSecure();

	    if(Arrays.stream(environment.getActiveProfiles()).anyMatch(env -> GlobalConstants.SPRING_PFOFILE_DEV.equalsIgnoreCase(env))) {
            ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if(requestAttributes!=null && requestAttributes.getRequest()!=null
                    && requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV) !=null){
                THDEnv thdEnv =  (THDEnv)requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV);
                if(thdEnv!=null){
                    wcsHostSecure = thdEnv.getSecureUrl();
                    log.debug("WCS secure host overrided to "+wcsHostSecure);
                }
            }
        }

	    final String wcsHostSecureFinal = wcsHostSecure;

		errors.getErrors().forEach(error -> {
		    if(IdentityErrorCode.ACCOUNT_FORCED_RESET.getCode().equalsIgnoreCase(error.getErrorCode())){
		        StringBuilder strLink = new StringBuilder();
		        strLink.append("<a href=\"");
		        strLink.append(GlobalConstants.HTTPS);
		        strLink.append("://");
		        strLink.append(wcsHostSecureFinal);
		        strLink.append("/account/view/forgotpassword");
		        strLink.append("\" class=\"u__default-link\">reset your password</a>");
		        error.setErrorMessage(messageSource.getMessage(error.getErrorCode(),new String[]{strLink.toString()},null));
		    }else{
		        error.setErrorMessage(messageSource.getMessage(error.getErrorCode(),null,null));
		    }

            if (error.getDeveloperErrorMessage() == null) {
                error.setDeveloperErrorMessage("");
            }
		});

		return getResponseObj(errors.getResource(), errors);
	}


	private BaseResponse getResponseObj(Resource resource, Errors errors){
		BaseResponse responsObj;

        switch(resource!=null?resource:Resource.DEFAULT){
			case ACCOUNT:
				Account account = new Account();
				account.setErrors(errors.getErrors());
				ProfileResponse profileResponse = new ProfileResponse();
				profileResponse.setAccount(account);
				responsObj = profileResponse;
				break;

			case ADDRESS:
				Addresses addresses = new Addresses();
				addresses.setErrors(errors.getErrors());
				AddressResponse addressResponse = new AddressResponse();
				addressResponse.setAddresses(addresses);
				responsObj = addressResponse;
				break;

			case PAYMENT:
				PaymentCards paymentCards = new PaymentCards();
				paymentCards.setErrors(errors.getErrors());
				PaymentResponse paymentResponse = new PaymentResponse();
				paymentResponse.setPaymentCards(paymentCards);
				responsObj = paymentResponse;

				break;

			case IDENTITY:
				Identity identity = new Identity();
				identity.setErrors(errors.getErrors());
				IdentityResponse identityResponse = new IdentityResponse();
				identityResponse.setIdentity(identity);
				responsObj = identityResponse;
				break;

			case PREFERENCE:
				Preferences preferences = new Preferences();
				preferences.setErrors(errors.getErrors());
				responsObj = new PreferencesResponse(preferences);
				break;

			case DEFAULT:
				default:
				responsObj = new ErrorResponse(errors.getErrors());
				break;
		}

		return responsObj;
	}
}
