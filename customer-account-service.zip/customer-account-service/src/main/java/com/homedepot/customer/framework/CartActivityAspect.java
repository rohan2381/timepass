package com.homedepot.customer.framework;

import java.util.Optional;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.homedepot.customer.datasync.util.DataSyncUtil;
import com.homedepot.customer.exception.*;
import com.homedepot.customer.service.impl.CartExecutor;
import com.homedepot.customer.util.*;

/**
 * Created by jirapat on 4/3/17.
 */
@Aspect
@Component
@Slf4j
public class CartActivityAspect {

    @Autowired
    private CustomerAccountRequestContext requestContext;

    @Autowired
    EnvPropertyUtil envProperty;

    @Autowired
    CartExecutor cartTaskExecutor;
    
    @Autowired
    private DataSyncUtil dataSyncUtil;

    @AfterReturning(
            pointcut = "execution(* com.homedepot.customer.controller.guest.RegistrationController.registerAccount(..)) || execution(* com.homedepot.customer.controller.guest.RegistrationController.signUp(..)))",
            returning= "result")
    public void migrateCartAfterReturningRegistration(JoinPoint joinPoint, Object result) throws RepositoryException {
        if (envProperty.getCartMigrationEnabled()) {

            Optional<HttpServletRequest> requestOptional = Optional.ofNullable(requestContext.getRequest());
            Cookie[] reqCookies = requestOptional.map(HttpServletRequest::getCookies).orElse(new Cookie[0]);

            cartTaskExecutor.asyncMigrateCart(joinPoint.getArgs(), result, reqCookies);
            dataSyncUtil.pauseAroundDataSync();
        }
    }

}
