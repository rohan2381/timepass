package com.homedepot.customer.framework;

import javax.servlet.http.HttpServletRequest;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

import com.homedepot.customer.integration.wcs.dto.crossref.CrossRefInfo;
import com.homedepot.customer.model.Store;
import com.homedepot.customer.util.SessionAuth;
import com.homedepot.customer.util.THDEnv;

import lombok.Data;

/**
 * Created by rxb1809 on Sep 8, 2016
 * This class stores the request specific context fields It is defined as a spring bean with request scope. 
 * The instance will be active for the life-cyle of the http request and will destroyed once the http request processing is over. 
 * Since it will be injected into other singleton objects, we need to enable the proxy mode to leverage AOP based proxy mechanism
 */
@Scope(value="request", proxyMode=ScopedProxyMode.TARGET_CLASS)
@Component
@Data
public class CustomerAccountRequestContext {

    private String businessChannel;
    private String authToken;
    private HttpServletRequest request;
    private String svocCustomerAccountId;
    private String wcsMemberId;
    private SessionAuth sessionAuth;
    private boolean isWCSRequest = false;
    private CrossRefInfo crossRefInfo;
    private boolean isReqServedFromWCS = false;
    //SVOC EMAIL ID for set password flow (set in SetPasswordRequestValidator)
    private String svocEmailId;
    //SVOC ID for set password email flow (set in SetPasswordRequestValidator)
    private String svocId;
    private String firstName;
    private THDEnv thdEnv;
    private Store localStore;
}
