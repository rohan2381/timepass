package com.homedepot.customer.framework;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

/**
 * Created by jirapat on 8/28/16.
 */
@Aspect
@Component
@Slf4j
public class CustomerAccountRequestProfiler {

    @Around("execution(* com.homedepot.customer.controller.*.*(..)) || execution(* com.homedepot.customer.controller.guest.*.*(..))")
    public Object profileRequestProcessTime(ProceedingJoinPoint joinPoint) throws Throwable {
        long startTime = System.currentTimeMillis();
        Object retVal = joinPoint.proceed();

        log.debug("Customer Account Request args: {}", joinPoint.getArgs());
        log.info("Customer-Account-Request: {}, Latency: {}", joinPoint.toShortString(), System.currentTimeMillis() - startTime);

        return retVal;
    }
}
