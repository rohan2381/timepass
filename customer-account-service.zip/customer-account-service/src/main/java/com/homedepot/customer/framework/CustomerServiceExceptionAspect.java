package com.homedepot.customer.framework;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;
import com.homedepot.customer.util.Resource;
import com.netflix.hystrix.exception.HystrixRuntimeException;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.Collections;

/**
 * Created by rxb1809 on Oct 6, 2016
 * This class intercepts all the relevant controllers to throw appropriate exceptions back to the exception handler class 
 * It uses Spring AOP for execution
 *
 */
@Aspect
@Component
public class CustomerServiceExceptionAspect {

    /**
     * Advice for exceptions thrown for Address controller methods
     * @param jp
     * @param ex
     * @throws CustomerAccountServiceException
     */
    @AfterThrowing(pointcut="execution(* com.homedepot.customer.controller.AddressController.*(..))", throwing="ex")
    public void throwAddressException(JoinPoint jp, Throwable ex) throws CustomerAccountServiceException{
        
        if(ex instanceof CustomerAccountServiceException){
            ((CustomerAccountServiceException) ex).getErrors().setResource(Resource.ADDRESS);
        }else if(ex instanceof HystrixRuntimeException){
            // HystrixRuntimeException cause may not be CustomerAccountServiceException
            if (ex.getCause() instanceof CustomerAccountServiceException) {
                ((CustomerAccountServiceException) ex.getCause()).getErrors().setResource(Resource.ADDRESS);
                throw (CustomerAccountServiceException) ((HystrixRuntimeException) ex).getFallbackException().getCause();
            }
            else {
                throwGenericError(ex.getCause(), Resource.ADDRESS);
            }
        }
        else{   
            throwGenericError(ex, Resource.ADDRESS);
        }
    }
    
    /**
     * Advice for exceptions thrown for account related controller methods
     * @param jp
     * @param ex
     * @throws CustomerAccountServiceException
     */
    @AfterThrowing(pointcut = "(execution(* com.homedepot.customer.controller.ProfileController.*(..))" +
                              " || execution(* com.homedepot.customer.controller.guest.RegistrationController.registerAccount(..)))" +
                              " && !execution(* com.homedepot.customer.controller.ProfileController.updateIdentity(..))", throwing="ex")
    public void throwProfileException(JoinPoint jp, Throwable ex) throws CustomerAccountServiceException{
        
        if(ex instanceof CustomerAccountServiceException){    
            ((CustomerAccountServiceException) ex).getErrors().setResource(Resource.ACCOUNT);
        
        }
        else if (ex instanceof HystrixRuntimeException) {
            // HystrixRuntimeException cause may not be CustomerAccountServiceException
            if (ex.getCause() instanceof CustomerAccountServiceException) {
                ((CustomerAccountServiceException) ((HystrixRuntimeException) ex).getFallbackException().getCause()).getErrors().setResource(Resource.ACCOUNT);
                throw (CustomerAccountServiceException) ((HystrixRuntimeException) ex).getFallbackException().getCause();
            }
            else {
                throwGenericError(ex.getCause(), Resource.ACCOUNT);
            }
        }
        else{
            throwGenericError(ex, Resource.ACCOUNT);
        }
    }
    
    /**
     * Advice for exceptions thrown for account related controller methods
     * @param jp
     * @param ex
     * @throws CustomerAccountServiceException
     */
    @AfterThrowing(pointcut = "(execution(* com.homedepot.customer.controller.guest.RegistrationController.emailAlreadyExists(..)))", throwing="ex")
    public void throwCheckEmailException(JoinPoint jp, Throwable ex) throws CustomerAccountServiceException{
        
        if(ex instanceof CustomerAccountServiceException){    
            ((CustomerAccountServiceException) ex).getErrors().setResource(Resource.DEFAULT);
        
        }
        else if (ex instanceof HystrixRuntimeException) {
            // HystrixRuntimeException cause may not be CustomerAccountServiceException
            if (ex.getCause() instanceof CustomerAccountServiceException) {
                ((CustomerAccountServiceException) ((HystrixRuntimeException) ex).getFallbackException().getCause()).getErrors().setResource(Resource.DEFAULT);
                throw (CustomerAccountServiceException) ((HystrixRuntimeException) ex).getFallbackException().getCause();
            }
            else {
                throwGenericError(ex.getCause(), Resource.DEFAULT);
            }
        }
        else{
            throwGenericError(ex, Resource.DEFAULT);
        }
    }
    
    /**
     * Advice for exceptions thrown for Payment controller methods
     * @param jp
     * @param ex
     * @throws CustomerAccountServiceException
     */
    @AfterThrowing(pointcut="execution(* com.homedepot.customer.controller.PaymentController.*(..))", throwing="ex")
    public void throwPaymentException(JoinPoint jp, Throwable ex) throws CustomerAccountServiceException{
        
        if(ex instanceof CustomerAccountServiceException){    
            ((CustomerAccountServiceException) ex).getErrors().setResource(Resource.PAYMENT);
        
        }
        else if (ex instanceof HystrixRuntimeException) {
            // HystrixRuntimeException cause may not be CustomerAccountServiceException
            if (ex.getCause() instanceof CustomerAccountServiceException) {
                ((CustomerAccountServiceException) ((HystrixRuntimeException) ex).getFallbackException().getCause()).getErrors().setResource(Resource.PAYMENT);
                throw (CustomerAccountServiceException) ((HystrixRuntimeException) ex).getFallbackException().getCause();
            }
            else {
                throwGenericError(ex.getCause(), Resource.PAYMENT);
            }
        }
        else{
            throwGenericError(ex, Resource.PAYMENT);
        }
    }

    /**
     * Advice for exceptions thrown for Payment controller methods
     * @param jp
     * @param ex
     * @throws CustomerAccountServiceException
     */
    @AfterThrowing(pointcut="execution(* com.homedepot.customer.controller.guest.LoginController.*(..))"
            + "|| execution(* com.homedepot.customer.controller.ProfileController.updateIdentity(..))", throwing="ex")
    public void throwIdentityException(JoinPoint jp, Throwable ex) throws CustomerAccountServiceException{

        if(ex instanceof CustomerAccountServiceException ){
            ((CustomerAccountServiceException) ex).getErrors().setResource(Resource.IDENTITY);

        }
        else if (ex instanceof HystrixRuntimeException) {
            // HystrixRuntimeException cause may not be CustomerAccountServiceException
            if (ex.getCause() instanceof CustomerAccountServiceException) {
                ((CustomerAccountServiceException) ((HystrixRuntimeException) ex).getFallbackException().getCause()).getErrors().setResource(Resource.IDENTITY);
                throw ((CustomerAccountServiceException) ((HystrixRuntimeException) ex).getFallbackException().getCause());
            }
            else {
                throwGenericError(ex.getCause(), Resource.IDENTITY);
            }
        }
        else {
            throwGenericError(ex, Resource.IDENTITY);
        }
    }
    
    /**
     * Advice for exceptions thrown for PrivacyPreferences controller methods
     * @param jp
     * @param ex
     * @throws CustomerAccountServiceException
     */
    @AfterThrowing(pointcut="execution(* com.homedepot.customer.controller.guest.PrivacyPreferencesController.*(..))", throwing="ex")
    public void throwPreferencesException(JoinPoint jp, Throwable ex) throws CustomerAccountServiceException{
        
        if(ex instanceof CustomerAccountServiceException){
            ((CustomerAccountServiceException) ex).getErrors().setResource(Resource.PREFERENCE);
        } else{   
            throwGenericError(ex, Resource.PREFERENCE);
        }
    }


    private void throwGenericError(Throwable ex, Resource resource) throws CustomerAccountServiceException{
        Error error = new Error();
        error.setErrorCode(ErrorCode.SYSTEM_ERROR);
        
        Errors errors = new Errors();
        errors.setErrors(Collections.singletonList(error));
        errors.setResource(resource);
        
        throw new CustomerAccountServiceException(errors,HttpStatus.INTERNAL_SERVER_ERROR,ex);
    }
}
