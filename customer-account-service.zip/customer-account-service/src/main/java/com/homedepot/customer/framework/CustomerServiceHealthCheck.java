package com.homedepot.customer.framework;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on May 14, 2016
 *
 */
@Component
@Slf4j
public class CustomerServiceHealthCheck implements HealthIndicator {

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.boot.actuate.health.HealthIndicator#health()
     */
    @Override
    public Health health() {

        List<String> integrationErrors = checkIntegrationPoints();

        if (!integrationErrors.isEmpty()) {
            return Health.down().withDetail("INTEGRATION-POINTS-DOWN", String.join(", ", integrationErrors)).build();
        }

        return Health.up().build();
    }

    private List<String> checkIntegrationPoints() {
        List<String> integrationErrors = new ArrayList<String>();

        // Add logic to check SVOC, IAM and xRef
        // integrationErrors.add("SVOC"); //NOSONAR
        // integrationErrors.add("IAM"); // NOSONAR

        return integrationErrors;
    }

}
