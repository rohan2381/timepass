package com.homedepot.customer.framework;

import java.util.*;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.homedepot.customer.util.*;
import com.homedepot.customer.validator.BaseRequestValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Aug 11, 2016
 *
 */
@Component
@Slf4j
public class CustomerServiceRequestInterceptor extends HandlerInterceptorAdapter {

    @Autowired
    @Qualifier(value = "requestheadervalidator")
    BaseRequestValidator<HttpServletRequest> headerValidator;
    
    @Autowired
    @Qualifier(value = "sessionvalidator")
    BaseRequestValidator<HttpServletRequest> sessionValidator;
    
    @Autowired
    @Qualifier(value = "tokenvalidator")
    BaseRequestValidator<HttpServletRequest> tokenValidator;
    
    @Autowired
    CustomerAccountRequestContext requestContext;
    
    @Autowired
    AccountRequestHelper accountRequestHelper;
    
    @Autowired
    private Environment environment;

    @Autowired
    private EnvPropertyUtil envProperty;

    @SuppressWarnings("unchecked")
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        
        // This is to avoid OPTIONS CORS pre flight requests to go through any request interceptor validations
        if(HttpMethod.valueOf(request.getMethod()) == HttpMethod.OPTIONS){
            return true;
        }
        
        // Validate header
        headerValidator.validate(request, HttpMethod.valueOf(request.getMethod()));

        updateWCSSessionIDCookie(request);
        
        // Set business channel
        requestContext.setBusinessChannel(
                BusinessChannel.valueOfId(Integer.valueOf(request.getHeader(GlobalConstants.CHANNEL_ID))).toString());

        requestContext.setAuthToken(request.getHeader(GlobalConstants.THD_AUTH_TOKEN));
        requestContext.setRequest(request);


        /**
         * Set THD environment attribute. Only applicable for DEV profile. 
         * Also set the inheritable flag to true to ensure propagation to child threads
         */        
        if(Arrays.stream(environment.getActiveProfiles()).anyMatch(env -> GlobalConstants.SPRING_PFOFILE_DEV.equalsIgnoreCase(env))) {  
            if(ArrayUtils.isNotEmpty(request.getCookies())){
                Optional<Cookie> thdEnvCookie = Arrays.asList(request.getCookies())
                                                        .stream()
                                                        .filter(c -> c.getName().equalsIgnoreCase(GlobalConstants.THD_ENV))
                                                        .findFirst();
                
                if(thdEnvCookie.isPresent() && StringUtils.isNotBlank(thdEnvCookie.get().getValue())){
                    try{
                        ServletRequestAttributes requestAttributes = (ServletRequestAttributes)RequestContextHolder.getRequestAttributes();
                        requestAttributes.setAttribute(GlobalConstants.THD_ENV, THDEnv.valueOf(thdEnvCookie.get().getValue()), RequestAttributes.SCOPE_REQUEST);
                        RequestContextHolder.setRequestAttributes(requestAttributes, true);
                    }catch(IllegalArgumentException iAEx){
                        log.error("Invalid Environment header passed "+iAEx);
                    }
                }
            }  
        }
        
        // Validate HMAC token for certain guest APIs
        if(Arrays.stream(GlobalConstants.HMAC_PROTECTED_REQUEST_PATHS).anyMatch(request.getServletPath()::contains)){
            tokenValidator.validate(request, HttpMethod.valueOf(request.getMethod()));
        }
        
        // Validate Customers Session to access protected resources
        if(Arrays.stream(GlobalConstants.PROTECTED_REQUEST_PATHS).anyMatch(request.getServletPath()::contains)){
            sessionValidator.validate(request, HttpMethod.valueOf(request.getMethod()));

            if(request.getRequestURI().contains("paymentcards") && envProperty.getPaymentSource().equalsIgnoreCase(GlobalConstants.WCS)){
                accountRequestHelper.validateAndSetCustAcctIdForPaymentCards(request);
            }else{
                accountRequestHelper.validateAndSetCustAcctId(request);
            }
        }

        return true;
    }

    private void updateWCSSessionIDCookie(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        String  xWCSSessionIDValue = request.getHeader(GlobalConstants.XWCSSESSIONID);
        log.debug("Header : {} Value : {}", GlobalConstants.XWCSSESSIONID, xWCSSessionIDValue);
        if(null != cookies && StringUtils.isNotBlank(xWCSSessionIDValue)) {
            String delimiter = environment.getProperty("wcsSessionIDDelimiter");
            String[] cookieValArr = xWCSSessionIDValue.split(delimiter);
            if(cookieValArr.length >= 2) {
                String updatedWCSSessionIDValue = cookieValArr[0] + GlobalConstants.COLON + cookieValArr[1];
                Arrays.stream(cookies).filter(c -> c.getName().equals(GlobalConstants.WCSSESSIONID)).findFirst().ifPresent(wcsSessionIDCookie -> {
                    log.debug("WCSSESSIONID value before update " + wcsSessionIDCookie.getValue());
                    wcsSessionIDCookie.setValue(updatedWCSSessionIDValue);
                    log.debug("WCSSESSIONID value after update " + wcsSessionIDCookie.getValue());
                });
            }
        }
    }

}
