package com.homedepot.customer.framework;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

/**
 * Created by jirapat on 8/29/16.
 */
@Aspect
@Component
@Slf4j
public class IntegrationServiceRequestProfiler {

    @Around("execution(* com.homedepot.customer.integration.*.*.sendRequest(..)) "
            + "|| execution(* com.homedepot.customer.integration.*.*.sendWCSRequest(..)) "
            + "|| execution(* com.homedepot.customer.integration.*.*.sendWCSFallBackRequest(..)) "
            + "|| execution(* com.homedepot.customer.integration.*.*.getToken())")
    public Object profileRequestProcessTime(ProceedingJoinPoint joinPoint) throws Throwable {
        long startTime = System.currentTimeMillis();
        Object retVal = joinPoint.proceed();

        log.info("Integration-Request: {},  Latency: {}", joinPoint.toShortString(), System.currentTimeMillis() - startTime);

        return retVal;
    }
}
