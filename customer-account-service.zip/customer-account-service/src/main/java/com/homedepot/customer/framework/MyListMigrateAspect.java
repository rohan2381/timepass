package com.homedepot.customer.framework;

import java.net.*;
import java.util.*;
import javax.servlet.http.*;
import org.aspectj.lang.*;
import org.aspectj.lang.annotation.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import com.homedepot.customer.exception.*;
import com.homedepot.customer.service.impl.*;
import com.homedepot.customer.util.*;

import lombok.extern.slf4j.*;

@Aspect
@Component
@Slf4j
public class MyListMigrateAspect {

    @Autowired
    private CustomerAccountRequestContext requestContext;

    @Autowired
    EnvPropertyUtil envProperty;

    @Autowired
    MyListTaskExecutor myListTaskExecutor;

    @Autowired
    FeatureSwitchUtil featureSwitchUtil;

    @AfterReturning(
            pointcut = "execution(* com.homedepot.customer.controller.guest.LoginController.logIn(..)) || execution(* com.homedepot.customer.controller.guest.RegistrationController.registerAccount(..)) || execution(* com.homedepot.customer.controller.guest.RegistrationController.signUp(..)) || execution(* com.homedepot.customer.controller.guest.LoginController.signIn(..))",
            returning= "result")
    public void migrateMyListAfterReturningRegistration(JoinPoint joinPoint, Object result) throws RepositoryException {
        if (featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.GUEST_LIST_MIGRATE_GCP_FEATURE)) {
            Optional<HttpServletRequest> requestOptional = Optional.ofNullable(requestContext.getRequest());
            Cookie[] reqCookies = requestOptional.map(HttpServletRequest::getCookies).orElse(new Cookie[0]);
            Cookie[] respCookies = buildResponseCookieArray(joinPoint.getArgs());
            myListTaskExecutor.asyncMigrateList(result, reqCookies, respCookies);
        }
    }

    private Cookie[] buildResponseCookieArray(Object[] args) {
        Map<String, Cookie> cookieMap = new HashMap<>();
        Arrays.stream(args)
                .filter(o -> o instanceof HttpServletResponse)
                .map(o -> (HttpServletResponse) o)
                .map(resp -> resp.getHeaders(GlobalConstants.SETCOOKIE))
                .flatMap(Collection::stream)
                .map(HttpCookie::parse)
                .flatMap(List::stream)
                .forEach(httpCookie -> cookieMap.put(httpCookie.getName(), new Cookie(httpCookie.getName(), httpCookie.getValue())));

        return cookieMap.values().toArray(new Cookie[cookieMap.size()]);
    }

}
