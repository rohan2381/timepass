package com.homedepot.customer.integration.acxiom;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.integration.acxiom.dto.FieldError;
import com.homedepot.customer.integration.acxiom.dto.ReadPreferenceResponse;
import com.homedepot.customer.integration.acxiom.dto.Response;
import com.homedepot.customer.model.Error;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.homedepot.customer.exception.error.ErrorCode.SYSTEM_ERROR;

/**
 * Created by axb4725 on 9/29/16.
 */
@Component
@Slf4j
public class AcxiomResponseErrorHandler  {
    @Autowired
    @Qualifier("errorCodeMapResource-acxiom")
    ResourceBundleMessageSource errorCodeSource;

    public void handleError(Object respObj) throws IntegrationException {
        String acxiomResponseStr=null;
        if(respObj instanceof ReadPreferenceResponse){

            if (((ReadPreferenceResponse) respObj).getResultCode() == 205) {
                // ignore code 205: email doesn't exist, and mapper will create empty preference list
                // response will be 200 with empty list instead of error, so frontend won't confuse it with real error
                log.debug("Response result code 205: Email address does not exist in the system, original response: {}", respObj);
            }
            else if (((ReadPreferenceResponse) respObj).getResultCode() != 100) {
                acxiomResponseStr = "{Status= "+((ReadPreferenceResponse) respObj).getResultCode()+" ,message= "+((ReadPreferenceResponse) respObj).getResultMessage() + " ,requestId= "+ ((ReadPreferenceResponse) respObj).getRequestId()+"}";
                log.error("Original acxiom error response: {}", respObj);
                Error error = new Error();
                error.setErrorMessage(((ReadPreferenceResponse) respObj).getResultMessage());
               // getMessage(String code, Object[] args, String defaultMessage, Locale locale)
                error.setErrorCode(errorCodeSource.getMessage(String.valueOf(((ReadPreferenceResponse) respObj).getResultCode()), null, SYSTEM_ERROR, null));
                List<Error> errorList = new ArrayList<>();
                errorList.add(error);
                com.homedepot.customer.model.Errors errors = new com.homedepot.customer.model.Errors();
                errors.setErrors(errorList);
                throw new IntegrationException(errors, HttpStatus.BAD_REQUEST,acxiomResponseStr);
            }
        }
        else if (respObj instanceof Response) {
            Response response = (Response) respObj;
            if (response.getResultCode() != 100) {
                log.debug("add/update response for request id {}, result code: {}, message: {}", response.getRequestId(), response.getResultCode(), response.getResultMessage());
                Optional<List<FieldError>> optFieldErrorList = Optional.ofNullable(response.getErrors());
                List<Error> errorList = new ArrayList<>();
                Error error = new Error();
                error.setErrorCode(errorCodeSource.getMessage(String.valueOf(response.getResultCode()), null, SYSTEM_ERROR, null));
                error.setDeveloperErrorMessage(response.getResultMessage());
                errorList.add(error);
                acxiomResponseStr = "{Status= "+response.getResultCode()+" ,message= "+response.getResultMessage() + " ,requestId= "+ response.getRequestId()+"}";

                optFieldErrorList.ifPresent(fieldErrors -> fieldErrors.forEach(fieldError -> {
                    log.debug("field error name: {}, message: {}", fieldError.getName(), fieldError.getMessage());
                    Error modelFieldError = new Error();
                    modelFieldError.setErrorCode(errorCodeSource.getMessage(String.valueOf(response.getResultCode()), null, SYSTEM_ERROR, null));
                    modelFieldError.setDeveloperErrorMessage(fieldError.getName() + ": " + fieldError.getMessage());
                    errorList.add(modelFieldError);
                }));

                com.homedepot.customer.model.Errors errors = new com.homedepot.customer.model.Errors();
                errors.setErrors(errorList);
                throw new IntegrationException(errors, HttpStatus.BAD_REQUEST,acxiomResponseStr);
            }
        }
    }
}
