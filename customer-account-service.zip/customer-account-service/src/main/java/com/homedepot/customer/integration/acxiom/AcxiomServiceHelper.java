package com.homedepot.customer.integration.acxiom;


import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.JAXBIntrospector;
import javax.xml.bind.Unmarshaller;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.WebServiceTransportException;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.client.SoapFaultClientException;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.exception.error.PreferencesErrorCode;
import com.homedepot.customer.integration.acxiom.dto.preferences.MyAccountAPIException;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;

/**
 * Created by jirapat on 9/23/16.
 */
@SuppressWarnings({"rawtypes", "unchecked"})
@Service
@Slf4j
@PropertySource("acxiom/acxiom-integration.properties")
public class AcxiomServiceHelper{
    @Autowired
    @Qualifier("acxiomWebServiceTemplate")
    WebServiceTemplate webServiceTemplate;
    
    @Autowired
    @Qualifier("acxiomPvcyPreferencesTemplate")
    WebServiceTemplate acxiomPvcyPreferencesTemplate;
    
    @Autowired
    @Qualifier("faultMssgUnmarshaller")
    Unmarshaller faultMssgUnmarshaller;

    @Autowired
    EnvPropertyUtil envProperty;

    @Autowired
    Environment env;

    @Autowired
    AcxiomResponseErrorHandler acxiomResponseErrorHandler;

    public  <T> T sendRequest(Object requestObj) throws IntegrationException {
        try {
            log.debug("calling Acxiom, requestObj: {}", requestObj);

            String url = GlobalConstants.HTTPS +"://" + envProperty.getAcxiomHost() + "/" + env.getProperty("acxiomEndpoint");
            log.debug("Calling: URL -- {}", url);

            JAXBElement response = (JAXBElement) webServiceTemplate.marshalSendAndReceive(url, requestObj);
            T res = (T) JAXBIntrospector.getValue(response);
            acxiomResponseErrorHandler.handleError(res);
            return res;
        }
        catch (IntegrationException e) {
            throw e;
        }
        catch (Exception ex) {
            Errors errors = new Errors();
            Error error = new Error();
            errors.setErrors(Arrays.asList(error));
            error.setErrorCode(ErrorCode.SYSTEM_ERROR);
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, ex);
        }
    }
    
    public  <T> T updatePvcyPreferences(Object requestObj) throws IntegrationException {
        try {
            String url = GlobalConstants.HTTPS +"://" + envProperty.getAcxiomHost() + "/" + env.getProperty("privacyPreferencesEndPoint");
            log.debug("Acxiom Service URL -- {}", url);

            JAXBElement response = (JAXBElement)acxiomPvcyPreferencesTemplate.marshalSendAndReceive(url, requestObj);
            
            return (T) JAXBIntrospector.getValue(response);
        
        } catch(SoapFaultClientException faultExp){
            log.error("SoapFaultClientException in updatePvcyPreferences(): " + faultExp);
            MyAccountAPIException acxiomException = handleFaultMessage(faultExp);
                    
            Errors errors = new Errors();
            Error error = getAcxiomError(acxiomException.getDetails());
            errors.setErrors(Arrays.asList(error));
            String errMssg = "Acxiom Error Detail: " + acxiomException.getDetails() + ", And Error Message: " + acxiomException.getMessage();
            
            throw new IntegrationException(errors, HttpStatus.BAD_REQUEST, errMssg);
            
        } catch (Exception ex) {
            log.error("Exception Occurred in updatePvcyPreferences(): " + ex);
            Error error = new Error();
            error.setErrorCode(ErrorCode.SYSTEM_ERROR);
            Errors errors = new Errors();
            errors.setErrors(Arrays.asList(error));
            
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, ex);
        }
    }

    private MyAccountAPIException handleFaultMessage(SoapFaultClientException faultExp) throws IntegrationException {
        
        try{
            JAXBElement response = faultMssgUnmarshaller.unmarshal(
                    faultExp.getSoapFault().getFaultDetail().getDetailEntries().next().getSource(), MyAccountAPIException.class);
            MyAccountAPIException acxiomException = (MyAccountAPIException) JAXBIntrospector.getValue(response);
            
            log.info("ERROR: Privacy Preference Exception, details: {}, message: {}", acxiomException.getDetails(), acxiomException.getMessage());
            
            return acxiomException;
        
        }catch (JAXBException jaxEx){
            log.error("Exception while parsing the JAXB Element in handleFaultMessage(): " + jaxEx);
            throw new IntegrationException(HttpStatus.INTERNAL_SERVER_ERROR, "Exception while parsing the JAXB Element", jaxEx);
        }
        
    }
    
    private Error getAcxiomError(String errorMssg){
        
        String lobMissing = "Line of business is required";
        String lobNotFound = "Line of business ([a-zA-Z0-9])+ not found";
        String sourceMissing = "Source is required";
        String asOfDateMissing = "AsOfDate is required";
        String invalidShareInfo = "Invalid value ([a-zA-Z0-9])+ for field shareInfo. Valid values are: -1, 0, 1.";
        
        String invalidEmailPattern = "Invalid value ([a-zA-Z0-9])+.* for field emailAddress";
        String invalidSubscribeEmail = "Invalid value ([a-zA-Z0-9])+ for field tHDPromoPermissions. Valid values are: -1, 0, 1.";
        
        String invalidSubscribePhone = "Invalid value ([a-zA-Z0-9])+ for field callMe. Valid values are: -1, 0, 1.";
        String invalidPhone = "Invalid value ([a-zA-Z0-9])+ for field phoneNumber";
        
        String invalidState = "Invalid value ([a-zA-Z0-9])+ for field state.*";
        String invalidZip1 = "Invalid value ([a-zA-Z0-9])+ for field zip";
        String invalidZip2 = "Invalid value ([a-zA-Z0-9])+ for field zip. Length must be at most 5.";
        String invalidSubscribeMail1 = "Invalid value ([a-zA-Z0-9])+ for field tHDDMChannelPermission. Valid values are: -1, 0, 1.";
        String invalidSubscribeMail2 = "Invalid value ([a-zA-Z0-9])+ for field thDDCatalogHandRaiser. Valid values are: -1, 0, 1.";
        
        Map<String, Pattern> errPatternsMap = new HashMap();
        errPatternsMap.put(PreferencesErrorCode.LINE_OF_BUSINESS_MISSING.getCode(), Pattern.compile(lobMissing));
        errPatternsMap.put(PreferencesErrorCode.INVALID_LINE_OF_BUSINESS.getCode(), Pattern.compile(lobNotFound));
        errPatternsMap.put(PreferencesErrorCode.SOURCE_MISSING.getCode(), Pattern.compile(sourceMissing));
        errPatternsMap.put(PreferencesErrorCode.AS_OF_DATE_MISSING.getCode(), Pattern.compile(asOfDateMissing));
        
        errPatternsMap.put(PreferencesErrorCode.INVALID_EMAILID.getCode(), Pattern.compile(invalidEmailPattern));
        errPatternsMap.put(PreferencesErrorCode.INVALID_VALUE_SUBSCRIBE_EMAIL.getCode(), Pattern.compile(invalidSubscribeEmail));
        
        errPatternsMap.put(PreferencesErrorCode.INVALID_VALUE_SUBSCRIBE_PHONE.getCode(), Pattern.compile(invalidSubscribePhone));
        errPatternsMap.put(PreferencesErrorCode.INVALID_PHONE_NO.getCode(), Pattern.compile(invalidPhone));
        
        errPatternsMap.put(PreferencesErrorCode.INVALID_STATE.getCode(), Pattern.compile(invalidState));
        errPatternsMap.put(PreferencesErrorCode.INVALID_ZIP_CODE.getCode(), Pattern.compile(invalidZip1));
        errPatternsMap.put(PreferencesErrorCode.INVALID_ZIP_LENGTH.getCode(), Pattern.compile(invalidZip2)); 
        errPatternsMap.put(PreferencesErrorCode.INVALID_VALUE_SUBSCRIBE_MAIL.getCode(), Pattern.compile(invalidSubscribeMail1));
        errPatternsMap.put(PreferencesErrorCode.INVALID_SUBSCRIBE_MAIL.getCode(), Pattern.compile(invalidSubscribeMail2));
        
        errPatternsMap.put(PreferencesErrorCode.INVALID_VALUE_SHARE_INFO.getCode(), Pattern.compile(invalidShareInfo));
        
        Error error = new Error();
        error.setDeveloperErrorMessage(errorMssg);
        
        for(Map.Entry<String, Pattern> entry : errPatternsMap.entrySet()){
            if(entry.getValue().matcher(errorMssg).matches()){
                error.setErrorCode(entry.getKey());
                break;
            } 
        }
        
        if(StringUtils.isBlank(error.getErrorCode())){
            error.setErrorCode(PreferencesErrorCode.UNDEFINED_ERROR.getCode());
        }
        
        return error;
    }
    
    
}
