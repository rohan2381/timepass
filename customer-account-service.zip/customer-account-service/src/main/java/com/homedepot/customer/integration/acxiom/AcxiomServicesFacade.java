package com.homedepot.customer.integration.acxiom;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.integration.acxiom.dto.Channel;
import com.homedepot.customer.integration.acxiom.dto.LOB;
import com.homedepot.customer.integration.acxiom.dto.Preference;
import com.homedepot.customer.integration.acxiom.dto.ProfileAttribute;
import com.homedepot.customer.integration.acxiom.dto.ReadPreferenceRequest;
import com.homedepot.customer.integration.acxiom.dto.ReadPreferenceResponse;
import com.homedepot.customer.integration.acxiom.dto.Response;
import com.homedepot.customer.integration.acxiom.dto.preferences.UpdateAllRequest;
import com.homedepot.customer.integration.acxiom.dto.preferences.UpdateAllResponse;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;

/**
 * Created by rxb1809 on Apr 28, 2016
 *
 */

@Service
@Slf4j
@PropertySource("acxiom/acxiom-integration.properties")
public class AcxiomServicesFacade {
    
    private final long THD_LOB = 1;
    private final long THD_SITE_REGD = 0;

    @Autowired
    AcxiomServiceHelper acxiomServiceHelper;

    @Autowired
    Environment env;


    public ReadPreferenceResponse readPreference(String email) throws IntegrationException {
        try {
            ReadPreferenceRequest request = new ReadPreferenceRequest();
            request.setDetail(env.getProperty("acxiomPrivacyOnly"));
            request.setEmail(email);
            return acxiomServiceHelper.sendRequest(request);
        } catch (IntegrationException iEx) {
            iEx.setErrorMessage("There was an issue retrieving user preferences. "+ iEx.getMessage() );
            throw iEx;
        }
    }
    
    public Response setPreferences(String email, String zipCode, Preference preference) throws IntegrationException {

        preference.setEmail(email);
        preference.setSourceId(env.getProperty("acxiomSourceId"));

        ProfileAttribute profileAttribute = new ProfileAttribute();
        profileAttribute.setName(env.getProperty("acxiomProfileNameZip5"));
        profileAttribute.setValue(zipCode);
        preference.getProfile().add(profileAttribute);

        LOB lob = preference.getLobs().get(0);
        lob.setName(env.getProperty("acxiomLobNameHd"));
        Channel channel = lob.getChannels().get(0);
        channel.setName(env.getProperty("acxiomChannelNameEmail"));
        channel.setGlobalOptin(new BigInteger(env.getProperty("acxiomGlobalOptin")));

        try {
            return acxiomServiceHelper.sendRequest(preference);
        }
        catch (IntegrationException e) {
            e.setErrorMessage("There was an issue updating user preferences. "+ e.getMessage());
            throw e;
        }
    }
    
    public boolean updatePrivacyPreferences(UpdateAllRequest request) throws IntegrationException{
        try {
            // Setting up the mandatory fields
            request.setLineOfBusiness(THD_LOB);   // ‘1’ signifies Home Depot Direct
            request.setSource(THD_SITE_REGD);     // ‘0’ signifies US Home Depot Site Registration
            if(null == request.getAsOfDate()){
                GregorianCalendar gcal = new GregorianCalendar();
                XMLGregorianCalendar xgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal);
                request.setAsOfDate(xgcal); // Sets current date in XML Gregorian format
                log.debug("AsOfDate in XMLGregorianCalendar format: {}", xgcal.toXMLFormat());
            }
            log.debug("in AcxiomServicesFacade UpdatePrivacyPreferences Request: [{}]", request.toString());
            
            UpdateAllResponse acxiomResponse = acxiomServiceHelper.updatePvcyPreferences(request);
            log.debug("No. Of records updated: {}", acxiomResponse.getUpdatedFieldCount());
            
            return acxiomResponse.getUpdatedFieldCount() >= 0 ? true : false;
            
        } catch (IntegrationException e) {
            e.setErrorMessage("There was an issue updating user preferences. "+ e.getMessage());
            throw e;
        } catch (Exception ex) {
            
            Error error = new Error();
            error.setErrorCode(ErrorCode.SYSTEM_ERROR);
            error.setErrorMessage("ERROR: AcxiomServicesFacade.updatePrivacyPreferences()- Error occured wile creating XMLGregorianCalendar type Date. "+ ex.getMessage());
            
            Errors errors = new Errors();
            errors.setErrors(Arrays.asList(error));
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, ex);
        } 
    }
}
