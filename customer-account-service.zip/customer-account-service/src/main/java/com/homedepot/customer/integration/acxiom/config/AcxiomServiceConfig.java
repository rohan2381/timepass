package com.homedepot.customer.integration.acxiom.config;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.http.auth.UsernamePasswordCredentials;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.FaultMessageResolver;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.ws.soap.client.SoapFaultClientException;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;

import com.homedepot.customer.integration.acxiom.dto.preferences.MyAccountAPIException;
import com.homedepot.customer.util.EnvPropertyUtil;

/**
 * Created by jirapat on 9/23/16.
 */
@Configuration
public class AcxiomServiceConfig {

    @Autowired
    EnvPropertyUtil envProperty;
    
    @Bean(name="acxiomWebServiceTemplate")
    public WebServiceTemplate webServiceTemplate() throws Exception {
        WebServiceTemplate webServiceTemplate = new WebServiceTemplate();

        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        //Specifying which class to expect to Marshall and Unmarshall
         marshaller.setContextPath("com.homedepot.customer.integration.acxiom.dto");
        //Setting Credentials to the messageSender
        HttpComponentsMessageSender messageSender = new HttpComponentsMessageSender();
        messageSender.setCredentials(new UsernamePasswordCredentials(envProperty.getAcxiomUsername(), envProperty.getAcxiomPassword()));
        //Should be called inorder to set property to messageSender
        messageSender.afterPropertiesSet();
        //Binding message sender and webServiceTemplate
        webServiceTemplate.setMessageSender(messageSender);
        webServiceTemplate.setMarshaller(marshaller);
        webServiceTemplate.setUnmarshaller(marshaller);
        return webServiceTemplate;
    }
    
    @Bean(name="acxiomPvcyPreferencesTemplate")
    public WebServiceTemplate pvcyPreferencesTemplate() throws Exception {
        WebServiceTemplate webServiceTemplate = new WebServiceTemplate();

        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        //Specifying which class to expect to Marshall and Unmarshall
        marshaller.setContextPath("com.homedepot.customer.integration.acxiom.dto.preferences");
        //Setting Credentials to the message Sender
        HttpComponentsMessageSender messageSender = new HttpComponentsMessageSender();
        messageSender.setCredentials(new UsernamePasswordCredentials(envProperty.getAcxiomUsername(), envProperty.getAcxiomPassword()));
        //Should be called in order to set property to messageSender
        messageSender.afterPropertiesSet();
        //Binding message sender and webServiceTemplate
        webServiceTemplate.setMessageSender(messageSender);
        webServiceTemplate.setMarshaller(marshaller);
        webServiceTemplate.setUnmarshaller(marshaller);
        
        //Handling Fault Message
        FaultMessageResolver faultResolver = (WebServiceMessage message ) -> {
            SoapMessage soapMessage = (SoapMessage) message;
            throw new SoapFaultClientException(soapMessage);
        };
        
        webServiceTemplate.setFaultMessageResolver(faultResolver);
        
        return webServiceTemplate;
    }
    
    @Bean(name="faultMssgUnmarshaller")
    public Unmarshaller pvcyPrefFaultMssgUnmarshaller() throws JAXBException {
        JAXBContext acxiomContext = JAXBContext.newInstance(MyAccountAPIException.class);
        
        return acxiomContext.createUnmarshaller();
    }

    @Bean(name="errorCodeMapResource-acxiom")
    public ResourceBundleMessageSource resourceBundleMessageSource() {
        ResourceBundleMessageSource source = new ResourceBundleMessageSource();
        // Set the svoc error code to internal error code mapping
        source.setBasename("acxiom/acxiom-errorcode-mapping");
        source.setUseCodeAsDefaultMessage(true);
        return source;
    }
}
