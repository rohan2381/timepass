package com.homedepot.customer.integration.cart;


import javax.servlet.http.Cookie;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.integration.cart.dto.*;
import com.homedepot.customer.util.FeatureSwitchUtil;
import com.homedepot.customer.util.GlobalConstants;

/**
 * Created by jirapat on 3/30/17.
 */
@Service
@Slf4j
@PropertySource("cart/cart-integration.properties")
public class CartServiceFacade {

    @Autowired
    FeatureSwitchUtil featureSwitchUtil;

    @Autowired
    CartServiceHelper cartServiceHelper;

    @Autowired
    Environment env;

    public CartResponse migrateCart(String userId, Cookie[] cookies) throws IntegrationException {
        CartResponse cartResponse = null;
        try {
            if (featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCC_CART_MIGRATE_GCP_FEATURE)) {
                String migrateCartUrl = String.format(env.getProperty("migrateCartMCCBaseUrl"), userId);
                cartResponse = cartServiceHelper.sendRequestMCC(migrateCartUrl, HttpMethod.GET, CartResponse.class, cookies);
            }
            else {
                String migrateCartUrl = String.format(env.getProperty("migrateCartBaseUrl"), userId);
                cartResponse = cartServiceHelper.sendRequest(migrateCartUrl, HttpMethod.GET, CartResponse.class, cookies);
            }

        }catch(IntegrationException ex){
            ex.setErrorMessage("Error migrating cart for customer "+userId+". "+ex.getMessage());
            throw ex;
        }
        return cartResponse;
    }
}
