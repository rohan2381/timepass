package com.homedepot.customer.integration.cart;

import java.util.*;
import java.util.stream.Collectors;

import javax.servlet.http.Cookie;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.integration.cart.config.*;
import com.homedepot.customer.integration.cart.dto.*;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;
import com.homedepot.customer.util.*;

/**
 * Created by jirapat on 3/30/17.
 */
@Service
@Slf4j
public class CartServiceHelper {

    @Autowired
    @Qualifier("cartRestTemplate")
    CartRestTemplateInfo cartRestTemplateInfo;

    @Autowired
    EnvPropertyUtil envProperty;
    
    @Autowired
    private Environment environment;

    @Autowired
    CartResponseErrorHandler cartErrorHandler;

    public <T> T sendRequest(String url, HttpMethod method, Class<T> responseType, Cookie[] cookies) throws IntegrationException {
        ResponseEntity<String> responseStr = null;
        T responseObj = null;
        String cartHostSecure = null;

        try {            
            // This is required to ensure we start fresh and dont carry any old cookies
            if(cartRestTemplateInfo.getCookieStore()!=null){
                cartRestTemplateInfo.getCookieStore().clear();
            }
            
            HttpHeaders headers = new HttpHeaders();
            headers.setAccept(Collections.singletonList(new MediaType(GlobalConstants.APPLICATION, GlobalConstants.JSON)));
            headers.setContentType(new MediaType(GlobalConstants.APPLICATION, GlobalConstants.JSON));

            if (cookies != null) { // Async flow
                String cookieStr = Arrays.asList(cookies).stream()
                        .map(c -> c.getName().concat("=").concat(c.getValue()))
                        .collect(Collectors.joining(";"));
                log.debug("send Cookie to cart service: {}", cookieStr);
                headers.add("Cookie", cookieStr);
            }
            
            if(Arrays.stream(environment.getActiveProfiles()).anyMatch(env -> GlobalConstants.SPRING_PFOFILE_DEV.equalsIgnoreCase(env))) {                  
                ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
                if(requestAttributes!=null && requestAttributes.getRequest()!=null 
                        && requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV) !=null){
                    THDEnv thdEnv =  (THDEnv)requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV);
                    if(thdEnv!=null){
                        cartHostSecure = thdEnv.getSecureUrl();
                        log.debug("Cart host set to "+cartHostSecure);
                    }                            
                }
            }

            HttpEntity<Object> requestEntity = new HttpEntity<>(headers);

            String urlToCall = GlobalConstants.HTTPS + "://" + (cartHostSecure!=null ? cartHostSecure : envProperty.getCartHostName()) + "/" + url;
            log.debug("Calling cart service: URL -- {}", urlToCall);

            responseStr = cartRestTemplateInfo.getRestTemplate().exchange(urlToCall, method, requestEntity, String.class);

            log.debug("Cart service call response: {}", responseStr);

            if(responseStr.getBody() != null) {
                responseObj = cartRestTemplateInfo.getObjectMapper().readValue(responseStr.getBody(), responseType);
                if (!cartErrorHandler.isError(responseObj)) {
                    log.debug("sendRequest(): Cart Response object after unmarshalling "+responseObj);
                    HttpHeaders responseHeaders = responseStr.getHeaders();
                    List<String> responseCookies = Optional.ofNullable(responseHeaders.get("Set-Cookie"))
                                                            .map(ArrayList<String>::new)
                                                            .orElse(new ArrayList<>());
                    ((CartResponse) responseObj).setResponseCookies(responseCookies);
                } else {
                    cartErrorHandler.handleError(responseStr.getBody(), responseStr.getStatusCode());
                }
            }

        } catch(IntegrationException ex){
            throw ex;
        } catch (Exception ex) {
            Errors errors = new Errors();
            Error error = new Error();
            errors.setErrors(Arrays.asList(error));
            error.setErrorCode(ErrorCode.SYSTEM_ERROR);
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, ex);
        }

        log.debug("sendRequest(): Cart Response to be returned "+responseObj);
        return responseObj!=null?responseObj:null;
    }

    public <T> T sendRequestMCC(String url, HttpMethod method, Class<T> responseType, Cookie[] cookies) throws IntegrationException {
        ResponseEntity<String> responseStr = null;
        T responseObj = null;

        try {
            // This is required to ensure we start fresh and dont carry any old cookies
            if (cartRestTemplateInfo.getCookieStore() != null) {
                cartRestTemplateInfo.getCookieStore().clear();
            }

            HttpHeaders headers = new HttpHeaders();
            headers.setAccept(Collections.singletonList(new MediaType(GlobalConstants.APPLICATION, GlobalConstants.JSON)));
            headers.setContentType(new MediaType(GlobalConstants.APPLICATION, GlobalConstants.JSON));

            if (cookies != null) { // Async flow
                String cookieStr = Arrays.asList(cookies).stream()
                        .map(c -> c.getName().concat("=").concat(c.getValue()))
                        .collect(Collectors.joining(";"));
                log.debug("send Cookie to cart service: {}", cookieStr);
                headers.add("Cookie", cookieStr);
            }

            HttpEntity<Object> requestEntity = new HttpEntity<>(headers);

            String scheme = GlobalConstants.HTTP;
            if (!GlobalConstants.LOCALHOST.equalsIgnoreCase(envProperty.getRegistryHostName())) {
                scheme = GlobalConstants.HTTPS;
            }

            String urlToCall = scheme + "://" + envProperty.getCartGcpHostName() + "/" + url;

            log.debug("Calling cart service: URL -- {}", urlToCall);

            responseStr = cartRestTemplateInfo.getRestTemplate().exchange(urlToCall, method, requestEntity, String.class);

            log.debug("Cart service call response: {}", responseStr);

            if(responseStr.getBody() != null) {
                responseObj = cartRestTemplateInfo.getObjectMapper().readValue(responseStr.getBody(), responseType);
                if (!cartErrorHandler.isError(responseObj)) {
                    log.debug("sendRequest(): Cart Response object after unmarshalling "+responseObj);
                    HttpHeaders responseHeaders = responseStr.getHeaders();
                    List<String> responseCookies = Optional.ofNullable(responseHeaders.get("Set-Cookie"))
                            .map(ArrayList<String>::new)
                            .orElse(new ArrayList<>());
                    ((CartResponse) responseObj).setResponseCookies(responseCookies);
                } else {
                    cartErrorHandler.handleError(responseStr.getBody(), responseStr.getStatusCode());
                }
            }
        }
        catch(IntegrationException ex){
            throw ex;
        }
        catch (Exception ex) {
            Errors errors = new Errors();
            Error error = new Error();
            errors.setErrors(Arrays.asList(error));
            error.setErrorCode(ErrorCode.SYSTEM_ERROR);
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, ex);
        }

        log.debug("sendRequest(): Cart Response to be returned "+responseObj);
        return responseObj!=null?responseObj:null;
    }
}
