package com.homedepot.customer.integration.cart.config;

import org.apache.http.client.CookieStore;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.*;
import org.springframework.core.env.Environment;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.*;
import org.springframework.http.converter.json.*;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.homedepot.customer.util.*;

/**
 * Created by jirapat on 3/30/17.
 */
@Configuration
@PropertySource("cart/cart-integration.properties")
public class CartServiceConfig {

    @Autowired
    Environment env;

    @Bean(name = "cartRestTemplate")
    public CartRestTemplateInfo restTemplate() {
        final RestTemplate restTemplate = new RestTemplate();

        // Set message converters
        setMessageConverters(restTemplate);

        // Set connection params
        CookieStore httpCookieStore = setConnectionParams(restTemplate);

        return new CartRestTemplateInfo(restTemplate, customCartObjectMapper(),httpCookieStore);
    }

    private void setMessageConverters(RestTemplate restTemplate) {
        // find and replace Jackson message converter with custom. Old style for
        // loop to retain the iteration counter
        for (int i = 0; i < restTemplate.getMessageConverters().size(); i++) {
            final HttpMessageConverter<?> httpMessageConverter = restTemplate.getMessageConverters().get(i);
            if (httpMessageConverter instanceof MappingJackson2HttpMessageConverter) {
                restTemplate.getMessageConverters().set(i, mappingJackson2HttpMessageConverter());
            }
        }
    }

    private MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter() {
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        converter.setObjectMapper(customCartObjectMapper());

        return converter;
    }

    private ObjectMapper customCartObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.enable(SerializationFeature.WRAP_ROOT_VALUE);
        objectMapper.enable(DeserializationFeature.UNWRAP_ROOT_VALUE);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);

        return objectMapper;
    }


    private CookieStore setConnectionParams(RestTemplate restTemplate) {
        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
        connectionManager.setMaxTotal(Integer.parseInt(env.getProperty("cartConnectionMaxTotal")));
        connectionManager.setDefaultMaxPerRoute(Integer.parseInt(env.getProperty("cartDefaultMaxPerRoute")));
        RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(Integer.parseInt(env.getProperty("cartConnectionTimeout")))
                .setSocketTimeout(Integer.parseInt(env.getProperty("cartSocketTimeout"))).build();
        
        CookieStore httpCookieStore = new BasicCookieStore();
        HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
        httpClientBuilder.setConnectionManager(connectionManager);
        httpClientBuilder.setDefaultRequestConfig(requestConfig);
        httpClientBuilder.setDefaultCookieStore(httpCookieStore);

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClientBuilder.build());

        restTemplate.setRequestFactory(requestFactory);
        
        return httpCookieStore;
    }

    @Bean(name="cartErrorCodeMapResource")
    public ResourceBundleMessageSource resourceBundleMessageSource() {
        ResourceBundleMessageSource source = new ResourceBundleMessageSource();
        // Set the svoc error code to internal error code mapping
        source.setBasename("cart/cart-errorcode-mapping");
        source.setUseCodeAsDefaultMessage(true);
        return source;
    }
}
