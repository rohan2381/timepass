package com.homedepot.customer.integration.cart.dto;

import java.util.*;

import com.fasterxml.jackson.annotation.*;

import lombok.*;

/**
 * Created by nxw6207 on 8/4/17.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonRootName("CartMigrateResponse")
public class CartResponse {

    private  String status;

    private String errorCode;

    private String errorDescription;

    private List<String> responseCookies;

}
