package com.homedepot.customer.integration.cca;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.integration.cca.dto.HDNotificationEventList;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.client.DefaultResponseErrorHandler;

import java.io.IOException;
import java.util.Collections;

@Component
@Slf4j
public class CCAResponseErrorHandler extends DefaultResponseErrorHandler {

    private static final String FAILED_ACTION = "FAILED";

    @Autowired
    @Qualifier("ccaErrorCodeMapResource")
    private MessageSource errorCodeSource;

    @Override
    public void handleError(ClientHttpResponse response) throws IOException {

        log.error("Response error: {} {}", response.getStatusCode(), response.getStatusText());
    }

    public <T> void handleError(ResponseEntity<T> responseObj) throws IntegrationException {

        T respBody = responseObj.getBody();
        if (respBody instanceof HDNotificationEventList) {
            HDNotificationEventList eventList = (HDNotificationEventList) respBody;
            String ccaErrorMsg = String.format("CCA Response Error: Status = %s, Error Message = %s",
                                                    responseObj.getStatusCode(),
                                                    eventList.getEvent().getMethods().getStatus().getNotificationMsg());
            log.error(ccaErrorMsg);
            String code = eventList.getEvent().getMethods().getStatus().getNotificationCode();
            String message = eventList.getEvent().getMethods().getStatus().getNotificationMsg();
            Error error = new Error();
            error.setErrorCode(errorCodeSource.getMessage(code, null, ErrorCode.SYSTEM_ERROR, null));
            error.setDeveloperErrorMessage(code + ": " + message);
            Errors errors = new Errors();
            errors.setErrors(Collections.singletonList(error));
            throw new IntegrationException(errors, responseObj.getStatusCode(), ccaErrorMsg);
        }
    }

    public Errors createErrors(String errorCode) {

        Error error = new Error();
        error.setErrorCode(errorCode);
        Errors errors = new Errors();
        errors.setErrors(Collections.singletonList(error));
        return errors;
    }

    public <T> boolean hasError(ResponseEntity<T> responseObj) {

        boolean retVal = false;
        HttpStatus statusCode = responseObj.getStatusCode();
        if (statusCode.series() == HttpStatus.Series.CLIENT_ERROR ||
                statusCode.series() == HttpStatus.Series.SERVER_ERROR) {
            retVal = true;
        } else if (statusCode.series() == HttpStatus.Series.SUCCESSFUL) {
            T respBody = responseObj.getBody();
            if (respBody instanceof HDNotificationEventList) {
                HDNotificationEventList eventList = (HDNotificationEventList) respBody;
                retVal = FAILED_ACTION.equals(eventList.getEvent().getMethods().getStatus().getNotificationAction());
            }
        }
        return retVal;
    }

}