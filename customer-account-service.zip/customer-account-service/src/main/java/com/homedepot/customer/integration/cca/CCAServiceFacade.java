package com.homedepot.customer.integration.cca;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.integration.cca.dto.*;
import com.homedepot.customer.model.EmailNotificationInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
@Slf4j
@PropertySource("cca/cca-integration.properties")
public class CCAServiceFacade {

    private static final String SRC_TYPE = "MyAccount";

    @Autowired
    private CCAServiceHelper ccaServiceHelper;

    @Autowired
    private Environment env;

    public HDNotificationEventList sendNotification(EmailNotificationInfo info) {

        Orders request = createOrders(info);
        log.debug("CCA request body - {}", request);
        HDNotificationEventList resp = null;
        try {
            String ccaBaseUrl = env.getProperty("ccaBaseUrl");
            resp = ccaServiceHelper.sendRequest(HttpMethod.POST,
                                                ccaBaseUrl,
                                                new HttpHeaders(),
                                                request,
                                                HDNotificationEventList.class);
        } catch (IntegrationException ex) {
            log.error("Error sending email notification, Root Cause: " + ExceptionUtils.getRootCauseMessage(ex));
        }
        return resp;
    }

    private Orders createOrders(EmailNotificationInfo notificationInfo) {

        Orders orders = new Orders();
        orders.setSourceType(SRC_TYPE);
        orders.setNotificationTypeCode(notificationInfo.getEmailType().getCcaCode());
        Order order = new Order();
        HDCustNotificationInfoList infoList = new HDCustNotificationInfoList();
        HDCustNotificationInfo info = new HDCustNotificationInfo();
        info.setNotificationKey(String.valueOf(UUID.randomUUID()));
        infoList.setInfo(info);
        order.setInfoList(infoList);
        if (StringUtils.isNotBlank(notificationInfo.getOldEmail())) {
            PersonInfoShipTo shipTo = new PersonInfoShipTo();
            shipTo.setEmailId(notificationInfo.getOldEmail());
            order.setShipTo(shipTo);
        }
        // New email in case of email update request
        // billTo is a mandatory request element
        PersonInfoBillTo billTo = new PersonInfoBillTo();
        billTo.setEmailId(notificationInfo.getEmail());
        billTo.setFirstName(notificationInfo.getFirstName());
        order.setBillTo(billTo);
        order.setMessage(notificationInfo.getResetPwdUrl());
        orders.setOrder(order);
        return orders;
    }

}
