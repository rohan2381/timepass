package com.homedepot.customer.integration.cca;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.model.Errors;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.Objects;

@Service
@Slf4j
@PropertySource("cca/cca-integration.properties")
public class CCAServiceHelper {

    @Autowired
    @Qualifier("ccaRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private EnvPropertyUtil envProperty;

    @Autowired
    private CCAResponseErrorHandler errorHandler;

    public <T> T sendRequest(HttpMethod method,
                             String path,
                             HttpHeaders headers,
                             Object requestObj,
                             Class<T> responseType) throws IntegrationException {

        ResponseEntity<T> responseObj;
        try {
            setHeaders(headers);
            String urlToCall = String.format("%s://%s/%s", GlobalConstants.HTTPS, envProperty.getCcaHost(), path);
            HttpEntity<Object> requestEntity = new HttpEntity<>(requestObj, headers);

            log.debug("Calling CCA - " + urlToCall);
            responseObj = restTemplate.exchange(urlToCall, method, requestEntity, responseType);
            log.debug("CCA call response: {}", responseObj);

            Objects.requireNonNull(responseObj, "Response from CCA must not be null");
            if (errorHandler.hasError(responseObj)) { // Handle error response
                errorHandler.handleError(responseObj);
            }
        } catch (IntegrationException iEx) {
            throw iEx;
        } catch (Exception ex) {
            Errors errors = errorHandler.createErrors(ErrorCode.SYSTEM_ERROR);
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, ex);
        }
        return responseObj.getBody();
    }

    private void setHeaders(HttpHeaders headers) {

        headers.setContentType(new MediaType(GlobalConstants.APPLICATION, GlobalConstants.XML));
        headers.setAccept(Collections.singletonList(new MediaType(GlobalConstants.APPLICATION, GlobalConstants.XML)));
    }

}