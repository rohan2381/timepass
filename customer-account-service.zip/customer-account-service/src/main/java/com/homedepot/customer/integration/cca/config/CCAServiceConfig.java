package com.homedepot.customer.integration.cca.config;

import java.io.*;
import java.security.*;

import javax.net.ssl.*;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.homedepot.customer.integration.cca.CCAResponseErrorHandler;
import com.homedepot.customer.util.*;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.*;
import org.apache.http.conn.socket.*;
import org.apache.http.conn.ssl.*;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.env.Environment;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.xml.MappingJackson2XmlHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.*;

@Configuration
@PropertySource("cca/cca-integration.properties")
@Slf4j
public class CCAServiceConfig {

    @Autowired
    private CCAResponseErrorHandler errorHandler;

    @Autowired
    EnvPropertyUtil envProperty;

    @Autowired
    Environment env;

    @Bean(name = "ccaErrorCodeMapResource")
    public MessageSource resourceBundleMessageSource() {

        ResourceBundleMessageSource source = new ResourceBundleMessageSource();
        source.setBasename("cca/cca-errorcode-mapping");
        source.setUseCodeAsDefaultMessage(true);
        return source;
    }

    @Bean(name = "ccaRestTemplate")
    public RestTemplate restTemplate() {

        final RestTemplate restTemplate = new RestTemplate();
        setMessageConverters(restTemplate);
        setConnectionParams(restTemplate);
        restTemplate.setErrorHandler(errorHandler);
        return restTemplate;
    }

    public XmlMapper customCCAXmlMapper() {

        Jackson2ObjectMapperBuilder builder = new Jackson2ObjectMapperBuilder();
        builder.createXmlMapper(true);
        builder.serializationInclusion(JsonInclude.Include.NON_EMPTY);
        return builder.build();
    }

    private void setMessageConverters(RestTemplate restTemplate){

        restTemplate.getMessageConverters().replaceAll( converter ->
            (converter instanceof MappingJackson2XmlHttpMessageConverter) ?
                    mappingJackson2XmlHttpMessageConverter() : converter
        );
    }

    private MappingJackson2XmlHttpMessageConverter mappingJackson2XmlHttpMessageConverter() {

        MappingJackson2XmlHttpMessageConverter converter = new MappingJackson2XmlHttpMessageConverter();
        converter.setObjectMapper(customCCAXmlMapper());
        return converter;
    }

    private void setConnectionParams(RestTemplate restTemplate) {

        try{
            SSLContext context = SSLContext.getInstance("TLS");

            File file = new File(envProperty.getThdApiGatewayKeyStore());
            char[] keypass = envProperty.getThdApiGatewayKeyStorePass().toCharArray();

            KeyManagerFactory kmf = KeyManagerFactory.getInstance(GlobalConstants.KEY_MANAGER_FACTORY_ALGORITHM);
            FileInputStream fin = new FileInputStream(file);
            KeyStore ks = KeyStore.getInstance(GlobalConstants.KEY_STORE_TYPE);
            ks.load(fin, keypass);

            kmf.init(ks, keypass);
            context.init(kmf.getKeyManagers(), null, null);

            SSLConnectionSocketFactory socketFactory =
                    new SSLConnectionSocketFactory(context, GlobalConstants.SSL_PROTOCOLS, null, SSLConnectionSocketFactory.getDefaultHostnameVerifier());

            Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder
                    .<ConnectionSocketFactory> create().register(GlobalConstants.HTTPS, socketFactory)
                    .build();

            PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
            connectionManager.setMaxTotal(Integer.parseInt(env.getProperty("ccaConnectionMaxTotal")));
            connectionManager.setDefaultMaxPerRoute(Integer.parseInt(env.getProperty("ccaDefaultMaxPerRoute")));
            RequestConfig requestConfig = RequestConfig.custom()
                    .setConnectTimeout(Integer.parseInt(env.getProperty("ccaConnectionTimeout")))
                    .setSocketTimeout(Integer.parseInt(env.getProperty("ccaSocketTimeout")))
                    .build();
            HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
            httpClientBuilder.setConnectionManager(connectionManager);
            httpClientBuilder.setDefaultRequestConfig(requestConfig);
            HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClientBuilder.build());
            restTemplate.setRequestFactory(requestFactory);

        } catch(Exception ex){
            log.error("Error configuring http connection params for CCA: "+ex);
        }
    }

}
