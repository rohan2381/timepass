package com.homedepot.customer.integration.cca.dto;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.Data;

@Data
public class HDCustNotificationInfoList {

    @JacksonXmlProperty(localName = "HDCustNotificationInfo")
    private HDCustNotificationInfo info;

}
