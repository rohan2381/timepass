package com.homedepot.customer.integration.cca.dto;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.Data;

@Data
public class HDNotificationEvent {

    @JacksonXmlProperty(isAttribute = true, localName = "NotificationKey")
    private String notificationKey;

    @JacksonXmlProperty(localName = "NotificationMethods")
    private NotificationMethods methods;

}
