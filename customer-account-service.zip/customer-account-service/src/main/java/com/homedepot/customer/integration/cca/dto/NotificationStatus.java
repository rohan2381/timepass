package com.homedepot.customer.integration.cca.dto;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.Data;

@Data
public class NotificationStatus {

    @JacksonXmlProperty(isAttribute = true, localName = "NotificationCode")
    private String notificationCode;

    @JacksonXmlProperty(isAttribute = true, localName = "NotificationMsg")
    private String notificationMsg;

    @JacksonXmlProperty(isAttribute = true, localName = "NotificationSubCode")
    private String notificationSubCode;

    @JacksonXmlProperty(isAttribute = true, localName = "NotificationAction")
    private String notificationAction;

}
