package com.homedepot.customer.integration.cca.dto;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.Data;

@Data
public class Order {

    @JacksonXmlProperty(localName = "HDCustNotificationInfoList")
    private HDCustNotificationInfoList infoList;

    @JacksonXmlProperty(localName = "PersonInfoBillTo")
    private PersonInfoBillTo billTo;

    @JacksonXmlProperty(localName = "PersonInfoShipTo")
    private PersonInfoShipTo shipTo;

    @JacksonXmlProperty(isAttribute = true, localName = "Message")
    private String message;

}
