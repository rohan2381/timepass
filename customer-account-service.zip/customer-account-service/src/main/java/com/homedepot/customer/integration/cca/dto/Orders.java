package com.homedepot.customer.integration.cca.dto;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class Orders {

    @JacksonXmlProperty(isAttribute = true, localName = "SourceType")
    private String sourceType;

    @JacksonXmlProperty(isAttribute = true, localName = "NotificationTypeCode")
    private String notificationTypeCode;

    @JacksonXmlProperty(localName = "Order")
    private Order order;

}
