package com.homedepot.customer.integration.cca.dto;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.Data;

@Data
public class PersonInfoBillTo {

    @JacksonXmlProperty(isAttribute = true, localName = "FirstName")
    private String firstName;

    @JacksonXmlProperty(isAttribute = true, localName = "EMailID")
    private String emailId;

}
