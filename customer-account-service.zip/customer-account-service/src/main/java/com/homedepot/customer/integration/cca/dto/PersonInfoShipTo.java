package com.homedepot.customer.integration.cca.dto;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.Data;

@Data
public class PersonInfoShipTo {

    @JacksonXmlProperty(isAttribute = true, localName = "EMailID")
    private String emailId;
}
