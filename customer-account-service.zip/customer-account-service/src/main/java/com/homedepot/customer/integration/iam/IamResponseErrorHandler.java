package com.homedepot.customer.integration.iam;

import java.io.IOException;
import java.util.Collections;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.client.DefaultResponseErrorHandler;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.exception.error.IdentityErrorCode;
import com.homedepot.customer.integration.iam.dto.IAMErrorResponse;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class IamResponseErrorHandler extends DefaultResponseErrorHandler {

    private static final int INVALID_CRED_ERROR_CODE = 2243001;
    private static final int WILLBE_LOCKEDOUT_ERROR_CODE = 2243002;
    private static final int LOCKEDOUT_ERROR_CODE = 2243003;
    private static final int FORCE_RESET_ERROR_CODE = 2543011;
    private static final String LOCKOUT_COUNT_MSG = "Security Exception (1)";

    private static final String IAM_ERROR_MSG = "IAM Response Error:: ";

    @Autowired
    @Qualifier("iamErrorCodeMapResource")
    private ResourceBundleMessageSource errorCodeSource;

    @Override
    public void handleError(ClientHttpResponse response) throws IOException {

        log.error("IAM Response error: {} {}", response.getStatusCode(), response.getStatusText());
    }

    public void handleError(IAMErrorResponse resp, HttpStatus httpStatus) throws IntegrationException {
        HttpStatus httpStatusIAM = httpStatus;
        Errors errors;
        String respBody = (resp != null) ? resp.toString() : null;
        String iamErrorMsg = IAM_ERROR_MSG+"Status="+httpStatus+" Body="+respBody;
        if(HttpStatus.UNAUTHORIZED.equals(httpStatus)) {
            String msg = resp.getMessage();
            int iamCode = resp.getCode();

            if(iamCode == LOCKEDOUT_ERROR_CODE) { // Account is locked.
                errors = createErrors(String.valueOf(LOCKEDOUT_ERROR_CODE), iamErrorMsg);
            } else if(iamCode == FORCE_RESET_ERROR_CODE) { // Force reset password
                errors = createErrors(String.valueOf(FORCE_RESET_ERROR_CODE), iamErrorMsg);
            } else if(StringUtils.contains(msg, LOCKOUT_COUNT_MSG)) { // Account will be locked out msg
                errors = createErrors(String.valueOf(WILLBE_LOCKEDOUT_ERROR_CODE), iamErrorMsg);
            } else { // Invalid credentials msg
                errors = createErrors(String.valueOf(INVALID_CRED_ERROR_CODE), iamErrorMsg);
            }
        }
        else if (HttpStatus.BAD_REQUEST.equals(httpStatus) && iamErrorMsg.contains("iPlanetDirectoryCookie")) {
            errors = createErrors(String.valueOf(INVALID_CRED_ERROR_CODE), iamErrorMsg);
            httpStatusIAM = HttpStatus.UNAUTHORIZED;
        }
        else {
            errors = createErrors(String.valueOf(resp.getCode()), iamErrorMsg);
        }

        Error error = errors.getErrors().get(0);
        HttpStatus httpStatusMCM = (StringUtils.isNotEmpty(error.getErrorCode())) ? IdentityErrorCode.valueOfCode(error.getErrorCode()).getHttpStatus() : httpStatusIAM;
        throw new IntegrationException(errors, httpStatusMCM, iamErrorMsg);
    }

    public Errors createErrors(String errorCode, String developerErrorMsg) {
        Error error = new Error();
        error.setErrorCode(errorCodeSource.getMessage(errorCode, null, ErrorCode.SYSTEM_ERROR, null));
        error.setDeveloperErrorMessage(developerErrorMsg);
        Errors errors = new Errors();
        errors.setErrors(Collections.singletonList(error));

        return errors;
    }

    @Override
    public boolean hasError(HttpStatus status) {

        return status.series() == HttpStatus.Series.CLIENT_ERROR ||
                status.series() == HttpStatus.Series.SERVER_ERROR;
    }

}