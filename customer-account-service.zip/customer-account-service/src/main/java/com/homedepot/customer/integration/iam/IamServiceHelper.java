package com.homedepot.customer.integration.iam;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.integration.iam.config.IAMRestTemplateInfo;
import com.homedepot.customer.integration.iam.config.IAMServiceConfig;
import com.homedepot.customer.integration.iam.dto.*;
import com.homedepot.customer.model.Errors;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Objects;

@Service
@Slf4j
@PropertySource("iam/iam-integration.properties")
public class IamServiceHelper {

    @Autowired
    @Qualifier("iamRestTemplateInfo")
    private IAMRestTemplateInfo iamRestTemplateInfo;

    @Autowired
    private EnvPropertyUtil envProperty;

    @Autowired
    private IamResponseErrorHandler errorHandler;

    @Autowired
    private IAMServiceConfig iamServiceConfig;

    @Autowired
    private Environment env;

    public <T> T sendRequest(HttpMethod method,
            String path,
            HttpHeaders headers,
            Object requestObj,
            Class<T> responseType) throws IntegrationException {

        T iamResp = null;
        ResponseEntity<String> strIamRespObj;
        try {
            setHeaders(headers);
            String urlToCall = String.format("%s://%s/%s", GlobalConstants.HTTPS, envProperty.getIamHost(), path);
            HttpEntity<Object> requestEntity = new HttpEntity<>(requestObj, headers);

            log.debug("Calling IAM - " + urlToCall);
            log.debug("IAM call request Payload: {}", requestObj!=null?requestObj.toString():null);
            strIamRespObj = iamRestTemplateInfo.getRestTemplate().exchange(urlToCall, method, requestEntity, String.class);
            log.debug("IAM call response: {}", strIamRespObj);

            Objects.requireNonNull(strIamRespObj, "Response from IAM must not be null");
            ObjectMapper mapper = iamRestTemplateInfo.getObjectMapper();

            if(HttpStatus.UNAUTHORIZED.equals(strIamRespObj.getStatusCode()) && urlToCall.contains("_action=logout")){
                if(strIamRespObj.getBody() != null && strIamRespObj.getBody().contains("401")) {
                    iamResp = mapper.readValue(strIamRespObj.getBody(), responseType);
                    ((LogoutResponse) iamResp).setResult("Successfully logged out");
                    return iamResp;
                }
            }

            if (errorHandler.hasError(strIamRespObj.getStatusCode())) { // Handle error response
                IAMErrorResponse resp = mapper.readValue(strIamRespObj.getBody(), IAMErrorResponse.class);
                errorHandler.handleError(resp, strIamRespObj.getStatusCode());
            } else { // Handle success response
                iamResp = mapper.readValue(strIamRespObj.getBody(), responseType);
            }
        } catch (IntegrationException iEx) {
            throw iEx;
        } catch (Exception ex) {
            Errors errors = errorHandler.createErrors(null, ex.getMessage()); // defaults to "GEN_ERR_500"
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, ex);
        }
        return iamResp;
    }

    private void setHeaders(HttpHeaders headers) {

        headers.setContentType(new MediaType(GlobalConstants.APPLICATION, GlobalConstants.JSON));
        headers.setAccept(Collections.singletonList(new MediaType(GlobalConstants.APPLICATION, GlobalConstants.JSON)));
        headers.add(GlobalConstants.API_KEY,envProperty.getIamApiKey());
    }

}