package com.homedepot.customer.integration.iam;

import java.util.List;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.integration.iam.dto.*;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@PropertySource("iam/iam-integration.properties")
public class IamServicesFacade {

    @Autowired
    private IamServiceHelper iamServiceHelper;

    @Autowired
    private Environment env;

    private static final String URL_PATTERN = "%s?%s";

    private static final String CACHE_CONTROL = "Cache-Control";

    private static final String THDIAM_UNIFIED = "THDIAMUnified";

    private static final String X_OPENAM_USERNAME = "X-OpenAM-Username";

    private static final String X_OPENAM_PASSWORD = "X-OpenAM-Password"; // NOSONAR

    private static final String X_REQUESTED_WITH = "X-Requested-With";

    private static final String X_USERNAME = "X-Username";

    private static final String X_PASSWORD = "X-Password"; // NOSONAR

    private static final String X_NOSESSION = "X-NoSession";

    private static final String ACCEPT_LANGUAGE = "Accept-Language";

    private static final String IAM_BASE_URL = "iamBaseUrl";

    private static final String CACHE_CONTROL_VAL = "iamCacheControlHeaderValue";

    public String authenticateUser(String emailId, char[] passwd) throws IntegrationException {
        log.debug("authenticateUser - emailId: {}, channelId: {}", emailId);
        AuthenticateResponse authResp;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(X_OPENAM_USERNAME, emailId);
            String pass = Optional.ofNullable(passwd).map(String::valueOf).orElse(null);
            headers.add(X_OPENAM_PASSWORD, pass);
            String authPath = env.getProperty(IAM_BASE_URL) + env.getProperty("iamAuthURL");
            String authQuery = env.getProperty("iamAuthQuery");
            String authenticateUrl = String.format(URL_PATTERN, authPath, authQuery);
            authResp = iamServiceHelper.sendRequest(HttpMethod.POST,
                                                    authenticateUrl,
                                                    headers,
                                                    null,
                                                    AuthenticateResponse.class);
            log.debug("Successfully logged in IAM - emailId: {}", emailId);
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error authenticating user " + emailId + " in IAM: " + ex.getMessage());
            throw ex;
        }
        return Optional.ofNullable(authResp).map(AuthenticateResponse::getTokenId).orElse(null);
    }

    public IAMResponse validateUserSession(String authToken) throws IntegrationException {
        log.debug("validateUserSession - authToken: {}", authToken);
        IAMResponse resp;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(CACHE_CONTROL, env.getProperty(CACHE_CONTROL_VAL));
            String validatePath = env.getProperty(IAM_BASE_URL) + env.getProperty("iamValidateUrl") + authToken;
            String validateQuery = env.getProperty("iamValidateQuery");
            String validateUrl = String.format(URL_PATTERN, validatePath, validateQuery);
            SessionValidationResponse valResp = iamServiceHelper.sendRequest(HttpMethod.POST,
                                                                                validateUrl,
                                                                                headers,
                                                                                null,
                                                                                SessionValidationResponse.class);
            resp = new IAMResponse();
            resp.setSessionValid(valResp.getValid());
            resp.setUid(valResp.getUid());
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error validating user session in IAM: " + ex.getMessage());
            throw ex;
        }
        return resp;
    }

    public IAMResponse getUserInfo(String authToken, String email, String originId) throws IntegrationException {
        log.debug("getUserInfo - authToken: {}, email: {}", authToken, email);
        IAMResponse resp;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(CACHE_CONTROL, env.getProperty(CACHE_CONTROL_VAL));
            headers.add(THDIAM_UNIFIED, authToken);
            String userInfoPath = env.getProperty(IAM_BASE_URL) + env.getProperty("iamGetUrl");
            String userInfoQuery = String.format(env.getProperty("iamUserInfoQuery"), email, originId);
            String userInfoUrl = String.format(URL_PATTERN, userInfoPath, userInfoQuery);
            UserInfoResponse userInfoResp = iamServiceHelper.sendRequest(HttpMethod.GET,
                                                                            userInfoUrl,
                                                                            headers,
                                                                            null,
                                                                            UserInfoResponse.class);
            resp = new IAMResponse();
            List<UserInfo> userInfo = userInfoResp.getResult();
            Optional<UserInfo> optUI = userInfo.stream().findFirst();
            optUI.ifPresent(ui -> Optional.ofNullable(ui.getMail())
                                                        .ifPresent(m -> ui.getMail().stream()
                                                                                    .findFirst()
                                                                                    .ifPresent(resp::setMail)));
            optUI.ifPresent(ui -> Optional.ofNullable(ui.getHdOriginID())
                                                        .ifPresent(m -> ui.getHdOriginID().stream()
                                                                                            .findFirst()
                                                                                            .ifPresent(resp::setHdoriginid)));
            optUI.ifPresent(ui -> Optional.ofNullable(ui.getHdSvocID())
                                                        .ifPresent(m -> ui.getHdSvocID().stream()
                                                                                        .findFirst()
                                                                                        .ifPresent(resp::setHdsvocid)));
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error while getting user info for " + email + " from IAM: " + ex.getMessage());
            throw ex;
        }
        return resp;
    }

    public String registerUser(RegistrationRequest request) throws IntegrationException {
        log.debug("registerUser - request: {}", request);
        RegistrationResponse regResp;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(CACHE_CONTROL, env.getProperty(CACHE_CONTROL_VAL));
            String registrationPath = env.getProperty(IAM_BASE_URL) + env.getProperty("iamRegisterUrl");
            String registrationQuery = env.getProperty("iamRegistrationQuery");
            String registrationUrl = String.format(URL_PATTERN, registrationPath, registrationQuery);
            regResp = iamServiceHelper.sendRequest(HttpMethod.POST,
                                                    registrationUrl,
                                                    headers,
                                                    request,
                                                    RegistrationResponse.class);
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error while registering user in IAM: " + ex.getMessage());
            throw ex;
        }
        return Optional.ofNullable(regResp.getAdditions()).map(RegistrationSessionData::getTokenId).orElse(null);
    }

    public String forgotPassword(ForgotPasswordRequest request) throws IntegrationException {
        log.debug("forgotPassword - request: {}", request);
        ForgotPasswordResponse forgotResp;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(CACHE_CONTROL, env.getProperty(CACHE_CONTROL_VAL));
            headers.add(X_REQUESTED_WITH, env.getProperty("iamXmlHttpRequest"));
            headers.add(X_USERNAME, env.getProperty("iamAnonymous"));
            headers.add(X_PASSWORD, env.getProperty("iamAnonymous"));
            headers.add(X_NOSESSION, env.getProperty("iamTrue"));
            headers.add(ACCEPT_LANGUAGE, env.getProperty("iamUsEnglish"));
            String forgotPassPath = env.getProperty(IAM_BASE_URL) + env.getProperty("iamForgotUrl");
            String forgotPassQuery = env.getProperty("iamForgotPassQuery");
            String forgotPassUrl = String.format(URL_PATTERN, forgotPassPath, forgotPassQuery);
            forgotResp = iamServiceHelper.sendRequest(HttpMethod.POST,
                                                        forgotPassUrl,
                                                        headers,
                                                        request,
                                                        ForgotPasswordResponse.class);
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error while making forgot password request to IAM: " + ex.getMessage());
            throw ex;
        }
        return Optional.ofNullable(forgotResp).map(ForgotPasswordResponse::getToken).orElse(null);
    }

    public ChangeEmailResponse changeEmail(ChangeEmailRequest emailRequest, String authToken, String hdSvocId) throws IntegrationException {
        log.debug("changeEmail - request: {}", emailRequest);
        ChangeEmailResponse changeEmailResponse;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(THDIAM_UNIFIED, authToken);
            String changeEmailUrl = env.getProperty(IAM_BASE_URL) + env.getProperty("iamChangeEmailUrl") + hdSvocId;
            changeEmailResponse = iamServiceHelper.sendRequest(HttpMethod.PUT,
                                                                changeEmailUrl,
                                                                headers,
                                                                emailRequest,
                                                                ChangeEmailResponse.class);
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error while making change email request for " + emailRequest.getMail() + " to IAM: " + ex.getMessage());
            throw ex;
        }
        return changeEmailResponse;
    }

    public Object changePassword(ChangePasswordRequest request, String authToken, String hdSvocId) throws IntegrationException {
        log.debug("changePassword - request: {}", request);
        Object changePasswordResponse;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(THDIAM_UNIFIED, authToken);
            String changePassUrl = env.getProperty(IAM_BASE_URL) + env.getProperty("iamChangePassUrl") + hdSvocId;
            changePasswordResponse = iamServiceHelper.sendRequest(HttpMethod.PUT,
                                            changePassUrl,
                                            headers,
                                            request,
                                            Object.class);
        } catch (IntegrationException ex) {
            ex.setErrorMessage("IAM Password Update Failed: " + ex.getMessage());
            throw ex;
        }
        return changePasswordResponse;
    }

    public ResetPasswordResponse resetPassword(ResetPasswordRequest request) throws
            IntegrationException {
        log.debug("resetPassword - request: {}", request);
        ResetPasswordResponse resetPasswordResponse;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(CACHE_CONTROL, env.getProperty(CACHE_CONTROL_VAL));
            String forgotPassPath = env.getProperty(IAM_BASE_URL) + env.getProperty("iamForgotUrl");
            String forgotPassQuery = env.getProperty("iamForgotPassQuery");
            String forgotPassUrl = String.format(URL_PATTERN, forgotPassPath, forgotPassQuery);
            resetPasswordResponse = iamServiceHelper.sendRequest(HttpMethod.POST,
                    forgotPassUrl,
                    headers,
                    request,
                    ResetPasswordResponse.class);
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error while making reset password request to IAM: " + ex.getMessage());
            throw ex;
        }
        return resetPasswordResponse;
    }

    public String signOutUser(String authToken) throws IntegrationException {
        log.debug("signOutUser - authToken: {}", authToken);
        LogoutResponse logoutResp;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(CACHE_CONTROL, env.getProperty(CACHE_CONTROL_VAL));
            headers.add(THDIAM_UNIFIED, authToken);
            String signOutPath = env.getProperty(IAM_BASE_URL) + env.getProperty("iamSignoutUrl");
            String signOutQuery = env.getProperty("iamSignOutQuery");
            String signOutUrl = String.format(URL_PATTERN, signOutPath, signOutQuery);
            logoutResp = iamServiceHelper.sendRequest(HttpMethod.POST,
                                                        signOutUrl,
                                                        headers,
                                                        null,
                                                        LogoutResponse.class);
            log.debug("Successfully logged out customer session in IAM");
        } catch(IntegrationException ex){
            ex.setErrorMessage("Error logging out customer session in IAM: " + ex.getMessage());
            throw ex;
        }
        return Optional.ofNullable(logoutResp).map(LogoutResponse::getResult).orElse(null);
    }

    public String getSvocIdFromSession(String authToken) throws IntegrationException {
        log.debug("getSvocIdFromSession - authToken: {}", authToken);
        IdFromSessionResponse idFromSessionResp;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(THDIAM_UNIFIED, authToken);
            String idFromSessionPath = env.getProperty(IAM_BASE_URL) + env.getProperty("iamIdFromSessionUrl");
            String idFromSessionQuery = env.getProperty("iamIdFromSessionQuery");
            String idFromSessionUrl = String.format(URL_PATTERN, idFromSessionPath, idFromSessionQuery);
            idFromSessionResp = iamServiceHelper.sendRequest(HttpMethod.POST,
                                                                idFromSessionUrl,
                                                                headers,
                                                                null,
                                                                IdFromSessionResponse.class);
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error while getting svoc id from IAM: " + ex.getMessage());
            throw ex;
        }
        return Optional.ofNullable(idFromSessionResp).map(IdFromSessionResponse::getId).orElse(null);
    }

    public boolean userExists(String svocId, String serviceAuthToken) throws IntegrationException {

        log.debug("userExists - svoc id: {}", svocId);
        boolean userExists;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(THDIAM_UNIFIED, serviceAuthToken);
            String userExistUrl = env.getProperty(IAM_BASE_URL) + String.format(env.getProperty("iamUserExistUrl"), svocId);
            UserInfo userInfo = iamServiceHelper.sendRequest(HttpMethod.GET,
                                                                userExistUrl,
                                                                headers,
                                                                null,
                                                                UserInfo.class);
            userExists = CollectionUtils.isNotEmpty(userInfo.getMail()); // 200 - user found
        } catch(IntegrationException ex) {
            if(HttpStatus.NOT_FOUND.equals(ex.getHttpStatus())) {
                userExists = false; // 404 resource not found
                log.debug("User with svoc id {} does not exist in IAM", svocId);
            } else {
                ex.setErrorMessage("Error while checking user existence for " + svocId + " in IAM: " + ex.getMessage());
                throw ex;
            }
        }
        return userExists;
    }

    public String getServiceAuthToken(String userName, String password) throws IntegrationException {
        log.debug("getServiceAuthToken - userName: {} ", userName);
        AuthenticateResponse serviceTokenResponse;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(X_OPENAM_USERNAME, userName);
            headers.add(X_OPENAM_PASSWORD, password);
            String serviceTokenUrl = env.getProperty("iamServiceBaseUrl") + env.getProperty("iamServiceAuthUrl");
            serviceTokenResponse = iamServiceHelper.sendRequest(HttpMethod.POST,
                                                                serviceTokenUrl,
                                                                headers,
                                                                null,
                                                                AuthenticateResponse.class);
        } catch(IntegrationException ex) {
            ex.setErrorMessage("Error while requesting service auth token: " + ex.getMessage());
            throw ex;
        }
        return serviceTokenResponse.getTokenId();
    }

    public Object accountLock(AccountLockRequest accountLockRequest ,String authToken, String hdSvocId) throws
            IntegrationException {
        log.debug("accountLock - hdSvocId: {}", hdSvocId);
        Object accountLockResponse;
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(THDIAM_UNIFIED, authToken);
            String accountLockUrl = env.getProperty("iamBaseUrl") + String.format(env.getProperty("iamAccountLockUrl"), hdSvocId);
            accountLockResponse = iamServiceHelper.sendRequest(HttpMethod.PUT,
                                                                accountLockUrl,
                                                                headers,
                                                                accountLockRequest,
                                                                Object.class);
        } catch(IntegrationException ex) {
            ex.setErrorMessage("Error while unlock/locking user account: " + ex.getMessage());
            throw ex;
        }
        return accountLockResponse;
    }

}
