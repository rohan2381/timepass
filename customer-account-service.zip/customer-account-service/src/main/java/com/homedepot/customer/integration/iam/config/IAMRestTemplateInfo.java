package com.homedepot.customer.integration.iam.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.web.client.RestTemplate;

@Data
@AllArgsConstructor
public class IAMRestTemplateInfo {

    private RestTemplate restTemplate;
    private ObjectMapper objectMapper;
}
