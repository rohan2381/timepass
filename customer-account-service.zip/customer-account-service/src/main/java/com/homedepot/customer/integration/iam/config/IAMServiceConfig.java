package com.homedepot.customer.integration.iam.config;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.homedepot.customer.integration.iam.IamResponseErrorHandler;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;

import lombok.extern.slf4j.Slf4j;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.env.Environment;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.*;
import org.springframework.http.converter.json.*;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.util.Set;
import java.util.regex.Pattern;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

/**
 * Created by rxb1809 on May 16, 2016
 * Handles configurations for interacting with IAM services
 */
@Configuration
@PropertySource("iam/iam-integration.properties")
@Slf4j
public class IAMServiceConfig {

    private static final String REPEAT_CHAR_REGEX_KEY = "rule.password.repeat.char";

    @Autowired
    private IamResponseErrorHandler errorHandler;

    @Autowired
    Environment env;
    
    @Autowired
    EnvPropertyUtil envProperty;

    @Autowired
    @Qualifier("rulesMessageResource")
    private MessageSource messageSource;

    @Bean(name = "dictionaryPwdWords")
    public Set<String> dictionaryPwdWords() throws IOException {

        return PropertiesLoaderUtils.loadAllProperties("iam/passwd_dictionary.properties").stringPropertyNames();
    }

    @Bean(name = "repeatedPwdCharPattern")
    public Pattern repeatedPwdCharPattern() {

        return Pattern.compile(messageSource.getMessage(REPEAT_CHAR_REGEX_KEY, null, null));
    }

    @Bean(name = "iamErrorCodeMapResource")
    public ResourceBundleMessageSource resourceBundleMessageSource() {

        ResourceBundleMessageSource source = new ResourceBundleMessageSource();
        source.setBasename("iam/iam-errorcode-mapping");
        source.setUseCodeAsDefaultMessage(true);
        return source;
    }

    @Bean(name = "iamRestTemplateInfo")
    public IAMRestTemplateInfo restTemplateInfo() {

        final RestTemplate restTemplate = new RestTemplate();

        // Set message converters
        setMessageConverters(restTemplate);

        // Set connection params
        setConnectionParams(restTemplate);

        // Set error handler
        restTemplate.setErrorHandler(errorHandler);

        return new IAMRestTemplateInfo(restTemplate, customIAMObjectMapper());
    }

    private void setMessageConverters(RestTemplate restTemplate){
        //find and replace Jackson message converter with custom. Old style for loop to retain the iteration counter
        for (int i = 0; i < restTemplate.getMessageConverters().size(); i++) {
            final HttpMessageConverter<?> httpMessageConverter = restTemplate.getMessageConverters().get(i);
            if (httpMessageConverter instanceof MappingJackson2HttpMessageConverter){
                restTemplate.getMessageConverters().set(i, mappingJackson2HttpMessageConverter());
            }
        }
    }

    private MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter() {
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        converter.setObjectMapper(customIAMObjectMapper());

        return converter;
    }

    public ObjectMapper customIAMObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);

        return objectMapper;
    }

    private void setConnectionParams(RestTemplate restTemplate) {
        
        try{
            // Trust store settings
            File trustStoreFile = new File(envProperty.getThdApiGatewayTrustStore());
            char[] trustStorePass = envProperty.getThdApiGatewayTrustStorePass().toCharArray();
            
            TrustManagerFactory tmf = TrustManagerFactory.getInstance(GlobalConstants.TRUST_MANAGER_FACTORY_ALGORITHM, 
                                                                    GlobalConstants.TRUST_MANAGER_FACTORY_ALGORITHM_PROVIDER);
            FileInputStream trustStoreInStream = new FileInputStream(trustStoreFile);
            KeyStore tks = KeyStore.getInstance(GlobalConstants.KEY_STORE_TYPE);
            tks.load(trustStoreInStream,trustStorePass);
            tmf.init(tks);
            
            // Key store settings
            File keyStoreFile = new File(envProperty.getThdApiGatewayKeyStore());
            char[] keyStorePass = envProperty.getThdApiGatewayKeyStorePass().toCharArray();
            
            KeyManagerFactory kmf = KeyManagerFactory.getInstance(GlobalConstants.KEY_MANAGER_FACTORY_ALGORITHM);
            FileInputStream keyStoreInStream = new FileInputStream(keyStoreFile);
            KeyStore kks = KeyStore.getInstance(GlobalConstants.KEY_STORE_TYPE);
            kks.load(keyStoreInStream, keyStorePass);
            kmf.init(kks, keyStorePass);
            
            // Initialize the SSL context
            SSLContext context = SSLContext.getInstance(GlobalConstants.SSL_CONTEXT);
            context.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

            SSLConnectionSocketFactory socketFactory = 
                    new SSLConnectionSocketFactory(context, GlobalConstants.SSL_PROTOCOLS, null, SSLConnectionSocketFactory.getDefaultHostnameVerifier());
            
            Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder
                    .<ConnectionSocketFactory> create().register(GlobalConstants.HTTPS, socketFactory)
                    .build();

            PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
            connectionManager.setMaxTotal(Integer.parseInt(env.getProperty("iamConnectionMaxTotal")));
            connectionManager.setDefaultMaxPerRoute(Integer.parseInt(env.getProperty("iamDefaultMaxPerRoute")));
            RequestConfig requestConfig = RequestConfig.custom()
                                            .setConnectTimeout(Integer.parseInt(envProperty.getIamConnectionTimeout()))
                                            .setSocketTimeout(Integer.parseInt(envProperty.getIamSocketTimeout()))
                                            .build();

            HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
            httpClientBuilder.setConnectionManager(connectionManager);
            httpClientBuilder.setDefaultRequestConfig(requestConfig);

            HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClientBuilder.build());

            restTemplate.setRequestFactory(requestFactory);
        }catch(Exception ex){
            log.error("Error configuring http connection params for IAM: " + ex);
        }
        
    }

}
