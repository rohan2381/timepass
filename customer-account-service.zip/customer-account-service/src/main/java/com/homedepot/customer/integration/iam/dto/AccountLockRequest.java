package com.homedepot.customer.integration.iam.dto;

import com.fasterxml.jackson.annotation.*;

import lombok.*;

/**
 * Created by nxw6207 on 2/10/17.
 */
@Data
@JsonRootName("")
public class AccountLockRequest {
    String inetuserstatus;
}
