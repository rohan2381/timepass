package com.homedepot.customer.integration.iam.dto;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;
import lombok.ToString;

/**
 * Created by Nitin Ware on 9/26/16.
 */
@Data
@ToString
@JsonRootName("")
public class ChangeEmailRequest {
    private String mail;
}
