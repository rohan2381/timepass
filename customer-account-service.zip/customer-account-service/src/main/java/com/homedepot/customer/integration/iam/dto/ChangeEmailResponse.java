package com.homedepot.customer.integration.iam.dto;

import lombok.Data;

import java.util.List;

/**
 * Created by Nitin Ware on 9/27/16.
 */
@Data
public class ChangeEmailResponse {
    private String username;
    private List<String> mail;
}
