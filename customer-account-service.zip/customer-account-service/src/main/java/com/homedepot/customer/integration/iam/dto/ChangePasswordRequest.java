package com.homedepot.customer.integration.iam.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString(exclude = {"userpassword"})
public class ChangePasswordRequest {

    private char[] userpassword;
}
