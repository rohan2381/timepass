package com.homedepot.customer.integration.iam.dto;

import lombok.Data;

@Data
public class ForgotPasswordData {

    private String queryFilter; // NOSONAR
}
