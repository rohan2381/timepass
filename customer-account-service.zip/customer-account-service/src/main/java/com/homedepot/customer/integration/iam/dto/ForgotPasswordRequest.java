package com.homedepot.customer.integration.iam.dto;

import lombok.Data;

@Data
public class ForgotPasswordRequest {

    private ForgotPasswordData input; // NOSONAR
}
