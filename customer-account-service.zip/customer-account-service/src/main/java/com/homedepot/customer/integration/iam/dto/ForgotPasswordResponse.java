package com.homedepot.customer.integration.iam.dto;

import lombok.Data;

@Data
public class ForgotPasswordResponse {

    private String token; // NOSONAR
}
