package com.homedepot.customer.integration.iam.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode
@ToString
public class IAMErrorResponse {

    private int code;
    private String reason;
    private String message;
}
