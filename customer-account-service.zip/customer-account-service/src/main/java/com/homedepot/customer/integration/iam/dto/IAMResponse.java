package com.homedepot.customer.integration.iam.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by rxb1809 on Aug 18, 2016
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IAMResponse {

	private String hdsvocid;
	private String token;
	private String username;
	private String mail;
	private String uid;
	private String status;
	private String hdoriginid;
	private Boolean sessionValid;
	
}
