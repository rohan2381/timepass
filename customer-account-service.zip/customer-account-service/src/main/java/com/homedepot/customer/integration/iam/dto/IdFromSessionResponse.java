package com.homedepot.customer.integration.iam.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class IdFromSessionResponse {

    String id;
}
