package com.homedepot.customer.integration.iam.dto;

import lombok.Data;

@Data
public class LogoutResponse {

    private String result; // NOSONAR
}
