package com.homedepot.customer.integration.iam.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString(exclude = "userPassword")
public class RegistrationData {

    private String mail;
    private String username;
    private char[] userPassword;
    private String cn;
    private String sn;
}
