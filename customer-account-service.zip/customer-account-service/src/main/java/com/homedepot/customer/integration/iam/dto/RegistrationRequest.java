package com.homedepot.customer.integration.iam.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class RegistrationRequest {

    private RegistrationInput input;
}
