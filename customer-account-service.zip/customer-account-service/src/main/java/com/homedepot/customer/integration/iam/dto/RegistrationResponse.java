package com.homedepot.customer.integration.iam.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode
@ToString
public class RegistrationResponse {

    private String type;
    private String tag;
    private RegistrationStatus status;
    private RegistrationSessionData additions;
}
