package com.homedepot.customer.integration.iam.dto;

import lombok.*;

/**
 * Created by nxw6207 on 12/22/16.
 */
@Data
@EqualsAndHashCode
@ToString(exclude = "password")
public class ResetPasswordInput {

    private char[]  password;

    private String queryFilter;

}
