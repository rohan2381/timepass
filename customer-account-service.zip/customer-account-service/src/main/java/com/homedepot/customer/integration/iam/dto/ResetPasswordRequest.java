package com.homedepot.customer.integration.iam.dto;

import lombok.*;

/**
 * Created by nxw6207 on 12/22/16.
 */
@Data
@ToString
public class ResetPasswordRequest {

    private ResetPasswordInput input;

    private String token;

}
