package com.homedepot.customer.integration.iam.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode
public class SessionValidationResponse {

    private Boolean valid;
    private String uid;
}
