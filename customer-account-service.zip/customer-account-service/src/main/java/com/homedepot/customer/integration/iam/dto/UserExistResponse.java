package com.homedepot.customer.integration.iam.dto;

import lombok.Data;

import java.util.List;

@Data
public class UserExistResponse {

    private int resultCount;
    private List<UserInfo> result;
}
