package com.homedepot.customer.integration.iam.dto;

import lombok.Data;

import java.util.List;

@Data
public class UserInfo {

    private List<String> mail;
    private List<String> hdOriginID;
    private List<String> hdSvocID;
}
