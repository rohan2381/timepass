package com.homedepot.customer.integration.iam.dto;

import lombok.Data;

import java.util.List;

@Data
public class UserInfoResponse {

    private List<UserInfo> result; // NOSONAR
}
