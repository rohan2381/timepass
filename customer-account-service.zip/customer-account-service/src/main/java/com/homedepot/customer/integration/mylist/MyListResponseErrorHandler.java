package com.homedepot.customer.integration.mylist;

import java.io.*;
import org.springframework.http.*;
import org.springframework.http.client.*;
import org.springframework.stereotype.*;
import org.springframework.web.client.*;
import lombok.extern.slf4j.*;

@Component
@Slf4j
public class MyListResponseErrorHandler extends DefaultResponseErrorHandler {
    private static final String MYLIST_ERROR_MSG = "MYLIST Response Error:: ";
    private static final String MYLIST_UNVAIALABE_MSG = "MYLIST Services Not Available:: ";

    @Override
    public void handleError(ClientHttpResponse response) throws IOException {
        //NOSONAR
    }

    @Override
    public boolean hasError(HttpStatus status) {

        return status.series() == HttpStatus.Series.CLIENT_ERROR ||
                status.series() == HttpStatus.Series.SERVER_ERROR;
    }

    public void handleError(Object respObj, HttpStatus httpStatus) {
        String listErrorMsg;
        if(respObj==null)
            listErrorMsg = MYLIST_ERROR_MSG+"Status="+httpStatus;
        else
            listErrorMsg = MYLIST_UNVAIALABE_MSG+"Status="+httpStatus+" Body="+respObj.toString();
        log.error(listErrorMsg);

    }
}
