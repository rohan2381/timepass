package com.homedepot.customer.integration.mylist;

import java.util.*;
import javax.servlet.http.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.*;
import org.springframework.http.*;
import org.springframework.stereotype.*;
import com.homedepot.customer.exception.*;
import com.homedepot.customer.integration.mylist.dto.*;
import com.homedepot.customer.util.*;

import lombok.extern.slf4j.*;

@Service
@Slf4j
@PropertySource("mylist/mylist-integration.properties")
public class MyListServiceFacade {

    @Autowired
    Environment env;

    @Autowired
    MyListServiceHelper myListServiceHelper;

    public MyListResponse migrateMyList(String userId, Cookie[] reqCookies, Cookie[] respCookies) throws IntegrationException {
        try {
            String migrateMyListUrl = String.format(env.getProperty("migrateListBaseUrl"), userId);
            Map<String, String> requestHeaders = buildRequestHeaders(respCookies);
            Cookie[] cookies = buildCookieArray(reqCookies, respCookies);
            return myListServiceHelper.sendRequest(migrateMyListUrl, HttpMethod.GET, MyListResponse.class, requestHeaders, cookies);
        }catch(IntegrationException ex){
            ex.setErrorMessage("Error migrating list for customer "+userId+". "+ex.getMessage());
            throw ex;
        }
    }

    private Map<String, String> buildRequestHeaders(Cookie[] respCookies) {
        Map<String, String> requestHeaders = new HashMap<>();
        requestHeaders.put(GlobalConstants.THD_AUTH_TOKEN, getAuthToken(respCookies));
        return requestHeaders;
    }

    private String getAuthToken(Cookie[] respCookies) {
        String authToken = null;
        Optional<Cookie> thdUserSessionCookieOpt =  Arrays.stream(respCookies)
                .filter(c -> c.getName().equals(GlobalConstants.THD_USER_SESSION))
                .findAny();
        if (thdUserSessionCookieOpt.isPresent())
            authToken = thdUserSessionCookieOpt.get().getValue();
        return authToken;
    }

    private Cookie[] buildCookieArray(Cookie[] originalReqCookies, Cookie[] originalRespCookies) {
        Map<String, Cookie> cookieMap = new HashMap<>();
        if (originalReqCookies != null) {
            for (Cookie c: originalReqCookies) {
                if (!cookieMap.containsKey(c.getName())) {
                    cookieMap.put(c.getName(), c);
                }
            }
        }
        if (originalRespCookies != null) {
            for (Cookie c: originalRespCookies) {
                if (!cookieMap.containsKey(c.getName())) {
                    cookieMap.put(c.getName(), c);
                }
            }
        }
        return cookieMap.values().toArray(new Cookie[cookieMap.size()]);
    }

}
