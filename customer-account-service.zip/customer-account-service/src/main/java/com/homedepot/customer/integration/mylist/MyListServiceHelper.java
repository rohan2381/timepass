package com.homedepot.customer.integration.mylist;

import java.util.*;
import java.util.stream.*;
import javax.servlet.http.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.stereotype.*;
import com.homedepot.customer.exception.*;
import com.homedepot.customer.exception.error.*;
import com.homedepot.customer.integration.mylist.config.*;
import com.homedepot.customer.model.*;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.util.*;
import lombok.extern.slf4j.*;

@Service
@Slf4j
public class MyListServiceHelper {

    @Autowired
    @Qualifier("mylistRestTemplate")
    MyListRestTemplateInfo myListRestTemplateInfo;

    @Autowired
    EnvPropertyUtil envProperty;

    @Autowired
    MyListResponseErrorHandler myListResponseErrorHandler;

    public <T> T sendRequest(String url, HttpMethod method, Class<T> responseType, Map<String, String>requestHeaders, Cookie[] cookies) throws IntegrationException {
        ResponseEntity<String> responseEntity = null;
        T responseObj = null;
        String mylistHostSecure = null;

        try {

            // This is required to ensure we start fresh and dont carry any old cookies
            if (myListRestTemplateInfo.getCookieStore() != null) {
                myListRestTemplateInfo.getCookieStore().clear();
            }

            HttpHeaders headers = new HttpHeaders();
            headers.setAccept(Collections.singletonList(new MediaType(GlobalConstants.APPLICATION, GlobalConstants.JSON)));
            headers.setContentType(new MediaType(GlobalConstants.APPLICATION, GlobalConstants.JSON));
            requestHeaders.forEach((k,v) -> headers.add(k, v));

            if (cookies != null) {
                String cookieStr = Arrays.asList(cookies).stream()
                        .map(c -> c.getName().concat("=").concat(c.getValue()))
                        .collect(Collectors.joining(";"));
                log.debug("send Cookie to mylist service: {}", cookieStr);
                headers.add("Cookie", cookieStr);
            }

            HttpEntity<Object> requestEntity = new HttpEntity<>(headers);

            String urlToCall = GlobalConstants.HTTP + "://" + (mylistHostSecure!=null ? mylistHostSecure : envProperty.getMylistHostName()) + "/" + url;
            log.debug("Calling mylist service: URL -- {}", urlToCall);

            responseEntity = myListRestTemplateInfo.getRestTemplate().exchange(urlToCall, method, requestEntity, String.class);

            log.debug("Mylist call response: {}", responseEntity);

            if (myListResponseErrorHandler.hasError(responseEntity.getStatusCode())) { // Handle error response
                myListResponseErrorHandler.handleError(responseEntity.getBody(), responseEntity.getStatusCode());
            } else {
                responseObj = myListRestTemplateInfo.getObjectMapper().readValue(responseEntity.getBody(), responseType);
            }

        } catch (Exception ex) {
            Errors errors = new Errors();
            Error error = new Error();
            errors.setErrors(Arrays.asList(error));
            error.setErrorCode(ErrorCode.SYSTEM_ERROR);
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, ex);
        }
        log.debug("sendRequest(): Mylist Response to be returned "+responseObj);
        return responseObj!=null?responseObj:null;
    }

}
