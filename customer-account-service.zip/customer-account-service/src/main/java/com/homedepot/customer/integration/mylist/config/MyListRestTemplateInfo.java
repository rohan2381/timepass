package com.homedepot.customer.integration.mylist.config;

import org.apache.http.client.*;
import org.springframework.web.client.*;

import com.fasterxml.jackson.databind.*;

import lombok.*;

/**
 * Created by admin on 8/11/17.
 */
@Data
@AllArgsConstructor
public class MyListRestTemplateInfo {
    private RestTemplate restTemplate;
    private ObjectMapper objectMapper;
    private CookieStore cookieStore;
}