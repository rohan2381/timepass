package com.homedepot.customer.integration.mylist.config;

import org.apache.http.client.*;
import org.apache.http.client.config.*;
import org.apache.http.impl.client.*;
import org.apache.http.impl.conn.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.context.annotation.*;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.*;
import org.springframework.http.client.*;
import org.springframework.http.converter.*;
import org.springframework.http.converter.json.*;
import org.springframework.web.client.*;
import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;

/**
 * Created by jirapat on 3/30/17.
 */
@Configuration
@PropertySource("mylist/mylist-integration.properties")
public class MyListServiceConfig {

    @Autowired
    Environment env;

    @Bean(name = "mylistRestTemplate")
    public MyListRestTemplateInfo restTemplate() {
        final RestTemplate restTemplate = new RestTemplate();

        // Set message converters
        setMessageConverters(restTemplate);

        // Set connection params
        CookieStore httpCookieStore = setConnectionParams(restTemplate);

        return new MyListRestTemplateInfo(restTemplate, customMyListObjectMapper(),httpCookieStore);
    }

    private void setMessageConverters(RestTemplate restTemplate) {
        // find and replace Jackson message converter with custom. Old style for
        // loop to retain the iteration counter
        for (int i = 0; i < restTemplate.getMessageConverters().size(); i++) {
            final HttpMessageConverter<?> httpMessageConverter = restTemplate.getMessageConverters().get(i);
            if (httpMessageConverter instanceof MappingJackson2HttpMessageConverter) {
                restTemplate.getMessageConverters().set(i, mappingJackson2HttpMessageConverter());
            }
        }
    }

    private MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter() {
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        converter.setObjectMapper(customMyListObjectMapper());

        return converter;
    }

    private ObjectMapper customMyListObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.enable(SerializationFeature.WRAP_ROOT_VALUE);
        objectMapper.enable(DeserializationFeature.UNWRAP_ROOT_VALUE);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);

        return objectMapper;
    }


    private CookieStore setConnectionParams(RestTemplate restTemplate) {
        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
        connectionManager.setMaxTotal(Integer.parseInt(env.getProperty("mylistConnectionMaxTotal")));
        connectionManager.setDefaultMaxPerRoute(Integer.parseInt(env.getProperty("mylistDefaultMaxPerRoute")));
        RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(Integer.parseInt(env.getProperty("mylistConnectionTimeout")))
                .setSocketTimeout(Integer.parseInt(env.getProperty("mylistSocketTimeout"))).build();
        
        CookieStore httpCookieStore = new BasicCookieStore();
        HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
        httpClientBuilder.setConnectionManager(connectionManager);
        httpClientBuilder.setDefaultRequestConfig(requestConfig);
        httpClientBuilder.setDefaultCookieStore(httpCookieStore);

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClientBuilder.build());

        restTemplate.setRequestFactory(requestFactory);
        
        return httpCookieStore;
    }

}
