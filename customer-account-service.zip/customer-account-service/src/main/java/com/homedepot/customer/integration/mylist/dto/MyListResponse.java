package com.homedepot.customer.integration.mylist.dto;

import com.fasterxml.jackson.annotation.*;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonRootName("ListResponse")
public class MyListResponse {

    private String memberId;

    private String status;

    private Boolean success;

}
