package com.homedepot.customer.integration.passport;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Sep 10, 2016
 *
 */
@Service
@Slf4j
@PropertySource("passport/passport-integration.properties")
public class THDPassportServiceFacade {
    
    @Autowired
    @Qualifier("passportRestTemplate")
    RestTemplate restTemplate;

    @Autowired
    EnvPropertyUtil envProperty;

    @Autowired
    Environment env;

    public static final String USER_NAME = "j_username";

    public static final String PASSWOD = "j_password";

    public static final String CALLING_PROGRAM = "callingProgram";

    public static final String SET_COOKIE = "Set-Cookie";
    
    private static final String PASSPORT_ERROR_MESSAGE = "Error getting token from Passport service ";

    public String getToken() throws IntegrationException{
        
        String ssoToken = null;
        ResponseEntity<String> response = null;
        
        try{
            String urlToCall = GlobalConstants.HTTPS +"://" + envProperty.getPassportHost() + "/" + env
                    .getProperty("getTokenUrl");
            
            // For WCS QP environment, we need to have a hard codes sso token
            if(urlToCall!=null && urlToCall.contains("hdapps-qp")) {
                return env.getProperty("qpssotoken");
            }
            
 
            HttpHeaders requestHeaders = new HttpHeaders();
            requestHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            
            MultiValueMap<String, String> reqParams = new LinkedMultiValueMap<>(); 
            reqParams.add(USER_NAME, envProperty.getPassportUsr());
            reqParams.add(PASSWOD, envProperty.getPassPortUsrPwd());
            reqParams.add(CALLING_PROGRAM, env.getProperty("api"));

            HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(reqParams,requestHeaders);

            log.debug("Calling Passport Service To get Token: URL -- " + urlToCall);

            response = restTemplate.exchange(urlToCall, HttpMethod.POST, requestEntity, String.class);
            
            log.debug("THDPassport service call response: {}", response);
            
            if(response.getStatusCode().is2xxSuccessful()){
                HttpHeaders responseHeaders = response.getHeaders();
                List<String> responseCookies = responseHeaders.get(SET_COOKIE);
                
                Optional<String> ssoOptional = responseCookies.stream().filter(p -> p.contains(env.getProperty
                        ("thdsso"))).findAny();
                if(ssoOptional.isPresent()){
                    String tokenPair = Arrays.asList(ssoOptional.map(p -> p.split(";")).get())
                            .stream().filter(p -> p.contains(env.getProperty("thdsso"))).findAny()
                            .get();
                    
                    ssoToken = tokenPair.substring(tokenPair.lastIndexOf("=")+1);
                }
            }else{
                throw new IntegrationException(response.getStatusCode(),response.getBody(),null);
            }
        }catch(IntegrationException ex){
            log.error(PASSPORT_ERROR_MESSAGE+ex);
            throw ex;
        }catch(Exception ex){
            log.error(PASSPORT_ERROR_MESSAGE+ex);
            throw new IntegrationException(response.getStatusCode(),response.getBody(),ex);
        }
        
        return ssoToken;
    }
    
}
