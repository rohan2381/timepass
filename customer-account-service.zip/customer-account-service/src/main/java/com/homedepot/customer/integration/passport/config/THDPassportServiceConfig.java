package com.homedepot.customer.integration.passport.config;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

/**
 * Created by rxb1809 on Sep 10, 2016
 *
 */
@Configuration
@PropertySource("passport/passport-integration.properties")
public class THDPassportServiceConfig {
    @Autowired
    Environment env;

    @Bean(name="passportRestTemplate")
    public RestTemplate restTemplate() {
        final RestTemplate restTemplate = new RestTemplate();

        // Set connection params
        setConnectionParams(restTemplate);

        return restTemplate;
    }

    private void setConnectionParams(RestTemplate restTemplate){
        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
        connectionManager.setMaxTotal(Integer.parseInt(env.getProperty("passortConnectionMaxTotal")));
        connectionManager.setDefaultMaxPerRoute(Integer.parseInt(env.getProperty("passortDefaultMaxPerRoute")));
        RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(Integer.parseInt(env.getProperty
                ("passortConnectionTimeout"))).setSocketTimeout(Integer.parseInt(env.getProperty("passortSocketTimeout"))).build();

        HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
        httpClientBuilder.setConnectionManager(connectionManager);
        httpClientBuilder.setDefaultRequestConfig(requestConfig);

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClientBuilder.build());

        restTemplate.setRequestFactory(requestFactory);
    }
}
