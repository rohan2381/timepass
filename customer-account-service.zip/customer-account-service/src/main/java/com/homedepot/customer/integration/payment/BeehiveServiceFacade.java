package com.homedepot.customer.integration.payment;

import java.util.Arrays;
import java.util.Optional;

import com.homedepot.customer.util.EnvPropertyUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.exception.error.PaymentErrorCode;
import com.homedepot.customer.integration.payment.dto.beehive.BinInfoData;
import com.homedepot.customer.integration.payment.dto.beehive.Data;
import com.homedepot.customer.integration.payment.dto.beehive.RspnData;
import com.homedepot.customer.integration.payment.dto.beehive.XRefRequest;
import com.homedepot.customer.integration.payment.dto.beehive.XRefResponse;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;
import com.homedepot.customer.util.GlobalConstants;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Sep 23, 2016
 * This class provides method to talk to Enterprise Beehive services
 */
@Slf4j
@Service
@PropertySource("payment/beehive-integration.properties")
public class BeehiveServiceFacade {

    @Autowired
    EnvPropertyUtil envProperty;
    
    @Autowired
    BeehiveServiceHelper beehiveServiceHelper;

    @Autowired
    Environment env;
    
    private static final Integer SUCCESS_RESPONSE_CODE = 0;
    private static final Integer INVALID_ENCRYPTION_DETAILS_CODE = 340;
    
    public BinInfoData getXRefDetails(String pieCardNumber, String pieIntegrityCheck, String pieKeyId, String piePhaseBit) throws IntegrationException{
        BinInfoData binInfoData = null;
        XRefRequest request = new XRefRequest();
        request.setStoreNumber(GlobalConstants.ONLINE_STORE);
        request.setPrimaryAccountNumber(pieCardNumber);
        request.setEncryptedPan(Boolean.TRUE.toString());
        request.setIntegrityString(pieIntegrityCheck);
        request.setKeyID(pieKeyId);
        request.setPhaseCharacter(piePhaseBit);
        
        XRefResponse xRefResponse = beehiveServiceHelper.sendRequest(request,env.getProperty("beehiveXrefLookUpBaseUrl"), HttpMethod.POST, XRefResponse.class);
        
        Integer responseCode = Optional.ofNullable(xRefResponse)
                                    .map(XRefResponse::getData)
                                    .map(Data::getRspnData)
                                    .map(RspnData::getResponseCode).orElse(null);
        
        if(SUCCESS_RESPONSE_CODE.equals(responseCode)){
            log.debug("Successfully retrieved xRef number from Beehive");
            binInfoData = Optional.ofNullable(xRefResponse)
                    .map(XRefResponse::getData)
                    .map(Data::getBinInfoData).get();
        }else if(INVALID_ENCRYPTION_DETAILS_CODE.equals(responseCode)){
            log.error("Error retrieving xRef number due to invalid encryption details");
            Errors errors = new Errors();
            Error error = new Error();
            errors.setErrors(Arrays.asList(error));
            error.setErrorCode(PaymentErrorCode.INVALID_PIE_ENCRYPTION_VALUES.getCode());
            throw new IntegrationException(errors,HttpStatus.BAD_REQUEST);
        }else{
            log.error("Error calling Beehive services");
            Errors errors = new Errors();
            Error error = new Error();
            errors.setErrors(Arrays.asList(error));
            error.setErrorCode(ErrorCode.SYSTEM_ERROR);
            throw new IntegrationException(errors,HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return binInfoData;
    }

}
