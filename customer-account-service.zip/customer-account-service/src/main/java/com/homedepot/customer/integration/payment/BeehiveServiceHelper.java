package com.homedepot.customer.integration.payment;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.util.Arrays;
import java.util.UUID;

/**
 * Created by rxb1809 on Sep 24, 2016
 * Helper class for beehive interaction
 */
@Service
@Slf4j
@PropertySource("payment/beehive-integration.properties")
public class BeehiveServiceHelper {

    @Autowired
    EnvPropertyUtil envProperty;

    @Autowired
    @Qualifier("beehiveRestTemplate")
    RestTemplate restTemplate;

    @Autowired
    Environment env;

    public static final String PS_CLIENT_ID = "PS-Client-ID";
    public static final String API_KEY = "api_key";
    public static final String _UUID = "UUID";


    public <T> T sendRequest(Object requestObj, String url, HttpMethod httpMethod, Class<T> responseType) throws IntegrationException {
        ResponseEntity<T> responseObj = null;

        try{
            HttpHeaders headers = new HttpHeaders();
            headers.add(PS_CLIENT_ID,GlobalConstants.APPLICATION_ID.toUpperCase());

            headers.add(API_KEY,envProperty.getBeehiveApiKey());
            headers.add(_UUID, String.valueOf(UUID.randomUUID()));
            headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
            headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
            HttpEntity<Object> requestEntity = new HttpEntity<>(requestObj,headers);

            StringBuilder requestUrl = new StringBuilder();
            requestUrl.append(GlobalConstants.HTTPS);
            requestUrl.append("://");
            requestUrl.append(envProperty.getBeehiveHost());
            requestUrl.append(url);

            log.debug("Calling Beehive: -- " + requestUrl.toString());

            responseObj = restTemplate.exchange(requestUrl.toString(), httpMethod, requestEntity, responseType);

            log.debug("Beehive call completed");

        }catch(Exception ex){
            log.error("Error calling Beehive services",ex);
            Errors errors = new Errors();
            Error error = new Error();
            errors.setErrors(Arrays.asList(error));
            error.setErrorCode(ErrorCode.SYSTEM_ERROR);
            throw new IntegrationException(errors,HttpStatus.INTERNAL_SERVER_ERROR,ex);
        }

        return responseObj!=null?responseObj.getBody():null;
    }

    /**
     * Generates an encoded HMAC token to call beehive payment services
     * @return
     */
    public String generateEncodedHMACToken(String timestamp){
        String encodedToken = null;

        try {
            log.debug(timestamp);

            String message = timestamp+GlobalConstants.APPLICATION_ID.toUpperCase();

            Mac sha256HMAC = Mac.getInstance(env.getProperty("paymentAuthAlgorithm"));
            SecretKeySpec secretKey = new SecretKeySpec(envProperty.getBeehiveAuthToken().getBytes(), env.getProperty
                    ("paymentAuthAlgorithm"));
            sha256HMAC.init(secretKey);

            encodedToken = Base64.encodeBase64String(sha256HMAC.doFinal(message.getBytes()));
            log.debug(encodedToken);
        }
        catch (Exception e){
            log.error("Error generating HMAC Token"+e);
        }

        return encodedToken;
    }
}
