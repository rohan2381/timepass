package com.homedepot.customer.integration.payment;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.homedepot.customer.exception.error.PaymentErrorCode;
import com.homedepot.customer.integration.payment.dto.PaymentOption;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResponseErrorHandler;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxm4390 on 8/31/16.
 */

@Component
@Slf4j
public class PaymentResponseErrorHandler implements ResponseErrorHandler {
    
    private static final String PAYMENT_ERROR_MSG = "Payment Service Response Error:: ";

    @Autowired
    @Qualifier("errorMessageResource")
    private ResourceBundleMessageSource messageSource;

    @Autowired
    @Qualifier("paymentErrorCodeMapResource")
    private ResourceBundleMessageSource errorMapSource;

    @Override
    public void handleError(ClientHttpResponse response) throws IOException {
        //NOSONAR
    }

    @Override
    public boolean hasError(ClientHttpResponse response) throws IOException {
        return isError(response.getStatusCode());
    }

    protected boolean isError(HttpStatus status) {
        HttpStatus.Series series = status.series();
        return HttpStatus.Series.CLIENT_ERROR.equals(series) || HttpStatus.Series.SERVER_ERROR.equals(series);
    }

    public void handleError(Object respObj, HttpStatus httpStatus) throws IntegrationException {
        String pymtErrorMsg = null;
        if(respObj==null)
            pymtErrorMsg = PAYMENT_ERROR_MSG+"Status="+httpStatus;
        else
            pymtErrorMsg = PAYMENT_ERROR_MSG+"Status="+httpStatus+" Body="+respObj.toString();
        log.error(pymtErrorMsg);
        
        List<Error> errorList = new ArrayList<>();
        Error error = new Error();
        HttpStatus httpStatusCode = httpStatus;

        if (respObj instanceof PaymentOption) {

            List<com.homedepot.customer.integration.payment.dto.Error> paymentErrors = ((PaymentOption) respObj).getErrors();
            paymentErrors.forEach(paymentError 
                    -> {
                        error.setErrorCode(errorMapSource.getMessage(paymentError.getCode(), null, ErrorCode.SYSTEM_ERROR, null));
                        error.setDeveloperErrorMessage(paymentError.getMessage());
                        });
                   
            try{
                httpStatusCode = PaymentErrorCode.valueOfHttpStatus(error.getErrorCode());
            }catch(IllegalArgumentException iLx){
                log.error("No payment error code defined..",iLx);
                httpStatusCode = HttpStatus.INTERNAL_SERVER_ERROR;
            }
            
            errorList.add(error);
        }
        else {
            error.setErrorMessage(httpStatusCode.getReasonPhrase());
            errorList.add(error);
        }
        Errors errors = new Errors();
        errors.setErrors(errorList);
        throw new IntegrationException(errors, httpStatusCode, pymtErrorMsg);
    }

    public Errors createErrors(String errorCode) {
        Error error = new Error();
        error.setErrorCode(errorCode);
        error.setErrorMessage(messageSource.getMessage(errorCode, null, ErrorCode.SYSTEM_ERROR, null));
        Errors errors = new Errors();
        errors.setErrors(Collections.singletonList(error));
        return errors;
    }
}
