package com.homedepot.customer.integration.payment;

import com.homedepot.customer.integration.payment.dto.PaymentOptions;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.integration.payment.dto.PaymentOption;
import com.homedepot.customer.integration.payment.dto.PaymentResponse;

/**
 * Created by rxb1809 on Apr 28, 2016
 *
 */
@Slf4j
@Service
public class PaymentServiceFacade {

    @Autowired
    PaymentServiceHelper paymentServiceHelper;

    public PaymentOptions getAllPaymentCards(String customerId, String pageNumber, String pageSize, String sort)
            throws IntegrationException {

    	try{
			String url = paymentServiceHelper.buildGetAllPaymentCardsApiUrl(customerId, pageNumber, pageSize, sort);
			return paymentServiceHelper.sendRequest(url, HttpMethod.GET, null, PaymentOptions.class);
    	} catch(IntegrationException ex){
            ex.setErrorMessage("Error while getting All paymentcards for customer:" + customerId+". "+ex.getMessage());
            throw ex;
        }
        
    }

    public PaymentOption getUniquePaymentCard(String customerId, String paymentId) throws IntegrationException {

    	try{
    		String url = paymentServiceHelper.buildGetUniqueCardApiUrl(customerId, paymentId);
            return paymentServiceHelper.sendRequest(url, HttpMethod.GET, null, PaymentOption.class);
    	} catch(IntegrationException ex){
            ex.setErrorMessage("Error while getting Unique Payment Card: " + paymentId + " for customer:" + customerId+". "+ex.getMessage());
            throw ex;
        }
    }

    public PaymentOption createPaymentCard(String customerId, PaymentOption paymentOption) throws IntegrationException {
    	try{
    		String url = paymentServiceHelper.buildCreatePaymentCardUrl(customerId);
            return paymentServiceHelper.sendRequest(url, HttpMethod.POST, paymentOption, PaymentOption.class);
    	} catch(IntegrationException ex){
            ex.setErrorMessage("Error Creating paymentcard for customer: " + customerId+". "+ex.getMessage());
            throw ex;
        }
    }

    public PaymentOption updatePaymentCard(String customerId, PaymentOption paymentOption) throws IntegrationException {
    	try{
    		String url = paymentServiceHelper.buildUpdatePaymentCardUrl(customerId, paymentOption.getPaymentOptionId());
            return paymentServiceHelper.sendRequest(url, HttpMethod.PUT, paymentOption, PaymentOption.class);
    	} catch(IntegrationException ex){
            ex.setErrorMessage("Error updating paymentcard:" + paymentOption.getPaymentOptionId() + " for customer:" + customerId+". "+ex.getMessage());
            throw ex;
        }
        
    }

    public boolean deletePaymentCard(String customerId, String paymentId) throws IntegrationException {
        log.debug("Start PaymentServiceFacade.deletePaymentCard, delete paymentcard customerId: {}, paymenntId: {}",
                customerId, paymentId);
        PaymentResponse response;
        try {
            String url = paymentServiceHelper.buildGetUniqueCardApiUrl(customerId, paymentId);
            response = paymentServiceHelper.sendRequest(url, HttpMethod.DELETE, null, PaymentResponse.class);
            log.debug("End PaymentServiceFacade.deletePaymentCard, response: {}", response);
            
            return response == null ? true : false;

        } catch(IntegrationException ex){
            ex.setErrorMessage("Error deleting paymentcard:" + paymentId + " for customer:" + customerId+". "+ex.getMessage());
            throw ex;
        }
    }
}
