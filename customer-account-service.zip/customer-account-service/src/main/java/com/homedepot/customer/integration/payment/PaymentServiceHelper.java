package com.homedepot.customer.integration.payment;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.integration.payment.config.*;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;

/**
 * Created by rxm4390 on 8/31/16.
 */

@Slf4j
@Service
@PropertySource("payment/payment-integration.properties")
public class PaymentServiceHelper {
    @Autowired
    Environment env;

    @Autowired
    EnvPropertyUtil envProperty;

    @Autowired
    @Qualifier("paymentRestTemplate")
    PaymentRestTemplateInfo paymentRestTemplateInfo;

    @Autowired
    PaymentResponseErrorHandler errorHandler;

    @Autowired
    CustomerAccountRequestContext reqContext;

    public <T> T sendRequest(String url, HttpMethod httpMethod, Object requestBody, Class<T> responseType)
            throws IntegrationException {
        ResponseEntity<T> responseObj;
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        headers.add(GlobalConstants.SOURCE_SYSTEM, GlobalConstants.HDCOM + ": "+ reqContext.getBusinessChannel());
        headers.add(GlobalConstants.PROGRAM, GlobalConstants.APPLICATION_ID);
        headers.add(GlobalConstants.USER_ID, envProperty.getPaymentUserId());
        headers.add(GlobalConstants.API_KEY, envProperty.getPaymentApiKey());
        HttpEntity<Object> requestEntity = new HttpEntity<>(requestBody, headers);
        StringBuilder requestUrl = new StringBuilder();
        requestUrl.append(GlobalConstants.HTTPS);
        requestUrl.append("://");
        requestUrl.append(envProperty.getPaymentHost());
        requestUrl.append("/");
        requestUrl.append(envProperty.getPaymentHostEnv());
        requestUrl.append(url);
        try {
             log.debug("Calling Payment: -- " + requestUrl.toString());
             log.debug("Payment call request Payload: {}", requestBody);
             log.debug("Payment call request Headers: {}", headers.toString());
             responseObj = paymentRestTemplateInfo.getRestTemplate().exchange(requestUrl.toString(), httpMethod, requestEntity,
                    responseType);
            log.debug("Payment call response: {}", responseObj);
            if (errorHandler.isError(responseObj.getStatusCode())) {
                errorHandler.handleError(responseObj.getBody(), responseObj.getStatusCode());
            }
        }catch(IntegrationException iEx){
            throw iEx;
        }
        catch (ResourceAccessException rae) {
            Errors errors = new Errors();
            Error error = new Error();
            error.setErrorCode(ErrorCode.SYSTEM_ERROR);
            error.setDeveloperErrorMessage("Payment Card API timed out.");
            errors.setErrors(Arrays.asList(error));
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, rae);
        } catch (Exception e) {
            Errors errors = new Errors();
            Error error = new Error();
            error.setErrorCode(ErrorCode.SYSTEM_ERROR);
            error.setDeveloperErrorMessage("An unexpected error has occured.");
            errors.setErrors(Arrays.asList(error));
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, e);
        }

        return responseObj.getBody();
    }

    public String buildGetAllPaymentCardsApiUrl(String customerId, String pageNumber, String pageSize, String sort) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(env.getProperty("paymentBaseUrl"));
        stringBuilder.append(customerId);
        stringBuilder.append(env.getProperty("paymentCardUrl"));
        stringBuilder.append("?authorizedCards=true&");
        
        if (pageNumber != null) {
            stringBuilder.append(env.getProperty("paymentQueryParamPage"));
            stringBuilder.append("=");
            stringBuilder.append(pageNumber);
            if(pageSize != null || sort != null)
                stringBuilder.append("&");
        }
        if (pageSize != null) {
            stringBuilder.append(env.getProperty("paymentQueryParamSize"));
            stringBuilder.append("=");
            stringBuilder.append(pageSize);
            if(sort != null)
                stringBuilder.append("&");
        }
        if (sort != null) {
            stringBuilder.append(env.getProperty("paymentQueryParamSort"));
            stringBuilder.append("=");
            stringBuilder.append(sort);
        }
        return stringBuilder.toString();
    }

    public String buildGetUniqueCardApiUrl(String customerId, String paymentId) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(env.getProperty("paymentBaseUrl"));
        stringBuilder.append(customerId);
        stringBuilder.append(env.getProperty("paymentCardUrl"));
        stringBuilder.append("/");
        stringBuilder.append(paymentId);
        return stringBuilder.toString();
    }

    public String buildCreatePaymentCardUrl(String customerId) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(env.getProperty("paymentBaseUrl"));
        stringBuilder.append(customerId);
        stringBuilder.append(env.getProperty("paymentCardUrl"));

        return stringBuilder.toString();
    }
    
    public String buildUpdatePaymentCardUrl(String customerId, Long paymentId) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(env.getProperty("paymentBaseUrl"));
        stringBuilder.append(customerId);
        stringBuilder.append(env.getProperty("paymentCardUrl"));
        stringBuilder.append("/");
        stringBuilder.append(paymentId);
        return stringBuilder.toString();
    }

}
