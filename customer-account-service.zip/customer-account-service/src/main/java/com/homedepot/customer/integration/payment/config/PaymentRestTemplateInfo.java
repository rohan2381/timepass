package com.homedepot.customer.integration.payment.config;

import org.springframework.web.client.*;

import com.fasterxml.jackson.databind.*;

import lombok.*;

/**
 * Created by nxw6207 on 6/20/17.
 */
@Data
@AllArgsConstructor
public class PaymentRestTemplateInfo {
    private RestTemplate restTemplate;
    private ObjectMapper objectMapper;
}
