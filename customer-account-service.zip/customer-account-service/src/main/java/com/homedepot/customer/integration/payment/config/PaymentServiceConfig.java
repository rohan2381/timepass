package com.homedepot.customer.integration.payment.config;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.homedepot.customer.integration.payment.PaymentResponseErrorHandler;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.env.Environment;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import java.io.File;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.text.SimpleDateFormat;

/**
 * Created by rxb1809 on Jun 12, 2016
 * Handles configurations for interacting with Pro services
 */
@Configuration
@PropertySource("payment/payment-integration.properties")
@Slf4j
public class PaymentServiceConfig {

    @Autowired
    PaymentResponseErrorHandler errorHandler;

    @Autowired
    Environment env;

    @Autowired
    EnvPropertyUtil envProperty;

    @Bean(name="paymentRestTemplate")
    public PaymentRestTemplateInfo restTemplateInfo() {
        final RestTemplate restTemplate = new RestTemplate();

        // Set message converters
        setMessageConverters(restTemplate);

        // Set connection params
        setConnectionParams(restTemplate);

        // Set error handler
        restTemplate.setErrorHandler(errorHandler);

        return new PaymentRestTemplateInfo(restTemplate, customPaymentObjectMapper());
    }

    private void setMessageConverters(RestTemplate restTemplate){
        //find and replace Jackson message converter with custom. Old style for loop to retain the iteration counter
        for (int i = 0; i < restTemplate.getMessageConverters().size(); i++) {
            final HttpMessageConverter<?> httpMessageConverter = restTemplate.getMessageConverters().get(i);
            if (httpMessageConverter instanceof MappingJackson2HttpMessageConverter){
                restTemplate.getMessageConverters().set(i, mappingJackson2HttpMessageConverter());
            }
        }
    }

    private MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter() {
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        converter.setObjectMapper(customPaymentObjectMapper());

        return converter;
    }

    private ObjectMapper customPaymentObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
        objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
        return objectMapper;
    }

    private void setConnectionParams(RestTemplate restTemplate){

        try{
            SSLContext context = SSLContext.getInstance("TLS");

            File file = new File(envProperty.getThdApiGatewayKeyStore());
            char[] keypass = envProperty.getThdApiGatewayKeyStorePass().toCharArray();

            KeyManagerFactory kmf = KeyManagerFactory.getInstance(GlobalConstants.KEY_MANAGER_FACTORY_ALGORITHM);
            FileInputStream fin = new FileInputStream(file);
            KeyStore ks = KeyStore.getInstance(GlobalConstants.KEY_STORE_TYPE);
            ks.load(fin, keypass);

            kmf.init(ks, keypass);
            context.init(kmf.getKeyManagers(), null, null);

            SSLConnectionSocketFactory socketFactory =
                    new SSLConnectionSocketFactory(context, GlobalConstants.SSL_PROTOCOLS, null, SSLConnectionSocketFactory.getDefaultHostnameVerifier());

            Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder
                    .<ConnectionSocketFactory> create().register(GlobalConstants.HTTPS, socketFactory)
                    .build();

            PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
            connectionManager.setMaxTotal(Integer.parseInt(env.getProperty("paymentConnectionMaxTotal")));
            connectionManager.setDefaultMaxPerRoute(Integer.parseInt(env.getProperty("paymentDefaultMaxPerRoute")));
            RequestConfig requestConfig = RequestConfig.custom()
                    .setConnectTimeout(Integer.parseInt(envProperty.getPaymentConnectionTimeout()))
                    .setSocketTimeout(Integer.parseInt(envProperty.getPaymentSocketTimeout()))
                    .build();
            HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
            httpClientBuilder.setConnectionManager(connectionManager);
            httpClientBuilder.setDefaultRequestConfig(requestConfig);

            HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClientBuilder.build());

            restTemplate.setRequestFactory(requestFactory);
        }catch(Exception ex){
            log.error("Error configuring http connection params for payment"+ex);
        }
    }

    @Bean(name="paymentErrorCodeMapResource")
    public ResourceBundleMessageSource resourceBundleMessageSource() {
        ResourceBundleMessageSource source = new ResourceBundleMessageSource();
        // Set the svoc error code to internal error code mapping
        source.setBasename("payment/payment-errorcode-mapping");
        source.setUseCodeAsDefaultMessage(true);
        return source;
    }
}
