
package com.homedepot.customer.integration.payment.dto;

import lombok.Data;

@Data
public class CardBrand {

    private Integer code;
    private String shortDesc;
    private String description;

}
