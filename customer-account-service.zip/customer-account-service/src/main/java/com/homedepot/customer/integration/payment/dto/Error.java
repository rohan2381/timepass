package com.homedepot.customer.integration.payment.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/**
 * Created by hxg3585 on 10/10/16.
 */
@JsonIgnoreProperties(ignoreUnknown = false)
@Data
public class Error {
    String code;
    String message;
}
