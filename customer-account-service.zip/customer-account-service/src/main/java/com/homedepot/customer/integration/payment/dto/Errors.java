package com.homedepot.customer.integration.payment.dto;

import java.util.List;
import com.homedepot.customer.integration.payment.dto.Error;
import lombok.Data;


/**
 * Created by hxg3585 on 10/10/16.
 */
@Data
public class Errors {
    private List<Error> errors;
}
