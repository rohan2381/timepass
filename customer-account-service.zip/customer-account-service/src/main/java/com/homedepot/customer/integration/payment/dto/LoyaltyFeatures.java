
package com.homedepot.customer.integration.payment.dto;

import lombok.Data;

@Data
public class LoyaltyFeatures {

    private CardStatus cardStatus;
    private StatusReason statusReason;
    private String autoPaymentEnabled;
    private String proTextEnabled;
    private String moveHistoricalSales;
    private String effectiveDate;

}
