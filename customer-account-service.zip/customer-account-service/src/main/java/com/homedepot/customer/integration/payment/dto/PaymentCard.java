package com.homedepot.customer.integration.payment.dto;

import java.util.*;

import lombok.*;

@Data
@ToString(exclude={"last4digits"})
public class PaymentCard {

    private Integer addressId;
    private CardBrand cardBrand;
    private String last4digits;
    private String cardExpiryMonth;
    private String cardExpiryYear;
    private Boolean isGSA;
    private String buyerId; //For HDCOM and HDCON
    private Date lastModifiedDate;

}
