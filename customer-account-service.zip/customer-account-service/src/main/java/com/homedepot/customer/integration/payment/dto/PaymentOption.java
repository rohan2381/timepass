
package com.homedepot.customer.integration.payment.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.*;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown=true)
@ToString(exclude={"cardNumber"})
public class PaymentOption {

    private PaymentCard paymentCard;
    private Long paymentOptionId;
    private String customerAccountId;
    private String cardHolderName;
    private String cardNickName;
    private String cardNumber;
    private Boolean isDefault;
    private LoyaltyFeatures loyaltyFeatures;
    private List<Error> errors;

}
