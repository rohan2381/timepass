
package com.homedepot.customer.integration.payment.dto;

import java.util.List;

import lombok.Data;

@Data
public class PaymentOptions {

    private List<PaymentOption> paymentOptions;
    private Integer page;
    private Integer numberOfElements;
    private Integer size;
    private Integer totalElements;
    private Integer totalPages;

}
