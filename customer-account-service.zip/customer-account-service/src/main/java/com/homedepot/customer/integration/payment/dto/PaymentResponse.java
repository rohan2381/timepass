package com.homedepot.customer.integration.payment.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.homedepot.customer.integration.payment.dto.Errors;
import lombok.Data;

import java.util.List;

/**
 * Created by hxg3585 on 9/27/16.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown=true)
public class PaymentResponse {
    private String page;
    private Integer numberOfElements;
    private Integer size;
    private Integer totalElements;
    private Integer totalPages;
    private List<PaymentOption> paymentOptions;
    private String type;
    private Errors errors;
}
