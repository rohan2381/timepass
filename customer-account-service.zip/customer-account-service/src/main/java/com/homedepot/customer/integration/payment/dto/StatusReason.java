
package com.homedepot.customer.integration.payment.dto;

import lombok.Data;

@Data
public class StatusReason {

    private String code;
    private String shortDesc;
    private String longDesc;

}
