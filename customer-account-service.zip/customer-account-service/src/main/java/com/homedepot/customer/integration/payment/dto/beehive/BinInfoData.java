
package com.homedepot.customer.integration.payment.dto.beehive;

import lombok.Data;

@Data
public class BinInfoData {

    private String xrefNbr;
    private Boolean gloBinRgFound;
    private Object ctrycdrgFound;
    private String paymtMethCd;
    private String rptPaymtMethCd;
    private Integer crTndrTypId;
    private String issCntryCd;
    private String crHostId;
    private String binbrPrpdInd;
    private String cardClass;
    private Object authByrNbr;

}
