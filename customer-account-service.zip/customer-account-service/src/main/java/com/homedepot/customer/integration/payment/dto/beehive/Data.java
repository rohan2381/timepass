
package com.homedepot.customer.integration.payment.dto.beehive;

import java.util.List;

@lombok.Data
public class Data {

    private RspnData rspnData;
    private List<Object> membershipData;
    private BinInfoData binInfoData;

}
