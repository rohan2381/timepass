
package com.homedepot.customer.integration.payment.dto.beehive;

import lombok.Data;

@Data
public class RspnData {

    private Integer responseCode;
    private String responseDescription;
}
