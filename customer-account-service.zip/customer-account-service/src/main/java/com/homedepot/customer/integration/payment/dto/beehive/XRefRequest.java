package com.homedepot.customer.integration.payment.dto.beehive;

import lombok.Data;

/**
 * Created by rxb1809 on Sep 23, 2016
 *
 */
@Data
public class XRefRequest {

    String storeNumber;
    String primaryAccountNumber;
    String encryptedPan;
    String integrityString;
    String keyID;
    String phaseCharacter;
}
