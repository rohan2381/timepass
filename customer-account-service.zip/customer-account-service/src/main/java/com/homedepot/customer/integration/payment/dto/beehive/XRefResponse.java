
package com.homedepot.customer.integration.payment.dto.beehive;

@lombok.Data
public class XRefResponse {

    private Data data;
    private Integer responseCode;
    private String responseMessage;
    private String uuid;
    private Boolean gsaFlg;

}
