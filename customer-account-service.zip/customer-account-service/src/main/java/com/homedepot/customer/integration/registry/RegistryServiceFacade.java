package com.homedepot.customer.integration.registry;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.integration.registry.dto.RegistryServiceResponse;
import com.homedepot.customer.util.EnvPropertyUtil;

@Slf4j
@Service
public class RegistryServiceFacade {
    
    @Autowired
    RegistryServiceHelper registryServiceHelper;
    
    @Autowired
    EnvPropertyUtil envProperty;
    
    public RegistryServiceResponse getFeatures() {
        log.debug("Retrieving Features in RegistryServiceFacade");
        RegistryServiceResponse response = null;
        try {
            response = registryServiceHelper.sendRequest(envProperty.getRegistryContextPath(), HttpMethod.GET, null, RegistryServiceResponse.class);
            
            log.info("Registry Feature Switches List: {}", response);
        }
        catch (IntegrationException e) {
            log.error("Error loading Features in RegistryServiceFacade: " + e);
        }
        
        return response;
    }

    public RegistryServiceResponse getCartFeatures() {
        log.debug("Retrieving Cart Features in RegistryServiceFacade");
        RegistryServiceResponse response = null;
        try {
            response = registryServiceHelper.sendRequest(envProperty.getRegistryContextCartPath(), HttpMethod.GET, null, RegistryServiceResponse.class);

            log.info("Registry Cart Feature Switches List: {}", response);
        }
        catch (IntegrationException e) {
            log.error("Error loading Cart Features in RegistryServiceFacade: " + e);
        }

        return response;
    }

    public RegistryServiceResponse getListFeatures() {
        log.debug("Retrieving List Features in RegistryServiceFacade");
        RegistryServiceResponse response = null;
        try {
            response = registryServiceHelper.sendRequest(envProperty.getRegistryContextListPath(), HttpMethod.GET, null, RegistryServiceResponse.class);

            log.info("Registry List Feature Switches List: {}", response);
        }
        catch (IntegrationException e) {
            log.error("Error loading List Features in RegistryServiceFacade: " + e);
        }

        return response;
    }

}
