package com.homedepot.customer.integration.registry;

import java.util.Arrays;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;


@Slf4j
@Service
public class RegistryServiceHelper {
    
    @Autowired
    @Qualifier("registryRestTemplate")
    RestTemplate restTemplate;
    
    @Autowired
    EnvPropertyUtil envProperty;

    public <T> T sendRequest(String contextPath, HttpMethod httpMethod, Object requestBody, Class<T> responseType) throws IntegrationException {
        
        ResponseEntity<T> responseEntity = null;

        try {
            HttpHeaders httHeaders = new HttpHeaders();
            httHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");
            httHeaders.set(HttpHeaders.ACCEPT, "application/json");
            HttpEntity<Object> requestEntity = new HttpEntity<>(requestBody, httHeaders);
            
            String url = getRegistryServiceURL(contextPath);
            log.debug("Calling: URL -- {}", url);

            responseEntity = restTemplate.exchange(url, httpMethod, requestEntity, responseType);
            log.debug("in RegistryServiceHelper, Registry API call's responseEntity: {}", responseEntity);
            
        } catch (Exception ex) {
            log.error("Error while loading Feature switches from Registry Service in RegistryServiceHelper: {}", ex.getMessage());
            Errors errors = new Errors();
            Error error = new Error();
            errors.setErrors(Arrays.asList(error));
            error.setErrorCode(ErrorCode.SYSTEM_ERROR);
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, ex);
        }

        return responseEntity.getBody();
    }
    
    private String getRegistryServiceURL(String contextPath){
        StringBuilder requestUrl = new StringBuilder();
        if(GlobalConstants.LOCALHOST.equalsIgnoreCase(envProperty.getRegistryHostName()))
            requestUrl.append(GlobalConstants.HTTP);
        else
            requestUrl.append(GlobalConstants.HTTPS);
        requestUrl.append("://");
        requestUrl.append(envProperty.getRegistryHostName());
        requestUrl.append("/");
        requestUrl.append(contextPath);
        requestUrl.append("/");
        requestUrl.append(envProperty.getRegistryHostEnv());
        
        return requestUrl.toString();
    }

}
