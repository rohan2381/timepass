package com.homedepot.customer.integration.registry.config;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import com.homedepot.customer.util.EnvPropertyUtil;

@Configuration
@PropertySource("registry/registry-integration.properties")
public class RegistryServiceConfig {
    
    @Autowired
    Environment env;

    @Autowired
    EnvPropertyUtil envProperty;
    
    @Bean(name="registryRestTemplate")
    public RestTemplate restTemplate() {
        final RestTemplate restTemplate = new RestTemplate();

        // Set message converters
        setMessageConverters(restTemplate);

        // Set connection params
        setConnectionParams(restTemplate);

        return restTemplate;
    }
    
    private void setMessageConverters(RestTemplate restTemplate) {
        //find and replace Jackson message converter with custom. Old style for loop to retain the iteration counter
        for (int i = 0; i < restTemplate.getMessageConverters().size(); i++) {
            final HttpMessageConverter<?> httpMessageConverter = restTemplate.getMessageConverters().get(i);
            if (httpMessageConverter instanceof MappingJackson2HttpMessageConverter) {
                restTemplate.getMessageConverters().set(i, mappingJackson2HttpMessageConverter());
            }
        }
    }
    
    private MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter() {
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();

        return converter;
    }
    
    private void setConnectionParams(RestTemplate restTemplate) {
        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
        connectionManager.setMaxTotal(Integer.parseInt(env.getProperty("registryConnectionMaxTotal")));
        connectionManager.setDefaultMaxPerRoute(Integer.parseInt(env.getProperty("registryDefaultMaxPerRoute")));
        RequestConfig requestConfig = RequestConfig.custom()
                                        .setConnectTimeout(Integer.parseInt(env.getProperty("registryConnectionTimeout")))
                                        .setSocketTimeout(Integer.parseInt(env.getProperty("registrySocketTimeout")))
                                        .build();

        HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
        httpClientBuilder.setConnectionManager(connectionManager);
        httpClientBuilder.setDefaultRequestConfig(requestConfig);

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClientBuilder.build());

        restTemplate.setRequestFactory(requestFactory);
    }

}
