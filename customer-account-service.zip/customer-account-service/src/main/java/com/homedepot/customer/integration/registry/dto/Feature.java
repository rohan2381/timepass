package com.homedepot.customer.integration.registry.dto;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Feature {
    private String systemName;
    private String subsystemName;
    private String environment;
    private String featureId;
    private String featureName;
    private Integer integerValue;
    private String characterValue;

}
