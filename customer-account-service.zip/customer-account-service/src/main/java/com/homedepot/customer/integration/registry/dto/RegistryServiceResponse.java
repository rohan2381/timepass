package com.homedepot.customer.integration.registry.dto;

import java.util.List;

import lombok.Data;

@Data
public class RegistryServiceResponse {
    
    private List<Feature> feature;

}
