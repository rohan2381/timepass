package com.homedepot.customer.integration.storesearch;

import java.util.ArrayList;
import java.util.Optional;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.integration.storesearch.dto.Store;
import com.homedepot.customer.integration.storesearch.dto.StoreSearchResponse;
import com.homedepot.customer.util.EnvPropertyUtil;

/**
 * Created by jirapat on 10/25/16.
 */
@Service
@Slf4j
@PropertySource("storesearch/storesearch-integration.properties")
public class StoreSearchServiceFacade {

    @Autowired
    StoreSearchServiceHelper storeSearchServiceHelper;

    @Autowired
    EnvPropertyUtil envProperty;

    @Autowired
    Environment env;

    public Optional<Store> findStore(String zipCode) throws IntegrationException {
        log.debug("findStoreNumber, zipCode: {}", zipCode);

        try {
            StoreSearchResponse response = storeSearchServiceHelper.sendRequest(env.getProperty("storesearchUrl"),
                    HttpMethod.GET,
                    StoreSearchResponse.class,
                    zipCode, envProperty.getStoresearchRadius());

            return Optional.of(response)
                    .map(StoreSearchResponse::getStores)
                    .orElse(new ArrayList<>())
                    .stream()
                    .findFirst();
        }
        catch (IntegrationException e) {
            e.setErrorMessage("Error finding store Id from zipCode: " + zipCode + ". " + e.getMessage());
            throw e;
        }
    }

    public Optional<Store> retrieveStoreById(String storeId) throws IntegrationException {
        log.debug("retrieveStoreById, storeId: {}", storeId);

        try {
            StoreSearchResponse response = storeSearchServiceHelper.sendRequest(env.getProperty("storesearchbyIDUrl"),
                    HttpMethod.GET,
                    StoreSearchResponse.class,
                    storeId);

            return Optional.of(response)
                    .map(StoreSearchResponse::getStores)
                    .orElse(new ArrayList<>())
                    .stream()
                    .findFirst();
        }
        catch (IntegrationException e) {
            e.setErrorMessage("Error finding store Id from storeId: " + storeId + ". " + e.getMessage());
            throw e;
        }
    }
}
