package com.homedepot.customer.integration.storesearch;

import java.util.Arrays;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;

/**
 * Created by jirapat on 10/25/16.
 */
@Service
@Slf4j
public class StoreSearchServiceHelper {

    @Autowired
    @Qualifier("storeSearchRestTemplate")
    RestTemplate restTemplate;

    @Autowired
    EnvPropertyUtil envProperty;

    public <T> T sendRequest(String url, HttpMethod method, Class<T> responseType, Object... params) throws IntegrationException {
        ResponseEntity<T> responseObj = null;

        try {
            HttpHeaders headers = new HttpHeaders();
            HttpEntity<Object> requestEntity = new HttpEntity<>(headers);

            String urlToCall = GlobalConstants.HTTP + "://" + envProperty.getStoresearchHostName() + "/" + url;
            log.debug("Calling: URL -- {}, parameters: {}", urlToCall, params);

            responseObj = restTemplate.exchange(urlToCall, method, requestEntity, responseType, params);
            log.debug("StoreSearch call response: {}", responseObj);
        }
        catch (Exception ex) {
            Errors errors = new Errors();
            Error error = new Error();
            errors.setErrors(Arrays.asList(error));
            error.setErrorCode(ErrorCode.SYSTEM_ERROR);
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, ex);
        }

        return responseObj != null ? responseObj.getBody() : null;
    }
}
