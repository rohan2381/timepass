package com.homedepot.customer.integration.storesearch.dto;

import lombok.Data;

/**
 * Created by jirapat on 4/27/17.
 */
@Data
public class Address {
    String street;
    String city;
    String state;
    String postalCode;
}
