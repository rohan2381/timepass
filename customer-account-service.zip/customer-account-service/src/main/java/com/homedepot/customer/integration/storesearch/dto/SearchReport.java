package com.homedepot.customer.integration.storesearch.dto;

import lombok.Data;

/**
 * Created by jirapat on 10/31/16.
 */
@Data
public class SearchReport {
    private int recordCount;
    private int currentPage;
    private int storesPerPage;
}
