package com.homedepot.customer.integration.storesearch.dto;

import lombok.Data;

/**
 * Created by jirapat on 10/25/16.
 */
@Data
public class Store {
    private String storeId;
    private String name;
    private Address address;
}
