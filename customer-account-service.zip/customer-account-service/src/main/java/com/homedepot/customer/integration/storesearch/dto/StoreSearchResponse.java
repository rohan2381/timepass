package com.homedepot.customer.integration.storesearch.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * Created by jirapat on 10/25/16.
 */
@Data
public class StoreSearchResponse {
    @JsonProperty(value = "status.code")
    private SearchReport searchReport;
    private List<Store> stores;
}
