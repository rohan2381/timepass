package com.homedepot.customer.integration.svoc;

import java.util.List;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.integration.svoc.dto.Address;
import com.homedepot.customer.integration.svoc.dto.AddressIdList;
import com.homedepot.customer.integration.svoc.dto.AddressRequest;
import com.homedepot.customer.integration.svoc.dto.AddressResponse;
import com.homedepot.customer.integration.svoc.dto.Addresses;
import com.homedepot.customer.integration.svoc.dto.DeleteAddressRequest;
import com.homedepot.customer.integration.svoc.dto.DeleteAddressResponse;
import com.homedepot.customer.integration.svoc.dto.RetrieveAddressRequest;
import com.homedepot.customer.integration.svoc.dto.RetrieveAddressResponse;
import com.homedepot.customer.util.GlobalConstants;

/**
 * Created by rxb1809 on Apr 28, 2016
 * This is a facade class which interacts with SVOC to perform CRUD operations on Customer Address component
 *
 */
@Service
@Slf4j
@PropertySource("svoc/svoc-integration.properties")
public class SVOCAddressServiceFacade {

    @Autowired
    SVOCServiceHelper svocServiceHelper;

    @Autowired
    Environment env;

    /**
     * Method to get all or selective customer addresses
     * @param customerAccountId
     * @param addressIds
     * @return
     */
    public RetrieveAddressResponse getCustomerAddress(String customerAccountId, List<String> addressIds,String pageNumber, String pageSize) throws IntegrationException {
        log.debug("getCustomerAddress, customerAccountId: {}, addressIds: {}", customerAccountId, addressIds);

        RetrieveAddressResponse response = null;

        try{
            RetrieveAddressRequest retrieveAddressRequest = new RetrieveAddressRequest();
            retrieveAddressRequest.setCustomerAccountId(customerAccountId);

                retrieveAddressRequest.setPageSize(pageSize);
                retrieveAddressRequest.setPageNumber(pageNumber);


            if(!CollectionUtils.isEmpty(addressIds)){
                AddressIdList addressIdList = new AddressIdList();
                addressIdList.setAddressId(addressIds);
                retrieveAddressRequest.setAddressIds(addressIdList);
            }

            response = svocServiceHelper.sendRequest(retrieveAddressRequest, env.getProperty("svocGetAddressUrl"),
                    HttpMethod.POST,GlobalConstants.JSON,
                    RetrieveAddressResponse.class);

            log.debug("Successfully retrieved address for customer in SVOC");
        }catch(IntegrationException ex){
            ex.setErrorMessage("Error retrieving address for customer "+customerAccountId+". "+ex.getMessage());
            throw ex;
        }


        return response;
    }

    /**
     *
     * @param customerAccountId
     * @param addresses
     * @return
     */
    public List<Address> createCustomerAddress(String customerAccountId, List<Address> addresses) throws IntegrationException {

        AddressResponse response = null;

        try{
            AddressRequest createAddressRequest = new AddressRequest();
            createAddressRequest.setCustomerAccountId(customerAccountId);
            Addresses addressList = new Addresses();
            addressList.setAddress(addresses);
            createAddressRequest.setAddresses(addressList);

            response = svocServiceHelper.sendRequest(createAddressRequest, env.getProperty("svocCreateAddressUrl"),
                    HttpMethod.POST, GlobalConstants.JSON, AddressResponse.class);

            log.debug("Successfully created address for customer in SVOC");
        }catch(IntegrationException ex){
            ex.setErrorMessage("Error creating address for customer "+customerAccountId+". "+ex.getMessage());
            throw ex;
        }

        return response != null ? response.getContent().getAddress() : null;
    }

    /**
     *
     * @param customerAccountId
     * @param addresses
     * @return
     */
    public List<Address> updateCustomerAddress(String customerAccountId, List<Address> addresses) throws IntegrationException {

        AddressResponse response = null;

        try{
            AddressRequest updateAddressRequest = new AddressRequest();
            updateAddressRequest.setCustomerAccountId(customerAccountId);
            Addresses addressList = new Addresses();
            addressList.setAddress(addresses);
            updateAddressRequest.setAddresses(addressList);

            log.debug("update address request: " + updateAddressRequest);

            response = svocServiceHelper.sendRequest(updateAddressRequest, env.getProperty("svocUpdateSvocAddressUrl"), HttpMethod.POST,
                    GlobalConstants.JSON, AddressResponse.class);

            log.debug("Response from updated address for customer in SVOC: " + response);
        }catch(IntegrationException ex){
            ex.setErrorMessage("Error updating address for customer "+customerAccountId+". "+ex.getMessage());
            throw ex;
        }

        return response != null ? response.getContent().getAddress() : null;
    }

    /**
     *
     * @param customerAccountId
     * @param addressList
     * @return
     */
    public boolean deleteCustomerAddress(String customerAccountId, List<Address> addressList) throws IntegrationException {

        DeleteAddressResponse response = null;

        try{
            DeleteAddressRequest deleteAddressRequest = new DeleteAddressRequest();
            deleteAddressRequest.setCustomerAccountId(customerAccountId);
            Addresses addresses = new Addresses();
            addresses.setAddress(addressList);
            deleteAddressRequest.setAddresses(addresses);

            log.debug("delete address request: {}", deleteAddressRequest);

            response = svocServiceHelper.sendRequest(deleteAddressRequest, env.getProperty("svocDeleteAddressUrl"), HttpMethod.POST,
                    GlobalConstants.JSON, DeleteAddressResponse.class);

            log.debug("Successfully Deleted address for customer in SVOC, response: {}", response);
        }catch(IntegrationException ex){
            ex.setErrorMessage("Error deleting address for customer "+customerAccountId+". "+ex.getMessage());
            throw ex;
        }

        return response!=null?true:false;
    }

}
