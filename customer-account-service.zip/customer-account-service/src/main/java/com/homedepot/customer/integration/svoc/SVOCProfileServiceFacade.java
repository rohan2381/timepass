package com.homedepot.customer.integration.svoc;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.integration.svoc.dto.*;
import com.homedepot.customer.util.GlobalConstants;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by rxb1809 on Apr 28, 2016 This is a facade class which interacts
 * with SVOC to perform CRUD operations on Customer Profile
 *
 */
@Service
@Slf4j
@PropertySource("svoc/svoc-integration.properties")
public class SVOCProfileServiceFacade {

    @Autowired
    Environment env;

    @Autowired
    SVOCServiceHelper svocServiceHelper;

    public Customer createCustomer(Customer customer) throws IntegrationException {
        log.debug("creating a customer in SVOC");
        CustomerResponse response = null;

        try {
            response = svocServiceHelper.sendRequest(customer, env.getProperty("svocCreateCustomerUrl"), HttpMethod
                    .POST, GlobalConstants.JSON,
                    CustomerResponse.class);

            log.debug("Finished creating customer in SVOC");
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error creating customer "+ex.getMessage());
            throw ex;
        }

        return response != null ? response.getContent().getCustomer().get(0) : null;
    }

    public Customer updateCustomer(Customer customer) throws IntegrationException {
        CustomerResponse response = null;

        try {
            response = svocServiceHelper.sendRequest(customer, env.getProperty("svocUpdateCustomerUrl"), HttpMethod
                    .POST, GlobalConstants.JSON,
                    CustomerResponse.class);

            log.debug("Finished updating customer in SVOC");
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error updating customer "+customer.getCustomerAccountId()+". "+ex.getMessage());
            throw ex;
        }

        return response != null ? response.getContent().getCustomer().get(0) : null;
    }

    public List<Customer> retrieveCustomer(String customerAccountId) throws IntegrationException {
        CustomerRetrieveRequest retriveCust = new CustomerRetrieveRequest();
        retriveCust.setCustomerAccountId(customerAccountId);
//        retriveCust.setCustomerEmail("Y");  // Value should be email address. Only svoc id OR email needs to be sent
        retriveCust.setRetrieveAddressFlag("N");
        retriveCust.setRetrievePhoneFlag("Y");
        retriveCust.setRetrieveEmailFlag("Y");
        retriveCust.setRetrieveLookUpFlag("N");
        retriveCust.setRetrieveTradeTypeFlag("N");
        retriveCust.setRetrieveStoresFlag("Y");
        retriveCust.setLookUpResultCap("1");

        CustomerResponse response = null;

        try {
            response = svocServiceHelper.sendRequest(retriveCust, env.getProperty("svocGetCustomerUrl"), HttpMethod
                    .POST,
                    GlobalConstants.JSON,
                    CustomerResponse.class);

            log.debug("Successfully called get customer in SVOC");
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error retrieving customer info "+customerAccountId+". "+ex.getMessage());
            throw ex;
        }

        return response != null ? response.getContent().getCustomer() : null;

    }


    public CustomerExistenceResponse userExists(CustomerExistenceByEmailRequest request) throws IntegrationException {
        CustomerExistenceResponse response;
        try {
            response = svocServiceHelper.sendRequest(request, env.getProperty("svocCustExistsUrl"),
                    HttpMethod.POST, GlobalConstants.JSON, 
                    CustomerExistenceResponse.class);
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error checking customer existence "+ex.getMessage());
            throw ex;
        }
        return response;
    }

    public CustomerDuplicateEmailCheckResponse duplicateUserExists(CustomerDuplicateEmailCheckRequest request) throws IntegrationException {
        CustomerDuplicateEmailCheckResponse response;
        try {
            response = svocServiceHelper.sendRequest(request, env.getProperty("svocDupUserExistsUrl"), HttpMethod.POST,
                    GlobalConstants.JSON,CustomerDuplicateEmailCheckResponse.class);
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error checking duplicate user existence "+ex.getMessage());
            throw ex;
        }
        return response;
    }

}
