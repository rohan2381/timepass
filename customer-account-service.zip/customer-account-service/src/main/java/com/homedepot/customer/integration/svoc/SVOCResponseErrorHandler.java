package com.homedepot.customer.integration.svoc;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.integration.svoc.dto.AddressResponse;
import com.homedepot.customer.integration.svoc.dto.CustomerResponse;
import com.homedepot.customer.integration.svoc.dto.Errors;
import com.homedepot.customer.model.Error;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResponseErrorHandler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by jirapat on 7/8/16.
 */
@Component
@Slf4j
public class SVOCResponseErrorHandler implements ResponseErrorHandler {
    
    private static final String SVOC_ERROR_MSG = "SVOC Response Error:: ";
    private static final String SVOC_UNVAIALABE_MSG = "SVOC Services Not Available:: ";

    @Autowired
    @Qualifier("addressErrorCodeMapResource")
    ResourceBundleMessageSource addressErrorCodeSource;

    @Autowired
    @Qualifier("profileErrorCodeMapResource")
    ResourceBundleMessageSource profileErrorCodeSource;

    @Override
    public void handleError(ClientHttpResponse response) throws IOException {
      //NOSONAR 
    }

    @Override
    public boolean hasError(ClientHttpResponse response) throws IOException {
        return isError(response.getStatusCode());
    }

    protected boolean isError(HttpStatus status) {
        HttpStatus.Series series = status.series();
        return HttpStatus.Series.CLIENT_ERROR.equals(series) || HttpStatus.Series.SERVER_ERROR.equals(series);
    }

    public void handleError(Object respObj, HttpStatus httpStatus) throws IntegrationException {
        String svocErrorMsg = null;
        
        if(respObj==null){ // Account for SVOC down scenario
            svocErrorMsg = SVOC_UNVAIALABE_MSG+"Status="+httpStatus;
            com.homedepot.customer.model.Errors errors = new com.homedepot.customer.model.Errors();
            Error error = new Error();
            errors.setErrors(Arrays.asList(error));
            error.setErrorCode(ErrorCode.SYSTEM_ERROR);
            error.setDeveloperErrorMessage(svocErrorMsg);
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR,svocErrorMsg);
        }
        
        svocErrorMsg = SVOC_ERROR_MSG+"Status="+httpStatus+" Body="+respObj.toString();
        log.error(svocErrorMsg);
        
        Errors svocErrors = null;
        List<Error> errorList = new ArrayList<>();

        if (respObj instanceof AddressResponse) {
            AddressResponse response = (AddressResponse) respObj;
            svocErrors = response.getErrors();
        } else if (respObj instanceof CustomerResponse) {
            CustomerResponse response = (CustomerResponse) respObj;
            svocErrors = response.getErrors();
        }

        if (!CollectionUtils.isEmpty(svocErrors.getError())) {
            svocErrors.getError().forEach(svocError -> {
                Error error = new Error();
                if(respObj instanceof AddressResponse) {
                    error.setErrorCode(addressErrorCodeSource.getMessage(svocError.getErrorCode(), null, ErrorCode.SYSTEM_ERROR, null));
                }
                else{
                    error.setErrorCode(profileErrorCodeSource.getMessage(svocError.getErrorCode(), null, ErrorCode.SYSTEM_ERROR, null));
                }
                error.setDeveloperErrorMessage(svocError.getErrorCode()+" : "+svocError.getMessage());
                errorList.add(error);
            });
        }

        com.homedepot.customer.model.Errors errors = new com.homedepot.customer.model.Errors();
        errors.setErrors(errorList);

        throw new IntegrationException(errors, httpStatus,svocErrorMsg);

    }
    
    public void throwGenericError(Exception ex) throws IntegrationException{
        com.homedepot.customer.model.Errors errors = new com.homedepot.customer.model.Errors();
        Error error = new Error();
        errors.setErrors(Arrays.asList(error));
        error.setErrorCode(ErrorCode.SYSTEM_ERROR);
        error.setDeveloperErrorMessage(ex.getMessage());
        throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, ex);
    }
}