package com.homedepot.customer.integration.svoc;

import java.util.Arrays;
import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.integration.svoc.config.SVOCRestTemplateInfo;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by jirapat on 6/20/16.
 */
@Service
@Slf4j
@PropertySource("svoc/svoc-integration.properties")
public class SVOCServiceHelper {

    @Autowired
    @Qualifier("svocRestTemplateInfo")
    SVOCRestTemplateInfo svocRestTemplateInfo;

    @Autowired
    EnvPropertyUtil envProperty;

    @Autowired
    SVOCResponseErrorHandler svocErrorHandler;

    @Autowired
    CustomerAccountRequestContext reqContext;

    @Autowired
    Environment env;

    private static final String USER_ID = "userId";
    private static final String SOURCE_SYSTEM = "sourceSystem";
    private static final String THDSERVICE_AUTH = "THDService-Auth";
    private static final String API_KEY = "api_key";

    public <T> T sendRequest(Object requestObj, String url, HttpMethod method, String msgFormat, Class<T> responseType)
            throws IntegrationException {
        ResponseEntity<T> responseObj = null;

        try {

            HttpHeaders headers = new HttpHeaders();
            headers.add(USER_ID, envProperty.getSvocUserId());
            headers.add(SOURCE_SYSTEM, reqContext.getBusinessChannel());

            headers.setContentType(new MediaType(GlobalConstants.APPLICATION, msgFormat != null ? msgFormat : GlobalConstants
                    .JSON));
            headers.setAccept(Collections.singletonList(new MediaType(GlobalConstants.APPLICATION, msgFormat != null ? msgFormat
                    : GlobalConstants.JSON)));
            headers.add(THDSERVICE_AUTH, envProperty.getSvocAuthToken());
            headers.add(API_KEY, envProperty.getSvocApiKey());

            String urlToCall = GlobalConstants.HTTPS + "://" + envProperty.getSvocHost() + "/" + url;

            HttpEntity<Object> requestEntity = new HttpEntity<>(requestObj, headers);
            log.debug("Calling SVOC: -- " + urlToCall);
            log.debug("SVOC call request Payload: {}", svocRestTemplateInfo.getObjectMapper().writeValueAsString(requestObj));
            log.debug("SVOC call request Headers: {}", headers.toString());

            responseObj = svocRestTemplateInfo.getRestTemplate().exchange(urlToCall, method, requestEntity, responseType);

            if (svocErrorHandler.isError(responseObj.getStatusCode())) {
                svocErrorHandler.handleError(responseObj.getBody(), responseObj.getStatusCode());
            }

            log.debug("SVOC call response: {}", responseObj);
        } catch (IntegrationException iEx) {
            throw iEx;
        } catch (Exception ex) {
            Errors errors = new Errors();
            Error error = new Error();
            errors.setErrors(Arrays.asList(error));
            error.setErrorCode(ErrorCode.SYSTEM_ERROR);
            error.setDeveloperErrorMessage(ex.getMessage());
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, ex);
        }

        return responseObj != null ? responseObj.getBody() : null;

    }

}
