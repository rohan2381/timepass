package com.homedepot.customer.integration.svoc.config;

import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Created by rxb1809 on Jan 27, 2017
 *
 */
@Data
@AllArgsConstructor
public class SVOCRestTemplateInfo {

    private RestTemplate restTemplate;
    private ObjectMapper objectMapper;
}
