package com.homedepot.customer.integration.svoc.config;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.homedepot.customer.integration.svoc.SVOCResponseErrorHandler;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.util.TextHtmlMessageConverter;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.env.Environment;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.security.KeyStore;

/**
 * Created by rxb1809 on Apr 30, 2016 Handles configurations for interacting
 * with svoc services
 */
@Configuration
@PropertySource("svoc/svoc-integration.properties")
@Slf4j
public class SVOCServiceConfig {

    @Autowired
    SVOCResponseErrorHandler errorHandler;

    @Autowired
    Environment env;
    
    @Autowired
    EnvPropertyUtil envProperty;

    @Bean(name = "svocRestTemplateInfo")
    public SVOCRestTemplateInfo restTemplateInfo() {
        final RestTemplate restTemplate = new RestTemplate();

        // Set message converters
        setMessageConverters(restTemplate);

        // Set connection params
        setConnectionParams(restTemplate);

        // Set error handler
        restTemplate.setErrorHandler(errorHandler);
        
        return new SVOCRestTemplateInfo(restTemplate, customSVOCObjectMapper());
    }

    @Bean(name = "addressErrorCodeMapResource")
    public ResourceBundleMessageSource resourceAddressBundleMessageSource() {
        ResourceBundleMessageSource source = new ResourceBundleMessageSource();
        // Set the svoc error code to internal error code mapping
        source.setBasename("svoc/svoc-address-errorcode-mapping");
        source.setUseCodeAsDefaultMessage(true);
        return source;
    }

    @Bean(name = "profileErrorCodeMapResource")
    public ResourceBundleMessageSource resourceProfileBundleMessageSource() {
        ResourceBundleMessageSource source = new ResourceBundleMessageSource();
        // Set the svoc error code to internal error code mapping
        source.setBasename("svoc/svoc-profile-errorcode-mapping");
        source.setUseCodeAsDefaultMessage(true);
        return source;
    }

    private void setMessageConverters(RestTemplate restTemplate) {
        // find and replace Jackson message converter with custom. Old style for
        // loop to retain the iteration counter
        for (int i = 0; i < restTemplate.getMessageConverters().size(); i++) {
            final HttpMessageConverter<?> httpMessageConverter = restTemplate.getMessageConverters().get(i);
            if (httpMessageConverter instanceof MappingJackson2HttpMessageConverter) {
                restTemplate.getMessageConverters().set(i, mappingJackson2HttpMessageConverter());
            }
        }

        // register text/html converter to catch and log http error 500 from gateway
        restTemplate.getMessageConverters().add(new TextHtmlMessageConverter());
    }

    private MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter() {
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        converter.setObjectMapper(customSVOCObjectMapper());

        return converter;
    }

    private ObjectMapper customSVOCObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.enable(SerializationFeature.WRAP_ROOT_VALUE);
        objectMapper.enable(DeserializationFeature.UNWRAP_ROOT_VALUE);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);

        return objectMapper;
    }

    private void setConnectionParams(RestTemplate restTemplate) {
        try{
            
            // Trust store settings
            File trustStoreFile = new File(envProperty.getThdApiGatewayTrustStore());
            char[] trustStorePass = envProperty.getThdApiGatewayTrustStorePass().toCharArray();
            
            TrustManagerFactory tmf = TrustManagerFactory.getInstance(GlobalConstants.TRUST_MANAGER_FACTORY_ALGORITHM, 
                                                                    GlobalConstants.TRUST_MANAGER_FACTORY_ALGORITHM_PROVIDER);
            FileInputStream trustStoreInStream = new FileInputStream(trustStoreFile);
            KeyStore tks = KeyStore.getInstance(GlobalConstants.KEY_STORE_TYPE);
            tks.load(trustStoreInStream,trustStorePass);
            tmf.init(tks);
            
            // Key store settings
            File keyStoreFile = new File(envProperty.getThdApiGatewayKeyStore());
            char[] keyStorePass = envProperty.getThdApiGatewayKeyStorePass().toCharArray();
            
            KeyManagerFactory kmf = KeyManagerFactory.getInstance(GlobalConstants.KEY_MANAGER_FACTORY_ALGORITHM);
            FileInputStream keyStoreInStream = new FileInputStream(keyStoreFile);
            KeyStore kks = KeyStore.getInstance(GlobalConstants.KEY_STORE_TYPE);
            kks.load(keyStoreInStream, keyStorePass);
            kmf.init(kks, keyStorePass);
            
            // Initialize the SSL context
            SSLContext context = SSLContext.getInstance(GlobalConstants.SSL_CONTEXT);
            context.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

            SSLConnectionSocketFactory socketFactory = 
                    new SSLConnectionSocketFactory(context, GlobalConstants.SSL_PROTOCOLS, null, SSLConnectionSocketFactory.getDefaultHostnameVerifier());
            
            Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder
                    .<ConnectionSocketFactory> create().register(GlobalConstants.HTTPS, socketFactory)
                    .build();
            
            PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
            connectionManager.setMaxTotal(Integer.parseInt(env.getProperty("svocConnectionMaxTotal")));
            connectionManager.setDefaultMaxPerRoute(Integer.parseInt(env.getProperty("svocDefaultMaxPerRoute")));
            RequestConfig requestConfig = RequestConfig.custom()
                                            .setConnectTimeout(Integer.parseInt(envProperty.getSvocConnectionTimeout()))
                                            .setSocketTimeout(Integer.parseInt(envProperty.getSvocSocketTimeout()))
                                            .build();
            HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
            httpClientBuilder.setConnectionManager(connectionManager);
            httpClientBuilder.setDefaultRequestConfig(requestConfig);

            HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClientBuilder.build());

            restTemplate.setRequestFactory(requestFactory);
        }catch(Exception ex){
            log.error("Error configuring http connection params for SVOC: "+ex);
        }
        
    }
}
