package com.homedepot.customer.integration.svoc.dto;

import java.util.Date;

import lombok.Data;

/**
 * Created by rxb1809 on Apr 30, 2016
 *
 */
@Data
public class Address {

    private String firstName;

    private String lastName;

    private String countyName;

    private String postalCode;

    private String primaryFlag;
    
    private String cityName;

    private String countryCode;

    private String stateCode;

    private String actionType;

    private String contactMethodEnumeration;
    
    private Short addressId; // old contactMethodCode
    
    private String contactMethodDescription;

    private String secondaryFlag;

    private String addressLine2;

    private String addressLine1;
    
    private Date lastUpdateTimestamp;
    
    private String displayCustomerEmailAddress;
    
    private AddressPhones addressPhones;
    
    
}
