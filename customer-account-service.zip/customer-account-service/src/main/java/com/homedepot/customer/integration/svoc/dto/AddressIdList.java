package com.homedepot.customer.integration.svoc.dto;



import java.util.List;

import lombok.Data;

/**
 * Created by axb4725 on May 15, 2016
 *
 */
@Data

public class AddressIdList {

    private List<String> addressId;

}
