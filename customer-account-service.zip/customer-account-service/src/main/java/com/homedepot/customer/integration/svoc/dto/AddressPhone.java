package com.homedepot.customer.integration.svoc.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by rxb1809 on May 11, 2016
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AddressPhone {

    private String phoneNumber;

    private String countryCode;

    private String actionType;

    private String extension;

    private String primaryFlag;

    private String secondaryFlag;

    private Short phoneSequenceNumber;

    private Date lastUpdateTimestamp;
}
