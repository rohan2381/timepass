package com.homedepot.customer.integration.svoc.dto;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;

/**
 * Created by rxb1809 on May 16, 2016
 *
 */
@Data
@JsonRootName("addressRequest")
public class AddressRequest {

    private String customerAccountId;

    private String typeCode;

    private Addresses addresses;
}
