package com.homedepot.customer.integration.svoc.dto;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;

/**
 * Created by rxb1809 on May 16, 2016
 *
 */
@Data
@JsonRootName("addressResponse")
public class AddressResponse {

    private Header header;

    private Errors errors;

    private Content content;

}
