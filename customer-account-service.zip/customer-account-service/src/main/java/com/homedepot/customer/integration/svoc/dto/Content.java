package com.homedepot.customer.integration.svoc.dto;

import java.util.List;

import lombok.Data;

/**
 * Created by rxb1809 on May 16, 2016
 *
 */
@Data
public class Content {

     private List<String> addressId;

     private List<Address> address;

     private List<Customer> customer;

     private PaginationInfo PaginationInfo;

     private List<String> customerAccountId;
}
