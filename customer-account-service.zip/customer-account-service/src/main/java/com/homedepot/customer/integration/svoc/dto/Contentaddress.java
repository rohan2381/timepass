package com.homedepot.customer.integration.svoc.dto;

import lombok.Data;

/**
 * Created by axb4725 on May 16, 2016
 *
 */
@Data
public class Contentaddress {

    private String addressId;

}
