package com.homedepot.customer.integration.svoc.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;

/**
 * Created by rxb1809 on Apr 30, 2016
 *
 */
@Data
@JsonRootName("customer")
public class Customer {

    private Integer customerId;

    private String customerAccountId;

    private String firstName;

    private String middleName;

    private String lastName;

    private String businessName;

    private String preferredLanguageCode;

    private Emails emails;

    private String nationalAccountFlag;

    private String managedAccountFlag;

    private String suffix;

    private Phones phones;

    private String title;

    private RelatedCustomers relatedCustomers;

    private String taxId;

    private String typeEnumeration;

    private Lookups lookups;

    private TradeTypes tradeTypes;

    private String preferedContactTimeTypeCode;

    private Addresses addresses;
    
    private ExternalSystems externalSystems;
    
    private String hdTaxExemptId;
    
    private String localizationPostalCode;
    
    private String registeredCustomerFlag;
    
    private String editCustomerFlag;
    
    private Date lastUpdateTimestamp;
    
    private String lastUpdateUserId;


    //New fields added
    private String sourceSystemName;

    private Short typeCode;

    private String typeDescription;

    private String ccpReviewTimeStamp;

    private String isOrganizationFlag;

    private String enrollInLoyaltyFlag;

    private String loyaltyEnrollmentEnumeration;

    private String loyaltyEnrollmentIndicator;

    private String requireCGR;

    private Integer paymentVendorNumber;

    private String actionType;

    private String statusMessage;

    private String responseSource;

    private Stores stores;
    
    private String userId;
    
    private String encryptedTaxId;
    
    private Integer retryCount;
        
    private Boolean customerIdentityFlag;
        
    private Boolean active;

}
