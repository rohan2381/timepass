package com.homedepot.customer.integration.svoc.dto;


import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;

@Data
@JsonRootName("customerDuplicateEmailCheckRequest")
public class CustomerDuplicateEmailCheckRequest {

    private String emailAddress;
}
