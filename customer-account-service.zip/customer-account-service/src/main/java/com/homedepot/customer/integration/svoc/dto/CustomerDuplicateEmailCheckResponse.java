package com.homedepot.customer.integration.svoc.dto;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;

@Data
@JsonRootName("customerDuplicateEmailCheckResponse")
public class CustomerDuplicateEmailCheckResponse {

    private Header header;
    private Content content;
}
