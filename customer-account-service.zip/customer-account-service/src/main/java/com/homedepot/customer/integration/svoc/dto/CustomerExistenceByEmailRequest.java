package com.homedepot.customer.integration.svoc.dto;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;

@Data
@JsonRootName("customerExistenceByEmailRequest")
public class CustomerExistenceByEmailRequest {

    private String emailAddress;
}
