package com.homedepot.customer.integration.svoc.dto;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;

@Data
@JsonRootName("customerExistenceResponse")
public class CustomerExistenceResponse {

    private Header header;
    private Content content;
    private Errors errors;
}
