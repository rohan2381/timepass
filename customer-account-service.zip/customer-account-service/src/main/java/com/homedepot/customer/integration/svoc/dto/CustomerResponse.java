package com.homedepot.customer.integration.svoc.dto;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;

/**
 * Created by rxb1809 on Apr 30, 2016
 *
 */
@Data
@JsonRootName("customerResponse")
public class CustomerResponse {
    private Content content;
    
    private Header header;
    
    private Errors errors;

}
