package com.homedepot.customer.integration.svoc.dto;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by ankitbajpai on 7/19/16.
 */
/*
 *Created by AXB4725, on 7/19/16
 *
 */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @JsonRootName("customerRetrieveRequest")
public class CustomerRetrieveRequest {

    private String customerAccountId;

    private String customerEmail;

    private String retrieveAddressFlag;

    private String retrievePhoneFlag;

    private String retrieveEmailFlag;

    private String retrieveLookUpFlag;

    private String retrieveTradeTypeFlag;

    private String retrieveStoresFlag;

    private String lookUpResultCap;

    private String addressResultCap;




}
