package com.homedepot.customer.integration.svoc.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;

/**
 * Created by rxb1809 on Apr 30, 2016
 *
 */
@Data
@JsonRootName("customers")
public class Customers {
    
    private List<Customer> customer;
    
    private Messages messages;

}
