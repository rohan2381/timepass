package com.homedepot.customer.integration.svoc.dto;


import com.fasterxml.jackson.annotation.JsonRootName;

/**
 * Extends AddressRequest to have delete specific json root name
 * Created by axb4725 on May 15, 2016
 *
 */
@JsonRootName("deleteAddressRequest")
public class DeleteAddressRequest extends AddressRequest {
}
