package com.homedepot.customer.integration.svoc.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonRootName;

/**
 * Extends AddressResponse to have delete specific json root name
 * Created by axb4725 on May 15, 2016
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonRootName("deleteAddressResponse")
public class DeleteAddressResponse extends AddressResponse {
}
