package com.homedepot.customer.integration.svoc.dto;

import java.util.List;

import lombok.Data;

/**
 * Created by rxb1809 on May 7, 2016
 *
 */
@Data
public class Emails {

    private List<Email> email;
}
