package com.homedepot.customer.integration.svoc.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/**
 * Created by rxb1809 on May 7, 2016
 *
 */
// TODO: REMOVE THIS BEFORE CHECKIN, some svoc error has code, which should not be there, this should catch it so we can inform them
@JsonIgnoreProperties(ignoreUnknown = false)
@Data
public class Error {
    private String errorCode;
    private String message;
}
