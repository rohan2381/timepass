package com.homedepot.customer.integration.svoc.dto;

import lombok.Data;

/**
 * Created by rxb1809 on Apr 30, 2016
 *
 */
@Data
public class ExternalSystem {

    private String externalSystemId;
    private String externalSystemName;
}
