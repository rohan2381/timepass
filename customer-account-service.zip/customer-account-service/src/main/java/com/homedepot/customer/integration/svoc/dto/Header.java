package com.homedepot.customer.integration.svoc.dto;

import lombok.Data;

/**
 * Created by rxb1809 on May 16, 2016
 *
 */
@Data
public class Header {

    private int status;

    private int code;

    private String message;

    private String developerMessage;

    private String moreInfo;
}
