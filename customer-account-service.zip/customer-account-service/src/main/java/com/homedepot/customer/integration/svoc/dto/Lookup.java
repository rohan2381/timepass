package com.homedepot.customer.integration.svoc.dto;

import lombok.Data;

/**
 * Created by rxb1809 on Apr 30, 2016
 *
 */
@Data
public class Lookup {
    
    private String lookupName;

    private String typeEnumeration;

    private String actionType;

    private String lookupValue;

    private String statusEnumeration;

}
