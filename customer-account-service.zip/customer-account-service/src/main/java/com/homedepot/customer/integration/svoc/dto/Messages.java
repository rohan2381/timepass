package com.homedepot.customer.integration.svoc.dto;

import lombok.Data;

/**
 * Created by rxb1809 on May 7, 2016
 *
 */
@Data
public class Messages {

    private String success;
    
    private Errors errors;
}
