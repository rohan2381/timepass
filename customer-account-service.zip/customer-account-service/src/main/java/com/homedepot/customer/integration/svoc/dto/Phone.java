package com.homedepot.customer.integration.svoc.dto;

import java.util.Date;

import lombok.Data;

/**
 * Created by rxb1809 on Apr 30, 2016
 *
 */
@Data
public class Phone {
    
    private String phoneNumber;

    private String typeEnumeration;

    private String primaryFlag;

    private String countryCode;

    private String actionType;

    private String contactMethodEnumeration;

    private String secondaryFlag;

    private Preferences preferences;

    private Date lastUpdateTimestamp;
}
