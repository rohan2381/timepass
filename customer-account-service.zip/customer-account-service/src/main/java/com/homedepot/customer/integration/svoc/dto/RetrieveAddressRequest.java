package com.homedepot.customer.integration.svoc.dto;


import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.Data;

/**
 * Created by axb4725 on May 18, 2016
 *
 */
@Data
@JsonRootName("retrieveAddressRequest")
public class RetrieveAddressRequest {
    private String customerAccountId;
    private AddressIdList addressIds;
    private String pageSize;
    private String pageNumber;

}
