package com.homedepot.customer.integration.svoc.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonRootName;

/**
 * Created by axb4725 on May 18, 2016
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonRootName("retrieveAddressResponse")
public class RetrieveAddressResponse extends AddressResponse {

}
