package com.homedepot.customer.integration.svoc.dto;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by ankitbajpai on 7/19/16.
 */
/*
 *Created by AXB4725, on 7/19/16
 *
 */
@Data
@NoArgsConstructor
public class Stores {
    List<Store> store;
}
