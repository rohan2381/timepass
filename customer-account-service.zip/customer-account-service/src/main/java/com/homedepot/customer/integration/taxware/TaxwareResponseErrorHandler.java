package com.homedepot.customer.integration.taxware;

import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.integration.taxware.dto.CityStateLookupResponse;
import com.homedepot.customer.model.Error;

import static com.homedepot.customer.exception.error.ErrorCode.SYSTEM_ERROR;

/**
 * Created by jirapat on 10/14/16.
 */
@Component
@Slf4j
public class TaxwareResponseErrorHandler {

    @Autowired
    @Qualifier("errorCodeMapResource-taxware")
    ResourceBundleMessageSource errorCodeSource;

    public void handleError(CityStateLookupResponse response) throws IntegrationException {
        if (response.getResponseCode() != 0) {
            log.debug("error in CityStateLookupResponse");
            List<Error> errorList = new ArrayList<>();
            Error error = new Error();
            error.setErrorCode(errorCodeSource.getMessage(String.valueOf(response.getResponseCode()), null, SYSTEM_ERROR, null));
            error.setDeveloperErrorMessage(response.getErrorMessage());
            errorList.add(error);

            com.homedepot.customer.model.Errors errors = new com.homedepot.customer.model.Errors();
            errors.setErrors(errorList);
            throw new IntegrationException(errors, HttpStatus.BAD_REQUEST);
        }
    }
}
