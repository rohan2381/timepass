package com.homedepot.customer.integration.taxware;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.integration.taxware.dto.CityStateLookupResponse;
import com.homedepot.customer.integration.taxware.dto.CityStateZipValidResponse;
import com.homedepot.customer.model.PostalDetails;
import com.homedepot.customer.util.EnvPropertyUtil;

/**
 * Created by jirapat on 9/8/16.
 */
@Service
@Slf4j
@PropertySource("taxware/taxware-integration.properties")
public class TaxwareServiceFacade {


    @Autowired
    TaxwareServiceHelper taxwareServiceHelper;

    @Autowired
    EnvPropertyUtil envProperty;

    @Autowired
    TaxwareResponseErrorHandler taxwareResponseErrorHandler;

    @Autowired
    Environment env;

    public boolean isCityStateZipValid(PostalDetails postalDetails) throws IntegrationException {
        log.debug("isCityStateZipValid, postalDetails: {}", postalDetails);

        try {
            CityStateZipValidResponse response = taxwareServiceHelper.sendRequest(env.getProperty("taxwareCityStateZipcodeValidurl"),
                    HttpMethod.GET, CityStateZipValidResponse.class,
                    postalDetails.getCity(), postalDetails.getState(), postalDetails.getZipCode(), envProperty.getTaxwareKey());
            return response != null && response.isValid();
        }
        catch (IntegrationException e) {
            e.setErrorMessage("Error checking city/state/zipcode matching (" + postalDetails.getCity() + "/" + postalDetails.getState()
                    + "/" + postalDetails.getZipCode() + "). " + e.getMessage());
            throw e;
        }
    }

    public CityStateLookupResponse getCityStates(String zipCode) throws IntegrationException {
        log.debug("getCityStates, zipCode: {}", zipCode);

        try {
            CityStateLookupResponse response = taxwareServiceHelper.sendRequest(env.getProperty("taxwareCityStatesUrl"), HttpMethod.GET,
                    CityStateLookupResponse.class, zipCode, envProperty.getTaxwareKey());
            taxwareResponseErrorHandler.handleError(response);

            return response;
        }
        catch (IntegrationException e) {
            e.setErrorMessage("Error getting city/state list from zipCode: " + zipCode + ". " + e.getMessage());
            throw e;
        }
    }
}
