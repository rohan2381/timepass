package com.homedepot.customer.integration.taxware;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.Collections;

/**
 * Created by jirapat on 9/8/16.
 */
@Service
@Slf4j
@PropertySource("taxware/taxware-integration.properties")
public class TaxwareServiceHelper {

    @Autowired
    @Qualifier("taxwareRestTemplate")
    RestTemplate restTemplate;

    @Autowired
    EnvPropertyUtil envProperty;

    @Autowired
    Environment env;

    public static final String X_CLIENT_GROUP = "X-Client-Group";

    public <T> T sendRequest(String url, HttpMethod method, Class<T> responseType, Object... params) throws IntegrationException {
        ResponseEntity<T> responseObj = null;

        try {

            HttpHeaders headers = new HttpHeaders();
            headers.setAccept(Collections.singletonList(new MediaType(GlobalConstants.APPLICATION, GlobalConstants.JSON)));
            headers.add(X_CLIENT_GROUP, env.getProperty("taxwareGcpCom"));
            headers.add(GlobalConstants.API_KEY, envProperty.getTaxwareApiKey());
            HttpEntity<Object> requestEntity = new HttpEntity<>(headers);

            String urlToCall = GlobalConstants.HTTPS + "://" + envProperty.getTaxwareHost() + "/" + url;
            log.debug("Taxware calling: URL -- {}, parameters: {}", urlToCall, params);

            responseObj = restTemplate.exchange(urlToCall, method, requestEntity, responseType, params);
            log.debug("Taxware call response: {}", responseObj);
        }
        catch (Exception ex) {
            Errors errors = new Errors();
            Error error = new Error();
            errors.setErrors(Arrays.asList(error));
            error.setErrorCode(ErrorCode.SYSTEM_ERROR);
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, ex);
        }

        return responseObj != null ? responseObj.getBody() : null;
    }
}