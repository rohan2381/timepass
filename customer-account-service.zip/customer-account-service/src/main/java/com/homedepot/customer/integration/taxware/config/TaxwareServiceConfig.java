package com.homedepot.customer.integration.taxware.config;

import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.env.Environment;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.File;
import java.io.FileInputStream;
import java.security.KeyStore;

/**
 * Created by jirapat on 9/8/16.
 */
@Configuration
@PropertySource("taxware/taxware-integration.properties")
@Slf4j
public class TaxwareServiceConfig {

    @Autowired
    Environment env;

    @Autowired
    EnvPropertyUtil envProperty;

    @Bean(name = "taxwareRestTemplate")
    public RestTemplate restTemplate() {
        final RestTemplate restTemplate = new RestTemplate();

        // Set message converters
        setMessageConverters(restTemplate);

        // Set connection params
        setConnectionParams(restTemplate);

        return restTemplate;
    }

    private void setMessageConverters(RestTemplate restTemplate) {
        //find and replace Jackson message converter with custom. Old style for loop to retain the iteration counter
        for (int i = 0; i < restTemplate.getMessageConverters().size(); i++) {
            final HttpMessageConverter<?> httpMessageConverter = restTemplate.getMessageConverters().get(i);
            if (httpMessageConverter instanceof MappingJackson2HttpMessageConverter) {
                restTemplate.getMessageConverters().set(i, mappingJackson2HttpMessageConverter());
            }
        }
    }

    private MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter() {
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();

        return converter;
    }

    private void setConnectionParams(RestTemplate restTemplate) {
        try{

            // Trust store settings
            File trustStoreFile = new File(envProperty.getThdApiGatewayTrustStore());
            char[] trustStorePass = envProperty.getThdApiGatewayTrustStorePass().toCharArray();

            TrustManagerFactory tmf = TrustManagerFactory.getInstance(GlobalConstants.TRUST_MANAGER_FACTORY_ALGORITHM,
                    GlobalConstants.TRUST_MANAGER_FACTORY_ALGORITHM_PROVIDER);
            FileInputStream trustStoreInStream = new FileInputStream(trustStoreFile);
            KeyStore tks = KeyStore.getInstance(GlobalConstants.KEY_STORE_TYPE);
            tks.load(trustStoreInStream,trustStorePass);
            tmf.init(tks);

            // Key store settings
            File keyStoreFile = new File(envProperty.getThdApiGatewayKeyStore());
            char[] keyStorePass = envProperty.getThdApiGatewayKeyStorePass().toCharArray();

            KeyManagerFactory kmf = KeyManagerFactory.getInstance(GlobalConstants.KEY_MANAGER_FACTORY_ALGORITHM);
            FileInputStream keyStoreInStream = new FileInputStream(keyStoreFile);
            KeyStore kks = KeyStore.getInstance(GlobalConstants.KEY_STORE_TYPE);
            kks.load(keyStoreInStream, keyStorePass);
            kmf.init(kks, keyStorePass);

            // Initialize the SSL context
            SSLContext context = SSLContext.getInstance(GlobalConstants.SSL_CONTEXT);
            context.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

            SSLConnectionSocketFactory socketFactory =
                    new SSLConnectionSocketFactory(context, GlobalConstants.SSL_PROTOCOLS, null, SSLConnectionSocketFactory.getDefaultHostnameVerifier());

            Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder
                    .<ConnectionSocketFactory> create().register(GlobalConstants.HTTPS, socketFactory)
                    .build();

            PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager(socketFactoryRegistry);
            connectionManager.setMaxTotal(Integer.parseInt(env.getProperty("taxwareConnectionMaxTotal")));
            connectionManager.setDefaultMaxPerRoute(Integer.parseInt(env.getProperty("taxwareDefaultMaxPerRoute")));
            RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(Integer.parseInt(envProperty.getTaxwareConnectionTimeout())).setSocketTimeout(Integer.parseInt(envProperty.getTaxwareSocketTimeout())).build();

            HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
            httpClientBuilder.setConnectionManager(connectionManager);
            httpClientBuilder.setDefaultRequestConfig(requestConfig);

            HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClientBuilder.build());

            restTemplate.setRequestFactory(requestFactory);
        }catch(Exception ex){
            log.error("Error configuring http connection params for Beehive: "+ex);
        }

    }

    @Bean(name = "errorCodeMapResource-taxware")
    public ResourceBundleMessageSource resourceBundleMessageSource() {
        ResourceBundleMessageSource source = new ResourceBundleMessageSource();
        // Set the taxware error code to internal error code mapping
        source.setBasename("taxware/taxware-errorcode-mapping");
        source.setUseCodeAsDefaultMessage(true);
        return source;
    }
}