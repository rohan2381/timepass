package com.homedepot.customer.integration.taxware.dto;

import lombok.Data;

/**
 * Created by jirapat on 10/14/16.
 */
@Data
public class CityState {
    public String city;
    public String stateCode;
}
