package com.homedepot.customer.integration.taxware.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * Created by jirapat on 10/14/16.
 */
@Data
public class CityStateLookupResponse {
    @JsonProperty(value = "responseCityStates")
    public List<CityState> cityStateList;

    public int responseCount;
    public String zipCodeSearchByCity;

    @JsonProperty(value = "RESPONSE_CODE")
    private int responseCode;

    @JsonProperty(value = "GENERIC_ERROR")
    private String errorMessage;
}
