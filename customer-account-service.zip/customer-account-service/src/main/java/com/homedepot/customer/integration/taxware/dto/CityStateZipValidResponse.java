package com.homedepot.customer.integration.taxware.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * Created by jirapat on 9/9/16.
 */
@Data
public class CityStateZipValidResponse {
    @JsonProperty(value = "RESPONSE_CODE")
    private int responseCode;

    @JsonProperty(value = "IS_VALID")
    private boolean isValid;
}
