package com.homedepot.customer.integration.wcs;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.integration.wcs.config.WCSServiceConfig;
import com.homedepot.customer.integration.wcs.dto.WCSResponse;
import com.homedepot.customer.model.Address;
import com.homedepot.customer.model.Addresses;
import com.homedepot.customer.request.AddressRequest;
import com.homedepot.customer.util.GlobalConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by rxb1809 on Aug 24, 2016 This is a facade class to call WCS address
 * APIs
 */
@Service
@Slf4j
@PropertySource("wcs/wcs-integration.properties")
public class WCSAddressServiceFacade {

    @Autowired
    private WCSServiceHelper wcsServiceHelper;

    @Autowired
    private WCSServiceConfig wcsServiceConfig;

    @Autowired
    Environment env;
    
    public List<Address> createCustomerAddressCSR(String memberId, List<Address> addresses, String ssoToken)
            throws IntegrationException {
        String url = String.format(env.getProperty("wcsCreateAddressCsrUrl"), memberId);
        
        AddressRequest request = new AddressRequest();
        request.setAddress(addresses);

        Addresses addrResponse = null;
        try{
            WCSResponse<Addresses> wcsResponse = wcsServiceHelper.sendWCSRequest(request, url, HttpMethod.POST, GlobalConstants.JSON, 
                                ssoToken, wcsServiceConfig.customWCSObjectMapper(), Addresses.class, false, null);
                    
            addrResponse = wcsResponse!=null ? wcsResponse.getResponseObj() : null;
        } catch (IntegrationException iEx) {
            throw iEx;
        }

        return addrResponse!=null ? addrResponse.getAddress() : null;
    }

    public List<Address> updateCustomerAddressCSR(String memberId, List<Address> addresses, String ssoToken)
            throws IntegrationException {
        String url = String.format(env.getProperty("wcsUpdateAddressCsrUrl"), memberId);
        AddressRequest request = new AddressRequest();
        request.setAddress(addresses);

        Addresses addrResponse = null;
        try {
            WCSResponse<Addresses> wcsResponse = wcsServiceHelper.sendWCSRequest(request, url, HttpMethod.PUT, GlobalConstants.JSON,
                    ssoToken, wcsServiceConfig.customWCSObjectMapper(), Addresses.class, false, null);

            addrResponse = wcsResponse != null ? wcsResponse.getResponseObj() : null;
        } catch (IntegrationException e) {
            log.error("get IntegrationException while updating customer address", e);
        }
        log.debug("Address updated in wcs");
        return addrResponse != null ? addrResponse.getAddress() : null;
    }

    public boolean deleteCustomerAddressCSR(String memberId, String addressId, String ssoToken)
            throws IntegrationException {
        String url = String.format(env.getProperty("wcsDeleteAddressCsrUrl"), memberId, addressId);
        Addresses addrResponse = null;
        try {
            WCSResponse<Addresses> wcsResponse = wcsServiceHelper.sendWCSRequest(null, url, HttpMethod.DELETE, GlobalConstants.JSON, ssoToken,wcsServiceConfig.customWCSObjectMapper(), Addresses.class,false, null);
            addrResponse = wcsResponse!=null ? wcsResponse.getResponseObj() : null;
        } catch (IntegrationException e) {
            log.error("" + e);
        }
        log.debug("Address deleted in wcs");
        return addrResponse != null ? true : false;
    }

    public List<Address> getCustomerAddressWCSFallBack(String addressId, String userToken)
            throws IntegrationException {
        String url = null;

        if(addressId != null){
            url = String.format(env.getProperty("wcsGetAddressByIdUrl"), addressId);
        }else{
            url = String.format(env.getProperty("wcsGetAllAddressUrl"));
        }

        Addresses addrResponse = null;
        try{
            WCSResponse<Addresses> wcsResponse = wcsServiceHelper.sendWCSFallBackRequest(null, url, HttpMethod.GET,
                    GlobalConstants.JSON,
                    userToken, wcsServiceConfig.customWCSObjectMapper(), Addresses.class, true, null);

            addrResponse = wcsResponse!=null ? wcsResponse.getResponseObj() : null;
        } catch (IntegrationException iEx) {
            throw iEx;
        }

        return addrResponse!=null ? addrResponse.getAddress() : null;
    }

    public List<Address> createCustomerAddressWCSFallBack(List<Address> addresses, String userToken) throws
            IntegrationException{
        String url = String.format(env.getProperty("wcsCreateWcsAddressUrl"));
        AddressRequest request = new AddressRequest();
        request.setAddress(addresses);

        Addresses addrResponse = null;
        try{
            WCSResponse<Addresses> wcsResponse = wcsServiceHelper.sendWCSFallBackRequest(request, url, HttpMethod.POST, GlobalConstants.JSON,
                    userToken, wcsServiceConfig.customWCSObjectMapper(), Addresses.class, true, null);

            addrResponse = wcsResponse!=null ? wcsResponse.getResponseObj() : null;
        } catch (IntegrationException iEx) {
            throw iEx;
        }

        return addrResponse!=null ? addrResponse.getAddress() : null;
    }

    public List<Address> updateCustomerAddressWCSFallBack(List<Address> addresses, String userToken) throws
            IntegrationException{
        String url = String.format(env.getProperty("wcsUpdateAddressUrl"));
        AddressRequest request = new AddressRequest();
        request.setAddress(addresses);

        Addresses addrResponse = null;
        try {
            WCSResponse<Addresses> wcsResponse = wcsServiceHelper.sendWCSFallBackRequest(request, url, HttpMethod
                    .PUT,
                    GlobalConstants.JSON,
                    userToken, wcsServiceConfig.customWCSObjectMapper(), Addresses.class, true, null);

            addrResponse = wcsResponse != null ? wcsResponse.getResponseObj() : null;
        } catch (IntegrationException e) {
            log.error("get IntegrationException while updating customer address", e);
            throw e;
        }
        log.debug("Address updated in wcs");
        return addrResponse != null ? addrResponse.getAddress() : null;
    }

    public boolean deleteCustomerAddressWCSFallBack(String addressId, String userToken) throws IntegrationException{
        String url = String.format(env.getProperty("wcsDeleteWcsAddressUrl"), addressId);
        Addresses addrResponse = null;
        try {
            WCSResponse<Addresses> wcsResponse = wcsServiceHelper.sendWCSFallBackRequest(null, url, HttpMethod.DELETE, GlobalConstants.JSON,
                    userToken,wcsServiceConfig.customWCSObjectMapper(), Addresses.class,true, null);
            addrResponse = wcsResponse!=null ? wcsResponse.getResponseObj() : null;
        } catch (IntegrationException e) {
            log.error("Address deletion in WCS failed" + e);
            throw e;
        }
        log.debug("Address deleted in wcs");
        return addrResponse != null ? true : false;
    }


}
