package com.homedepot.customer.integration.wcs;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.integration.wcs.config.WCSServiceConfig;
import com.homedepot.customer.integration.wcs.dto.WCSResponse;
import com.homedepot.customer.integration.wcs.dto.crossref.CrossRefInfo;
import com.homedepot.customer.util.GlobalConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

/**
 * Created by rxb1809 on Oct 14, 2016
 * This is a facade class for accessing WCS APIs to maintain the cross reference tables for Aurora - wcs reference ids
 */
@Service
@Slf4j
@PropertySource("wcs/wcs-integration.properties")
public class WCSCrossRefServiceFacade {


    @Autowired
    private WCSServiceHelper wcsServiceHelper;
    @Autowired
    private WCSServiceConfig wcsServiceConfig;

    @Autowired
    Environment env;

    public CrossRefInfo getCrossRefInfoForSVOCCustAcctId(String svocCustAccountId) throws IntegrationException{
        WCSResponse<CrossRefInfo> response = null;
        try {
            String url = new StringBuilder(env.getProperty("wcsCrossrefInfoBaseUrl")).append
                    (env.getProperty("wcsCrossrefGetQueryParam")).append
                    (svocCustAccountId).toString();
            response = wcsServiceHelper.sendWCSRequest(null, url, HttpMethod.GET, GlobalConstants.JSON, null, wcsServiceConfig.customWCSObjectMapper(), CrossRefInfo.class,false, null);
        } catch (IntegrationException iEx) {
            throw iEx;
        }

        return response!=null?response.getResponseObj():null;
    }

    public CrossRefInfo getCrossRefInfoForWCSMemberId(String wcsMemberId) throws IntegrationException{
        WCSResponse<CrossRefInfo> response = null;
        try {
            String url = new StringBuilder(env.getProperty("wcsCrossrefInfoBaseUrl")).append(env.getProperty("wcsGetCrossRefWCSIdQueryParam")).append
                    (wcsMemberId)
                    .toString();
            response = wcsServiceHelper.sendWCSRequest(null, url, HttpMethod.GET, GlobalConstants.JSON, null, wcsServiceConfig.customWCSObjectMapper(), CrossRefInfo.class,false, null);
        } catch (IntegrationException iEx) {
            throw iEx;
        }

        return response!=null?response.getResponseObj():null;
    }

    public CrossRefInfo saveCrossRefInfo(CrossRefInfo crossRefInfo, String ssoToken) throws IntegrationException{
        WCSResponse<CrossRefInfo> response = null;

        try {
            log.debug("Saving cross reference info in WCS for "+crossRefInfo.getSvocCustAcctId() + " : "+ crossRefInfo.getWcsMemberId());
            response = wcsServiceHelper.sendWCSRequest(crossRefInfo, env.getProperty("wcsCrossrefInfoSaveUrl"),
                    HttpMethod.POST,
                    GlobalConstants.JSON, ssoToken,wcsServiceConfig.customWCSObjectMapper(), CrossRefInfo.class,false, null);
        } catch (IntegrationException iEx) {
            throw iEx;
        }

        return response!=null?response.getResponseObj():null;
    }

    public CrossRefInfo updateCrossRefInfo(CrossRefInfo crossRefInfo, String ssoToken) throws IntegrationException{
        WCSResponse<CrossRefInfo> response = null;

        try {
            log.debug("updating cross reference info in WCS");
            response = wcsServiceHelper.sendWCSRequest(crossRefInfo, env.getProperty("wcsCrossrefInfoUpdateUrl"),
                    HttpMethod.POST,
                    GlobalConstants.JSON, ssoToken,wcsServiceConfig.customWCSObjectMapper(), CrossRefInfo.class,false, null);
        } catch (IntegrationException iEx) {
            throw iEx;
        }

        return response!=null?response.getResponseObj():null;
    }

    public boolean deleteCrossRefInfo(CrossRefInfo crossRefInfo, String ssoToken) throws IntegrationException{
        WCSResponse<CrossRefInfo> response = null;

        try {
            log.debug("deleting cross reference info in WCS");
            response = wcsServiceHelper.sendWCSRequest(crossRefInfo, env.getProperty("wcsCrossrefInfoDeleteUrl"),
                    HttpMethod.POST,
                    GlobalConstants.JSON, ssoToken,wcsServiceConfig.customWCSObjectMapper(), CrossRefInfo.class,false, null);
        } catch (IntegrationException iEx) {
            throw iEx;
        }
        if(response.getResponseObj().getStatus().equals("SUCCESS")){
            return true;
        }
        else{
            return false;
        }
    }
}
