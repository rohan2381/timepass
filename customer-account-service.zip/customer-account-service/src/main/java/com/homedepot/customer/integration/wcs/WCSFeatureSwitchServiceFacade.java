package com.homedepot.customer.integration.wcs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.integration.wcs.dto.KillSwitchData;
import com.homedepot.customer.integration.wcs.dto.WCSResponse;
import com.homedepot.customer.util.GlobalConstants;

import lombok.extern.slf4j.Slf4j;



/**
 * Created by vxg6469 on 12/12/16.
 */

@Service
@PropertySource("wcs/wcs-integration.properties")
@Slf4j
public class WCSFeatureSwitchServiceFacade {
    
    @Autowired
    private WCSServiceHelper wcsServiceHelper;

    @Autowired
    Environment env;

    public KillSwitchData loadOptionsData() {
        String url = env.getProperty("wcsFeatureSwitch");
        
        try {
            XmlMapper xmlMapper = new XmlMapper();
            xmlMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            WCSResponse<KillSwitchData> wcsResponse = wcsServiceHelper.sendWCSRequest(null, url, HttpMethod.GET, GlobalConstants.XML, null, xmlMapper, KillSwitchData.class, false,null);
            return wcsResponse.getResponseObj();
        } catch (IntegrationException e) {
            log.error("Error retrieving Feature switch from WCS registries "+e);
            return null;
        }

    }

}
