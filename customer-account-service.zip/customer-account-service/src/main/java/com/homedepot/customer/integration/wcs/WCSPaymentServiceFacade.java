package com.homedepot.customer.integration.wcs;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.integration.wcs.config.WCSServiceConfig;
import com.homedepot.customer.integration.wcs.dto.PaymentAccount;
import com.homedepot.customer.integration.wcs.dto.WCSResponse;
import com.homedepot.customer.model.Errors;
import com.homedepot.customer.model.PaymentCard;
import com.homedepot.customer.model.PaymentCards;
import com.homedepot.customer.util.GlobalConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Created by rxb1809 on Aug 24, 2016 This is a facade class to call WCS credit card APIs
 */
@Service
@PropertySource("wcs/wcs-integration.properties")
public class WCSPaymentServiceFacade {
    @Autowired
    Environment env;

    @Autowired
    private WCSServiceHelper wcsServiceHelper;

    @Autowired
    private WCSServiceConfig wcsServiceConfig;

    public PaymentCard createPaymentCardCSR(String memberId, PaymentCard paymentCard, String ssoToken)
            throws IntegrationException {
        String url = String.format(env.getProperty("wcsCreateCardUrl"), memberId);
        PaymentAccount account = new PaymentAccount();

        PaymentCards paymentCards = new PaymentCards();
        paymentCards.setPaymentCard(Collections.singletonList(paymentCard));
        account.setPaymentCards(paymentCards);
        try {
            WCSResponse<PaymentAccount> response = wcsServiceHelper.sendWCSRequest(account, url, HttpMethod.POST,
                    GlobalConstants.JSON, ssoToken, wcsServiceConfig.customWCSObjectMapper(), PaymentAccount.class,
                    false, null);
            account = response.getResponseObj();

        } catch (IntegrationException iEx) {
            throw iEx;
        }

        return (account != null && account.getPaymentCards() != null
                && account.getPaymentCards().getPaymentCard() != null)
                        ? account.getPaymentCards().getPaymentCard().get(0) : null;
    }

    public boolean deletePaymentCardCSR(String customerAccountId, String paymentId, String ssoToken)
            throws IntegrationException {
        PaymentCards paymentCards;
        String url = String.format(env.getProperty("wcsDeleteCardUrl"), customerAccountId) + paymentId +
                "?type=json";
        try {
            WCSResponse<PaymentCards> response = wcsServiceHelper.sendWCSRequest(null, url, HttpMethod.DELETE,
                    GlobalConstants.JSON, ssoToken, wcsServiceConfig.customWCSObjectMapper(), PaymentCards.class,
                    false, null);
            paymentCards = response.getResponseObj();

            return paymentCards.getPaymentCard().get(0).getStatus() == null ? false : true;

        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error deleting WCS paymentcard: " + paymentId + " for customer: " + customerAccountId);
            throw ex;
        }
    }

    public boolean deletePaymentCardFallBack(String customerAccountId, String paymentId, String ssoToken) throws IntegrationException {
        String url = env.getProperty("wcsDeleteCardFallBackUrl")+paymentId+env.getProperty("wcsDeleteCardFallBackQueryParam");
        PaymentCards paymentCards;
        try {
            WCSResponse<PaymentCards> response = wcsServiceHelper.sendWCSFallBackRequest(null, url, HttpMethod.POST,
                    GlobalConstants.JSON, ssoToken, wcsServiceConfig.customWCSObjectMapper(), PaymentCards.class,
                    true, null);
            paymentCards = response.getResponseObj();

            return paymentCards.getPaymentCard().get(0).getStatus() == null ? false : true;

        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error deleting WCS paymentcard: " + paymentId + " for customer: " + customerAccountId);
            throw ex;
        }

    }

    public PaymentCard updatePaymentCardCSR(String memberId, PaymentCard paymentCard, String ssoToken)
            throws IntegrationException {
        String url = String.format(env.getProperty("wcsUpdateCardUrl"), memberId) + "?type=json";
        PaymentAccount account = new PaymentAccount();

        PaymentCards paymentCards = new PaymentCards();
        paymentCards.setPaymentCard(Collections.singletonList(paymentCard));
        account.setPaymentCards(paymentCards);
        try {
            WCSResponse<PaymentAccount> response = wcsServiceHelper.sendWCSRequest(account, url, HttpMethod.PUT,
                    GlobalConstants.JSON, ssoToken, wcsServiceConfig.customWCSObjectMapper(), PaymentAccount.class,
                    false, null);
            account = response.getResponseObj();

        } catch (IntegrationException iEx) {
            throw iEx;
        }

        return (account != null && account.getPaymentCards() != null
                && account.getPaymentCards().getPaymentCard() != null)
                        ? account.getPaymentCards().getPaymentCard().get(0) : null;
    }
    
    public PaymentAccount getAllPaymentCardsCSR(String memberId, String ssoToken) throws IntegrationException {
        String url = String.format(env.getProperty("wcsGetCardCsrUrl"), memberId) + "&type=json";
        PaymentAccount account = new PaymentAccount();
        
        try {
            WCSResponse<PaymentAccount> response = wcsServiceHelper.sendWCSRequest(null, url, HttpMethod.GET,
                    GlobalConstants.JSON, ssoToken, wcsServiceConfig.customWCSObjectMapper(), PaymentAccount.class, false, null);

            account = response.getResponseObj();

        } catch (IntegrationException iEx) {
            throw iEx;
        }

        return account != null ? account : null;
    }
    
    public PaymentAccount getAllPaymentCardsFallBack(String wcsPaymentId, String userToken)
            throws IntegrationException {
        String url = env.getProperty("wcsGetCardFallBackUrl");
        PaymentAccount account = new PaymentAccount();
        
        try {
            WCSResponse<PaymentAccount> response = wcsServiceHelper.sendWCSFallBackRequest(null, url, HttpMethod.GET,
                    GlobalConstants.JSON, userToken, wcsServiceConfig.customWCSObjectMapper(), PaymentAccount.class, true, null);

            account = response.getResponseObj();

        } catch (IntegrationException iEx) { // This is added to avoid propagating Cards not found exception during fallback 
            // to be consistent with the new xRef flow
            if(HttpStatus.NOT_FOUND.equals(iEx.getHttpStatus()) 
                    && Optional.ofNullable(iEx.getErrors())
                                .map(Errors::getErrors)
                                .map(errors -> errors.stream().filter(error -> error.getErrorCode().equalsIgnoreCase("PYMTCRD_ERR_136")))
                                .isPresent()){
                return  null;
            }
            throw iEx;
        }

        return account != null ? account : null;
    }

    public PaymentCard createPaymentCardFallBack(PaymentCard paymentCard, String userToken)
            throws IntegrationException {
        String url = env.getProperty("wcsCreateCardFallBackUrl");
        PaymentAccount account = new PaymentAccount();

        PaymentCards paymentCards = new PaymentCards();
        paymentCards.setPaymentCard(Collections.singletonList(paymentCard));
        account.setPaymentCards(paymentCards);
        try {
            WCSResponse<PaymentAccount> response = wcsServiceHelper.sendWCSFallBackRequest(account, url, HttpMethod.POST,
                    GlobalConstants.JSON, userToken, wcsServiceConfig.customWCSObjectMapper(), PaymentAccount.class,true, null);
            account = response.getResponseObj();

        } catch (IntegrationException iEx) {
            throw iEx;
        }

        return (account != null && account.getPaymentCards() != null
                && account.getPaymentCards().getPaymentCard() != null)
                ? account.getPaymentCards().getPaymentCard().get(0) : null;
    }

    public PaymentCard updatePaymentCardFallBack(PaymentCard paymentCard, String userToken)
            throws IntegrationException {
        String url = env.getProperty("wcsUpdateCardFallBackUrl");
        PaymentAccount account = new PaymentAccount();

        PaymentCards paymentCards = new PaymentCards();
        paymentCards.setPaymentCard(Collections.singletonList(paymentCard));
        account.setPaymentCards(paymentCards);
        try {
            WCSResponse<PaymentAccount> response = wcsServiceHelper.sendWCSFallBackRequest(account, url, HttpMethod.PUT,
                    GlobalConstants.JSON, userToken, wcsServiceConfig.customWCSObjectMapper(), PaymentAccount.class,true, null);
            account = response.getResponseObj();

        } catch (IntegrationException iEx) {
            throw iEx;
        }

        return (account != null && account.getPaymentCards() != null
                && account.getPaymentCards().getPaymentCard() != null)
                ? account.getPaymentCards().getPaymentCard().get(0) : null;
    }

    public PaymentCard getPaymentCardCSRByBrandNLast4Digits(String memberId, String cardBrand, String last4Digit,
            String userToken) throws IntegrationException {
        String cardBrandNLast4Digits = cardBrand + last4Digit;
        String url = String.format(env.getProperty("wcsGetCardByBrandN4DigitCsrUrl"), memberId, cardBrandNLast4Digits);
        PaymentAccount account = null;
        try {
            WCSResponse<PaymentAccount> response = wcsServiceHelper.sendWCSFallBackRequest(null, url, HttpMethod.GET,
                    GlobalConstants.JSON, userToken, wcsServiceConfig.customWCSObjectMapper(), PaymentAccount.class, false, null);
            account = response.getResponseObj();
        } catch (IntegrationException iEx) {
            throw iEx;
        }

        return Optional.ofNullable(account)
                .map(PaymentAccount::getPaymentCards)
                .map(PaymentCards::getPaymentCard)
                .orElse(new ArrayList<>())
                .stream()
                .sorted((pay1, pay2) -> pay2.getLastModifiedDate().compareTo(pay1.getLastModifiedDate()))
                .findFirst()
                .orElse(null);
    }

    public PaymentAccount getPaymentCardByBrandNLast4Digits(String cardBrand, String last4Digit, String userToken) throws IntegrationException {
        String cardBrandNLast4Digits = cardBrand + last4Digit;
        String url = String.format(env.getProperty("wcsGetCardByBrandN4DigitUrl"), cardBrandNLast4Digits);
        PaymentAccount account = null;
        try {
            WCSResponse<PaymentAccount> response = wcsServiceHelper.sendWCSRequest(null, url, HttpMethod.GET,
                    GlobalConstants.JSON, userToken, wcsServiceConfig.customWCSObjectMapper(), PaymentAccount.class, true, null);

            account = response.getResponseObj();

        } catch (IntegrationException iEx) {
            throw iEx;
        }
        return account;
    }

}
