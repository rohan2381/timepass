package com.homedepot.customer.integration.wcs;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;

import javax.servlet.http.Cookie;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.integration.wcs.config.WCSServiceConfig;
import com.homedepot.customer.integration.wcs.dto.ValidateTokenResponse;
import com.homedepot.customer.integration.wcs.dto.WCSLogoutResponse;
import com.homedepot.customer.integration.wcs.dto.WCSResponse;
import com.homedepot.customer.integration.wcs.dto.WCSUserIdentity;
import com.homedepot.customer.model.Account;
import com.homedepot.customer.model.Errors;
import com.homedepot.customer.util.GlobalConstants;

import lombok.extern.slf4j.Slf4j;


/**
 * Created by rxb1809 on Aug 24, 2016
 * This is a facade class to call WCS profile APIs
 */
@Service
@Slf4j
@PropertySource("wcs/wcs-integration.properties")
public class WCSProfileServiceFacade {

    @Autowired
    private WCSServiceHelper wcsServiceHelper;

    private ObjectMapper objectMapper;

    @Autowired
    private WCSServiceConfig wcsServiceConfig;

    @Autowired
    Environment env;

    public WCSUserIdentity authenticateUser(String emailId, char[] passwd, Cookie[] cookies) throws IntegrationException {
        log.debug("authenticateUser - emailId: {}, channelId: {}", emailId);
        WCSUserIdentity wcsUserIdentity = null;
        WCSResponse<WCSUserIdentity> wcsResponse = null;
        try {
            MultiValueMap<String, String> reqParams = new LinkedMultiValueMap<String, String>();
            reqParams.add("logonId", emailId);
            reqParams.add("password", new String(passwd));
            wcsResponse = wcsServiceHelper.sendWCSRequest(reqParams, env.getProperty("wcsLoginUserUrl"), HttpMethod
                    .POST,"x-www-form-urlencoded",null, wcsObjectMapper(), WCSUserIdentity.class, false, cookies);
            if(null != wcsResponse) {
                wcsUserIdentity = wcsResponse.getResponseObj();
                HttpHeaders responseHeaders = wcsResponse.getHeaders();
                List<String> responseCookies = new ArrayList<>(responseHeaders.get("Set-Cookie"));
                wcsUserIdentity.setResponseCookies(responseCookies);
            }
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error on user authentication in WCS");
            throw ex;
        } catch(Exception ex) {
            Errors errors = wcsServiceHelper.getErrors(null);
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR,ex);
        }
        return Optional.ofNullable(wcsUserIdentity).orElse(null);
    }

    public WCSUserIdentity registerUser(String emailId, char[] passwd, char[] confirmPassword,
                                        String firstName, String lastName, String zipCode,
                                        String svocId) throws IntegrationException {

        log.debug("registerUser in WCS - emailId: {}", emailId);
        WCSUserIdentity wcsUserIdentity = null;
        WCSResponse<WCSUserIdentity> wcsResponse;
        try {
            MultiValueMap<String, String> reqParams = new LinkedMultiValueMap<>();
            reqParams.add("logonId", emailId);
            reqParams.add("password", new String(passwd));
            reqParams.add("confirmPassword", new String(confirmPassword));
            reqParams.add("firstName", firstName!=null ? firstName : "self");
            reqParams.add("lastName", lastName!=null ? lastName : "self");
            reqParams.add("zipCode", zipCode);
            String url = svocId == null ? env.getProperty("wcsRegisterUserFallBackUrl") :
                                            env.getProperty("wcsRegisterUserUrl");
            wcsResponse = wcsServiceHelper.sendWCSRequest(reqParams, url, HttpMethod.POST,
                                                 "x-www-form-urlencoded",
                                                null,wcsObjectMapper(),WCSUserIdentity.class,
                                                true, null);
            if(null != wcsResponse) {
                wcsUserIdentity = wcsResponse.getResponseObj();
                HttpHeaders responseHeaders = wcsResponse.getHeaders();
                List<String> responseCookies = new ArrayList<>(responseHeaders.get(GlobalConstants.SETCOOKIE));
                wcsUserIdentity.setResponseCookies(responseCookies);
            }
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error on user registration in WCS");
            throw ex;
        } catch(Exception ex) {
            Errors errors = wcsServiceHelper.getErrors(null);
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR,ex);
        }
        return wcsUserIdentity;
    }

    private ObjectMapper wcsObjectMapper() {
        if(objectMapper == null){
            objectMapper = new ObjectMapper();
            objectMapper.enable(SerializationFeature.WRAP_ROOT_VALUE);
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
            objectMapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
        }
        return objectMapper;
    }

    public Account updateUserProfileCSR(String memberId, Account wcsAccountProfile, String ssoToken)
            throws IntegrationException {
        String url = String.format(env.getProperty("wcsUpdateProfileCsrUrl"), memberId);
        WCSResponse<Account> wcsResponse = null;

        try {
            wcsResponse = wcsServiceHelper.sendWCSRequest(wcsAccountProfile, url, HttpMethod.PUT, GlobalConstants.JSON,
                    ssoToken, wcsObjectMapper(), Account.class, false, null);
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error on updating User Profile in WCS");
            throw ex;
        }
        log.debug("Profile updated in wcs");
        return Optional.ofNullable(wcsResponse).map(WCSResponse::getResponseObj).orElse(null);

    }
    
    
    public ValidateTokenResponse validateUserToken(String wcsUserToken, boolean isAsync, Cookie[] cookies) throws IntegrationException{
        WCSResponse<ValidateTokenResponse> response = null;

        try{
            if(isAsync){
                response = wcsServiceHelper.sendWCSRequest(null, env.getProperty("wcsValidateTokenUrl"), HttpMethod
                        .GET, GlobalConstants
                        .JSON, wcsUserToken, wcsObjectMapper(), ValidateTokenResponse.class, false, cookies);
            }else{
                response = wcsServiceHelper.sendWCSRequest(null, env.getProperty("wcsValidateTokenUrl"), HttpMethod
                        .GET, GlobalConstants
                        .JSON, wcsUserToken, wcsObjectMapper(), ValidateTokenResponse.class, true, null);
            }    
        }catch (IntegrationException ex) {
            ex.setErrorMessage("Error on validating user token in WCS");
            throw ex;
        } catch(Exception ex) {
            Errors errors = wcsServiceHelper.getErrors(null);
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR,ex);
        }
        
        return Optional.ofNullable(response).map(WCSResponse::getResponseObj).orElse(null);
    }

    public Account getUserInfoCSR(String memberId, String userToken) throws IntegrationException {

        String url = String.format(env.getProperty("wcsGetProfileCsrUrl"), memberId);
        WCSResponse<Account> wcsResponse;
        try {
            wcsResponse = wcsServiceHelper.sendWCSRequest(null, url, HttpMethod.GET, GlobalConstants.JSON,
                                                            userToken, wcsServiceConfig.customWCSObjectMapper(),
                                                            Account.class, false, null);
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error on getting User Profile from WCS");
            throw ex;
        }
        return Optional.ofNullable(wcsResponse).map(WCSResponse::getResponseObj).orElse(null);
    }


    public WCSLogoutResponse logoutUser(String wcsAuthToken) throws IntegrationException {

        WCSResponse<String> wcsResponse;
        WCSLogoutResponse response = new WCSLogoutResponse();
        try {
            wcsResponse = wcsServiceHelper.sendWCSRequest(null, env.getProperty("wcsLogoutUserUrl"),
                                                            HttpMethod.GET, GlobalConstants.JSON,
                                                            wcsAuthToken, wcsObjectMapper(),
                                                            String.class, true, null);
            if (wcsResponse != null) {
                HttpHeaders responseHeaders = wcsResponse.getHeaders();
                log.debug("WCS Response Headers = {}", responseHeaders);
                response.setResponseCookies(responseHeaders.get("Set-Cookie"));
            }
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error on logout from WCS");
            throw ex;
        } catch (Exception ex) {
            Errors errors = wcsServiceHelper.getErrors(null);
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, ex);
        }
        return response;
    }

    public Account getUserInfoWCSFallBack(String userToken) throws IntegrationException{
        String url = env.getProperty("wcsGetProfileUrl");
        WCSResponse<Account> wcsResponse = null;

        try {
            wcsResponse = wcsServiceHelper.sendWCSFallBackRequest(null, url, HttpMethod.GET, GlobalConstants.JSON,
                    userToken, wcsServiceConfig.customWCSObjectMapper(), Account.class, true, null);
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error on getting User Profile from WCS");
            throw ex;
        }
        return Optional.ofNullable(wcsResponse).map(WCSResponse::getResponseObj).orElse(null);
    }

    public Account updateUserProfileWCSFallBack(Account wcsAccountProfile, String ssoToken)
            throws IntegrationException {
        String url = env.getProperty("wcsUpdateProfileUrl");
        WCSResponse<Account> wcsResponse = null;

        try {
            wcsResponse = wcsServiceHelper.sendWCSFallBackRequest(wcsAccountProfile, url, HttpMethod.PUT,
                    GlobalConstants.JSON,
                    ssoToken, wcsServiceConfig.customWCSObjectMapper(), Account.class, true, null);
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error on updating User Profile in WCS");
            throw ex;
        }
        log.debug("Profile updated in wcs");
        return Optional.ofNullable(wcsResponse).map(WCSResponse::getResponseObj).orElse(null);

    }

    public Account unlockUser(String memberId, String userToken) throws IntegrationException {
        String url = String.format(env.getProperty("wcsUnlockUserCsrUrl"), memberId);
        WCSResponse<Account> wcsResponse;
        try {
            wcsResponse = wcsServiceHelper.sendWCSRequest(null, url, HttpMethod.POST, GlobalConstants.JSON,
                    userToken, wcsServiceConfig.customWCSObjectMapper(),
                    Account.class, false, null);
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error on Unlocking User Profile in WCS");
            throw ex;
        }
        return Optional.ofNullable(wcsResponse).map(WCSResponse::getResponseObj).orElse(null);

    }
    
    public boolean sendForgotPasswordEmail(Account wcsAccountProfile) throws IntegrationException{
        String url = env.getProperty("wcsForgotPasswordUrl");
        
        try {
            WCSResponse<Account> wcsResponse = wcsServiceHelper.sendWCSFallBackRequest(wcsAccountProfile, url, HttpMethod.POST, 
                    GlobalConstants.JSON, null, wcsServiceConfig.customWCSObjectMapper(),
                    Account.class, false, null);
        } catch (IntegrationException ex) {
            ex.setErrorMessage("Error triggering forgot password email in WCS");
            throw ex;
        }        
        return true;
    }
    
    @Async("profileTaskExecutor")
    public Future<Boolean> checkEmailExists(String emailId){
        boolean emailExists = false;
        
        String url = String.format(env.getProperty("wcsEmailExistUrl"), emailId);        
        try {            
            WCSResponse<com.homedepot.customer.integration.wcs.dto.Account> wcsResponse = wcsServiceHelper.sendWCSRequest(null, url, HttpMethod.GET, 
                    GlobalConstants.JSON, null, wcsServiceConfig.customWCSObjectMapper(),
                    com.homedepot.customer.integration.wcs.dto.Account.class, false, null);
            if(Optional.ofNullable(wcsResponse).map(WCSResponse::getResponseObj).isPresent()){
                emailExists = "FAILED".equalsIgnoreCase(wcsResponse.getResponseObj().getStatus());
            }
            
        } catch (Exception ex) {
            log.error("Error checking email exists in WCS for "+emailId, "Cause: " +ExceptionUtils.getRootCauseMessage(ex));
        }       
        
        return new AsyncResult<>(emailExists);
    }

}
