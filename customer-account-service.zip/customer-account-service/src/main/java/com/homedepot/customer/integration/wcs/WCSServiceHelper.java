package com.homedepot.customer.integration.wcs;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.integration.wcs.config.RestTemplateInfo;
import com.homedepot.customer.integration.wcs.config.WCSResponseErrorHandler;
import com.homedepot.customer.integration.wcs.config.WCSServiceConfig;
import com.homedepot.customer.integration.wcs.dto.Addresses;
import com.homedepot.customer.integration.wcs.dto.PaymentAccount;
import com.homedepot.customer.integration.wcs.dto.WCSResponse;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.util.THDEnv;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.Cookie;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by rxb1809 on Aug 25, 2016
 * Helper class to call WCS APIs
 */
@Service
@Slf4j
public class WCSServiceHelper {
    
    @Autowired
    @Qualifier("wcsRestTemplateInfo")
    RestTemplateInfo restTemplateInfo;
    
    @Autowired
    EnvPropertyUtil envProperty;
    
    @Autowired
    WCSResponseErrorHandler errorHandler;
    
    @Autowired
    WCSServiceConfig wcsServiceConfig;
    
    @Autowired
    @Qualifier("dataSyncRetryTemplate")
    private RetryTemplate retryTemplate;
    
    @Autowired
    CustomerAccountRequestContext reqContext;
    
    @Autowired
    private Environment environment;
    
    private static final String FAILED = "FAILED";
    
    private static Map<String, String> wcsChannelIdMap = null;
    
    static {
        wcsChannelIdMap = new HashMap<String, String>();
        wcsChannelIdMap.put("Desktop", "-1");
        wcsChannelIdMap.put("iOS", "-7");
        wcsChannelIdMap.put("Android", "-8");
        wcsChannelIdMap.put("S5", "-3");
        wcsChannelIdMap.put("S2", "-10");
    }
    

    public <T> WCSResponse<T> sendWCSRequest(Object requestObj, String url, HttpMethod method, String msgFormat, String wcsUserToken, 
            ObjectMapper objectMapper, Class<T> responseType, boolean isUserRequest, Cookie[] cookies) throws IntegrationException{
        T responseObj = null;
        ResponseEntity<String> responseStr = null;
        WCSResponse<T> wcsResponse = null;
        String wcsHost = null;
        
        Cookie[] cookiesLocal = null;
        try{
            // This is required to ensure we start fresh and dont carry any old cookies
            if(restTemplateInfo.getCookieStore()!=null){
                restTemplateInfo.getCookieStore().clear();
            }

            HttpHeaders headers = new HttpHeaders();
            headers.add("Authorization", wcsUserToken);
            if(isUserRequest && reqContext.getRequest().getCookies()!=null){
                cookiesLocal = reqContext.getRequest().getCookies();
                String cookieStr = Arrays.asList(reqContext.getRequest().getCookies()).stream()
                                   .map(c -> c.getName().concat("=").concat(c.getValue()))
                                   .collect(Collectors.joining(";"));
                headers.add("Cookie",cookieStr);
            }else if(cookies!=null){ // Async flow
                cookiesLocal = cookies;
                String cookieStr = Arrays.asList(cookies).stream()
                        .map(c -> c.getName().concat("=").concat(c.getValue()))
                        .collect(Collectors.joining(";"));
                headers.add("Cookie",cookieStr);
            }
            
            if(Arrays.stream(environment.getActiveProfiles()).anyMatch(env -> GlobalConstants.SPRING_PFOFILE_DEV.equalsIgnoreCase(env))) { 
                ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
                if(requestAttributes!=null && requestAttributes.getRequest()!=null 
                        && requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV) !=null){
                    THDEnv thdEnv =  (THDEnv)requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV);
                    if(thdEnv!=null){
                        wcsHost = thdEnv.getOriginUrl();
                        log.debug("WCS host set to "+wcsHost);
                    }                            
                }
            }

            headers.setContentType(new MediaType(GlobalConstants.APPLICATION,msgFormat!=null?msgFormat: GlobalConstants.JSON));
            headers.setAccept(Collections.singletonList(new MediaType(GlobalConstants.APPLICATION,msgFormat!=null?msgFormat:GlobalConstants.JSON)));

            String formatType = url.contains("?") ? "&type=" + GlobalConstants.JSON : "?type=" + GlobalConstants.JSON;
            
            String wcsBusinessChannelId = null;
            
            if(StringUtils.containsAny(url, "THDAPIController","THDAPIUserRegistration")){
                wcsBusinessChannelId = getWCSBusinessChannelId(cookiesLocal);
            }
            
            String urlToCall = new StringBuilder(GlobalConstants.HTTPS)
                                                .append("://")
                                                .append(wcsHost!=null ? wcsHost : envProperty.getWcsHost())
                                                .append("/")
                                                .append(wcsBusinessChannelId!=null ? url+"&businessChannelId="+wcsBusinessChannelId : url)
                                                .append(formatType)
                                                .toString();

            HttpEntity<Object> requestEntity = new HttpEntity<>(requestObj,headers);
            
            responseStr = retryTemplate.execute(retryContext -> {
                log.debug("WCS Request URL -- " + urlToCall+ " Attempt No --> " + (retryContext.getRetryCount()+1));
                log.debug("WCS Request headers -- "+requestEntity.getHeaders());
                
                return restTemplateInfo.getRestTemplate().exchange(urlToCall, method, requestEntity, String.class);
            });

            log.debug("WCS call response -- {}", responseStr);
            
            // Handle wcs nginx 302. Map it to 401 to prevent from falling into a generic 500 bucket
            if(HttpStatus.FOUND.equals(responseStr.getStatusCode()) && url.contains("THDAPIController")){
                throw new IntegrationException(HttpStatus.UNAUTHORIZED,"WCS returned a 302 from nginx",null);
            }

            // Handle wcs persistent user logout response.
            if(HttpStatus.UNAUTHORIZED.equals(responseStr.getStatusCode()) && url.contains("APILogoff")){
                if(responseStr.getBody() != null && responseStr.getBody().contains("AUTH_ERR_200")) {
                    responseObj = (T) responseStr.getBody();
                    log.debug("sendWCSRequest(): Response object after unmarshalling "+responseObj);
                    HttpHeaders responseHeaders = responseStr.getHeaders();
                    wcsResponse = new WCSResponse<T>();
                    wcsResponse.setResponseObj(responseObj);
                    wcsResponse.setHeaders(responseHeaders);
                    log.debug("sendWCSRequest(): WCS Response to be returned "+wcsResponse);
                    return wcsResponse;
                }
            }

            if(!errorHandler.isError(responseStr.getStatusCode())){
                if(responseStr.getBody() != null) {
                    responseObj = objectMapper.readValue(responseStr.getBody(), responseType);
                }
                
                log.debug("sendWCSRequest(): Response object after unmarshalling "+responseObj);
                HttpHeaders responseHeaders = responseStr.getHeaders();
                wcsResponse = new WCSResponse<T>();
                wcsResponse.setResponseObj(responseObj);
                wcsResponse.setHeaders(responseHeaders);
            } else {
                Errors errors = getErrors(responseStr.getBody());
                throw new IntegrationException(errors, responseStr.getStatusCode(), responseStr.getBody());
            }
        }catch(IntegrationException ex){
            throw ex;
        }catch(Exception ex){
            Errors errors = new Errors();
            Error error = new Error();
            errors.setErrors(Arrays.asList(error));
            error.setErrorCode(ErrorCode.SYSTEM_ERROR);
            error.setDeveloperErrorMessage(ex.getMessage());
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, ex);
        }
        
        log.debug("sendWCSRequest(): WCS Response to be returned "+wcsResponse);
        return wcsResponse!=null?wcsResponse:null;
    }

    public <T> WCSResponse<T> sendWCSFallBackRequest(Object requestObj, String url, HttpMethod method, String
            msgFormat, String wcsUserToken, ObjectMapper objectMapper, Class<T> responseType, boolean isUserRequest, Cookie[] cookies) throws IntegrationException{
        T responseObj = null;
        ResponseEntity<String> responseStr = null;
        WCSResponse<T> wcsResponse = null;
        String wcsHost = null;
        try{           
            // This is required to ensure we start fresh and dont carry any old cookies
            if(restTemplateInfo.getCookieStore()!=null){
                restTemplateInfo.getCookieStore().clear();
            }
            
            HttpHeaders headers = new HttpHeaders();
            headers.add("Authorization", wcsUserToken);

            if(isUserRequest && reqContext.getRequest().getCookies()!=null){
                String cookieStr = Arrays.asList(reqContext.getRequest().getCookies()).stream()
                        .map(c -> c.getName().concat("=").concat(c.getValue()))
                        .collect(Collectors.joining(";"));
                headers.add("Cookie",cookieStr);
            }else if(cookies!=null){ // Async flow
                String cookieStr = Arrays.asList(cookies).stream()
                        .map(c -> c.getName().concat("=").concat(c.getValue()))
                        .collect(Collectors.joining(";"));
                headers.add("Cookie",cookieStr);
            }
            
            if(Arrays.stream(environment.getActiveProfiles()).anyMatch(env -> GlobalConstants.SPRING_PFOFILE_DEV.equalsIgnoreCase(env))) {   
                ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
                if(requestAttributes!=null && requestAttributes.getRequest()!=null 
                        && requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV) !=null){
                    THDEnv thdEnv =  (THDEnv)requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV);
                    if(thdEnv!=null){
                        wcsHost = thdEnv.getOriginUrl();
                        log.debug("WCS host set to "+wcsHost);
                    }                            
                }
            }

            headers.setContentType(new MediaType(GlobalConstants.APPLICATION,msgFormat!=null?msgFormat: GlobalConstants.JSON));
            headers.setAccept(Collections.singletonList(new MediaType(GlobalConstants.APPLICATION,msgFormat!=null?msgFormat:GlobalConstants.JSON)));

            String formatType = url.contains("?") ? "&type=" + GlobalConstants.JSON : "?type=" + GlobalConstants.JSON;

            String urlToCall = GlobalConstants.HTTPS +"://" + (wcsHost!=null ? wcsHost : envProperty.getWcsHost()) + "/" + url + formatType;

            HttpEntity<Object> requestEntity = new HttpEntity<>(requestObj,headers);
            log.debug("WCS Request URL -- " + urlToCall);
            log.debug("WCS Request headers -- "+requestEntity.getHeaders());

            responseStr = restTemplateInfo.getRestTemplate().exchange(urlToCall, method, requestEntity, String.class);

            log.debug("WCS call response -- {}", responseStr);

            if(!errorHandler.isError(responseStr.getStatusCode())) {
                if (responseStr.getBody() != null) {

                    if (responseType.equals(Addresses.class)) {
                        com.homedepot.customer.integration.wcs.dto.Addresses wcsResponseObj = objectMapper.readValue(responseStr.getBody(), com.homedepot.customer.integration.wcs.dto.Addresses.class);
                        com.homedepot.customer.integration.wcs.dto.Address wcsAddress = wcsResponseObj.getAddress().stream().filter(a-> (FAILED).equals(a.getStatus())).findAny().orElse(null);
                        if(wcsAddress != null){
                            errorHandler.handleError(responseType, wcsResponseObj.getAddress().get(0).getErrors(), responseStr.getStatusCode());
                        }
                    } else if (responseType.equals(PaymentAccount.class)) {
                        com.homedepot.customer.integration.wcs.dto.PaymentAccountWCS wcsResponseObj = objectMapper.readValue(responseStr.getBody(), com.homedepot.customer.integration.wcs.dto.PaymentAccountWCS.class);
                        com.homedepot.customer.integration.wcs.dto.PaymentCard wcsPaymentCard = wcsResponseObj.getPaymentCards().getPaymentCard().stream().filter(a-> (FAILED).equals(a.getStatus())).findAny().orElse(null);
                        if(wcsPaymentCard != null){
                            errorHandler.handleError(responseType, wcsPaymentCard.getErrors(), responseStr.getStatusCode());
                        }
                    }
                    
                    responseObj = objectMapper.readValue(responseStr.getBody(), responseType);
                    HttpHeaders responseHeaders = responseStr.getHeaders();
                    wcsResponse = new WCSResponse<T>();
                    wcsResponse.setResponseObj(responseObj);
                    wcsResponse.setHeaders(responseHeaders);
                }
            }else {
                    if (responseStr.getBody() != null) {
                        com.homedepot.customer.integration.wcs.dto.ErrorWrapper errors = wcsServiceConfig.customErrorWCSObjectMapper().readValue(responseStr
                                .getBody(), com.homedepot.customer.integration.wcs.dto.ErrorWrapper.class);
                        errorHandler.handleError(responseType, errors.getErrors(), responseStr.getStatusCode());
                    }
                }

        }catch(IntegrationException ex){
            throw ex;
        }catch(Exception ex){
            Errors errors = getErrors(ex.getMessage());
            throw new IntegrationException(errors, HttpStatus.INTERNAL_SERVER_ERROR, ex);
        }
        return wcsResponse!=null?wcsResponse:null;
    }

    public Errors getErrors(String developerErrorMsg) {
        Errors errors = new Errors();
        Error error = new Error();
        errors.setErrors(Collections.singletonList(error));
        error.setErrorCode(ErrorCode.SYSTEM_ERROR);
        error.setDeveloperErrorMessage(developerErrorMsg);
        return errors;
    }

    protected String getWCSBusinessChannelId(Cookie[] cookies){
        String wcsChannelId = "-1";
        
        try{
            if(cookies!=null){
                String[] thdOnlineChannelValArray =                            
                            Arrays.asList(cookies).stream()
                            .filter(cookie -> cookie.getName().equalsIgnoreCase(GlobalConstants.THD_ONLINE_CHANNEL))
                            .map(cValUrlEncoded -> cValUrlEncoded.getValue())
                            .map(cVal -> urlDecoderWrapper(cVal))
                            .map(valArrStr -> valArrStr.split(GlobalConstants.THD_ONLINE_CHANNEL_SEPARATOR))
                            .findAny()
                            .orElse(null);

                
                if(ArrayUtils.isNotEmpty(thdOnlineChannelValArray)){
                    String channelStr = 
                            (String) Arrays.asList(thdOnlineChannelValArray).stream()
                            .filter(s -> s.contains("E2"))
                            .map(st -> st.split("=")[1])
                            .findAny()
                            .orElse(
                                (String) Arrays.asList(thdOnlineChannelValArray).stream()
                                .filter(s -> s.contains("E1"))
                                .map(st -> st.split("=")[1])
                                .findAny()
                                .orElse("Desktop")
                            );
        
                    wcsChannelId = wcsChannelIdMap.get(channelStr)!=null ? wcsChannelIdMap.get(channelStr) : "-1";
                }        
            } 
        }
        catch(Exception ex){
            log.error("Error getting WCS channel ids from cookies " +ex); // Absorb any errors
        }
               
        return wcsChannelId;
    }
    
    private String urlDecoderWrapper(String encodedVal){
        String decodedVal = null;
        try {
            decodedVal = URLDecoder.decode(encodedVal,GlobalConstants.CHARSET_UTF_8);
        } catch (UnsupportedEncodingException e) {
            log.error("Error decoding value "+encodedVal+": "+e);
        }
        
        return decodedVal;
    }

}
