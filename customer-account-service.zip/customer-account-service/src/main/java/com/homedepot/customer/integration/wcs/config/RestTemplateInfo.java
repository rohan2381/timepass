package com.homedepot.customer.integration.wcs.config;

import org.apache.http.client.CookieStore;
import org.springframework.web.client.RestTemplate;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Created by rxb1809 on Jan 11, 2017
 *
 */
@Data
@AllArgsConstructor
public class RestTemplateInfo {

    private RestTemplate restTemplate;
    private CookieStore cookieStore;
}
