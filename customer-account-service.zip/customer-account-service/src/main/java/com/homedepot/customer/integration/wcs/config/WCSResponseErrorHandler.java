package com.homedepot.customer.integration.wcs.config;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.error.AddressErrorCode;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.exception.error.PaymentErrorCode;
import com.homedepot.customer.exception.error.ProfileErrorCode;
import com.homedepot.customer.integration.wcs.dto.PaymentAccount;
import com.homedepot.customer.model.Account;
import com.homedepot.customer.model.Addresses;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResponseErrorHandler;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by rxb1809 on Aug 25, 2016
 *
 */
@Component
@Slf4j
public class WCSResponseErrorHandler implements ResponseErrorHandler{
    private static final String WCS_ERROR_MSG = "WCS Service Response Error:: ";

    @Autowired
    @Qualifier("wcsErrorCodeMapResource")
    private ResourceBundleMessageSource errorMapSource;

    @Override
    public boolean hasError(ClientHttpResponse response) throws IOException {
        return isError(response.getStatusCode());
    }

    public boolean isError(HttpStatus status) {
        HttpStatus.Series series = status.series();
        return HttpStatus.Series.CLIENT_ERROR.equals(series)
                || HttpStatus.Series.SERVER_ERROR.equals(series);
    }


    @Override
    public void handleError(ClientHttpResponse response) throws IOException {
        //do nothing
    }

    public void handleError(Class responseType, Object respObj, HttpStatus httpStatus) throws IntegrationException {
        String wcsErrorMsg = WCS_ERROR_MSG+"Status="+httpStatus+" Body="+respObj.toString();
        log.error(wcsErrorMsg);

        List<Error> errorList = new ArrayList<>();

        HttpStatus httpStatusCode = httpStatus;

        if (respObj instanceof com.homedepot.customer.integration.wcs.dto.Errors) {
            List<com.homedepot.customer.integration.wcs.dto.Error> wcsErrors = ((com.homedepot.customer.integration.wcs
                    .dto.Errors) respObj).getError();

            if (!CollectionUtils.isEmpty(wcsErrors)) {
                wcsErrors.forEach(wcsError -> {
                    Error error = new Error();
                    error.setErrorCode(errorMapSource.getMessage(wcsError.getId(), null, ErrorCode.SYSTEM_ERROR, null));
                    error.setDeveloperErrorMessage(wcsError.getId()+" : "+wcsError.getDescription());
                    errorList.add(error);
                });
            }

            try{
                if(responseType.equals(Addresses.class)) {

                    httpStatusCode = AddressErrorCode.valueOfHttpStatus(errorList.get(0).getErrorCode());
                }
                else if(responseType.equals(Account.class)){
                    httpStatusCode = ProfileErrorCode.valueOfHttpStatus(errorList.get(0).getErrorCode());
                }
                else if(responseType.equals(PaymentAccount.class)){
                    httpStatusCode = PaymentErrorCode.valueOfHttpStatus(errorList.get(0).getErrorCode());
                }
            }catch(IllegalArgumentException iLx){
                log.error("No wcs error code defined..",iLx);
                if(!HttpStatus.Series.CLIENT_ERROR.equals(httpStatusCode.series())) {
                    httpStatusCode = HttpStatus.INTERNAL_SERVER_ERROR;
                }
            }


        }

        Errors errors = new Errors();
        errors.setErrors(errorList);
        if(!httpStatusCode.equals(HttpStatus.OK)) {
            throw new IntegrationException(errors, httpStatusCode, wcsErrorMsg);
        }
    }

    public Error createError(String errorCode) {
        Error error = new Error();
        error.setErrorCode(errorMapSource.getMessage(errorCode, null, ErrorCode.SYSTEM_ERROR, null));
        return error;
    }

}
