package com.homedepot.customer.integration.wcs.config;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.Data;
import org.apache.http.client.CookieStore;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.env.Environment;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.text.SimpleDateFormat;

/**
 * Created by rxb1809 on Aug 24, 2016
 *
 */
@Configuration
@PropertySource("wcs/wcs-integration.properties")
@Data
public class WCSServiceConfig {
    
    @Autowired
    WCSResponseErrorHandler errorHandler;
    
    private ObjectMapper objectMapper;
    
    private ObjectMapper errorObjectMapper;

    @Autowired
    Environment env;
    
    @Bean(name="wcsRestTemplateInfo")
    public RestTemplateInfo restTemplateInfo() {
        final RestTemplate restTemplate = new RestTemplate();

        // Set message converters
        setMessageConverters(restTemplate);

        // Set connection params
        CookieStore httpCookieStore = setConnectionParams(restTemplate);
        
        // Set error handler
        restTemplate.setErrorHandler(errorHandler);
        
        RestTemplateInfo restTemplateInfo = new RestTemplateInfo(restTemplate,httpCookieStore);

        return restTemplateInfo;
    }

    private void setMessageConverters(RestTemplate restTemplate){
        //find and replace Jackson message converter with custom. Old style for loop to retain the iteration counter
        for (int i = 0; i < restTemplate.getMessageConverters().size(); i++) {
            final HttpMessageConverter<?> httpMessageConverter = restTemplate.getMessageConverters().get(i);
            if (httpMessageConverter instanceof MappingJackson2HttpMessageConverter){
                restTemplate.getMessageConverters().set(i, mappingJackson2HttpMessageConverter());
            }
        }
    }

    private MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter() {
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        converter.setObjectMapper(customWCSObjectMapper());

        return converter;
    }
    

    public ObjectMapper customWCSObjectMapper() {
        if(objectMapper == null){
            objectMapper = new ObjectMapper();
            objectMapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
            objectMapper.enable(SerializationFeature.WRAP_ROOT_VALUE);
            objectMapper.enable(DeserializationFeature.UNWRAP_ROOT_VALUE);
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
            objectMapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
            objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
        }

        return objectMapper;
    }
    
    public ObjectMapper customErrorWCSObjectMapper() {
        if(errorObjectMapper == null){
            errorObjectMapper = new ObjectMapper();
            errorObjectMapper.enable(SerializationFeature.WRAP_ROOT_VALUE);
            errorObjectMapper.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
            errorObjectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            errorObjectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
            errorObjectMapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
            errorObjectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
            errorObjectMapper.disable(DeserializationFeature.UNWRAP_ROOT_VALUE);
        }
        return errorObjectMapper;
    }

    private CookieStore setConnectionParams(RestTemplate restTemplate){
        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
        connectionManager.setMaxTotal(Integer.parseInt(env.getProperty("wcsConnectionMaxTotal")));
        connectionManager.setDefaultMaxPerRoute(Integer.parseInt(env.getProperty("wcsDefaultMaxPerRoute")));
        RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(Integer.parseInt(env.getProperty("wcsConnectionTimeout")))
                .setSocketTimeout(Integer.parseInt(env.getProperty("wcsSocketTimeout"))).build();
            
        CookieStore httpCookieStore = new BasicCookieStore();
        HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
        httpClientBuilder.setConnectionManager(connectionManager);
        httpClientBuilder.setDefaultRequestConfig(requestConfig);
        httpClientBuilder.setDefaultCookieStore(httpCookieStore);
        httpClientBuilder.disableRedirectHandling();

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClientBuilder.build());

        restTemplate.setRequestFactory(requestFactory);
        
        return httpCookieStore;
    }

    @Bean(name="wcsErrorCodeMapResource")
    public ResourceBundleMessageSource resourceBundleMessageSource() {
        ResourceBundleMessageSource source = new ResourceBundleMessageSource();
        source.setBasename("wcs/wcs-errorcode-mapping");
        source.setUseCodeAsDefaultMessage(true);
        return source;
    }
}
