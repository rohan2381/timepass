package com.homedepot.customer.integration.wcs.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Created by rxb1809 on Mar 29, 2017
 *
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Account {

    private String status;

    @JsonProperty("errors")
    Errors errors;
}
