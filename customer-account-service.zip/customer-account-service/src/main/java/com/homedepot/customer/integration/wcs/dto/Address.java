package com.homedepot.customer.integration.wcs.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Name;
import com.homedepot.customer.model.Phone;
import com.homedepot.customer.model.PostalDetails;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;
import java.util.List;

/**
 * Created by hxg3585
 * This is dto is used to map WCSFallback Errors
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Address {
    

    private Integer addrIdentifier;
    private String nickName;
    private String emailId;
    private Name name;
    private PostalDetails postalDetails;
    private Phone primaryPhone;
    private Phone alternatePhone;
    private Date lastModifiedDate;
    private Boolean isDefault;
    private Boolean isPartial;
    private String status;

    @JsonProperty("errors")
    Errors errors;
}
