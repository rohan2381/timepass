package com.homedepot.customer.integration.wcs.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.homedepot.customer.model.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Created by hxg3583
 *
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper=true)
@AllArgsConstructor
@NoArgsConstructor
@JsonRootName("addresses")
public class Addresses extends BaseEntity {
    private List<Address> address; // NOSONAR
}
