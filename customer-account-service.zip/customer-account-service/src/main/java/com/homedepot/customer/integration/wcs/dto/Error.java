package com.homedepot.customer.integration.wcs.dto;

import lombok.Data;

/**
 * Created by hxg3585 on 1/3/17.
 */
@Data
public class Error {
    String id;
    String description;
}
