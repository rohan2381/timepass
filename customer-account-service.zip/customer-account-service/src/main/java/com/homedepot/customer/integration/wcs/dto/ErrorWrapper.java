package com.homedepot.customer.integration.wcs.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * Created by hxg3585 on 1/3/17.
 */
@Data
public class ErrorWrapper {
    @JsonProperty("errors")
    Errors errors;
}
