package com.homedepot.customer.integration.wcs.dto;

import lombok.Data;

import java.util.List;

/**
 * Created by hxg3585 on 1/3/17.
 */
@Data
public class Errors {

 private List<Error> error;

}
