package com.homedepot.customer.integration.wcs.dto;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by vxg6469 on 12/14/16.
 */
@Data
@NoArgsConstructor
@JacksonXmlRootElement(localName = "KillSwitchData")
//@JsonIgnoreProperties(ignoreUnknown = true)
public class KillSwitchData {

    @JacksonXmlProperty(localName = "com.homedepot.sa.el.common.options.dto.Option")
    @JacksonXmlElementWrapper(useWrapping = false)
    private Option[] option;

}

