package com.homedepot.customer.integration.wcs.dto;

/**
 * Created by vxg6469 on 12/14/16.
 */


import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import lombok.Data;

@Data
public class Option {

    @JacksonXmlProperty(localName="mCodeName")
    private String mCodeName;

    @JacksonXmlProperty(localName = "mCodeGroupId")
    private String mCodeGroupId;

    @JacksonXmlProperty(localName = "mIntVal")
    private String mIntVal;
    
    @JacksonXmlProperty(localName = "mCharVal")
    private String mCharVal;

}
