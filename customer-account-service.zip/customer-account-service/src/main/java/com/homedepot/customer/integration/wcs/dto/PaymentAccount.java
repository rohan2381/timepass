package com.homedepot.customer.integration.wcs.dto;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.homedepot.customer.model.Addresses;
import com.homedepot.customer.model.PaymentCards;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by rxb1809 on Jun 11, 2016
 *
 */
@Data
@NoArgsConstructor
@JsonRootName("account")
public class PaymentAccount {

    @ApiModelProperty(value = "paymentCards to be created/updated", required = true)
    private PaymentCards paymentCards;
    
    private Addresses addresses;

}
