package com.homedepot.customer.integration.wcs.dto;

import com.fasterxml.jackson.annotation.JsonRootName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by axb4725 on 6/7/17.
 */
@Data
@NoArgsConstructor
@JsonRootName("account")
public class PaymentAccountWCS {
    @ApiModelProperty(value = "paymentCards to be created/updated", required = true)
    private PaymentCards paymentCards;

    private Addresses addresses;
}
