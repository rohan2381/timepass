package com.homedepot.customer.integration.wcs.dto;

import com.homedepot.customer.model.PieEncryption;
import lombok.Data;

import java.util.Date;

/**
 * Created by rxb1809 on Jun 11, 2016
 *
 */
@Data
public class PaymentCard {
    private Errors errors; // NOSONAR
    private String cardNickName;
    private String cardHolderName;
    private String cardType;
    private String cardBrand;
    private String cardBrandDisplayName;
    private String cardNumber;
    private String cardExpiryMonth;
    private String cardExpiryYear;
    private com.homedepot.customer.model.Address billingAddress;
    private Boolean isDefault;
    private Boolean isCardExpired;
    private String maskedCardNumber;
    private Integer cardNumberLast4;
    private Boolean isCardGSA;
    private Date lastModifiedDate;
    private Boolean isCVVRequired;
    private String xrefCardNumber;
    private PieEncryption pieEncryption;
    private String buyerId;
    private String paymentId;
    private String status;

    // Start - Used in WCS sync up
    private String profileOrderId;
    private Boolean isXREF;
    // End - Used in WCS sync up
    private Boolean isReqServedFromWCS;
}
