package com.homedepot.customer.integration.wcs.dto;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.homedepot.customer.model.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Created by rxb1809 on Aug 6, 2016
 *
 */
@Data
@EqualsAndHashCode(callSuper=true)
@AllArgsConstructor
@NoArgsConstructor
@JsonRootName("paymentCards")
public class PaymentCards extends BaseEntity{

    private List<PaymentCard> paymentCard; // NOSONAR
}
