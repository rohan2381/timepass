package com.homedepot.customer.integration.wcs.dto;

import lombok.Data;

/**
 * Created by rxb1809 on Oct 27, 2016
 *
 */
@Data
public class ValidateTokenResponse {

    private String memberId;
    private String registerType;
}
