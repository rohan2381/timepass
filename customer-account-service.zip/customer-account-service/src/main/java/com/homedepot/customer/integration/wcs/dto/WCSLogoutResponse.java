package com.homedepot.customer.integration.wcs.dto;

import lombok.Data;
import lombok.ToString;

import java.util.List;

@Data
@ToString
public class WCSLogoutResponse {

    private List<String> responseCookies;
}
