package com.homedepot.customer.integration.wcs.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.http.HttpHeaders;

/**
 * Created by admin on 9/22/16.
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class WCSResponse<T> {
    T responseObj;
    HttpHeaders headers;
}
