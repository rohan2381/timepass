package com.homedepot.customer.integration.wcs.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

import com.homedepot.customer.model.Account;

/**
 * Created by Nitin Ware on 9/16/16.
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class WCSUserIdentity {

    private String userId;
    private String logonId;
    private String encodedActivityToken;
    private String nonTlsEncodedActivityToken;
    private List<String> responseCookies;
    private Account account;

}
