package com.homedepot.customer.integration.wcs.dto.crossref;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Created by rxb1809 on Oct 14, 2016
 *
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Addresses {

    private List<Address> address;
}
