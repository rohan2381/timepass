package com.homedepot.customer.integration.wcs.dto.crossref;

import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

/**
 * Created by rxb1809 on Oct 14, 2016
 *
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@JsonRootName("crossRefInfo")
public class CrossRefInfo {

    private String svocCustAcctId;
    private Payments payments;
    private String wcsMemberId;
    private Addresses addresses;
    private String status;
    private String lastUpdUser;
    private Date lastUpdTs;
}
