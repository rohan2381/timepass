package com.homedepot.customer.integration.wcs.dto.crossref;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Created by rxb1809 on Oct 14, 2016
 *
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Payment {

    private String svocCustAcctId;
    private String wcsMemberId;
    private String svocAddressId;
    private String xrefPaymentId;
    private String lastUpdUser;
    private String wcsPaymentId;
    private String lastUpdTs;
    //private String wcsAddressId;
}
