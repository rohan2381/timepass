package com.homedepot.customer.mapper;

import java.util.Arrays;

import org.springframework.http.HttpStatus;

import com.homedepot.customer.exception.MapperException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;

/**
 * Created by rxb1809 on Jun 12, 2016
 *
 */
public interface IModelMapper<M, D> {

    public M convertDataToModel(D dataObj) throws MapperException;

    public D convertModelToData(M modelObj) throws MapperException;

    default void handleError(Exception ex, String resourceId) throws MapperException {
        Errors errors = new Errors();
        Error error = new Error();
        errors.setErrors(Arrays.asList(error));
        error.setErrorCode(ErrorCode.SYSTEM_ERROR);
        error.setResourceId(resourceId);
        throw new MapperException(errors, HttpStatus.INTERNAL_SERVER_ERROR, ex);
    }

}
