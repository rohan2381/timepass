package com.homedepot.customer.mapper.impl;

import com.homedepot.customer.exception.MapperException;
import com.homedepot.customer.integration.svoc.dto.AddressPhone;
import com.homedepot.customer.integration.svoc.dto.AddressPhones;
import com.homedepot.customer.mapper.IModelMapper;
import com.homedepot.customer.model.Address;
import com.homedepot.customer.model.Name;
import com.homedepot.customer.model.Phone;
import com.homedepot.customer.model.PostalDetails;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Optional;

import static com.homedepot.customer.util.GlobalConstants.*;

/**
 * Created by rxb1809 on Jun 11, 2016
 *
 */
@Slf4j
@NoArgsConstructor
@Service
@SuppressWarnings("squid:S1481")
public class AddressMapperImpl implements IModelMapper<Address,com.homedepot.customer.integration.svoc.dto.Address>{

    @Override
    public Address convertDataToModel(com.homedepot.customer.integration.svoc.dto.Address dataAddress) throws MapperException{
        log.debug("convertDataToModel, addressId: {}", dataAddress.getAddressId());
        Address modelAddress = new Address();
        try{
            modelAddress.setAddrIdentifier(dataAddress.getAddressId()!=null?dataAddress.getAddressId().intValue():null);
            modelAddress.setName(new Name(dataAddress.getFirstName(),dataAddress.getLastName()));
            modelAddress.setIsDefault(dataAddress.getPrimaryFlag().equalsIgnoreCase(STR_Y));

            modelAddress.setPostalDetails(new PostalDetails(dataAddress.getAddressLine1(), dataAddress.getAddressLine2(),
                                    dataAddress.getCityName(), dataAddress.getStateCode(),
                                    dataAddress.getPostalCode(), dataAddress.getCountryCode()));

            modelAddress.setEmailId(dataAddress.getDisplayCustomerEmailAddress());
            modelAddress.setLastModifiedDate(dataAddress.getLastUpdateTimestamp());

            if(dataAddress.getAddressPhones()!=null && !CollectionUtils.isEmpty(dataAddress.getAddressPhones().getAddressPhone())){
                AddressPhone primaryPhone = dataAddress.getAddressPhones().getAddressPhone().stream()
                                        .filter(p -> STR_Y.equalsIgnoreCase(p.getPrimaryFlag()))
                                        .findAny()
                                        .orElse(null);

                AddressPhone secondaryPhone = dataAddress.getAddressPhones().getAddressPhone().stream()
                                        .filter(p -> STR_N.equalsIgnoreCase(p.getPrimaryFlag()))
                                        .findAny()
                                        .orElse(null);

                log.debug("primaryPhone: {}, secondaryPhone: {}", primaryPhone, secondaryPhone);

                if (primaryPhone != null) {
                    modelAddress.setPrimaryPhone(new Phone(primaryPhone.getPhoneNumber(), null,
                            primaryPhone.getPhoneSequenceNumber(),"PHN",null,null,
                         //   primaryPhone.getPrimaryFlag(),primaryPhone.getSecondaryFlag(),
                            primaryPhone.getLastUpdateTimestamp()));
                }

                if (secondaryPhone != null) {
                    modelAddress.setAlternatePhone(new Phone(secondaryPhone.getPhoneNumber(), null,
                            secondaryPhone.getPhoneSequenceNumber(),"PHN",null,null,
                      //      secondaryPhone.getPrimaryFlag(),secondaryPhone.getSecondaryFlag(),
                            secondaryPhone.getLastUpdateTimestamp()));
                }
            }
        }catch(Exception ex){
            handleError(ex, String.valueOf(dataAddress.getAddressId())); 
        }
        
        return modelAddress;
    }


    @Override
    public com.homedepot.customer.integration.svoc.dto.Address convertModelToData(Address modelObj) throws MapperException {
        log.debug("Converting address model to data: {}", modelObj);
        Optional<Address> modelObjOption = Optional.of(modelObj);
        com.homedepot.customer.integration.svoc.dto.Address dataAddress = new com.homedepot.customer.integration.svoc.dto.Address();
        
        try{
            if (modelObjOption.map(Address::getName).isPresent()) {
                dataAddress.setFirstName(modelObjOption.map(i -> i.getName().getFirstName()).orElse(""));
                dataAddress.setLastName(modelObjOption.map(i -> i.getName().getLastName()).orElse(""));
            }
            dataAddress.setLastUpdateTimestamp(modelObjOption.map(Address::getLastModifiedDate).orElse(null));

            Integer addressId = modelObjOption.map(Address::getAddrIdentifier).orElse(null);
            
            if (addressId != null) {
                dataAddress.setActionType(ACTION_TYPE_UPDATE);
                dataAddress.setAddressId(addressId.shortValue());
            }
            else {
                dataAddress.setActionType(ACTION_TYPE_INSERT);
            }

            if (modelObjOption.map(Address::getIsDefault).isPresent()) {
                if(modelObjOption.map(Address::getIsDefault).orElse(false)){
                    dataAddress.setPrimaryFlag(STR_Y);
                }
                else {
                    dataAddress.setPrimaryFlag(STR_N);
                }
            }

            /* Postal details */
            if (modelObjOption.map(Address::getPostalDetails).isPresent()) {
                dataAddress.setAddressLine1(modelObjOption.map(i->i.getPostalDetails().getAddressLine1()).orElse(""));
                dataAddress.setAddressLine2(modelObjOption.map(i->i.getPostalDetails().getAddressLine2()).orElse(""));
                dataAddress.setCityName(modelObjOption.map(i->i.getPostalDetails().getCity()).orElse(""));
                dataAddress.setStateCode(modelObjOption.map(i->i.getPostalDetails().getState()).orElse(""));
                dataAddress.setCountryCode(modelObjOption.map(i->i.getPostalDetails().getCountry()).orElse(""));
                dataAddress.setPostalCode(modelObjOption.map(i->i.getPostalDetails().getZipCode()).orElse(""));
            }

            /* Phone details */
            ArrayList<AddressPhone> addressPhoneList =  new ArrayList<>();

            if ( modelObjOption.map(Address::getPrimaryPhone).isPresent()){
                log.debug("mapping primary phone");
                Short phoneId = modelObjOption.map(i -> i.getPrimaryPhone().getId()).orElse(null);
                String phoneNumber = modelObjOption.map(i -> i.getPrimaryPhone().getNumber()).orElse("");
                String actionType = evalPhoneActionType(phoneId, phoneNumber);

                addressPhoneList.add(new AddressPhone(phoneNumber,
                        "1", actionType, "", "Y", "N", phoneId,
                        modelObjOption.map(i->i.getPrimaryPhone().getLastModifiedDate()).orElse(null)));
            }

            if( modelObjOption.map(Address::getAlternatePhone).isPresent()){
                log.debug("mapping alternate phone");
                Short phoneId = modelObjOption.map(i -> i.getAlternatePhone().getId()).orElse(null);
                String phoneNumber = modelObjOption.map(i -> i.getAlternatePhone().getNumber()).orElse("");
                String actionType = evalPhoneActionType(phoneId, phoneNumber);

                addressPhoneList.add(new AddressPhone(phoneNumber,
                        "1", actionType, "", "N", "Y", phoneId,
                        modelObjOption.map(i->i.getAlternatePhone().getLastModifiedDate()).orElse(null)));
            }

            if (!addressPhoneList.isEmpty()) {
                dataAddress.setAddressPhones(new AddressPhones(addressPhoneList));
            }

            dataAddress.setDisplayCustomerEmailAddress(modelObjOption.map(Address::getEmailId).orElse(""));

            log.debug("Converted address to SVOC DTO: {}", dataAddress);
        }catch(Exception ex){
            handleError(ex, String.valueOf(modelObj.getAddrIdentifier())); 
        }
        
        return dataAddress;
    }

    private String evalPhoneActionType(Short phoneId, String phoneNumber) {

        String actionType;
        if (phoneId == null) {
            // no id, must be new, insert
            actionType = ACTION_TYPE_INSERT;
        }
        else {
            if (StringUtils.isEmpty(phoneNumber)) {
                // has id but no phone number, delete
                actionType = ACTION_TYPE_DELETE;
            }
            else {
                // has id and number, must be update
                actionType = ACTION_TYPE_UPDATE;
            }
        }

        log.debug("evalPhoneActionType: phoneId: {}, phoneNumer: {} - actionType: {}", phoneId, phoneNumber, actionType);

        return actionType;
    }

}
