package com.homedepot.customer.mapper.impl;

import org.springframework.stereotype.Service;

import com.homedepot.customer.integration.iam.dto.IAMResponse;
import com.homedepot.customer.mapper.IModelMapper;
import com.homedepot.customer.model.UserIdentity;

import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Jun 11, 2016
 */
@Slf4j
@NoArgsConstructor
@Service
public class IdentityMapperImpl implements IModelMapper<UserIdentity, IAMResponse> {

    @Override
    public UserIdentity convertDataToModel(IAMResponse iamResponse) {
    	
    	log.debug("convertDataToModel, IAMResponse: {}", iamResponse);
        
    	UserIdentity identity = new UserIdentity();
    	identity.setCustomerAccountId(iamResponse.getHdsvocid());
    	identity.setSessionToken(iamResponse.getToken());
    	identity.setLogonId(iamResponse.getMail());
    	identity.setOriginId(iamResponse.getHdoriginid());
    	identity.setSessionValid(iamResponse.getSessionValid());
    	
        return identity;
    }

    @Override
    public IAMResponse convertModelToData(UserIdentity identity) {

        return null; // Not required
    }

}
