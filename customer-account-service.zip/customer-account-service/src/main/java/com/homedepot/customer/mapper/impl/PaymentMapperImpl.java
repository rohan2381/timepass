package com.homedepot.customer.mapper.impl;

import java.util.Calendar;
import java.util.Date;

import com.homedepot.customer.integration.payment.dto.PaymentOptions;
import com.homedepot.customer.model.PaginationInfo;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.*;
import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.MapperException;
import com.homedepot.customer.integration.payment.dto.CardBrand;
import com.homedepot.customer.integration.payment.dto.PaymentOption;
import com.homedepot.customer.mapper.IModelMapper;
import com.homedepot.customer.model.Address;
import com.homedepot.customer.model.PaymentCard;
import com.homedepot.customer.util.*;

/**
 * Created by rxb1809 on Jun 12, 2016
 *
 */
@Slf4j
@NoArgsConstructor
@Service
public class PaymentMapperImpl implements IModelMapper<PaymentCard, PaymentOption> {

    @Override
    public PaymentCard convertDataToModel(PaymentOption paymentOption) throws MapperException {

        com.homedepot.customer.model.PaymentCard paymentCardModel = new PaymentCard();
        try {
            paymentCardModel.setPaymentId(paymentOption.getPaymentOptionId().toString());
            paymentCardModel.setIsDefault(paymentOption.getIsDefault());
            paymentCardModel.setCardHolderName(paymentOption.getCardHolderName());
            paymentCardModel.setCardNickName(paymentOption.getCardNickName());
            paymentCardModel.setXrefCardNumber(paymentOption.getCardNumber());

            if (paymentOption.getPaymentCard() != null) {
                com.homedepot.customer.integration.payment.dto.PaymentCard paymentCardDto = paymentOption
                        .getPaymentCard();
                paymentCardModel.setIsCardGSA(paymentCardDto.getIsGSA());
                paymentCardModel.setCardNumberLast4(paymentCardDto.getLast4digits());
                if(null != paymentCardDto.getCardExpiryMonth()) {
                    paymentCardModel.setCardExpiryMonth(paymentCardDto.getCardExpiryMonth());

                    // Card expiry month should be in two digit
                    if (paymentCardModel.getCardExpiryMonth().length() < 2) {
                        paymentCardModel.setCardExpiryMonth("0" + paymentCardModel.getCardExpiryMonth());
                    }
                }

                paymentCardModel.setCardExpiryYear(paymentCardDto.getCardExpiryYear());
                paymentCardModel.setLastModifiedDate(paymentCardDto.getLastModifiedDate());
                paymentCardModel.setBuyerId(paymentCardDto.getBuyerId());
                PaymentCardType cardType = PaymentCardType.getByShortDesc(paymentCardDto.getCardBrand().getShortDesc());
                paymentCardModel.setCardType(cardType.getShortDesc());
                paymentCardModel.setCardBrand(cardType.getCardBrand().name());
                paymentCardModel.setCardBrandDisplayName(cardType.getDescription());

                paymentCardModel.setMaskedCardNumber(buildMaskedCardNumber(paymentCardDto.getLast4digits()));
                if(PaymentCardBrand.HDCOM.equals(cardType.getCardBrand()) || PaymentCardBrand.HDCON.equals(cardType.getCardBrand()))
                    paymentCardModel.setIsCardExpired(false);
                else
                    paymentCardModel.setIsCardExpired(isCardExpired(paymentCardDto.getCardExpiryMonth(), paymentCardDto.getCardExpiryYear()));

                Address address = new Address();
                address.setAddrIdentifier(paymentCardDto.getAddressId());
                // postal details are set from PaymentServiceImpl.java
                paymentCardModel.setBillingAddress(address);
            }
        } catch (Exception ex) {
            handleError(ex, String.valueOf(paymentOption.getPaymentOptionId()));
        }

        return paymentCardModel;

    }

    @Override
    public PaymentOption convertModelToData(PaymentCard paymentCard) throws MapperException {

        PaymentOption paymentOption = new PaymentOption();

        paymentOption.setCardNumber(paymentCard.getXrefCardNumber());
        paymentOption.setCardHolderName(paymentCard.getCardHolderName());
        paymentOption.setCardNickName(paymentCard.getCardNickName());
        if (paymentCard.getPaymentId() != null) {
            paymentOption.setPaymentOptionId(Long.valueOf(paymentCard.getPaymentId()));
        }
        paymentOption.setIsDefault(paymentCard.getIsDefault());
        com.homedepot.customer.integration.payment.dto.PaymentCard cardDTO = new com.homedepot.customer.integration.payment.dto.PaymentCard();

        if (paymentCard.getBillingAddress() != null) {
            cardDTO.setAddressId(paymentCard.getBillingAddress().getAddrIdentifier());
        }
        cardDTO.setIsGSA(paymentCard.getIsCardGSA());
        CardBrand cardBrand = new CardBrand();

        cardBrand.setShortDesc(paymentCard.getCardType());
        cardBrand.setDescription(paymentCard.getCardBrandDisplayName());

        cardDTO.setCardBrand(cardBrand);
        cardDTO.setLast4digits(StringUtils.right(paymentCard.getXrefCardNumber(), 4));
        cardDTO.setCardExpiryMonth(paymentCard.getCardExpiryMonth());
        cardDTO.setCardExpiryYear(paymentCard.getCardExpiryYear());


        cardDTO.setBuyerId(paymentCard.getBuyerId());
        paymentOption.setPaymentCard(cardDTO);

        return paymentOption;
    }

    public String buildMaskedCardNumber(String last4digits) {
        StringBuilder sb = new StringBuilder(PaymentCardConstants.PAYMENT_CARD_MASK);
        sb.append(last4digits);
        return sb.toString();
    }

    public boolean isCardExpired(String expiryMonth, String expiryYear) {

        if (StringUtils.isBlank(expiryMonth) || StringUtils.isBlank(expiryYear)) {
            return true;
        }

        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        // Java month starts at 0 (eg. Month of January = 0)
        int currentMonth = cal.get(Calendar.MONTH) + 1;
        int currentYear = cal.get(Calendar.YEAR);
        return (currentMonth > Integer.parseInt(expiryMonth)) && (currentYear >= Integer.parseInt(expiryYear));
    }

    public PaginationInfo convertPaginationDataToModel(PaymentOptions paymentOptions) {

        PaginationInfo paginationInfo = new PaginationInfo();

        if (paymentOptions != null) {
            paginationInfo.setPageNumber(paymentOptions.getPage().toString());
            paginationInfo.setPageSize(paymentOptions.getSize().toString());
            paginationInfo.setTotalNumberOfRecords(paymentOptions.getTotalElements().toString());
            paginationInfo.setTotalPages(paymentOptions.getTotalPages().toString());
        }

        return paginationInfo;
    }

}
