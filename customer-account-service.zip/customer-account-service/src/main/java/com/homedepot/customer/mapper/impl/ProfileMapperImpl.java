package com.homedepot.customer.mapper.impl;

import com.homedepot.customer.exception.MapperException;
import com.homedepot.customer.integration.svoc.dto.Address;
import com.homedepot.customer.integration.svoc.dto.Addresses;
import com.homedepot.customer.integration.svoc.dto.*;
import com.homedepot.customer.integration.svoc.dto.Store;
import com.homedepot.customer.mapper.IModelMapper;
import com.homedepot.customer.model.*;
import com.homedepot.customer.model.Phone;
import com.homedepot.customer.util.GlobalConstants;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.*;

import static com.homedepot.customer.util.GlobalConstants.*;

/**
 * Created by rxb1809 on Jun 12, 2016
 *
 */
@Slf4j
@NoArgsConstructor
@Service
@SuppressWarnings("squid:S1481")
public class ProfileMapperImpl implements IModelMapper<Account,Customer> {
    
    private static final String PREFERRED_STORE = "PREFERRED";
    private static final String PREFERRED_LANGUAGE = "United States English";
    private static final String UNKNOWN_PHONE_TYPE = "UNKNOWN";

    @Override
    public Account convertDataToModel(Customer customer) throws MapperException {
        Account tempAccount= new Account();
        try {
            Optional<Customer> customerOptional = Optional.of(customer);

            log.debug("converting Profile svoc data to model, customer id: {}", customer.getCustomerAccountId());

            Profile profileObj = new Profile();
            if(customer.getFirstName() != null || customer.getLastName() != null) {
                Name tempName = new Name();
                profileObj.setName(tempName);
            }

            customerOptional.ifPresent(i -> {
                tempAccount.setCustomerAccountId(i.getCustomerAccountId());
                tempAccount.setLastModifiedDate(i.getLastUpdateTimestamp());
            });
            customerOptional.map(i -> i.getFirstName()).ifPresent(i -> profileObj.getName().setFirstName(i));
            customerOptional.map(i -> i.getLastName()).ifPresent(i -> profileObj.getName().setLastName(i));
            customerOptional.map(i -> i.getLocalizationPostalCode()).ifPresent(i -> profileObj.setZipCode(i));

            customerOptional.map(i -> i.getEmails()).map(j->j.getEmail()).get().forEach(k -> {
                if (k.getPrimaryFlag().equals(GlobalConstants.STR_Y)) {
                    profileObj.setEmailId(k.getEmailAddress());
                    profileObj.setEmailContactMethodEnumeration(k.getContactMethodEnumeration());
                    profileObj.setLastModifiedDate(k.getLastUpdateTimestamp());
                }
            });

            customerOptional.map(Customer::getStores)
                    .map(Stores::getStore)
                    .ifPresent(stores -> stores.stream()
                            .filter(store -> PREFERRED_STORE.equals(store.getCustomerStoreRelationTypeEnumeration()))
                            .findFirst()
                            .ifPresent(store -> {
                                profileObj.setLocalStoreId(store.getStoreNumber());
                                profileObj.setLocalStoreLastModifiedDate(store.getLastUpdateTimestamp());
                            })
                    );

            customerOptional.map(i -> i.getPreferredLanguageCode()).ifPresent(i -> profileObj.setPreferredLanguageId(i));
            customerOptional.map(i -> i.getHdTaxExemptId()).ifPresent(i -> profileObj.setTaxExemptId(i));

            customerOptional.map(i -> i.getPreferredLanguageCode()).ifPresent(k ->
                    profileObj.setPreferredLanguageDescription(PREFERRED_LANGUAGE)
            );

            customerOptional.map(i -> i.getCustomerId()).ifPresent(k -> profileObj.setCustomerId(k));
            customerOptional.map(i -> i.getTypeEnumeration()).ifPresent(k -> profileObj.setUserType(k));
            tempAccount.setProfile(profileObj);

            // map all phones and let UI decide which one to show
            ArrayList<Phone> modelPhoneList = new ArrayList<>();
            customerOptional.map(Customer::getPhones)
                    .map(Phones::getPhone)
                    .ifPresent(phones -> phones.forEach(phone -> {
                        Phone modelPhone = new Phone();
                        modelPhone.setNumber(phone.getPhoneNumber());
                        modelPhone.setType(phone.getTypeEnumeration());
                        modelPhone.setLastModifiedDate(phone.getLastUpdateTimestamp());
                        modelPhone.setContactMethodEnumeration(phone.getContactMethodEnumeration());
                        modelPhone.setPrimaryFlag(phone.getPrimaryFlag());
                        modelPhone.setSecondaryFlag(phone.getSecondaryFlag());

                        modelPhoneList.add(modelPhone);
                    }));

            if (!modelPhoneList.isEmpty()) {
                ProfilePhones profilePhones = new ProfilePhones(modelPhoneList);
                tempAccount.setProfilePhones(profilePhones);
            }

            // new fields 2017-01-18
            customerOptional.map(Customer::getUserId).ifPresent(profileObj::setUserId);
            customerOptional.map(Customer::getEncryptedTaxId).ifPresent(profileObj::setEncryptedTaxId);
            customerOptional.map(Customer::getRetryCount).ifPresent(profileObj::setRetryCount);
            customerOptional.map(Customer::getCustomerIdentityFlag).ifPresent(profileObj::setCustomerIdentityFlag);
            customerOptional.map(Customer::getActive).ifPresent(profileObj::setActive);

            // for pro xtra
            customerOptional.map(Customer::getBusinessName)
                    .ifPresent(profileObj::setBusinessName);

            customerOptional.map(c -> c.getLoyaltyEnrollmentIndicator()).ifPresent(
               i -> {
                   if(i.equalsIgnoreCase(STR_P)){
                       profileObj.setLoyaltyEnrollmentIndicator(STR_Y);
                   }else{
                       profileObj.setLoyaltyEnrollmentIndicator(i);
                   }
               }
            );

            customerOptional.map(Customer::getTradeTypes)
                    .map(TradeTypes::getTradeType)
                    .ifPresent(tradeTypeList -> tradeTypeList.stream()
                            .findFirst()
                            .ifPresent(tradeType -> {
                                profileObj.setTradeType(tradeType.getTypeEnumeration());
                                profileObj.setTradeTypeLastModifiedDate(tradeType.getLastUpdateTimestamp());
                                if (StringUtils.hasText(tradeType.getTradeTypeOtherText())) {
                                    profileObj.setOtherTradeDescription(tradeType.getTradeTypeOtherText());
                                }
                            })
                    );

            // address, for pro xtra, map all addresses and let UI decide which to show
            ArrayList<com.homedepot.customer.model.Address> modelAddressList = new ArrayList<>();
            customerOptional.map(Customer::getAddresses)
                    .map(Addresses::getAddress)
                    .ifPresent(addressList -> addressList.forEach(dataAddress -> {
                        com.homedepot.customer.model.Address modelAddress = new com.homedepot.customer.model.Address();
                        modelAddress.setName(new Name(dataAddress.getFirstName(),dataAddress.getLastName()));
                        modelAddress.setAddrIdentifier(dataAddress.getAddressId()!=null?dataAddress.getAddressId().intValue():null);
                        modelAddress.setLastModifiedDate(dataAddress.getLastUpdateTimestamp());
                        modelAddress.setIsDefault(STR_Y.equalsIgnoreCase(dataAddress.getPrimaryFlag()));
                        modelAddress.setPostalDetails(new PostalDetails(dataAddress.getAddressLine1(), dataAddress.getAddressLine2(),
                                dataAddress.getCityName(), dataAddress.getStateCode(),
                                dataAddress.getPostalCode(), dataAddress.getCountryCode()));

                        modelAddressList.add(modelAddress);
                    }));

            if (!modelAddressList.isEmpty()) {
                tempAccount.setAddress(modelAddressList);
            }
        }
        catch (Exception ex) {
            handleError(ex, String.valueOf(customer.getCustomerAccountId()));
        }

        return tempAccount;
    }

    @Override
    public Customer convertModelToData(Account account) throws MapperException {
        Customer customer = new Customer();

        try {
            Optional<Account> optAccount = Optional.of(account);
            log.debug("converting profile model to svoc data, customer id: {}", account.getCustomerAccountId());
            customer.setResponseSource("SVOCS");
            customer.setCustomerAccountId(account.getCustomerAccountId());
            customer.setLastUpdateTimestamp(account.getLastModifiedDate());
            if (account.getCustomerAccountId() != null) {
                if(account.getLastModifiedDate()!=null) {  customer.setActionType(ACTION_TYPE_UPDATE); }
            } else {
                customer.setActionType(ACTION_TYPE_INSERT);
            }

            optAccount.map(Account::getProfile)
                    .ifPresent(modelProfile -> {
                        customer.setEmails(buildEmails(modelProfile));
                        customer.setLocalizationPostalCode(modelProfile.getZipCode());
                        customer.setPreferredLanguageCode(modelProfile.getPreferredLanguageId());
                        customer.setHdTaxExemptId(modelProfile.getTaxExemptId());

                        mapName(modelProfile, customer);

                        customer.setStores(buildStores(modelProfile.getLocalStoreId(), modelProfile.getLocalStoreLastModifiedDate()));

                        // new fields 2017-01-18
                        customer.setUserId(modelProfile.getUserId());
                        customer.setEncryptedTaxId(modelProfile.getEncryptedTaxId());
                        customer.setRetryCount(modelProfile.getRetryCount());
                        customer.setCustomerIdentityFlag(modelProfile.getCustomerIdentityFlag());
                        customer.setActive(modelProfile.getActive());
                        customer.setCustomerId(modelProfile.getCustomerId());

                        mapProXtraFields(modelProfile, customer);
                    });

            // for pro xtra
            optAccount.map(Account::getAddress)
                    .ifPresent(addressList -> addressList.stream()
                            .findFirst()
                            .ifPresent(modelAddress -> {
                                log.debug("converting model address to svoc address");
                                Address svocAddress = new Address();
                                svocAddress.setLastUpdateTimestamp(modelAddress.getLastModifiedDate());
                                if(modelAddress.getName()!=null){
                                    svocAddress.setFirstName(modelAddress.getName().getFirstName());
                                    svocAddress.setLastName(modelAddress.getName().getLastName());
                                }
                                List<AddressPhone> svocList= new ArrayList<AddressPhone>();
                                if(modelAddress.getPrimaryPhone()!=null && !StringUtils.isEmpty(modelAddress.getPrimaryPhone().getNumber())) {
                                    AddressPhone svocPrimaryPhone = new AddressPhone();
                                    svocPrimaryPhone.setPrimaryFlag("Y");
                                    svocPrimaryPhone.setPhoneNumber(modelAddress.getPrimaryPhone().getNumber());
                                    svocPrimaryPhone.setActionType("INSERT");
                                    svocPrimaryPhone.setCountryCode("1");
                                    svocList.add(svocPrimaryPhone);
                                    svocAddress.setAddressPhones(new AddressPhones(svocList));
                                }
                                if (modelAddress.getAddrIdentifier() != null) {
                                    svocAddress.setActionType(ACTION_TYPE_UPDATE);
                                    svocAddress.setAddressId(modelAddress.getAddrIdentifier().shortValue());
                                } else {
                                    svocAddress.setActionType(ACTION_TYPE_INSERT);
                                }
                                if (modelAddress.getIsDefault() == null || modelAddress.getIsDefault()) {
                                    // default set to primary=Y if not specified
                                    svocAddress.setPrimaryFlag(STR_Y);
                                }
                                else {
                                    svocAddress.setPrimaryFlag(STR_N);
                                }
                                Optional.ofNullable(modelAddress.getPostalDetails()).ifPresent(postalDetails -> {
                                    svocAddress.setAddressLine1(postalDetails.getAddressLine1());
                                    svocAddress.setAddressLine2(postalDetails.getAddressLine2());
                                    svocAddress.setCityName(postalDetails.getCity());
                                    svocAddress.setStateCode(postalDetails.getState());
                                    svocAddress.setPostalCode(postalDetails.getZipCode());
                                    svocAddress.setCountryCode(postalDetails.getCountry());
                                });
                                Addresses addresses = new Addresses();
                                addresses.setAddress(Collections.singletonList(svocAddress));
                                customer.setAddresses(addresses);
                            })
                    );

            // profile phone
            Phones svocPhones = new Phones();
            svocPhones.setPhone(new ArrayList<>());
            optAccount.map(Account::getProfilePhones)
                    .map(ProfilePhones::getPhone)
                    .ifPresent(phones -> phones.stream()
                            .forEach(phone -> {
                                log.debug("converting model phone to svoc phone");
                                com.homedepot.customer.integration.svoc.dto.Phone svocPhone = buildSvocPhone(phone);
                                svocPhones.getPhone().add(svocPhone);
                                customer.setPhones(svocPhones);
                            })
                    );
            customer.setPreferredLanguageCode("en_US");
        }
        catch (Exception ex) {
            handleError(ex, String.valueOf(account.getCustomerAccountId()));
        }

        return customer;
    }

    private com.homedepot.customer.integration.svoc.dto.Phone buildSvocPhone(Phone phone) {
        log.debug("build svoc phone");
        com.homedepot.customer.integration.svoc.dto.Phone svocPhone = new com.homedepot.customer.integration.svoc.dto.Phone();
        Optional<Phone> optPhone = Optional.of(phone);
        svocPhone.setActionType(ACTION_TYPE_INSERT);
        optPhone.map(Phone::getContactMethodEnumeration)
                .ifPresent(svocPhone::setContactMethodEnumeration);
        optPhone.map(Phone::getLastModifiedDate)
                .ifPresent(lastModifiedDate -> {
                    if (StringUtils.isEmpty(phone.getNumber())) {
                        // has no phone number, must be deletion
                        svocPhone.setActionType(ACTION_TYPE_DELETE);
                    }
                    else {
                        // has phone number, update
                        svocPhone.setActionType(ACTION_TYPE_UPDATE);
                    }

                    svocPhone.setLastUpdateTimestamp(lastModifiedDate);
                });
        svocPhone.setPhoneNumber(phone.getNumber());
        svocPhone.setTypeEnumeration(phone.getType() != null ? phone.getType() : UNKNOWN_PHONE_TYPE);

        svocPhone.setPrimaryFlag(phone.getPrimaryFlag());
        svocPhone.setSecondaryFlag(phone.getSecondaryFlag());
        svocPhone.setCountryCode("1");
        return svocPhone;
    }

    private void mapProXtraFields(Profile fromProfile, Customer toCustomer) {
        log.debug("mapProXtraFields from model profile to svoc customer");
        // for Pro Xtra mapping
        toCustomer.setEnrollInLoyaltyFlag(fromProfile.getLoyaltyEnrollmentIndicator());
        toCustomer.setLoyaltyEnrollmentIndicator(fromProfile.getLoyaltyEnrollmentIndicator());

        toCustomer.setBusinessName(fromProfile.getBusinessName());

        Optional<String> optionalTradeType = Optional.ofNullable(fromProfile.getTradeType());
        optionalTradeType.ifPresent(tradeTypeCode -> {
            log.debug("converting model trade type to svoc trade type");
            TradeType tradeType = new TradeType();
            tradeType.setSourceEnumeration("REWARDS");
            tradeType.setTypeEnumeration(tradeTypeCode);
            if (TRADE_TYPE_OTHER.equalsIgnoreCase(tradeTypeCode)) {
                tradeType.setTradeTypeOtherText(fromProfile.getOtherTradeDescription());
            } else {
                tradeType.setTradeTypeOtherText(null);
            }
            tradeType.setLastUpdateTimestamp(fromProfile.getTradeTypeLastModifiedDate());
            if (fromProfile.getTradeTypeLastModifiedDate() != null) {
                tradeType.setActionType(ACTION_TYPE_UPDATE);
            } else {
                tradeType.setActionType(ACTION_TYPE_INSERT);
            }
            TradeTypes tradeTypes = new TradeTypes();
            tradeTypes.setTradeType(Collections.singletonList(tradeType));
            toCustomer.setTradeTypes(tradeTypes);
        });
    }

    private void mapName(Profile fromProfile, Customer toCustomer) {
        Optional<Name> optName = Optional.ofNullable(fromProfile.getName());
        optName.ifPresent(name -> {
            toCustomer.setFirstName(name.getFirstName());
            toCustomer.setLastName(name.getLastName());
        });
    }

    /**
     * Extracted from lambda expression so that it's smaller than 20 lines
     * @param modelProfile
     * @return
     */
    private Emails buildEmails(Profile modelProfile) {
        log.debug("building svoc Emails");
        if (!StringUtils.hasText(modelProfile.getEmailId())) {
            // don't create Emails node if email id is not provided
            return null;
        }

        Email email = new Email();
        email.setEmailAddress(modelProfile.getEmailId());
        email.setPrimaryFlag(GlobalConstants.STR_Y);
        email.setSecondaryFlag(GlobalConstants.STR_N);

        // svoc use this as id for this email
        email.setContactMethodEnumeration(modelProfile.getEmailContactMethodEnumeration());
        email.setEmailReceiptOptInFlag(GlobalConstants.STR_N);
        email.setLastUpdateTimestamp(modelProfile.getLastModifiedDate());
        if (modelProfile.getLastModifiedDate() != null) {
            email.setActionType(ACTION_TYPE_UPDATE);
        } else {
            email.setActionType(ACTION_TYPE_INSERT);
        }
        Emails emails = new Emails();
        emails.setEmail(Arrays.asList(email));
        return emails;
    }

    /**
     * Extracted to avoid long lambda expression
     * @param localStoreId
     * @param localStoreLastModifiedDate
     * @return
     */
    private Stores buildStores(String localStoreId, Date localStoreLastModifiedDate) {
        if (StringUtils.hasText(localStoreId) || localStoreLastModifiedDate != null) {
            log.debug("building svoc Stores");

            Store store = new Store();
            store.setStoreNumber(localStoreId);
            store.setLastUpdateTimestamp(localStoreLastModifiedDate);
            store.setCustomerStoreRelationTypeCode(TYPE_CODE_PREFERRED_STORE);
            store.setCustomerStoreRelationTypeEnumeration("PREFERRED");
            if (localStoreLastModifiedDate == null) {
                store.setActionType(GlobalConstants.ACTION_TYPE_INSERT);
            }
            else {
                if (StringUtils.hasText(localStoreId)) {
                    store.setActionType(GlobalConstants.ACTION_TYPE_UPDATE);
                }
                else {
                    store.setActionType(GlobalConstants.ACTION_TYPE_DELETE);
                }
            }

            Stores stores = new Stores();
            stores.setStore(Collections.singletonList(store));

            return stores;
        }
        else {
            return null;
        }
    }


}
