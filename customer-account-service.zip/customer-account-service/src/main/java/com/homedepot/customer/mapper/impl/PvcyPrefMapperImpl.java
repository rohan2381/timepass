package com.homedepot.customer.mapper.impl;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.MapperException;
import com.homedepot.customer.integration.acxiom.dto.preferences.ObjectFactory;
import com.homedepot.customer.integration.acxiom.dto.preferences.UpdateAllRequest;
import com.homedepot.customer.mapper.IModelMapper;
import com.homedepot.customer.model.pvcypreferences.PrivacyPrefRequest;
import com.homedepot.customer.model.pvcypreferences.UpdateEmail;
import com.homedepot.customer.model.pvcypreferences.UpdateMail;
import com.homedepot.customer.model.pvcypreferences.UpdatePhone;

@Service
public class PvcyPrefMapperImpl implements IModelMapper<PrivacyPrefRequest, UpdateAllRequest>{

    @Override
    public PrivacyPrefRequest convertDataToModel(UpdateAllRequest dataObj) throws MapperException {
        // Not required, as currently we are not not focusing on their response. 
        return new PrivacyPrefRequest();
    }

    @Override
    public UpdateAllRequest convertModelToData(PrivacyPrefRequest modelObj) throws MapperException {

        UpdateAllRequest acxiomRequest = new ObjectFactory().createUpdateAllRequest();
        
        Optional<PrivacyPrefRequest> optPvcyPrefReq = Optional.ofNullable(modelObj);
        Optional<UpdateEmail> optEmail= optPvcyPrefReq.map(PrivacyPrefRequest::getUpdateEmail);
        Optional<UpdatePhone> optPhone= optPvcyPrefReq.map(PrivacyPrefRequest::getUpdatePhone);
        Optional<UpdateMail> optMail= optPvcyPrefReq.map(PrivacyPrefRequest::getUpdateMail);
        
        //Email Preferences
        optEmail.map(UpdateEmail::getEmailAddress).ifPresent(i -> acxiomRequest.setEmailAddress(i));
        optEmail.map(UpdateEmail::getSubscribeEmail).ifPresent(i -> acxiomRequest.setTHDPromoPermission(i));
        
        //Phone Preferences
        optPhone.map(UpdatePhone::getPhoneNo).ifPresent(i -> acxiomRequest.setPhoneNumber(i));
        optPhone.map(UpdatePhone::getSubscribePhone).ifPresent(i -> acxiomRequest.setCallMe(i));
        
        //Mail Preferences
        optMail.map(UpdateMail::getFirstName).ifPresent(i -> acxiomRequest.setFirstName(i));
        optMail.map(UpdateMail::getLastName).ifPresent(i -> acxiomRequest.setLastName(i));
        optMail.map(UpdateMail::getAddressLine1).ifPresent(i -> acxiomRequest.setAddressLine1(i));
        optMail.map(UpdateMail::getAddressLine2).ifPresent(i -> acxiomRequest.setAddressLine2(i));
        optMail.map(UpdateMail::getCity).ifPresent(i -> acxiomRequest.setCity(i));
        optMail.map(UpdateMail::getState).ifPresent(i -> acxiomRequest.setState(i));
        optMail.map(UpdateMail::getZip).ifPresent(i -> acxiomRequest.setZip(i));
        optMail.map(UpdateMail::getSubscribeMail).ifPresent(i -> {
                                                                    acxiomRequest.setTHDDMChannelPermission(i);
                                                                    acxiomRequest.setHDDCatalogHandRaiser(i);
                                                                });
        //Information Sharing Preference
        optPvcyPrefReq.map(PrivacyPrefRequest::getShareInfo).ifPresent(i -> acxiomRequest.setShareInfo(i));
        
        return acxiomRequest;
    
    }

}
