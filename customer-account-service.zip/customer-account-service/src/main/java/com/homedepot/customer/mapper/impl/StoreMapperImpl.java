package com.homedepot.customer.mapper.impl;

import java.util.*;

import org.apache.commons.lang.exception.*;
import org.springframework.stereotype.*;

import com.homedepot.customer.exception.*;
import com.homedepot.customer.integration.storesearch.dto.*;
import com.homedepot.customer.mapper.*;
import com.homedepot.customer.model.*;
import com.homedepot.customer.model.Store;

import lombok.*;
import lombok.extern.slf4j.*;

/**
 * Created by nxw6207 on 4/27/17.
 */
@Slf4j
@NoArgsConstructor
@Service
public class StoreMapperImpl implements IModelMapper<Store, com.homedepot.customer.integration.storesearch.dto.Store> {

    @Override
    public Store convertDataToModel(com.homedepot.customer.integration.storesearch.dto.Store dataStore)
            throws MapperException {
        Store storeModel = new Store();
        try{
            Optional<com.homedepot.customer.integration.storesearch.dto.Store> storeOptional = Optional.of(dataStore);
            log.debug("convertDataToModel, storeId: {}", dataStore.getStoreId());
            storeOptional.map(com.homedepot.customer.integration.storesearch.dto.Store::getStoreId).ifPresent(storeModel::setStoreId);
            storeOptional.map(com.homedepot.customer.integration.storesearch.dto.Store::getName).ifPresent(storeModel::setName);
            storeOptional.map(com.homedepot.customer.integration.storesearch.dto.Store::getAddress)
                    .ifPresent(modelAddress -> {
                        storeModel.setCity(modelAddress.getCity());
                        storeModel.setState(modelAddress.getState());
                    });
        }catch(Exception ex){
            log.error("Error Mapping Store DTO to Model for id " + dataStore.getStoreId() + " " + ExceptionUtils.getRootCauseMessage(ex));
        }
        return storeModel;
    }

    @Override
    public com.homedepot.customer.integration.storesearch.dto.Store convertModelToData(Store modelObj)
            throws MapperException {
        return null; // Not required
    }
}
