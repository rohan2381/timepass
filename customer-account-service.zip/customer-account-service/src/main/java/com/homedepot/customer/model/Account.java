package com.homedepot.customer.model;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonRootName;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Created by rxb1809 on Jun 11, 2016
 *
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper=true)
@AllArgsConstructor
@NoArgsConstructor
@JsonRootName("account")
public class Account extends BaseEntity {

    private String customerAccountId; // NOSONAR
    private Profile profile; // NOSONAR

    @ApiModelProperty(value = "Upgrade to pro requires a primary address")
    private List<Address> address; // NOSONAR

    @ApiModelProperty(value = "Upgrade to pro requires a primary phone")
    private ProfilePhones profilePhones; // NOSONAR

    @ApiModelProperty(value = "required for update")
    private Date lastModifiedDate; // NOSONAR

    private Boolean isReqServedFromWCS;
}
