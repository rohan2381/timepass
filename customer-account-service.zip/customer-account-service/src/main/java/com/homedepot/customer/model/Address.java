package com.homedepot.customer.model;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Created by rxb1809 on Jun 11, 2016
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class Address {
    
    @ApiModelProperty(value = "required for update")
    private Integer addrIdentifier;
    private String nickName;
    private String emailId;

    @ApiModelProperty(required = true)
    private Name name;

    @ApiModelProperty(required = true)
    private PostalDetails postalDetails;

    @ApiModelProperty(required = true, allowableValues = "Y, N")
    private Phone primaryPhone;
    private Phone alternatePhone;

    @ApiModelProperty(value = "required for update")
    private Date lastModifiedDate;

    @ApiModelProperty(value = "Default shipping address indicator. To set a new default, payload has to have old default address set to false. PO Box cannot be a default shipping address.", required = true, allowableValues = "true, false")
    private Boolean isDefault;
    private Boolean isPartial;

    private List<Error> errors; // NOSONAR
}
