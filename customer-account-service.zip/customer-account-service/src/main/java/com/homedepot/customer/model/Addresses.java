package com.homedepot.customer.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Created by rxb1809 on Jul 18, 2016
 *
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper=true)
@AllArgsConstructor
@NoArgsConstructor
@JsonRootName("addresses")
public class Addresses extends BaseEntity{
    private List<Address> address; // NOSONAR
}
