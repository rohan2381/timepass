package com.homedepot.customer.model;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Created by TXP1012 on 7/7/17.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonRootName("auth")
public class AuthEntity {
    private String clientAuthToken;
    private Boolean authTokenValid;
    private List<Error> errors;
 }
