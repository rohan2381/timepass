package com.homedepot.customer.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.homedepot.customer.util.BusinessChannel;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Created by rxb1809 on Aug 11, 2016
 *
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode
public abstract class BaseEntity {

    private String status; // NOSONAR
    @JsonIgnore
    private BusinessChannel channel;
    private List<Error> errors; // NOSONAR
}
