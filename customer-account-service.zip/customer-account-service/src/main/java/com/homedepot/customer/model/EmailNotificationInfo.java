package com.homedepot.customer.model;

import com.homedepot.customer.util.EmailType;
import lombok.Data;

@Data
public class EmailNotificationInfo {

    private String oldEmail;
    private String email;
    private EmailType emailType;
    private String firstName;
    private String resetPwdUrl;
}
