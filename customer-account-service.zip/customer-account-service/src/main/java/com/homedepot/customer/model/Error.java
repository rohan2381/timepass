package com.homedepot.customer.model;

import lombok.Data;

/**
 * Created by rxb1809 on Jul 31, 2016
 *
 */
@Data
public class Error {

    private String errorCode;
    private String errorMessage;
    private String resourceId;
    private String developerErrorMessage;
}
