package com.homedepot.customer.model;

import java.util.List;

import com.homedepot.customer.util.Resource;

import lombok.Data;

/**
 * Created by rxb1809 on Jul 31, 2016
 *
 */
@Data
public class Errors {

    private Resource resource;
    private List<Error> errors;
}
