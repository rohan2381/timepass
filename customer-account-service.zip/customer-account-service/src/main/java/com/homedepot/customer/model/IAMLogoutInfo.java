package com.homedepot.customer.model;

import lombok.Data;

@Data
public class IAMLogoutInfo {

    private boolean iamSuccess;
}
