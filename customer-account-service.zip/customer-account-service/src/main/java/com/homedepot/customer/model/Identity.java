package com.homedepot.customer.model;

import java.util.*;

import com.fasterxml.jackson.annotation.*;

import lombok.*;

/**
 * Created by Nitin Ware on 10/5/16.
 */
@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper=true)
@AllArgsConstructor
@NoArgsConstructor
@JsonRootName("identity")
public class Identity extends BaseEntity {

    @JsonIgnore
    private String sessionToken;
    private String svocCustomerAccountId;
    private String wcsMemberId;
    private String logonId;
    private Date emailLastModifiedDate;
    private Date accountLastModifiedDate;
    private List<Error> errors;
    private Boolean sessionValid;
    private String clientAuthToken;
}
