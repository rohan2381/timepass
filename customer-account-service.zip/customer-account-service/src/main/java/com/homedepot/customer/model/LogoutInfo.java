package com.homedepot.customer.model;

import lombok.Data;

@Data
public class LogoutInfo {

    private IAMLogoutInfo iamLogoutInfo;
    private WCSLogoutInfo wcsLogoutInfo;
}
