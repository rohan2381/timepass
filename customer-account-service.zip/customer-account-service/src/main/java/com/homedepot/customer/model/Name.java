package com.homedepot.customer.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Created by rxb1809 on Jun 11, 2016
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Name {

    @ApiModelProperty(required = true, value = "First name of the user")
    private String firstName;

    @ApiModelProperty(required = true, value = "Last name of the user")
    private String lastName;

}
