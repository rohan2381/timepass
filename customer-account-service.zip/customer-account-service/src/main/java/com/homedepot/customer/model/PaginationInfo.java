package com.homedepot.customer.model;

import lombok.Data;

/**
 * Created by axb4725 on 9/8/16.
 */
@Data
public class PaginationInfo {

    private String pageSize;

    private String pageNumber;

    private String totalPages;

    private String totalNumberOfRecords;
}