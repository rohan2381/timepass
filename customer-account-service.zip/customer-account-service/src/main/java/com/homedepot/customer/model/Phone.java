package com.homedepot.customer.model;

import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Created by rxb1809 on Jun 11, 2016
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Phone {

    @ApiModelProperty(value = "required for create/update, empty for delete")
    private String number;

    @ApiModelProperty(value = "phone type", allowableValues = "HOME, MOBILE, WORK, FAX, UNKNOWN (default if not provided)")
    private String type;

    @ApiModelProperty(value = "required for update/delete address phone")
    private Short  id;

    @ApiModelProperty(value = "required for update/delete profile phone")
    private String contactMethodEnumeration;

    @ApiModelProperty(value = "primary phone indicator, upgrading DIY user to pro requires primary phone flag = Y", required = true, allowableValues = "Y, N")
    private String primaryFlag;

    @ApiModelProperty(value = "secondary phone indicator", required = true, allowableValues = "Y, N")
    private String secondaryFlag;

    @ApiModelProperty(value = "required for update/delete(profile phone)")
    private Date lastModifiedDate;
}
