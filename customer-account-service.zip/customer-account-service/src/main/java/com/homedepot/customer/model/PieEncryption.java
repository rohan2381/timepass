package com.homedepot.customer.model;

import lombok.Data;

/**
 * Created by rxb1809 on Jun 11, 2016
 *
 */
@Data
public class PieEncryption {

    private String pieIntegrityCheck;
    private String pieKeyId;
    private String piePhaseBit;
}