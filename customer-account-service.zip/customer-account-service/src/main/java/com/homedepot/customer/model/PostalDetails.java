package com.homedepot.customer.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by rxb1809 on Jun 11, 2016
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PostalDetails {

    @ApiModelProperty(required = true)
    private String addressLine1;

    private String addressLine2;

    @ApiModelProperty(required = true)
    private String city;

    @ApiModelProperty(required = true)
    private String state;

    @ApiModelProperty(required = true)
    private String zipCode;

    @ApiModelProperty(required = true)
    private String country;
}