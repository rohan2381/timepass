package com.homedepot.customer.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by axb4725 on 9/23/16.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Preference {

    @ApiModelProperty(required = true, allowableValues = "GARDEN_CLUB_NEWSLETTER, PROMOTIONS, PRO, HOW_TO_NEWSLETTER, CATALOGS, SPECIAL_BUY_OF_THE_DAY")
    private String code;

    @ApiModelProperty(required = true, allowableValues = "true, false")
    private Boolean isSubscribed;
}
