package com.homedepot.customer.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by axb4725 on 9/23/16.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonRootName("preferences")
public class Preferences extends BaseEntity {
    List<Preference> preference;
}
