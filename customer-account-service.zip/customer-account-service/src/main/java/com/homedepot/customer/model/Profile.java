package com.homedepot.customer.model;

import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Created by rxb1809 on Jun 11, 2016
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString(exclude = {"password", "confirmPassword"})
public class Profile {
    private Name name;

    @ApiModelProperty(required = true)
    private String zipCode;

    @ApiModelProperty(required = true)
    private String emailId;

    @ApiModelProperty(required = true)
    private String emailContactMethodEnumeration;

    private String password;
    private String confirmPassword;
    private String preferredLanguageId;
    private String preferredLanguageDescription;
    private Boolean isContractor;
    private Boolean isTradesman;
    private Boolean isRememberPreferences;
    private String taxExemptId;
    private String taxExemptAttrId;
    private String channelType;
    private String userType;
    private String resetPasswordToken;
    private String goldenRecId;
    private String customerProfType;
    private Boolean receiveSMSNotification;
    private String subscription;

    @ApiModelProperty(value = "required for update")
    private Date lastModifiedDate;

    private String localStoreId;
    private Date localStoreLastModifiedDate;

    private StoreAddress localStoreAddress;

    // for Pro Xtra registration
    private String loyaltyEnrollmentIndicator;

    @ApiModelProperty(value = "required for pro update")
    private String businessName;

    @ApiModelProperty(value = "required for pro update")
    private String tradeType;

    @ApiModelProperty(value = "required if tradeType is OTHER")
    private String otherTradeDescription;

    @ApiModelProperty(value = "required for pro update")
    private Date tradeTypeLastModifiedDate;

    // future svoc fields
    private Integer customerId;
    private String userId;
    private String encryptedTaxId;
    private Integer retryCount;
    private Boolean customerIdentityFlag;
    private Boolean active;

    // pre-merge pro accounts
    private String mergeAcctOpt;
}
