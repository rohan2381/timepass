package com.homedepot.customer.model;

import java.util.*;

import lombok.*;

/**
 * Created by Nitin on 10/25/16.
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ProfilePhones {

    private List<Phone> phone;

}
