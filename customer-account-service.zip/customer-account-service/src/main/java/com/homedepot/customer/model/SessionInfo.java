package com.homedepot.customer.model;


import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@JsonRootName("sessioninfo")
public class SessionInfo extends BaseEntity {

    private String token;
    private boolean sessionValidFlag;
}
