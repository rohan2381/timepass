package com.homedepot.customer.model;

import java.net.*;
import java.nio.charset.*;

import org.apache.commons.lang3.exception.*;

import lombok.*;
import lombok.extern.slf4j.*;

/**
 * Created by nxw6207 on 4/27/17.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class Store {

    private String storeId;

    private String name;

    private String city;

    private String state;

    @Override
    public String toString() {
        String storeIdVal = storeId;
        String storeName = name;
        try {
            storeName = (null != name) ? name.replaceAll(" ", "%20") : name;
            storeIdVal = (null != storeId) ? Integer.valueOf(storeId).toString() : null;
        } catch (Exception ex) {
            log.error("ERROR: Failed to parse C4 Cookie Crumb Value , Root Cause: {}", ExceptionUtils.getRootCauseMessage(ex));
        }
        return storeIdVal + "+" + storeName + " - " + city + ", " + state + "+";
    }

}
