package com.homedepot.customer.model;

import lombok.*;

/**
 * Created by nxw6207 on 4/28/17.
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class StoreAddress {

    private String storeName;

    private String storeNumber;

    private String phoneNumber;

    private StorePostalData postalData;

}
