package com.homedepot.customer.model;

import lombok.*;

/**
 * Created by nxw6207 on 4/28/17.
 */
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class StorePostalData {

    private String address;

    private String city;

    private String stateProvinence;

    private String zipCode;

    private String country;

}
