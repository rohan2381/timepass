package com.homedepot.customer.model;

import lombok.Data;

/**
 * Created by rxb1809 on Oct 8, 2016
 * This pojo contains variables which will be part of the user session cookie
 * It will be set in the cookie as a json string and Base64 encoded
 */
@Data
public class THDUserInfo {
    private String svocCustomerAccountId;
    private String logonId;
}
