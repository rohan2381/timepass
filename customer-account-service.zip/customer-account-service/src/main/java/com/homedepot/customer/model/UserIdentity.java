package com.homedepot.customer.model;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.homedepot.customer.integration.wcs.dto.WCSUserIdentity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by sxp2991 on 08/02/2016.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonRootName("")
public class UserIdentity {

    private String sessionToken;
    private String customerAccountId;
    private String logonId;
    private String originId;
    private Boolean sessionValid;
    private WCSUserIdentity wcsUserIdentity;
    private char isEmailInConflict;
    private String firstName;
}
