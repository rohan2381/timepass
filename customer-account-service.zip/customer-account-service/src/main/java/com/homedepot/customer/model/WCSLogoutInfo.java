package com.homedepot.customer.model;

import lombok.Data;
import lombok.ToString;

import java.util.List;

@Data
@ToString
public class WCSLogoutInfo {

    private List<String> responseCookies;
}
