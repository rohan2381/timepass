package com.homedepot.customer.model;

import lombok.Data;

/**
 * Created by rxb1809 on Oct 3, 2016
 *
 */
@Data
public class XRefInfo {

    private String xrefNbr;
    private String paymtMethCd;
    private String rptPaymtMethCd;
}
