package com.homedepot.customer.model.pvcypreferences;

import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@JsonRootName("privacyPrefRequest")
public class PrivacyPrefRequest {
    
    private UpdateEmail updateEmail;
    private UpdatePhone updatePhone;
    private UpdateMail updateMail;
    
    private String shareInfo;
}
