package com.homedepot.customer.model.pvcypreferences;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class UpdateEmail {
    
    private String emailAddress;
    private String subscribeEmail;

}
