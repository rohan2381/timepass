package com.homedepot.customer.model.pvcypreferences;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class UpdatePhone {
    
    private String phoneNo;
    private String subscribePhone;

}
