package com.homedepot.customer.repository;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.exception.SVOCUnavailableException;
import com.homedepot.customer.model.Address;
import com.homedepot.customer.model.PostalDetails;
import com.homedepot.customer.request.AddressRequest;

/**
 * Created by rxb1809 on Apr 27, 2016
 * Interface for generic CRUD operations on Address
 */
@Repository
public interface IAddressRepository {

    public Map<String,Object> retrieveAll(AddressRequest request, String customerAccountId) throws RepositoryException, SVOCUnavailableException;

    public List<Address> retrieveById(String customerAccountId, List<String> addressIds) throws RepositoryException, SVOCUnavailableException;

    public List<Address> save(String customerAccountId, List<Address> addressesRequest) throws RepositoryException, SVOCUnavailableException;

    public List<Address> update(String customerAccountId, List<Address> address) throws RepositoryException, SVOCUnavailableException;

    public List<Address> deleteById(String customerAccountId, List<Address> modelAddressList) throws RepositoryException, SVOCUnavailableException;

    boolean isCityStateZipValid(PostalDetails postalDetails) throws RepositoryException;

    public List<PostalDetails> getCityStates(String zipCode) throws RepositoryException;
}
