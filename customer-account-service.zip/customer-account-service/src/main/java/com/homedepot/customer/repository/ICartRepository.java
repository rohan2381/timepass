package com.homedepot.customer.repository;

import javax.servlet.http.Cookie;

import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.integration.cart.dto.*;

/**
 * Created by jirapat on 3/31/17.
 */
public interface ICartRepository {
    public CartResponse migrateCart(String userId, Cookie[] cookies) throws RepositoryException;
}
