package com.homedepot.customer.repository;

import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.integration.iam.dto.ChangeEmailResponse;
import com.homedepot.customer.model.IAMLogoutInfo;
import com.homedepot.customer.model.UserIdentity;
import com.homedepot.customer.model.WCSLogoutInfo;
import com.homedepot.customer.request.*;

import javax.servlet.http.Cookie;

import org.springframework.stereotype.Repository;


/**
 * Created by rxb1809 on Apr 27, 2016
 *
 */
@Repository
public interface IIdentityRepository {
    
	public UserIdentity register(String svocId, String emailId, char[] password) throws RepositoryException;
	
	public String authenticate(String emailId, char[] passwd) throws RepositoryException;
	
	public void retrieve() throws RepositoryException;
	
	public ChangeEmailResponse updateEmail(IdentityRequest updateEmailRequest, String customerAccountId, String iamServiceAuthToken) throws RepositoryException;

	public Object updatePassword(IdentityRequest updateEmailRequest, String customerAccountId, String serviceAuthToken) throws
			RepositoryException;

	public Boolean resetPassword(PasswordRequest resetPwdRequest) throws RepositoryException;

	public String getResetPasswordToken(String email) throws RepositoryException;

	public IAMLogoutInfo logout(String authToken) throws RepositoryException;

	public WCSLogoutInfo wcsLogoutUser(String wcsAuthToken) throws RepositoryException;

	public String validateSession(String token) throws RepositoryException;

	public String getSvocId(String token) throws RepositoryException;

	public boolean userExists(String svocId, String serviceAuthToken) throws RepositoryException;

	public String getServiceAuthToken(String userName, String password) throws RepositoryException;
	
	public String validateWCSSession(String token, boolean isAsync, Cookie[] cookies) throws RepositoryException;

	public void changeAccountStatus(String svocId, String serviceAuthToken, String status) throws RepositoryException;

}
