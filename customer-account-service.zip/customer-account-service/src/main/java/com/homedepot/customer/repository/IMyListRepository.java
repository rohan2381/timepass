package com.homedepot.customer.repository;

import java.util.*;

import javax.servlet.http.*;
import com.homedepot.customer.exception.*;
import com.homedepot.customer.integration.mylist.dto.*;

public interface IMyListRepository {
    public MyListResponse migrateMyList(String userId, Cookie[] reqCookies, Cookie[] respCookies) throws RepositoryException;
}
