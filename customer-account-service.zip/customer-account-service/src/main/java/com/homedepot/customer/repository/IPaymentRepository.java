package com.homedepot.customer.repository;

import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.exception.XREFUnavailableException;
import com.homedepot.customer.model.PaymentCard;
import com.homedepot.customer.model.PieEncryption;
import com.homedepot.customer.model.XRefInfo;
import com.homedepot.customer.request.PaymentCardRequest;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * Created by rxb1809 on Apr 27, 2016
 */
@Repository
public interface IPaymentRepository {

    public Map<String, Object> retrieveAll(PaymentCardRequest paymentCardRequest, String customerAccountId)
            throws RepositoryException, XREFUnavailableException;

    public List<PaymentCard> retrieveById(String customerAccountId, List<String> paymentCardIds)
            throws RepositoryException, XREFUnavailableException;

    public PaymentCard save(String customerAccountId, PaymentCard paymentCard) throws RepositoryException, XREFUnavailableException;

    public PaymentCard update(String customerAccountId, PaymentCard paymentCard) throws RepositoryException, XREFUnavailableException;

    public boolean deleteById(String customerAccountId, String paymentId) throws RepositoryException, XREFUnavailableException;

    public XRefInfo retrieveXRefInfo(String pieEncryptedCardNumber, PieEncryption pieEncryptionDetails)
            throws RepositoryException, XREFUnavailableException;

}
