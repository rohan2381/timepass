package com.homedepot.customer.repository;

import org.springframework.stereotype.Repository;

import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.model.Preferences;
import com.homedepot.customer.model.pvcypreferences.PrivacyPrefRequest;

/**
 * Created by axb4725 on 9/26/16.
 */
@Repository
public interface IPreferencesRepository {
    
    public Preferences retrievePreferences(String email) throws RepositoryException;
    
    public Preferences setPreferences(String email, String zipCode, Preferences preferences) throws RepositoryException;
    
    public boolean updatePrivacyPreferences(PrivacyPrefRequest request) throws RepositoryException;
}
