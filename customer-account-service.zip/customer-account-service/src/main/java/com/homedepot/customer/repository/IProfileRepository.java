package com.homedepot.customer.repository;

import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.exception.SVOCUnavailableException;
import com.homedepot.customer.model.Account;
import org.springframework.stereotype.Repository;

/**
 * Created by rxb1809 on Apr 27, 2016
 * Interface for generic CRUD operations on Profile
 */
@Repository
public interface IProfileRepository {

    public Account save(Account account) throws RepositoryException;

    public Account update(String customerAccountId, Account account) throws RepositoryException, SVOCUnavailableException;

    public Account retrieve(String customerAccountId) throws RepositoryException, SVOCUnavailableException;

    public String userExists(String emailId) throws RepositoryException;

    public String duplicateUserExists(String emailId) throws RepositoryException;
    
    public boolean crossRefExists(String customerAccountId) throws RepositoryException;

}
