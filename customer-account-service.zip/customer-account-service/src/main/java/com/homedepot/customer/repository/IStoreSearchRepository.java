package com.homedepot.customer.repository;

import java.util.Optional;

import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.model.Store;

/**
 * Created by jirapat on 10/25/16.
 */
public interface IStoreSearchRepository {

    Optional<Store> findStore(String zipCode) throws RepositoryException;

    Optional<Store> retrieveStoreById(String storeId) throws RepositoryException;

}
