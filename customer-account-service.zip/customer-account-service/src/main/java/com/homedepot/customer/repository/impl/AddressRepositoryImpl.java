package com.homedepot.customer.repository.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.homedepot.customer.datasync.address.AddressFallBackExecutor;
import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.LamdaExceptionWrapper;
import com.homedepot.customer.exception.MapperException;
import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.exception.SVOCUnavailableException;
import com.homedepot.customer.integration.svoc.SVOCAddressServiceFacade;
import com.homedepot.customer.integration.svoc.dto.Content;
import com.homedepot.customer.integration.svoc.dto.RetrieveAddressResponse;
import com.homedepot.customer.integration.taxware.TaxwareServiceFacade;
import com.homedepot.customer.integration.taxware.dto.CityState;
import com.homedepot.customer.integration.taxware.dto.CityStateLookupResponse;
import com.homedepot.customer.mapper.impl.AddressMapperImpl;
import com.homedepot.customer.model.Address;
import com.homedepot.customer.model.Addresses;
import com.homedepot.customer.model.PaginationInfo;
import com.homedepot.customer.model.PostalDetails;
import com.homedepot.customer.repository.IAddressRepository;
import com.homedepot.customer.request.AddressRequest;
import com.homedepot.customer.util.FeatureSwitchUtil;
import com.homedepot.customer.util.GlobalConstants;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Apr 27, 2016
 *
 */
@Repository
@Slf4j
public class AddressRepositoryImpl implements IAddressRepository {

    @Autowired
    SVOCAddressServiceFacade svocAddressFacade;

    @Autowired
    AddressMapperImpl addressMapper;

    @Autowired
    TaxwareServiceFacade taxwareServiceFacade;
    
    @Autowired
    AddressFallBackExecutor addressFallbackExecutor;
    
    @Autowired
    FeatureSwitchUtil featureSwitchUtil;
    
    @Override
    public Map<String, Object> retrieveAll(AddressRequest request, String customerAccountId) throws RepositoryException, SVOCUnavailableException{
        List<Address> addressList = new ArrayList<>();
        HashMap<String, Object> responseData = new HashMap<>();
        try {
            Optional<RetrieveAddressResponse> addressResponseOptional = Optional.of(svocAddressFacade
                    .getCustomerAddress(customerAccountId, null, request.getPaginationInfo().getPageNumber(), request
                            .getPaginationInfo().getPageSize()));
            List<com.homedepot.customer.integration.svoc.dto.Address> svocAddressList = addressResponseOptional
                    .map(RetrieveAddressResponse::getContent).map(Content::getAddress).orElse(new ArrayList<>());

            svocAddressList.forEach(svocAddress -> {
                try {
                    addressList.add(addressMapper.convertDataToModel(svocAddress));
                } catch (MapperException mEx) {
                    throw new LamdaExceptionWrapper(mEx);
                }
            });
            responseData.put("addresses", new Addresses(addressList));
            PaginationInfo pageInfo = new PaginationInfo();
            addressResponseOptional.map(response -> response.getContent()).map(content -> content.getPaginationInfo())
                    .ifPresent(paginationInfo -> BeanUtils.copyProperties(paginationInfo, pageInfo));
            responseData.put("paginationInfo", pageInfo);
        } catch (IntegrationException iEx) {
            if(featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE) && iEx.getHttpStatus().is5xxServerError()){
                throw new SVOCUnavailableException(iEx.getErrors(), iEx.getHttpStatus(), iEx);        
            }
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
        } catch (LamdaExceptionWrapper lEx) {// NOSONAR
            if (lEx.getCause() instanceof MapperException) {
                MapperException mEx = (MapperException) lEx.getCause();
                throw new RepositoryException(mEx.getErrors(), mEx.getHttpStatus(), mEx);
            }
        }

        return responseData;
    }

    @Override
    public List<Address> retrieveById(String customerAccountId, List<String> addressIds) throws RepositoryException, SVOCUnavailableException {
        List<Address> addressList = new ArrayList<>();
        try {
            Optional<RetrieveAddressResponse> addressResponseOptional = Optional.of(svocAddressFacade
                    .getCustomerAddress(customerAccountId, addressIds, null, null));
            List<com.homedepot.customer.integration.svoc.dto.Address> svocAddressList = addressResponseOptional
                    .map(RetrieveAddressResponse::getContent).map(Content::getAddress).orElse(new ArrayList<>());

            svocAddressList.forEach(svocAddress -> {
                try {
                    addressList.add(addressMapper.convertDataToModel(svocAddress));
                } catch (MapperException mEx) {
                    throw new LamdaExceptionWrapper(mEx);
                }
            });
        } catch (IntegrationException iEx) {
            if(featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE) && iEx.getHttpStatus().is5xxServerError()){
                throw new SVOCUnavailableException(iEx.getErrors(), iEx.getHttpStatus(), iEx);        
            }
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
        } catch (LamdaExceptionWrapper lEx) {// NOSONAR
            if (lEx.getCause() instanceof MapperException) {
                MapperException mEx = (MapperException) lEx.getCause();
                throw new RepositoryException(mEx.getErrors(), mEx.getHttpStatus(), mEx);
            }
        }

        return addressList;
    }

    @Override
    public List<Address> save(String customerAccountId, List<Address> addresses) throws RepositoryException, SVOCUnavailableException {
        List<Address> addressList = new ArrayList<>();

        try {
            List<com.homedepot.customer.integration.svoc.dto.Address> addressesDo = new ArrayList<>();
            addresses.stream().forEach(ado -> {
                try {
                    addressesDo.add(addressMapper.convertModelToData(ado));
                } catch (MapperException mEx) {
                    throw new LamdaExceptionWrapper(mEx);
                }
            });

            List<com.homedepot.customer.integration.svoc.dto.Address> svocAddressList = svocAddressFacade
                    .createCustomerAddress(customerAccountId, addressesDo);

            // mapping dto address back to model address
            svocAddressList.forEach(svocAddress -> {
                try {
                    addressList.add(addressMapper.convertDataToModel(svocAddress));
                } catch (MapperException mEx) {
                    throw new LamdaExceptionWrapper(mEx);
                }
            });

        } catch (IntegrationException iEx) {
            if(featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE) && iEx.getHttpStatus().is5xxServerError()){
                throw new SVOCUnavailableException(iEx.getErrors(), iEx.getHttpStatus(), iEx);        
            }
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
        } catch (LamdaExceptionWrapper lEx) {// NOSONAR
            if (lEx.getCause() instanceof MapperException) {
                MapperException mEx = (MapperException) lEx.getCause();
                throw new RepositoryException(mEx.getErrors(), mEx.getHttpStatus(), mEx);
            }
        }

        return addressList;

    }

    @Override
    public List<Address> update(String customerAccountId, List<Address> addresses) throws RepositoryException, SVOCUnavailableException {
        List<Address> addressList = new ArrayList<>();

        try {
            List<com.homedepot.customer.integration.svoc.dto.Address> dataAddressList = new ArrayList<>();
            addresses.stream().forEach(modelAddress -> {
                try {
                    dataAddressList.add(addressMapper.convertModelToData(modelAddress));
                } catch (MapperException mEx) {
                    throw new LamdaExceptionWrapper(mEx);
                }
            });

            List<com.homedepot.customer.integration.svoc.dto.Address> svocAddressList = svocAddressFacade
                    .updateCustomerAddress(customerAccountId, dataAddressList);

            // mapping dto address back to model address
            svocAddressList.forEach(svocAddress -> {
                try {
                    addressList.add(addressMapper.convertDataToModel(svocAddress));
                } catch (MapperException mEx) {
                    throw new LamdaExceptionWrapper(mEx);
                }
            });
        } catch (IntegrationException iEx) {
            if(featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE) && iEx.getHttpStatus().is5xxServerError()){
                throw new SVOCUnavailableException(iEx.getErrors(), iEx.getHttpStatus(), iEx);        
            }
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
        } catch (LamdaExceptionWrapper lEx) {// NOSONAR
            if (lEx.getCause() instanceof MapperException) {
                MapperException mEx = (MapperException) lEx.getCause();
                throw new RepositoryException(mEx.getErrors(), mEx.getHttpStatus(), mEx);
            }
        }

        return addressList;
    }

    @Override
    public List<Address> deleteById(String customerAccountId, List<Address> modelAddressList)
            throws RepositoryException, SVOCUnavailableException {

        try {
            List<com.homedepot.customer.integration.svoc.dto.Address> svocAddressList = new ArrayList<>();

            modelAddressList.forEach(modelAddress -> {
                com.homedepot.customer.integration.svoc.dto.Address svocAddress;
                try {
                    svocAddress = addressMapper.convertModelToData(modelAddress);
                } catch (MapperException mEx) {
                    throw new LamdaExceptionWrapper(mEx);
                }
                // svoc delete endpoint does not need ActionType
                    svocAddress.setActionType(null);
                    svocAddressList.add(svocAddress);
                });
            boolean b = svocAddressFacade.deleteCustomerAddress(customerAccountId, svocAddressList);

            // we only support delete 1 address, interface just takes list of
            // address object
            Address address = modelAddressList.get(0);
            address.setLastModifiedDate(null); // clear timestamp, so it doesn't
                                               // show in response
        } catch (IntegrationException iEx) {
            if(featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE) && iEx.getHttpStatus().is5xxServerError()){
                throw new SVOCUnavailableException(iEx.getErrors(), iEx.getHttpStatus(), iEx);        
            }
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
        } catch (LamdaExceptionWrapper lEx) {// NOSONAR
            if (lEx.getCause() instanceof MapperException) {
                MapperException mEx = (MapperException) lEx.getCause();
                throw new RepositoryException(mEx.getErrors(), mEx.getHttpStatus(), mEx);
            }
        }

        return modelAddressList;
    }

    @Override
    public boolean isCityStateZipValid(PostalDetails postalDetails) throws RepositoryException {
        try {
            return taxwareServiceFacade.isCityStateZipValid(postalDetails);
        } catch (IntegrationException e) {
            throw new RepositoryException(e.getErrors(), e.getHttpStatus(), e);
        }
    }

    @Override
    public List<PostalDetails> getCityStates(String zipCode) throws RepositoryException {
        try {
            CityStateLookupResponse response = taxwareServiceFacade.getCityStates(zipCode);
            return mapResponseToModel(response);
        }
        catch (IntegrationException e) {
            throw new RepositoryException(e.getErrors(), e.getHttpStatus(), e);
        }
    }

    private List<PostalDetails> mapResponseToModel(CityStateLookupResponse response) {
        log.debug("mapping CityStateLookupResponse: {}: ", response);
        List<PostalDetails> postalDetailsList = new ArrayList<>();
        Optional<List<CityState>> optCityStateList = Optional.ofNullable(response.getCityStateList());

        optCityStateList.ifPresent(cityStates -> 
            cityStates.forEach(cityState -> {
                PostalDetails postalDetails = new PostalDetails();
                postalDetails.setCity(cityState.getCity());
                postalDetails.setState(cityState.getStateCode());
                postalDetailsList.add(postalDetails);
            }));

        return postalDetailsList;
    }
}
