package com.homedepot.customer.repository.impl;

import javax.servlet.http.Cookie;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.integration.cart.CartServiceFacade;
import com.homedepot.customer.integration.cart.dto.*;
import com.homedepot.customer.repository.ICartRepository;

/**
 * Created by jirapat on 3/31/17.
 */
@Repository
public class CartRepositoryImpl implements ICartRepository {
    @Autowired
    CartServiceFacade cartServiceFacade;

    @Override
    public CartResponse migrateCart(String userId, Cookie[] cookies) throws RepositoryException {
        try {
            return cartServiceFacade.migrateCart(userId, cookies);
        }
        catch (IntegrationException e) {
            throw new RepositoryException(e.getErrors(), e.getHttpStatus(), e);
        }
    }
}
