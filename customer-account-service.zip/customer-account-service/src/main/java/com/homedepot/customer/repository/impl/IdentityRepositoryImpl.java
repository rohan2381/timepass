package com.homedepot.customer.repository.impl;

import java.util.*;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.integration.iam.IamServicesFacade;
import com.homedepot.customer.integration.iam.dto.*;
import com.homedepot.customer.integration.wcs.WCSProfileServiceFacade;
import com.homedepot.customer.integration.wcs.dto.ValidateTokenResponse;
import com.homedepot.customer.integration.wcs.dto.WCSLogoutResponse;
import com.homedepot.customer.mapper.impl.IdentityMapperImpl;
import com.homedepot.customer.model.IAMLogoutInfo;
import com.homedepot.customer.model.UserIdentity;
import com.homedepot.customer.model.WCSLogoutInfo;
import com.homedepot.customer.repository.IIdentityRepository;
import com.homedepot.customer.request.*;
import com.homedepot.customer.util.GlobalConstants;

import javax.servlet.http.Cookie;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


/**
 * Created by rxb1809 on Apr 27, 2016
 */
@Repository
public class IdentityRepositoryImpl implements IIdentityRepository {

    @Autowired
    IamServicesFacade iamFacade;
    
    @Autowired
    WCSProfileServiceFacade wcsProfileFacade;

    @Autowired
    IdentityMapperImpl identityMapper;

    @Autowired
    CustomerAccountRequestContext requestContext;

    private static final String DEFAULT_CN = "1";
    private static final String DEFAULT_SN = "1";

    @Override
    public String authenticate(String emailId, char[] passwd) throws RepositoryException{
        try {
            return iamFacade.authenticateUser(emailId, passwd);
        } catch(IntegrationException iEx){
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(),iEx);
        }
    }

    @Override
    public UserIdentity register(String svocId, String emailId, char[] password) throws RepositoryException {
        RegistrationData data = new RegistrationData();
        data.setUsername(svocId);
        data.setMail(emailId);
        data.setUserPassword(password);
        data.setCn(DEFAULT_CN);
        data.setSn(DEFAULT_SN);
        RegistrationInput input = new RegistrationInput();
        input.setUser(data);
        RegistrationRequest request = new RegistrationRequest();
        request.setInput(input);
        String token;
        try {
            token = iamFacade.registerUser(request);
        } catch(IntegrationException iEx){
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
        }
        UserIdentity userIdentity = new UserIdentity();
        userIdentity.setSessionToken(token);
        userIdentity.setCustomerAccountId(svocId);
        userIdentity.setLogonId(emailId);
        return userIdentity;
    }

    @Override
    public void retrieve() throws RepositoryException {

    }

    @Override
    public ChangeEmailResponse updateEmail(IdentityRequest updateEmailRequest, String customerAccountId, String iamServiceAuthToken) throws
            RepositoryException {
        ChangeEmailResponse changeEmailResponse;
        try {
            ChangeEmailRequest changeEmailRequest = new ChangeEmailRequest();
            changeEmailRequest.setMail(updateEmailRequest.getNewLogonId());
            changeEmailResponse = iamFacade.changeEmail(changeEmailRequest, iamServiceAuthToken, customerAccountId);
        } catch (IntegrationException iEx) {
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
        }
        return changeEmailResponse;
    }

    @Override
    public Object updatePassword(IdentityRequest passwordRequest, String customerAccountId, String serviceAuthToken) throws
            RepositoryException {
        Object changePasswordResponse = null;
        try {
            ChangePasswordRequest changePasswordRequest = new ChangePasswordRequest();
            changePasswordRequest.setUserpassword(passwordRequest.getNewPassword());
            changePasswordResponse = iamFacade.changePassword(changePasswordRequest, serviceAuthToken, customerAccountId);
        } catch (IntegrationException iEx) {
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
        }
        return changePasswordResponse;
    }

    @Override
    public Boolean resetPassword(PasswordRequest resetPwdRequest) throws RepositoryException {
        ResetPasswordResponse resetPwdResp = null;
        try {
            ResetPasswordRequest resetPasswordRequest = new ResetPasswordRequest();
            ResetPasswordInput resetPasswordInput = new ResetPasswordInput();
            resetPasswordInput.setPassword(resetPwdRequest.getPassword());
            resetPasswordRequest.setToken(resetPwdRequest.getToken());
            resetPasswordRequest.setInput(resetPasswordInput);
            resetPwdResp = iamFacade.resetPassword(resetPasswordRequest);
        } catch (IntegrationException iEx) {
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
        }
        return Optional.ofNullable(resetPwdResp)
                .map(ResetPasswordResponse::getStatus)
                .map(ResetPasswordStatus::isSuccess)
                .orElse(null);
    }

    @Override
    public String getResetPasswordToken(String email) throws RepositoryException {
        ResetPasswordResponse resetPwdResp = null;
        try {
            ResetPasswordRequest resetPasswordRequest = new ResetPasswordRequest();
            ResetPasswordInput resetPasswordInput = new ResetPasswordInput();
            resetPasswordInput.setQueryFilter("mail eq \"" + email +"\"");
            resetPasswordRequest.setInput(resetPasswordInput);
            resetPwdResp = iamFacade.resetPassword(resetPasswordRequest);
        } catch (IntegrationException iEx) {
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
        }
        return Optional.ofNullable(resetPwdResp).map(ResetPasswordResponse::getToken).orElse(null);
    }

    @Override
    public IAMLogoutInfo logout(String authToken) throws RepositoryException {

        IAMLogoutInfo iamLogoutInfo = new IAMLogoutInfo();
        try {
            String resp = iamFacade.signOutUser(authToken);
            iamLogoutInfo.setIamSuccess(StringUtils.isNotBlank(resp));
        } catch(IntegrationException iEx){
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(),iEx);
        }
        return iamLogoutInfo;
    }

    @Override
    public WCSLogoutInfo wcsLogoutUser(String wcsAuthToken) throws RepositoryException {

        WCSLogoutInfo wcsLogoutInfo;
        try {
            WCSLogoutResponse logoutResponse = wcsProfileFacade.logoutUser(wcsAuthToken);
            wcsLogoutInfo = new WCSLogoutInfo();
            wcsLogoutInfo.setResponseCookies(logoutResponse.getResponseCookies());
        } catch (IntegrationException iEx) {
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
        }
        return wcsLogoutInfo;
    }

    @Override
    public String validateSession(String token) throws RepositoryException {

        String svocCustomerAccountId = null;
        try {
            IAMResponse resp = iamFacade.validateUserSession(token);
            if(resp!=null && resp.getSessionValid()){
                svocCustomerAccountId = resp.getUid();
            }
        } catch (IntegrationException iEx) {
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
        }
        return svocCustomerAccountId;
    }

    @Override
    public String getSvocId(String token) throws RepositoryException {

        String svocId;
        try {
            svocId = iamFacade.getSvocIdFromSession(token);
        } catch (IntegrationException iEx) {
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
        }
        return svocId;
    }

    @Override
    public boolean userExists(String svocId, String serviceAuthToken) throws RepositoryException {

        boolean exists;
        try {
            exists = iamFacade.userExists(svocId, serviceAuthToken);
        } catch (IntegrationException iEx) {
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
        }
        return exists;
    }

    @Override
    public String getServiceAuthToken(String userName, String password) throws RepositoryException {

        String serviceToken;
        try {
            serviceToken = iamFacade.getServiceAuthToken(userName, password);
        } catch (IntegrationException iEx) {
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
        }
        return serviceToken;
    }
    
    @Override
    public String validateWCSSession(String token, boolean isAsync, Cookie[] cookies) throws RepositoryException {

        String wcsMemberId = null;
        try {
            ValidateTokenResponse resp = wcsProfileFacade.validateUserToken(token, isAsync, cookies);
            if(resp!=null && GlobalConstants.WCS_REGISTERED_USER_TYPE.equalsIgnoreCase(resp.getRegisterType())){
                wcsMemberId = resp.getMemberId();
            }
        } catch (IntegrationException iEx) {
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
        }
        return wcsMemberId;
    }

    @Override
    public void changeAccountStatus(String svocId, String serviceAuthToken, String status) throws RepositoryException {
        try {
            AccountLockRequest accountLockRequest = new AccountLockRequest();
            accountLockRequest.setInetuserstatus(status);
            iamFacade.accountLock(accountLockRequest, serviceAuthToken, svocId);
        } catch (IntegrationException iEx) {
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
        }
    }

}
