package com.homedepot.customer.repository.impl;

import javax.servlet.http.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import com.homedepot.customer.exception.*;
import com.homedepot.customer.integration.mylist.*;
import com.homedepot.customer.integration.mylist.dto.*;
import com.homedepot.customer.repository.*;

@Repository
public class MyListRepository implements IMyListRepository {

    @Autowired
    MyListServiceFacade myListServiceFacade;

    @Override
    public MyListResponse migrateMyList(String userId, Cookie[] reqCookies, Cookie[] respCookies) throws RepositoryException {
        try {
            return myListServiceFacade.migrateMyList(userId, reqCookies, respCookies);
        }
        catch (IntegrationException e) {
            throw new RepositoryException(e.getErrors(), e.getHttpStatus(), e);
        }
    }

}
