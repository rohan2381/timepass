package com.homedepot.customer.repository.impl;

import com.homedepot.customer.exception.*;
import com.homedepot.customer.integration.payment.BeehiveServiceFacade;
import com.homedepot.customer.integration.payment.PaymentServiceFacade;
import com.homedepot.customer.integration.payment.dto.PaymentOption;
import com.homedepot.customer.integration.payment.dto.PaymentOptions;
import com.homedepot.customer.integration.payment.dto.beehive.BinInfoData;
import com.homedepot.customer.mapper.impl.PaymentMapperImpl;
import com.homedepot.customer.model.PaymentCard;
import com.homedepot.customer.model.PieEncryption;
import com.homedepot.customer.model.XRefInfo;
import com.homedepot.customer.repository.IPaymentRepository;
import com.homedepot.customer.request.PaymentCardRequest;
import com.homedepot.customer.util.FeatureSwitchUtil;
import com.homedepot.customer.util.GlobalConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.*;

/**
 * Created by rxb1809 on Apr 27, 2016
 */
@Repository
@Slf4j
public class PaymentRepositoryImpl implements IPaymentRepository {

    @Autowired
    PaymentServiceFacade paymentFacade;

    @Autowired
    PaymentMapperImpl paymentMapper;
    
    @Autowired
    BeehiveServiceFacade beehiveFacade;

    @Autowired
    FeatureSwitchUtil featureSwitchUtil;

    @Override
    public Map<String, Object> retrieveAll(PaymentCardRequest paymentCardRequest, String customerAccountId)
            throws RepositoryException, XREFUnavailableException {
        HashMap<String,Object> responseData = new HashMap<>();

    	List<PaymentCard> paymentCards = new ArrayList<>();
        try {
            PaymentOptions paymentResponseDto =
                    paymentFacade.getAllPaymentCards(customerAccountId,
                            paymentCardRequest.getPaginationInfo().getPageNumber(),
                            paymentCardRequest.getPaginationInfo().getPageSize(),
                            paymentCardRequest.getSortType());
            paymentResponseDto.getPaymentOptions().forEach(paymentOption -> {
            	try {
					paymentCards.add(paymentMapper.convertDataToModel(paymentOption));
				} catch(MapperException mEx){
                    throw new LamdaExceptionWrapper(mEx);
                }
            });
            responseData.put("paymentCards",paymentCards);
            responseData.put("paginationInfo", paymentMapper.convertPaginationDataToModel(paymentResponseDto));
        } catch (IntegrationException iEx) {
            if(featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE) && iEx.getHttpStatus().is5xxServerError()){
                throw new XREFUnavailableException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
            }
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
        } catch (LamdaExceptionWrapper lEx) {// NOSONAR
            if (lEx.getCause() instanceof MapperException) {
                MapperException mEx = (MapperException) lEx.getCause();
                throw new RepositoryException(mEx.getErrors(), mEx.getHttpStatus(), mEx);
            }
        }
        return responseData;
    }

    @Override
    public List<PaymentCard> retrieveById(String customerAccountId, List<String> paymentCardIds) throws RepositoryException, XREFUnavailableException {
        PaymentCard paymentCard = null;
        try {
            PaymentOption paymentOption = paymentFacade.getUniquePaymentCard(customerAccountId, paymentCardIds.get(0));
            try {
                paymentCard = paymentMapper.convertDataToModel(paymentOption);
            } catch (MapperException mEx) {
                throw new LamdaExceptionWrapper(mEx);
            }
        } catch (IntegrationException iExp) {
            if(featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE) && iExp.getHttpStatus().is5xxServerError()){
                throw new XREFUnavailableException(iExp.getErrors(), iExp.getHttpStatus(), iExp);
            }
            throw new RepositoryException(iExp.getErrors(), iExp.getHttpStatus(), iExp);
        }  catch (LamdaExceptionWrapper lEx) {// NOSONAR
            if (lEx.getCause() instanceof MapperException) {
                MapperException mEx = (MapperException) lEx.getCause();
                throw new RepositoryException(mEx.getErrors(), mEx.getHttpStatus(), mEx);
            }
        }
        return Collections.singletonList(paymentCard);
    }

    @Override
    public PaymentCard save(String customerAccountId, PaymentCard paymentCard) throws RepositoryException, XREFUnavailableException {

        log.debug("Start save() method with customerAccountId: {}", customerAccountId);
        PaymentCard xRefPaymentCard = null;
        try {
            try {
                PaymentOption paymentOptionReq = paymentMapper.convertModelToData(paymentCard);
                PaymentOption paymentOptionRes = paymentFacade.createPaymentCard(customerAccountId, paymentOptionReq);
                xRefPaymentCard = paymentMapper.convertDataToModel(paymentOptionRes);
            } catch (MapperException mEx) {
                throw new LamdaExceptionWrapper(mEx);
            }
        } catch (IntegrationException iExp) {
            if(featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE) && iExp.getHttpStatus().is5xxServerError()){
                throw new XREFUnavailableException(iExp.getErrors(), iExp.getHttpStatus(), iExp);
            }
            throw new RepositoryException(iExp.getErrors(), iExp.getHttpStatus(), iExp);
        }  catch (LamdaExceptionWrapper lEx) {// NOSONAR
            if (lEx.getCause() instanceof MapperException) {
                MapperException mEx = (MapperException) lEx.getCause();
                throw new RepositoryException(mEx.getErrors(), mEx.getHttpStatus(), mEx);
            }
        }
        return xRefPaymentCard;
    }

    @Override
    public PaymentCard update(String customerAccountId, PaymentCard paymentCard) throws RepositoryException, XREFUnavailableException {

        log.debug("Start update() method with customerAccountId: {} and paymentId : {} ", customerAccountId,
                paymentCard.getPaymentId());
        PaymentCard paymentCardResponse = null;
        try {
            try {
                PaymentOption paymentOptionReq = paymentMapper.convertModelToData(paymentCard);
                PaymentOption paymentOptionRes = paymentFacade.updatePaymentCard(customerAccountId, paymentOptionReq);

                paymentCardResponse = paymentMapper.convertDataToModel(paymentOptionRes);
            } catch (MapperException mEx) {
                throw new LamdaExceptionWrapper(mEx);
            }
            log.debug("End update() method with customerAccountId: {} and paymentId : {} ", customerAccountId,
                    paymentCard.getPaymentId());
        } catch (IntegrationException iExp) {
            if(featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE) && iExp.getHttpStatus().is5xxServerError()){
                throw new XREFUnavailableException(iExp.getErrors(), iExp.getHttpStatus(), iExp);
            }
            throw new RepositoryException(iExp.getErrors(), iExp.getHttpStatus(), iExp);
        }  catch (LamdaExceptionWrapper lEx) {// NOSONAR
            if (lEx.getCause() instanceof MapperException) {
                MapperException mEx = (MapperException) lEx.getCause();
                throw new RepositoryException(mEx.getErrors(), mEx.getHttpStatus(), mEx);
            }
        }
        return paymentCardResponse;
    }

    @Override
    public boolean deleteById(String customerAccountId, String paymentId) throws RepositoryException, XREFUnavailableException {
        log.debug("Start PaymentRepositoryImpl.deleteById, delete paymentcard, customerAccountId: {}, paymentId: {}",
                																		customerAccountId, paymentId);

        PaymentCard paymentCard = new PaymentCard();
        paymentCard.setPaymentId(paymentId);
        boolean flag;

        try {
            flag = paymentFacade.deletePaymentCard(customerAccountId, paymentId);
            return flag;
        }
        catch (IntegrationException iExp) {
            if(featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE) && iExp.getHttpStatus().is5xxServerError()){
                throw new XREFUnavailableException(iExp.getErrors(), iExp.getHttpStatus(), iExp);
            }
            throw new RepositoryException(iExp.getErrors(), iExp.getHttpStatus(), iExp);
        }
    }

    
    /**
     * This method retrieves the xRef number for a given voltage(pie) encrypted card number
     */
    @Override
    public XRefInfo retrieveXRefInfo(String pieEncryptedCardNumber, PieEncryption pieEncryptionDetails) throws RepositoryException, XREFUnavailableException{
        XRefInfo xRefInfo = new XRefInfo();
        try{
            BinInfoData binInfoData = beehiveFacade.getXRefDetails(pieEncryptedCardNumber, pieEncryptionDetails.getPieIntegrityCheck(), 
                    pieEncryptionDetails.getPieKeyId(),pieEncryptionDetails.getPiePhaseBit());
    
            Optional.ofNullable(binInfoData).ifPresent(binInfo -> BeanUtils.copyProperties(binInfo, xRefInfo));
        }catch(IntegrationException iExp){
            if(featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE) && iExp.getHttpStatus().is5xxServerError()){
                throw new XREFUnavailableException(iExp.getErrors(), iExp.getHttpStatus(), iExp);
            }
            throw new RepositoryException(iExp.getErrors(), iExp.getHttpStatus(), iExp);
        }

        return xRefInfo;
    }

}
