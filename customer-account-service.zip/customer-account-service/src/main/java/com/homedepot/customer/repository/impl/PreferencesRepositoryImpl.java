package com.homedepot.customer.repository.impl;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.MapperException;
import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.integration.acxiom.AcxiomServicesFacade;
import com.homedepot.customer.integration.acxiom.dto.Channel;
import com.homedepot.customer.integration.acxiom.dto.ChannelResponse;
import com.homedepot.customer.integration.acxiom.dto.LOB;
import com.homedepot.customer.integration.acxiom.dto.LOBResponse;
import com.homedepot.customer.integration.acxiom.dto.ReadPreferenceResponse;
import com.homedepot.customer.integration.acxiom.dto.Response;
import com.homedepot.customer.integration.acxiom.dto.preferences.UpdateAllRequest;
import com.homedepot.customer.mapper.impl.PvcyPrefMapperImpl;
import com.homedepot.customer.model.Preference;
import com.homedepot.customer.model.Preferences;
import com.homedepot.customer.model.pvcypreferences.PrivacyPrefRequest;
import com.homedepot.customer.repository.IPreferencesRepository;
import com.homedepot.customer.util.GlobalConstants;


/**
 * Created by axb4725 on 9/26/16.
 */
@Service
@Slf4j
public class PreferencesRepositoryImpl implements IPreferencesRepository {

    public static final BigInteger SUBSCRIPTION_ON = new BigInteger("1");
    public static final BigInteger SUBSCRIPTION_OFF = new BigInteger("0");
    public static final String LOB_NAME_HD = "HD";
    public static final String CHANNEL_NAME_EMAIL = "Email";

    @Autowired
    PvcyPrefMapperImpl PvcyPrefMapperImpl;
    
    @Autowired
    AcxiomServicesFacade acxiomServicesFacade;

    @Override
    public Preferences retrievePreferences(String email) throws RepositoryException {
        try {
            Optional<ReadPreferenceResponse> responseAcxiom = Optional.of(acxiomServicesFacade.readPreference(email));

        Preferences response = new Preferences();
        List<Preference> preferenceList = new ArrayList<>();

        responseAcxiom.map(res->res.getPrivacyData()).map(pri->pri.getLob())
                                                    .flatMap(lobResponsetoChannelFunction)
                                                    .map(channelResponse -> channelResponse.getPrivacy())
                                                    .ifPresent(privacies -> privacies.stream().forEach(p->{
                                                        Preference s = new Preference();
                                                        s.setIsSubscribed(StringUtils.equals(p.getValue(), "1"));
                                                        s.setCode(p.getName());
                                                        preferenceList.add(s);
                                                    }));

        response.setPreference(preferenceList);
        return response;
        }
        catch (IntegrationException iEx){
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(),iEx);

        }
    }
    
    Function<List<LOBResponse>,Optional<ChannelResponse>> lobResponsetoChannelFunction = lobResponseList-> lobResponseList.stream()
                                                                                                    .filter(l-> StringUtils.equals(l.getName(), LOB_NAME_HD))
                                                                                                    .limit(1).map(hdLob->hdLob.getChannel())
                                                                                                    .flatMap(channelResponses -> channelResponses.stream())
                                                                                                    .filter(chlist-> StringUtils.equals(chlist.getName(), CHANNEL_NAME_EMAIL))
                                                                                                    .findAny();

    @Override
    public Preferences setPreferences(String email, String zipCode, Preferences preferences) throws RepositoryException {
        com.homedepot.customer.integration.acxiom.dto.Preference preference = mapUpdateModelToData(preferences);
        try {
            Response response = acxiomServicesFacade.setPreferences(email, zipCode, preference);

            return mapUpdateDataToModel(response);
        }
        catch (IntegrationException e) {
            throw new RepositoryException(e.getErrors(), e.getHttpStatus(), e);
        }
    }
    
    @Override
    public boolean updatePrivacyPreferences(PrivacyPrefRequest request) throws RepositoryException {
        try {
            UpdateAllRequest acxiomRequest = PvcyPrefMapperImpl.convertModelToData(request);
            
            return acxiomServicesFacade.updatePrivacyPreferences(acxiomRequest);
        } catch (IntegrationException iEx) {
            throw new RepositoryException(iEx.getErrors(), iEx.getHttpStatus(), iEx);
        
        } catch (MapperException mEx) {
            throw new RepositoryException(mEx.getErrors(), mEx.getHttpStatus(), mEx);
        }
    }

    /**
     * Create Preference DTO structure in here and populate the subscriptions
     * Other values will be populated in AcxiomServiceFacade
     * @param preferences
     * @return
     */
    private com.homedepot.customer.integration.acxiom.dto.Preference mapUpdateModelToData(Preferences preferences) {
        log.debug("in mapUpdateModelToData()");
        com.homedepot.customer.integration.acxiom.dto.Preference preference = new com.homedepot.customer.integration.acxiom.dto.Preference();
        Channel channel = new Channel();
        LOB lob = new LOB();
        lob.getChannels().add(channel);
        preference.getLobs().add(lob);

        Optional<Preferences> optPreferences = Optional.of(preferences);
        optPreferences.map(Preferences::getPreference)
                .ifPresent(preferenceList -> preferenceList.forEach(modelPreference -> {
                    com.homedepot.customer.integration.acxiom.dto.Subscription acxiomSubscription = new com.homedepot.customer.integration.acxiom.dto.Subscription();
                    acxiomSubscription.setName(modelPreference.getCode());
                    acxiomSubscription.setValue(modelPreference.getIsSubscribed() ? SUBSCRIPTION_ON : SUBSCRIPTION_OFF);
                    channel.getSubscriptions().add(acxiomSubscription);
                }));

        return preference;
    }
    
    private Preferences mapUpdateDataToModel(Response response) {
        Preferences preferences = new Preferences();
        if (response.getResultCode() == 100) {
            preferences.setStatus(GlobalConstants.REQUEST_STATUS_SUCCESS);
        }

        return preferences;
    }
}
