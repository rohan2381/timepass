package com.homedepot.customer.repository.impl;

import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.MapperException;
import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.exception.SVOCUnavailableException;
import com.homedepot.customer.integration.svoc.SVOCProfileServiceFacade;
import com.homedepot.customer.integration.svoc.dto.*;
import com.homedepot.customer.integration.wcs.WCSCrossRefServiceFacade;
import com.homedepot.customer.integration.wcs.dto.crossref.CrossRefInfo;
import com.homedepot.customer.mapper.impl.ProfileMapperImpl;
import com.homedepot.customer.model.Account;
import com.homedepot.customer.repository.IProfileRepository;
import com.homedepot.customer.util.FeatureSwitchUtil;
import com.homedepot.customer.util.GlobalConstants;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Created by rxb1809 on Apr 27, 2016
 *
 */
@Repository
@Slf4j
public class ProfileRepositoryImpl implements IProfileRepository{

    @Autowired
    SVOCProfileServiceFacade svocProfileServiceFacade;

    @Autowired
    ProfileMapperImpl profileMapper;
    
    @Autowired
    FeatureSwitchUtil featureSwitchUtil;
    
    @Autowired
    WCSCrossRefServiceFacade crossRefFacade;

    /* (non-Javadoc)
     * @see com.homedepot.customer.repository.IProfileRepository#save()
     */
    @Override
    public Account save(Account account) throws RepositoryException{
        log.debug("creating a new account");
        try {
            Customer customerReq = profileMapper.convertModelToData(account);

            Customer customerResp = svocProfileServiceFacade.createCustomer(customerReq);

            Account accountResp = profileMapper.convertDataToModel(customerResp);

            return accountResp;
        }
        catch (IntegrationException | MapperException e) {
            throw new RepositoryException(e.getErrors(), e.getHttpStatus(), e);
        }
    }

    /* (non-Javadoc)
     * @see com.homedepot.customer.repository.IProfileRepository#update()
     */
    @Override
    public Account update(String customerAccountId, Account account) throws RepositoryException, SVOCUnavailableException{
        Customer customerReq = null;
        try {
            customerReq = profileMapper.convertModelToData(account);
            Customer customerResp = svocProfileServiceFacade.updateCustomer(customerReq);
            Account accountResp = profileMapper.convertDataToModel(customerResp);
            accountResp.setIsReqServedFromWCS(false);
            return accountResp;
        }
        catch (IntegrationException | MapperException e) {
            if(featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE) && e.getHttpStatus().is5xxServerError() && StringUtils.isEmpty(account.getProfile().getTradeType())){// dont do fallback for pro upgrade
                throw new SVOCUnavailableException(e.getErrors(), e.getHttpStatus(), e);
            }
            throw new RepositoryException(e.getErrors(), e.getHttpStatus(), e);
        }
    }

    /* (non-Javadoc)
     * @see com.homedepot.customer.repository.IProfileRepository#retrieve()
     */
    @Override
    public Account retrieve(String customerAccountId) throws RepositoryException,SVOCUnavailableException {
        try {
            List<Customer> customerList = svocProfileServiceFacade.retrieveCustomer(customerAccountId);

            Account account = new Account();
            if (customerList != null && !customerList.isEmpty()) {
                account = profileMapper.convertDataToModel(customerList.get(0));
            }
            account.setIsReqServedFromWCS(false);

            return account;
        }
        catch (IntegrationException | MapperException e) {
            if(featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE) && e.getHttpStatus().is5xxServerError()){
                throw new SVOCUnavailableException(e.getErrors(), e.getHttpStatus(), e);
            }
            throw new RepositoryException(e.getErrors(), e.getHttpStatus(), e);
        }

    }

    @Override
    public String userExists(String emailId) throws RepositoryException {

        CustomerExistenceResponse response;
        CustomerExistenceByEmailRequest request = new CustomerExistenceByEmailRequest();
        request.setEmailAddress(emailId);
        try {
            response = svocProfileServiceFacade.userExists(request);
        } catch (IntegrationException e) {
            throw new RepositoryException(e.getErrors(), e.getHttpStatus(), e);
        }
        return Optional.ofNullable(response.getContent()).flatMap(c -> c.getCustomerAccountId()
                                                                        .stream()
                                                                        .filter(e -> e != null)
                                                                        .findFirst())
                                                         .orElse(null);
    }

    @Override
    public String duplicateUserExists(String emailId) throws RepositoryException {

        CustomerDuplicateEmailCheckResponse response;
        CustomerDuplicateEmailCheckRequest request = new CustomerDuplicateEmailCheckRequest();
        request.setEmailAddress(emailId);
        try {
            response = svocProfileServiceFacade.duplicateUserExists(request);
        } catch (IntegrationException e) {
            throw new RepositoryException(e.getErrors(), e.getHttpStatus(), e);
        }
        return response.getContent() == null ? GlobalConstants.STR_N : GlobalConstants.STR_Y;
    }


    @Override
    public boolean crossRefExists(String customerAccountId) throws RepositoryException {
        boolean crossRefExists = false;
        try {
            CrossRefInfo crossRefInfo = crossRefFacade.getCrossRefInfoForSVOCCustAcctId(customerAccountId);
            if(crossRefInfo!=null && crossRefInfo.getWcsMemberId()!=null){
                crossRefExists = true;
            }
        } catch (IntegrationException iEx) {
            log.error("Could not find corresponding Wcs Member id for SVOC Id "+customerAccountId + " "+iEx);           
        }
        
        return crossRefExists;
    }

}
