package com.homedepot.customer.repository.impl;

import java.util.Optional;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.integration.storesearch.StoreSearchServiceFacade;
import com.homedepot.customer.mapper.impl.StoreMapperImpl;
import com.homedepot.customer.model.Store;
import com.homedepot.customer.repository.IStoreSearchRepository;

/**
 * Created by jirapat on 10/25/16.
 */
@Repository
@Slf4j
public class StoreSearchRepositoryImpl implements IStoreSearchRepository {

    @Autowired
    StoreSearchServiceFacade storeSearchServiceFacade;

    @Autowired
    StoreMapperImpl storeMapper;

    @Override
    public Optional<Store> findStore(String zipCode) {
        Optional<Store> modelStoreOptional = Optional.empty();

        try {
            Optional<com.homedepot.customer.integration.storesearch.dto.Store> dtoStoreOptional = storeSearchServiceFacade.findStore(zipCode);

            if (dtoStoreOptional.isPresent()) {
                Store modelStore = storeMapper.convertDataToModel(dtoStoreOptional.get());
                modelStoreOptional = Optional.ofNullable(modelStore);
            }
        }
        catch (Exception e) {
            log.error("Error retrieving local store number from store search API "+ExceptionUtils.getRootCauseMessage(e));
        }

        return modelStoreOptional;
    }

    @Override
    public Optional<Store> retrieveStoreById(String storeId) throws RepositoryException {
        Optional<Store> modelStoreOptional = Optional.empty();

        try {
            Optional<com.homedepot.customer.integration.storesearch.dto.Store> dtoStoreOptional = storeSearchServiceFacade.retrieveStoreById(storeId);
            if (dtoStoreOptional.isPresent()) {
                Store modelStore = storeMapper.convertDataToModel(dtoStoreOptional.get());
                modelStoreOptional = Optional.ofNullable(modelStore);
            }
        }
        catch (Exception e) {
            log.error("Error retrieving local for id " + storeId + " from store search API " + ExceptionUtils.getRootCauseMessage(e));
        }

        return modelStoreOptional;
    }
}
