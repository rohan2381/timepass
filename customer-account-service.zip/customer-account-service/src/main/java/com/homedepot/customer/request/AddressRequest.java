package com.homedepot.customer.request;

import com.fasterxml.jackson.annotation.JsonRootName;
import com.homedepot.customer.model.Address;
import com.homedepot.customer.model.PaginationInfo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Created by rxb1809 on Jun 11, 2016
 *
 */
@Data
@NoArgsConstructor
@JsonRootName("addresses")
public class AddressRequest {

    @ApiModelProperty(value = "list of addresses to be created/updated", required = true)
    private List<Address> address;

    private PaginationInfo paginationInfo;


}
