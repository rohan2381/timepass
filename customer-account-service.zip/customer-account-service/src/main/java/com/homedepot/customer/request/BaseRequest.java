package com.homedepot.customer.request;

/**
 * Created by rxb1809 on Jun 22, 2016
 *
 */
public abstract class BaseRequest {

}
