package com.homedepot.customer.request;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by txp1012 on 6/16/17.
 */
@NoArgsConstructor
@Data
public class ClientAuthRequest {

    private String clientAuthToken;
    private String timestamp;
    private String clientId;
    private String clientDelayForTokenValidation;
}