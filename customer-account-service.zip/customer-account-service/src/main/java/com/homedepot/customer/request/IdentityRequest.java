package com.homedepot.customer.request;

import com.fasterxml.jackson.annotation.JsonRootName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

/**
 * Created by sxp2991 on Aug 1, 2016
 *
 */
@Data
@NoArgsConstructor
@JsonRootName("identity")
@ToString(exclude={"password", "newPassword"})
public class IdentityRequest {

    @ApiModelProperty(required = true, value = "User login id(email id)")
    String logonId;
    @ApiModelProperty(required = true, value = "User login password")
    char[] password;
    @ApiModelProperty(value = "Required for an email update")
    String newLogonId;
    @ApiModelProperty(value = "Required for a password update")
    char[] newPassword;
    @ApiModelProperty(value = "Required for an email update")
    Date emailLastModifiedDate;
    private String loyaltyEnrollmentIndicator;
    @ApiModelProperty(value = "Required for email and/or password update")
    String firstName;
}
