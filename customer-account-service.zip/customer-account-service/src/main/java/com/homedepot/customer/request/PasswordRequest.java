package com.homedepot.customer.request;

import com.fasterxml.jackson.annotation.JsonRootName;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * Created by rxm4390 on 1/16/17.
 */
@Data
@NoArgsConstructor
@JsonRootName("passwordrequest")
@ToString(exclude={"password", "confirmPassword"})
public class PasswordRequest extends BaseRequest {

    @ApiModelProperty(value = "svoc id, required for set/reset password flow. This needs to be base 64 encoded format" )
    String svocId;
    @ApiModelProperty(value = "required for set/reset password flow")
    char[] password;
    @ApiModelProperty(value = "Email, used internally for set/reset password email")
    String email;
    @ApiModelProperty(value = "required for set/reset password flow")
    char[] confirmPassword;
    @ApiModelProperty(value = "token, required for reset password")
    String token;

}
