package com.homedepot.customer.request;

import com.homedepot.customer.model.PaginationInfo;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by rxb1809 on Jun 21, 2016
 *
 */
@NoArgsConstructor
@Data
public  class PaymentCardRequest {

    private String customerId;
    private String paymentId;
    private String sortType;
    private PaginationInfo paginationInfo;

}
