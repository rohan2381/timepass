package com.homedepot.customer.request;

import com.homedepot.customer.integration.svoc.dto.Preferences;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by axb4725 on 9/23/16.
 */
@AllArgsConstructor
@Data
@NoArgsConstructor
public class PreferencesRequest {
    private Preferences preferences;
}
