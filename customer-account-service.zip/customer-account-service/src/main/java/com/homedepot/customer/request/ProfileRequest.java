package com.homedepot.customer.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.homedepot.customer.model.Account;

/**
 * Created by rxb1809 on Jun 21, 2016
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProfileRequest {
    private Account account;
}
