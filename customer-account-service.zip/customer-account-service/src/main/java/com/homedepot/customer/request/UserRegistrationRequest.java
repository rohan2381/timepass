package com.homedepot.customer.request;

import com.fasterxml.jackson.annotation.JsonRootName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import com.homedepot.customer.model.Address;
import com.homedepot.customer.model.Phone;

/**
 * Created by rxb1809 on Jul 18, 2016
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString(exclude={"password","confirmPassword"})
@JsonRootName("user")
@ApiModel(value = "user")
public class UserRegistrationRequest {

    @ApiModelProperty(required = true, value = "User login id, has to be a valid email address")
    private String emailId;

    @ApiModelProperty(required = true, value = "Password for the new user")
    private char[] password;
    @ApiModelProperty(required = true, value = "Confirm password for the new user")
    private char[] confirmPassword;

    @ApiModelProperty(required = true, value = "Zip code for the new user")
    private String zipCode;

    // Required for Full Registration
    @ApiModelProperty(value = "First name of the user, Required for Full Registration")
    private String firstName;
    @ApiModelProperty(value = "Last name of the user, Required for Full Registration")
    private String lastName;

    // Required for Pro Xtra Registration
    @ApiModelProperty(value = "required for Pro Xtra registration", allowableValues = "Y")
    private String loyaltyEnrollmentIndicator;

    @ApiModelProperty(value = "required for Pro Xtra registration")
    private String businessName;

    @ApiModelProperty(value = "required for Pro Xtra registration")
    private String tradeType;

    @ApiModelProperty(value = "required for Pro Xtra registration, if tradeType = OTHER")
    private String otherTradeDescription;

    @ApiModelProperty(value = "unique primary address is required for Pro Xtra registration")
    private Address address;

    @ApiModelProperty(value = "unique primary phone is required for Pro Xtra registration")
    private Phone phone;
}
