package com.homedepot.customer.response;

import com.homedepot.customer.model.Addresses;
import com.homedepot.customer.model.PaginationInfo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Created by rxb1809 on Jun 11, 2016
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper=true)
public class AddressResponse extends BaseResponse {
    private PaginationInfo paginationInfo;
    private Addresses addresses; // NOSONAR

}
