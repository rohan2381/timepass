package com.homedepot.customer.response;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * Created by rxb1809 on Aug 12, 2016
 *
 */
@Data
@EqualsAndHashCode
public abstract class BaseResponse {
   
}
