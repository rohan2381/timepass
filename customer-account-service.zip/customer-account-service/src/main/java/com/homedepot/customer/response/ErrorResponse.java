package com.homedepot.customer.response;

import java.util.List;
import com.homedepot.customer.model.Error;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Created by rxb1809 on Aug 12, 2016
 *
 */
@NoArgsConstructor
@Data
@AllArgsConstructor
@EqualsAndHashCode(callSuper=true)
public class ErrorResponse extends BaseResponse{

    private List<Error> errors; // NOSONAR
}
