package com.homedepot.customer.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import com.homedepot.customer.model.Identity;

/**
 * Created by sxp2991 on 08/01/2016.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper=true)
public class IdentityResponse extends BaseResponse {
    private Identity identity;
}
