package com.homedepot.customer.response;

import com.homedepot.customer.model.PaginationInfo;
import com.homedepot.customer.model.PaymentCards;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Created by rxb1809 on Jun 18, 2016
 *
 */
@NoArgsConstructor
@Data
@AllArgsConstructor
@EqualsAndHashCode(callSuper=true)
public class PaymentResponse extends BaseResponse{

    private PaginationInfo paginationInfo;
    private PaymentCards paymentCards; // NOSONAR
}
