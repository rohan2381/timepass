package com.homedepot.customer.response;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import com.homedepot.customer.model.PostalDetails;

/**
 * Created by jirapat on 10/14/16.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper=true)
public class PostalResponse extends BaseResponse {
    private List<PostalDetails> postalDetailsList;
}
