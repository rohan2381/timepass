package com.homedepot.customer.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.homedepot.customer.model.Preferences;

/**
 * Created by axb4725 on 9/23/16.
 */
@AllArgsConstructor
@NoArgsConstructor
@Data
public class PreferencesResponse extends BaseResponse {
    private Preferences preferences;
}
