package com.homedepot.customer.response;

import com.homedepot.customer.model.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * Created by rxb1809 on Jun 18, 2016
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper=true)
public class ProfileResponse extends BaseResponse{
    private Account account; 
    private Identity identity;
}
