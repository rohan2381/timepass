package com.homedepot.customer.response;

import java.util.*;

import com.fasterxml.jackson.annotation.*;

import lombok.*;

/**
 * Created by admin on 10/4/16.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper=true)
@JsonRootName("")
public class UpdateIdentityResponse extends ErrorResponse  {
    String logonId;
    Date emailLastModifiedDate;
    Date accountLastModifiedDate;
}
