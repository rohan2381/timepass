package com.homedepot.customer.response.builder;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.response.BaseResponse;

/**
 * Created by rxb1809 on Oct 8, 2016
 * This is a generic interface for response builders. 
 */
@Service
public interface IResponseBuilder<M, V extends Object> {

    public BaseResponse buildResponse(M model, V obj, HttpServletResponse response) 
            throws CustomerAccountServiceException;
    
}
