package com.homedepot.customer.response.builder.impl;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.model.Account;
import com.homedepot.customer.model.Address;
import com.homedepot.customer.model.Addresses;
import com.homedepot.customer.model.PaginationInfo;
import com.homedepot.customer.response.AddressResponse;
import com.homedepot.customer.response.builder.IResponseBuilder;
import com.homedepot.customer.response.decorator.IFieldDecorator;

/**
 * Created by rxb1809 on Oct 8, 2016
 *
 */
@Service("addressResponseBuilder")
public class AddressResponseBuilderImpl implements IResponseBuilder<List<Address>, PaginationInfo>{
    
    @Autowired
    CustomerAccountRequestContext reqContext;
    
    @Autowired
    @Qualifier(value = "addressfielddecorator")
    IFieldDecorator<Addresses> fieldDecorator;

    @Override
    public AddressResponse buildResponse(List<Address> addrList, PaginationInfo paginationInfo, HttpServletResponse response) 
            throws CustomerAccountServiceException{
        AddressResponse addressResponse = new AddressResponse();
        
        Addresses addresses = new Addresses();
        addresses.setAddress(addrList);
        addressResponse.setAddresses(addresses);
        
        fieldDecorator.convertToDotComStandardCase(addresses);
        
        if(paginationInfo != null) {
            addressResponse.setPaginationInfo(paginationInfo);
        }
        
        return addressResponse;
    }

}
