package com.homedepot.customer.response.builder.impl;

import com.homedepot.customer.datasync.util.*;
import com.homedepot.customer.exception.*;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.integration.cart.dto.*;
import com.homedepot.customer.integration.wcs.dto.WCSUserIdentity;
import com.homedepot.customer.model.Account;
import com.homedepot.customer.model.Identity;
import com.homedepot.customer.model.Name;
import com.homedepot.customer.model.Profile;
import com.homedepot.customer.model.UserIdentity;
import com.homedepot.customer.response.IdentityResponse;
import com.homedepot.customer.response.builder.IResponseBuilder;
import com.homedepot.customer.service.impl.*;
import com.homedepot.customer.util.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;
import javax.servlet.http.*;

/**
 * Created by rxb1809 on Oct 8, 2016
 */
@Service
@Slf4j
public class LoginResponseBuilderImpl implements IResponseBuilder<UserIdentity, WCSUserIdentity> {

    @Autowired
    CookiesUtil responseCookiesUtil;
    
    @Autowired
    CustomerAccountRequestContext reqContext;

    @Autowired
    private EnvPropertyUtil envProperty;

    @Autowired
    private SessionHelper sessionHelper;

    @Autowired
    private CartExecutor cartTaskExecutor;

    @Autowired
    MyListTaskExecutor listTaskExecutor;

    @Autowired
    private DataSyncUtil dataSyncUtil;

    @Override
    public IdentityResponse buildResponse(UserIdentity userIdentity, WCSUserIdentity wcsUserIdentity,
                                          HttpServletResponse response) throws CustomerAccountServiceException {

        IdentityResponse identityResponse = new IdentityResponse();
        Identity identity = new Identity();
        if (wcsUserIdentity != null) {
            identity.setLogonId(wcsUserIdentity.getLogonId());
            identity.setWcsMemberId(wcsUserIdentity.getUserId());
            Optional.ofNullable(wcsUserIdentity.getAccount()).map(Account::getProfile).map(Profile::getName).map(Name::getFirstName).ifPresent(n -> reqContext.setFirstName(n));
            responseCookiesUtil.setWCSResponseCookies(identity, wcsUserIdentity, response);
        }
        if (StringUtils.isNotBlank(userIdentity.getCustomerAccountId())) {
            identity.setLogonId(userIdentity.getLogonId());
            identity.setSessionToken(userIdentity.getSessionToken());
            identity.setSvocCustomerAccountId(userIdentity.getCustomerAccountId());
            responseCookiesUtil.setIAMResponseCookies(identity, response);
        }
        if(wcsUserIdentity == null && StringUtils.isNotBlank(userIdentity.getCustomerAccountId())) {
            responseCookiesUtil.setFallbackWCSResponseCookies(identity, response);
        }
        identityResponse.setIdentity(identity);
        migrateCart(identityResponse, response);
        return identityResponse;
    }

    private void migrateCart(IdentityResponse identityResponse, HttpServletResponse response) throws RepositoryException {
        if (envProperty.getCartMigrationEnabled()) {

            boolean cartAsyncCallRequired = sessionHelper.wcsCallRequired(reqContext.getRequest());

            Optional<HttpServletRequest> requestOptional = Optional.ofNullable(reqContext.getRequest());
            Cookie[] reqCookies = requestOptional.map(HttpServletRequest::getCookies).orElse(new Cookie[0]);

            HttpServletResponse[] args = new HttpServletResponse[1];
            args[0] = response;

            if(cartAsyncCallRequired) {
                cartTaskExecutor.asyncMigrateCart(args, identityResponse, reqCookies);
                dataSyncUtil.pauseAroundDataSync();
            }
            else {
                CartResponse cartResponse = cartTaskExecutor.migrateCart(args, identityResponse, reqCookies); //Aurora Checkout Flow
                responseCookiesUtil.setCartMigrateResponseCookies(cartResponse, response);
            }
        }
    }

}
