package com.homedepot.customer.response.builder.impl;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.model.IAMLogoutInfo;
import com.homedepot.customer.model.WCSLogoutInfo;
import com.homedepot.customer.response.BaseResponse;
import com.homedepot.customer.response.builder.IResponseBuilder;
import com.homedepot.customer.util.CookiesUtil;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.util.THDEnv;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Collectors;

@Component
@Slf4j
public class LogoutResponseBuilderImpl implements IResponseBuilder<IAMLogoutInfo, WCSLogoutInfo> {
    
    @Autowired
    CookiesUtil cookiesUtil;
    
    @Autowired
    EnvPropertyUtil envProperty;

    @Autowired
    CustomerAccountRequestContext requestContext;
    
    @Autowired
    private Environment environment;

    @Override
    public BaseResponse buildResponse(IAMLogoutInfo iamLogoutInfo, WCSLogoutInfo wcsLogoutInfo,
                                      HttpServletResponse response) throws CustomerAccountServiceException {
        boolean iamLogout =(iamLogoutInfo != null && iamLogoutInfo.isIamSuccess());
        
        String iamCookieDomain = envProperty.getIamCookieDomain();

        String cartActivityCookieDomain = envProperty.getCartActivityCookieDomain();
        
        if(Arrays.stream(environment.getActiveProfiles()).anyMatch(env -> GlobalConstants.SPRING_PFOFILE_DEV.equalsIgnoreCase(env))) {   
            ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if(requestAttributes!=null && requestAttributes.getRequest()!=null 
                    && requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV) !=null){
                THDEnv thdEnv =  (THDEnv)requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV);
                if(thdEnv!=null){
                    iamCookieDomain = thdEnv.getDomain();
                    log.debug("cookie domain set to "+thdEnv.getOriginUrl());
                }                            
            }
        }

        //if (iamLogout) {
        Cookie iamSessionCookie = new Cookie(GlobalConstants.THD_USER_SESSION, "");// NOSONAR
        iamSessionCookie.setMaxAge(0);
        iamSessionCookie.setDomain(iamCookieDomain);
        iamSessionCookie.setPath("/");
        iamSessionCookie.setSecure(false);
        response.addCookie(iamSessionCookie);

        Cookie iamPersistentCookie = new Cookie(GlobalConstants.THD_USER, "");// NOSONAR
        iamPersistentCookie.setMaxAge(0);
        iamPersistentCookie.setDomain(iamCookieDomain);
        iamPersistentCookie.setPath("/");
        iamPersistentCookie.setSecure(false);
        response.addCookie(iamPersistentCookie);

        Cookie cartActivityCookie = new Cookie(GlobalConstants.CART_ACTIVITY.toLowerCase(), "");// NOSONAR
        cartActivityCookie.setMaxAge(0);
        cartActivityCookie.setDomain(cartActivityCookieDomain);
        cartActivityCookie.setPath("/");
        cartActivityCookie.setSecure(false);
        response.addCookie(cartActivityCookie);
        //}
        if (wcsLogoutInfo != null) {
            wcsLogoutInfo.getResponseCookies().forEach(cookieStr -> cookiesUtil.processWCSCookies(cookieStr, response));
        } else { // WCS logout failed
            
            final String iamCookieDomainFinal = iamCookieDomain;
            // Consumer function to take THD_PERSIST from request, remove c13 and add it to response
            Consumer<Cookie> cookieConsumer = cookie->  {
                                                            //Splitting crumbs
                                                            String[] crumbs = GlobalConstants.THD_PERSIST_CRUMB_SPLIT_PATTERN.split(cookie.getValue());
                                                            //Remove C13 from list
                                                            List<String> cc=  Arrays.stream(crumbs)
                                                                                    .filter(c->(!c.contains(GlobalConstants.COOKIE_CRUMB_C13)))
                                                                                    .collect(Collectors.toList());
                                                            //Create THD_PERSIST  and add it to response
                                                            Cookie thd_persist_response= new Cookie(GlobalConstants.THD_PERSIST, StringUtils.join(cc,GlobalConstants.THD_PERSIST_BASE64_DELIMETER));
                                                                    thd_persist_response.setDomain(iamCookieDomainFinal);
                                                                    thd_persist_response.setMaxAge(GlobalConstants.THD_PERSIST_MaxAge);
                                                                    thd_persist_response.setHttpOnly(GlobalConstants.THD_PERSIST_HttpOnly);
                                                                    thd_persist_response.setPath(GlobalConstants.THD_PERSIST_Path);
                                                                    thd_persist_response.setSecure(GlobalConstants.THD_PERSIST_SECURE);
                                                                    response.addCookie(thd_persist_response);
                                                        };
            //Creating optional if request is null
            Optional<CustomerAccountRequestContext> optionalRequestContext = Optional.ofNullable(requestContext);
            optionalRequestContext.map(resquestContext -> resquestContext.getRequest())
                                    .map(request -> request.getCookies())
                                    .ifPresent(cookies -> {
                                                            Arrays.stream(cookies)
                                                                  .filter(c->c.getName().equals(GlobalConstants.THD_PERSIST))
                                                                  .findFirst()
                                                                  .ifPresent(cookieConsumer);
                                                          });
        }
        return null;
    }

}
