package com.homedepot.customer.response.builder.impl;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.model.PaginationInfo;
import com.homedepot.customer.model.PaymentCard;
import com.homedepot.customer.model.PaymentCards;
import com.homedepot.customer.response.PaymentResponse;
import com.homedepot.customer.response.builder.IResponseBuilder;


/**
 * Created by rxb1809 on Oct 8, 2016
 *
 */
@Service("paymentResponseBuilder")
public class PaymentResponseBuilderImpl implements IResponseBuilder<List<PaymentCard>,PaginationInfo>{

    @Override
    public PaymentResponse buildResponse(List<PaymentCard> paymentCardList, PaginationInfo paginationInfo, HttpServletResponse response)
                throws CustomerAccountServiceException {
        PaymentResponse paymentResponse = new PaymentResponse();
        
        PaymentCards paymentCards = new PaymentCards();
        paymentCards.setPaymentCard(paymentCardList);
        paymentResponse.setPaymentCards(paymentCards);
        
        if(paginationInfo != null) {
            paymentResponse.setPaginationInfo(paginationInfo);
        }
        
        return paymentResponse;
    }
}
