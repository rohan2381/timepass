package com.homedepot.customer.response.builder.impl;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.model.PaginationInfo;
import com.homedepot.customer.model.PostalDetails;
import com.homedepot.customer.response.PostalResponse;
import com.homedepot.customer.response.builder.IResponseBuilder;

/**
 * Created by jirapat on 10/14/16.
 */
@Service("postalResponseBuilder")
public class PostalResponseBuilderImpl implements IResponseBuilder<List<PostalDetails>, PaginationInfo> {
    @Override
    public PostalResponse buildResponse(List<PostalDetails> model, PaginationInfo obj, HttpServletResponse response) throws CustomerAccountServiceException {
        return new PostalResponse(model);
    }
}
