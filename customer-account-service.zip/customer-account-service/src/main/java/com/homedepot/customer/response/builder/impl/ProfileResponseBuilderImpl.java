package com.homedepot.customer.response.builder.impl;

import java.util.Optional;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.model.Account;
import com.homedepot.customer.response.ProfileResponse;
import com.homedepot.customer.response.builder.IResponseBuilder;
import com.homedepot.customer.response.decorator.IFieldDecorator;
import com.homedepot.customer.util.BusinessChannel;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Oct 8, 2016
 *
 */
@Service
@Slf4j
public class ProfileResponseBuilderImpl implements IResponseBuilder<Account,Object>{

    @Autowired
    CustomerAccountRequestContext reqContext;
    
    @Autowired
    @Qualifier(value = "profilefielddecorator")
    IFieldDecorator<Account> fieldDecorator;

    @Override
    public ProfileResponse buildResponse(Account model, Object variableObj, HttpServletResponse response)
            throws CustomerAccountServiceException{
        
        fieldDecorator.convertToDotComStandardCase(model);
        
        // For certain channels (channelId 1, 2, and 3) we will suppress some fields on retrieve profile
        BusinessChannel businessChannel = BusinessChannel.valueOf(reqContext.getBusinessChannel());
        if (BusinessChannel.MCMDESKTOP.equals(businessChannel)
                || BusinessChannel.MCMMOBILE.equals(businessChannel)
                || BusinessChannel.MCMTABLET.equals(businessChannel)) {
            Optional.ofNullable(model)
                    .map(Account::getProfile)
                    .ifPresent(profile -> {

                        // SVOC does not allow update Trade Type to the same value
                        // suppress Trade Type fields so that DIY UI will not have to deal with them
                        profile.setTradeType(null);
                        profile.setTradeTypeLastModifiedDate(null);
                        profile.setOtherTradeDescription(null);
                    });
            model.setAddress(null);
        }

        return new ProfileResponse(model, null);
    }

}
