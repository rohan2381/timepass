package com.homedepot.customer.response.builder.impl;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.integration.wcs.dto.WCSUserIdentity;
import com.homedepot.customer.model.*;
import com.homedepot.customer.response.ProfileResponse;
import com.homedepot.customer.response.builder.IResponseBuilder;
import com.homedepot.customer.response.decorator.IFieldDecorator;
import com.homedepot.customer.util.CookiesUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.util.Optional;

@Service
@Slf4j
public class RegistrationResponseBuilderImpl implements IResponseBuilder<Account,UserIdentity> {

    @Autowired
    CookiesUtil responseCookiesUtil;

    @Autowired
    CustomerAccountRequestContext reqContext;

    @Autowired
    @Qualifier(value = "profilefielddecorator")
    IFieldDecorator<Account> fieldDecorator;

    @Override
    public ProfileResponse buildResponse(Account account,
                                         UserIdentity userIdentity,
                                         HttpServletResponse response) throws CustomerAccountServiceException {

        Identity identity = new Identity();
        if(userIdentity != null) {
            identity.setLogonId(userIdentity.getLogonId());
            identity.setSvocCustomerAccountId(userIdentity.getCustomerAccountId());
            identity.setSessionToken(userIdentity.getSessionToken());
            responseCookiesUtil.setIAMResponseCookies(identity, response);
            if(userIdentity.getWcsUserIdentity() != null) {
                WCSUserIdentity wcsUserIdentity = userIdentity.getWcsUserIdentity();
                identity.setLogonId(wcsUserIdentity.getLogonId());
                identity.setWcsMemberId(wcsUserIdentity.getUserId());
                responseCookiesUtil.setWCSResponseCookies(identity, userIdentity.getWcsUserIdentity(), response);
            }
            else {
                responseCookiesUtil.setFallbackWCSResponseCookies(identity, response);
            }

        }
        ProfileResponse profileResponse = new ProfileResponse();
        //Convert email from Upper case to standard format
        fieldDecorator.convertToDotComStandardCase(account);
        profileResponse.setAccount(account);
        profileResponse.setIdentity(identity);
        Optional<Account> accountOptional = Optional.ofNullable(account);
        accountOptional.map(Account::getProfile).map(Profile::getName).map(Name::getFirstName).ifPresent(n -> reqContext.setFirstName(n));

        // clear address list so it won't clutter response payload
        // UI may re-use response json as base for subsequence request payload to update profile
        accountOptional.ifPresent(account1 -> account1.setAddress(null));


        return profileResponse;
    }

}