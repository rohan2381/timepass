package com.homedepot.customer.response.decorator;

import org.springframework.stereotype.Service;

/**
 * Created by rxb1809 on Jan 23, 2017
 * This is an interface to specific various operations on response entity fields
 */
@Service
public interface IFieldDecorator<E> {

    public void convertToDotComStandardCase(E respEntity);
}
