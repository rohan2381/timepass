package com.homedepot.customer.response.decorator.impl;

import java.util.Optional;

import org.apache.commons.lang3.text.WordUtils;
import org.springframework.stereotype.Service;

import com.homedepot.customer.model.Addresses;
import com.homedepot.customer.response.decorator.IFieldDecorator;

/**
 * Created by rxb1809 on Jan 23, 2017
 * Address response specific field decorator
 */
@Service("addressfielddecorator")
public class AddressFieldDecoratorImpl implements IFieldDecorator<Addresses>{

    @Override
    public void convertToDotComStandardCase(Addresses addresses) {
        Optional.ofNullable(addresses)
                .map(Addresses::getAddress).ifPresent(addrList -> {
                    addrList.forEach(address -> {
                        Optional.ofNullable(address.getPostalDetails()).ifPresent(postal -> {
                            postal.setAddressLine1(WordUtils.capitalizeFully(postal.getAddressLine1()));
                            postal.setAddressLine2(WordUtils.capitalizeFully(postal.getAddressLine2()));
                        });
                        
                        Optional.ofNullable(address.getName()).ifPresent(name -> {
                            name.setFirstName(WordUtils.capitalizeFully(name.getFirstName()));
                            name.setLastName(WordUtils.capitalizeFully(name.getLastName()));
                        });
                        
                    });
                });
      
    }

}
