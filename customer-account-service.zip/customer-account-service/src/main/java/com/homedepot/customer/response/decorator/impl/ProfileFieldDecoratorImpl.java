package com.homedepot.customer.response.decorator.impl;

import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.springframework.stereotype.Service;

import com.homedepot.customer.model.Account;
import com.homedepot.customer.model.Profile;
import com.homedepot.customer.response.decorator.IFieldDecorator;

/**
 * Created by rxb1809 on Jan 23, 2017
 * Profile response specific field decorator
 */
@Service("profilefielddecorator")
public class ProfileFieldDecoratorImpl implements IFieldDecorator<Account>{

    @Override
    public void convertToDotComStandardCase(Account account) {
        
        // Set email to lowe case
        Optional.ofNullable(account)
        .map(Account::getProfile)
        .ifPresent(profile -> profile.setEmailId(StringUtils.lowerCase(profile.getEmailId())));   
        
        // Set first name and last name to camel case
        Optional.ofNullable(account)
                .map(Account::getProfile)
                .map(Profile::getName)
                .ifPresent(name -> {
                    name.setFirstName(WordUtils.capitalizeFully(name.getFirstName()));
                    name.setLastName(WordUtils.capitalizeFully(name.getLastName()));
                });                   
                
    }

}
