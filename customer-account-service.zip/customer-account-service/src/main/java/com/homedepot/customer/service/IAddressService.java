package com.homedepot.customer.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.model.Address;
import com.homedepot.customer.model.PostalDetails;
import com.homedepot.customer.request.AddressRequest;

/**
 * Created by rxb1809 on Apr 27, 2016
 *
 */
@Service
public interface IAddressService {

    public Map<String,Object> getAllUserAddresses(AddressRequest request, String customerAccountID) throws CustomerAccountServiceException;

    public List<Address> createUserAddress(AddressRequest addressRequest, String customerAccountId ) throws CustomerAccountServiceException;

    public List<Address> getUserAddressById(String customerAccountId, Integer addressId) throws CustomerAccountServiceException;

    public List<Address> updateUserAddress(AddressRequest addresseRequest, String customerAccountId) throws CustomerAccountServiceException;

    public List<Address> deleteUserAddressById(String customerAccountId, AddressRequest addressRequest) throws CustomerAccountServiceException;

    public List<PostalDetails> getCityStates(String zipCode) throws CustomerAccountServiceException;
}
