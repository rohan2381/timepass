package com.homedepot.customer.service;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import org.springframework.stereotype.Service;

/**
 * Created by rxb1809 on Dec 26, 2016
 *
 */
@Service
public interface IEmailService {

    public void sendRegistrationEmail(String email) throws CustomerAccountServiceException;
    
    public void sendAccountUpdateEmail(String oldEmail, String email, String firstName) throws CustomerAccountServiceException;
    
    public void sendResetPasswordEmail(String email, String svocId, String token) throws CustomerAccountServiceException;

    public void sendSetPasswordEmail(String email, String svocId, String token) throws CustomerAccountServiceException;
    
    public void sendPasswordUpdatedEmail(String email, String firstName) throws CustomerAccountServiceException;
    
}
