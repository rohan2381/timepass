package com.homedepot.customer.service;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.model.Identity;
import com.homedepot.customer.model.AuthEntity;
import com.homedepot.customer.model.LogoutInfo;
import com.homedepot.customer.model.UserIdentity;
import com.homedepot.customer.request.*;

import org.springframework.stereotype.Service;

/**
 * Created by rxb1809 on Apr 27, 2016
 *
 */
@Service
public interface IIdentityService {

    public UserIdentity authenticateUser(IdentityRequest identityRequest)
            throws CustomerAccountServiceException;
    
    public Identity updateIdentity(IdentityRequest updateIdentityRequest, String customerAccountId) throws
            CustomerAccountServiceException;
    
    public LogoutInfo logOutUser() throws CustomerAccountServiceException;
    
    public Identity validateUserSession() throws CustomerAccountServiceException;

    public AuthEntity getClientToken(ClientAuthRequest clientAuthRequest) throws CustomerAccountServiceException;

    public AuthEntity validateClientAuth(ClientAuthRequest clientAuthRequest) throws CustomerAccountServiceException;

}
