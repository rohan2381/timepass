package com.homedepot.customer.service;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.request.*;

import org.springframework.stereotype.Service;

/**
 * Created by rxm4390 on Jan 18, 2017
 *
 */
@Service
public interface IPasswordService {

    public void resetUserPassword(PasswordRequest resetPwdRequest) throws CustomerAccountServiceException;

    public void resetUserPasswordEmail(PasswordRequest resetPwdEmailRequest) throws CustomerAccountServiceException;

    public void setPassword(PasswordRequest passwordRequest) throws CustomerAccountServiceException;

    public void setPasswordEmail(PasswordRequest passwordRequest) throws CustomerAccountServiceException;

}
