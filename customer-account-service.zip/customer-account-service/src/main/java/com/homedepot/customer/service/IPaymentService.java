package com.homedepot.customer.service;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.model.PaymentCard;
import com.homedepot.customer.model.PaymentCards;
import com.homedepot.customer.request.PaymentCardRequest;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Created by rxb1809 on Apr 27, 2016
 */
@Service
public interface IPaymentService {

    public Map<String, Object> getAllPaymentCards(PaymentCardRequest paymentCardRequest, String customerAccountId)
            throws CustomerAccountServiceException;

    public Map<String, Object> getAllPaymentCardsWithFallback(PaymentCardRequest paymentCardRequest, String customerAccountId)
            throws CustomerAccountServiceException;

    public List<PaymentCard> createUserPaymentCard(String customerAccountId, PaymentCards paymentCards)
            throws CustomerAccountServiceException;

    public List<PaymentCard> getUserPaymentCardById(String customerAccountId, String paymentCardId)
            throws CustomerAccountServiceException;

    public List<PaymentCard> updateUserPaymentCard(String customerAccountId, PaymentCards paymentCards)
            throws CustomerAccountServiceException;

    public boolean deleteUserPaymentCardById(String customerAccountId, String paymentCardId)
            throws CustomerAccountServiceException;
}
