package com.homedepot.customer.service;

import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.model.Preferences;
import com.homedepot.customer.model.pvcypreferences.PrivacyPrefRequest;

/**
 * Created by axb4725 on 9/26/16.
 */
@Service
public interface IPreferencesService {
    
    public Preferences getPreferences(String email) throws CustomerAccountServiceException;
    
    public Preferences setPreferences(String email, String zipCode, Preferences subscriptions) throws CustomerAccountServiceException;
    
    public boolean updatePrivacyPreferences(PrivacyPrefRequest request) throws CustomerAccountServiceException;

}
