package com.homedepot.customer.service;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.model.Account;
import com.homedepot.customer.request.ProfileRequest;
import org.springframework.stereotype.Service;

/**
 * Created by rxb1809 on Apr 27, 2016
 *
 */
@Service
public interface IProfileService {

    public Account updateProfile(String customerAccountId, ProfileRequest profileRequest)
            throws CustomerAccountServiceException;

    public Account retrieveProfile(String customerAccountId) throws CustomerAccountServiceException;

}
