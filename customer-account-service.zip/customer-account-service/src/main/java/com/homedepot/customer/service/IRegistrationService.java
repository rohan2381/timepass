package com.homedepot.customer.service;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.request.UserRegistrationRequest;

/**
 * Created by rxb1809 on Apr 27, 2016
 *
 */
@Service
public interface IRegistrationService {

	public Map<String, Object> registerUser(UserRegistrationRequest userRegistrationRequest) throws
			CustomerAccountServiceException;

	public Boolean emailAlreadyExists(String emailId) throws CustomerAccountServiceException;
}
