package com.homedepot.customer.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.homedepot.customer.datasync.address.AddressFallBackExecutor;
import com.homedepot.customer.exception.AuthenticationException;
import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.exception.GenericSystemException;
import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.InvalidRequestException;
import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.mapper.impl.AddressMapperImpl;
import com.homedepot.customer.model.Address;
import com.homedepot.customer.model.Addresses;
import com.homedepot.customer.model.PaginationInfo;
import com.homedepot.customer.model.PostalDetails;
import com.homedepot.customer.repository.IAddressRepository;
import com.homedepot.customer.request.AddressRequest;
import com.homedepot.customer.service.IAddressService;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.util.PaginationUtil;
import com.homedepot.customer.validator.BaseRequestValidator;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Apr 27, 2016
 *
 */
@Service
@Slf4j
public class AddressServiceImpl implements IAddressService {

    @Autowired
    @Qualifier(value = "addressvalidator")
    BaseRequestValidator<AddressRequest> requestValidator;

    @Autowired
    @Qualifier(value = "citystatevalidator")
    BaseRequestValidator<String> cityStateRequestValidator;

    @Autowired
    IAddressRepository addressRepository;

    @Autowired
    AddressMapperImpl addressMapper;
    
    @Autowired
    AddressFallBackExecutor addressFallbackExecutor;
    
    @Autowired
    CustomerAccountRequestContext reqContext;
    
    @Autowired
    PaginationUtil paginationUtil;

    /*@HystrixCommand(commandKey="getAllAddressesFromSVOC",
            fallbackMethod = "getAllAddressesFromWCS", 
            ignoreExceptions={RepositoryException.class, GenericSystemException.class, AuthenticationException.class, 
                    InvalidRequestException.class, IntegrationException.class},
            commandProperties = {
                    @HystrixProperty(name = "execution.isolation.strategy", value = "SEMAPHORE"),
                    @HystrixProperty(name = "execution.timeout.enabled", value = "false")
                })*/
    @Override
    public Map<String,Object> getAllUserAddresses(AddressRequest request, String customerAccountID) throws CustomerAccountServiceException{
        if(reqContext.isWCSRequest()){
            return getAllAddressesFromWCS(request, customerAccountID, null);
        }
        
        requestValidator.validate(request,HttpMethod.GET);
        
        return addressRepository.retrieveAll(request, customerAccountID);
    }
    
    
    /*@HystrixCommand(commandKey="createAddressInSVOC",
            fallbackMethod = "createAddressInWCS", 
            ignoreExceptions={RepositoryException.class, GenericSystemException.class, AuthenticationException.class, 
                    InvalidRequestException.class, IntegrationException.class},
            commandProperties = {
                    @HystrixProperty(name = "execution.isolation.strategy", value = "SEMAPHORE"),
                    @HystrixProperty(name = "execution.timeout.enabled", value = "false")
                })*/
    @Override
    public List<Address> createUserAddress(AddressRequest addressRequest, String customerAccountId)
            throws CustomerAccountServiceException {
        if(reqContext.isWCSRequest()){
            return createAddressInWCS(addressRequest, customerAccountId, null);
        }
        
        requestValidator.validate(addressRequest, HttpMethod.POST);

        return addressRepository.save(customerAccountId, addressRequest.getAddress());
    }
    
    /*@HystrixCommand(commandKey="getAddressFromSVOC",
            fallbackMethod = "getAddressFromWCS", 
            ignoreExceptions={RepositoryException.class, GenericSystemException.class, AuthenticationException.class, 
                    InvalidRequestException.class, IntegrationException.class},
            commandProperties = {
                    @HystrixProperty(name = "execution.isolation.strategy", value = "SEMAPHORE"),
                    @HystrixProperty(name = "execution.timeout.enabled", value = "false")
                })*/
    @Override
    public List<Address> getUserAddressById(String customerAccountId, Integer addressId)
            throws CustomerAccountServiceException {
        log.debug("getUserAddressById, customerAccountId: {}, addressId: {}", customerAccountId, addressId);
        if(reqContext.isWCSRequest()){
            return getAddressFromWCS(customerAccountId, addressId, null);
        }

        return addressRepository.retrieveById(customerAccountId, Collections.singletonList(addressId.toString()));
    }
    
    
    /*@HystrixCommand(commandKey="updateAddressInSVOC",
            fallbackMethod = "updateAddressInWCS", 
            ignoreExceptions={RepositoryException.class, GenericSystemException.class, AuthenticationException.class, 
                    InvalidRequestException.class, IntegrationException.class},
            commandProperties = {
                    @HystrixProperty(name = "execution.isolation.strategy", value = "SEMAPHORE"),
                    @HystrixProperty(name = "execution.timeout.enabled", value = "false")
                })*/
    @Override
    public List<Address> updateUserAddress(AddressRequest addressesRequest, String customerAccountId)
            throws CustomerAccountServiceException {
        log.debug("updateUserAddress, customerAccountId: {}", customerAccountId);
        if(reqContext.isWCSRequest()){
            return updateAddressInWCS(addressesRequest, customerAccountId, null);
        }

        requestValidator.validate(addressesRequest, HttpMethod.PUT);

        return addressRepository.update(customerAccountId, addressesRequest.getAddress());
    }
    
    
    /*@HystrixCommand(commandKey="deleteAddressInSVOC",
            fallbackMethod = "deleteAddressInWCS", 
            ignoreExceptions={RepositoryException.class, GenericSystemException.class, AuthenticationException.class, 
                    InvalidRequestException.class, IntegrationException.class},
            commandProperties = {
                    @HystrixProperty(name = "execution.isolation.strategy", value = "SEMAPHORE"),
                    @HystrixProperty(name = "execution.timeout.enabled", value = "false")
                })*/
    @Override
    public List<Address> deleteUserAddressById(String customerAccountId, AddressRequest addressRequest)
            throws CustomerAccountServiceException {
        log.debug("deleteUserAddressById, customerAccountId: {}, addressId: {}", customerAccountId, addressRequest);
        if(reqContext.isWCSRequest()){
            return deleteAddressInWCS(customerAccountId, addressRequest, null);
        }

        return addressRepository.deleteById(customerAccountId, addressRequest.getAddress());
    }

    @Override
    public List<PostalDetails> getCityStates(String zipCode) throws CustomerAccountServiceException {
        cityStateRequestValidator.validate(zipCode, HttpMethod.GET);

        return addressRepository.getCityStates(zipCode);
    }
    
    
    
    /********* Fall-back Methods *****************/
    private Map<String, Object> getAllAddressesFromWCS(AddressRequest request, String customerAccountID, Throwable originalEx) throws IntegrationException{
        log.info(reqContext.isWCSRequest() ? GlobalConstants.REQUEST_VALID_FOR_WCS : GlobalConstants.SVOC_UNAVAILABLE
                +"Getting addresses info from WCS for svoc id "+customerAccountID);
        log.info(originalEx!=null ? GlobalConstants.SVOC_UNAVAILABLE_MSG+ExceptionUtils.getRootCauseMessage(originalEx) : "");
        
        List<Address> addressList = new ArrayList<>();
        HashMap<String, Object> responseData = new HashMap<>();
        
        addressList = addressFallbackExecutor.getCustomerAddressFromWCS( null);
        if(!CollectionUtils.isEmpty(addressList)){
            reqContext.setReqServedFromWCS(true);
        }
        
        PaginationInfo respPageInfo = new PaginationInfo();        
        if(request.getPaginationInfo()!=null && request.getPaginationInfo().getPageSize()!=null
                && !request.getPaginationInfo().getPageSize().equalsIgnoreCase("0")
                && !request.getPaginationInfo().getPageNumber().equalsIgnoreCase("0")){
            int pageNo = Integer.parseInt(request.getPaginationInfo().getPageNumber());
            int pageSize = Integer.parseInt(request.getPaginationInfo().getPageSize());
            
            List<Address> pagedAddressList = paginationUtil.paginate(addressList, pageNo, pageSize);                       
            respPageInfo.setPageNumber(request.getPaginationInfo().getPageNumber());
            respPageInfo.setPageSize(request.getPaginationInfo().getPageSize());
            respPageInfo.setTotalNumberOfRecords(String.valueOf(addressList.size()));
            respPageInfo.setTotalPages(String.valueOf(paginationUtil.getTotalPages(addressList.size(), pageSize)));
            responseData.put("addresses", new Addresses(pagedAddressList));     
        }else{
            responseData.put("addresses", new Addresses(addressList));
        }
        
        responseData.put("paginationInfo", respPageInfo);       
        return responseData;
    }
    
    private List<Address> createAddressInWCS(AddressRequest addressRequest, String customerAccountId, Throwable originalEx) throws IntegrationException{
        log.info(reqContext.isWCSRequest() ? GlobalConstants.REQUEST_VALID_FOR_WCS : GlobalConstants.SVOC_UNAVAILABLE
                +"Creating address in WCS for svoc id "+customerAccountId);
        log.info(originalEx!=null ? GlobalConstants.SVOC_UNAVAILABLE_MSG+originalEx.getMessage() : "");
        
        List<Address> addresses = addressFallbackExecutor.createCustomerAddressInWCS(addressRequest.getAddress());
        if(!CollectionUtils.isEmpty(addresses)){
            reqContext.setReqServedFromWCS(true);
        }
        
        return addresses;
    }
    
    private List<Address> getAddressFromWCS(String customerAccountId, Integer addressId, Throwable originalEx) throws IntegrationException{
        log.info(reqContext.isWCSRequest() ? GlobalConstants.REQUEST_VALID_FOR_WCS : GlobalConstants.SVOC_UNAVAILABLE
                +"Getting address info from WCS for svoc id "+customerAccountId +"and address id "+addressId);
        log.info(originalEx!=null ? GlobalConstants.SVOC_UNAVAILABLE_MSG+originalEx.getMessage() : "");
        List<Address> addressList = new ArrayList<>();
        
        addressList = addressFallbackExecutor.getCustomerAddressFromWCS(String.valueOf(addressId));
        if(!CollectionUtils.isEmpty(addressList)){
            reqContext.setReqServedFromWCS(true);
        }
        
        return addressList;

    }
    
    private List<Address> updateAddressInWCS(AddressRequest addressesRequest, String customerAccountId, Throwable originalEx) throws IntegrationException{
        log.info(reqContext.isWCSRequest() ? GlobalConstants.REQUEST_VALID_FOR_WCS : GlobalConstants.SVOC_UNAVAILABLE
                +"Updating address in WCS for svoc id "+customerAccountId);
        log.info(originalEx!=null ? GlobalConstants.SVOC_UNAVAILABLE_MSG+originalEx.getMessage() : "");
        
        List<Address> addresses = addressFallbackExecutor.updateCustomerAddressInWCS(addressesRequest.getAddress());
        if(!CollectionUtils.isEmpty(addresses)){
            reqContext.setReqServedFromWCS(true);
        }
        
        return addresses;
    }
    
    private List<Address> deleteAddressInWCS(String customerAccountId, AddressRequest addressRequest, Throwable originalEx) throws IntegrationException{
        log.info(reqContext.isWCSRequest() ? GlobalConstants.REQUEST_VALID_FOR_WCS : GlobalConstants.SVOC_UNAVAILABLE
                +"Deleting address from WCS");
        log.info(originalEx!=null ? GlobalConstants.SVOC_UNAVAILABLE_MSG+originalEx.getMessage() : "");
        
        boolean deleted = addressFallbackExecutor.deleteCustomerAddressInWCS(String.valueOf(
                addressRequest.getAddress().get(0).getAddrIdentifier()));
        
        if(deleted){
            reqContext.setReqServedFromWCS(true);
        }
        
        return addressRequest.getAddress();
    }

}
