package com.homedepot.customer.service.impl;

import java.net.HttpCookie;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.*;
import com.homedepot.customer.integration.cart.dto.*;
import com.homedepot.customer.model.*;
import com.homedepot.customer.repository.ICartRepository;
import com.homedepot.customer.response.IdentityResponse;
import com.homedepot.customer.response.ProfileResponse;

import static com.homedepot.customer.util.GlobalConstants.SETCOOKIE;

/**
 * Created by jirapat on 3/31/17.
 */
@Service
@Slf4j
public class CartExecutor {
    @Autowired
    ICartRepository cartRepository;

    @Async("cartTaskExecutor")
    public void asyncMigrateCart(Object[] args, Object result, Cookie[] reqCookies) {
        try {
            Optional<String> userIdOptional = findUserId(result);

            if (userIdOptional.isPresent()) {
                log.debug("migrate cart after customer login or registration for userId: {}", userIdOptional.get());
                Cookie[] cookieArray = buildCookieArray(args, reqCookies);

                migrateCart(userIdOptional.get(), cookieArray);
            }
        }
        catch (Exception e) {
            Throwable rootCause = ExceptionUtils.getRootCause(e);
            log.error("async migrate cart exception: ", rootCause != null ? rootCause : e);
        }
    }

    public CartResponse migrateCart(Object[] args, Object result, Cookie[] reqCookies) throws RepositoryException {
        CartResponse cartResponse = null;
        Optional<String> userIdOptional = findUserId(result);

        if (userIdOptional.isPresent()) {
            log.debug("migrate cart after customer login or registration for userId: {}", userIdOptional.get());
            Cookie[] cookieArray = buildCookieArray(args, reqCookies);

            cartResponse = migrateCart(userIdOptional.get(), cookieArray);
        }
        return cartResponse;
    }

    private CartResponse migrateCart(String userId, Cookie[] cookies) throws RepositoryException {
        CartResponse cartResponse = null;
        if (userId != null) {
            log.debug("start migrating cart for {}", userId);
            cartResponse = cartRepository.migrateCart(userId, cookies);
        }
        else {
            log.debug("no user id for cart migration");
        }
        return cartResponse;
    }

    private Optional<String> findUserId(Object result) {
        String userId = null;

        // get Identity object from appropriate return object
        Identity identity = null;
        if (result instanceof ProfileResponse) {
            identity = ((ProfileResponse) result).getIdentity();
        }
        else if (result instanceof IdentityResponse) {
            identity = ((IdentityResponse) result).getIdentity();
        }

        // get svoc user id if available, otherwise use wcs user id
        if (identity != null) {
            userId = identity.getSvocCustomerAccountId();

            if (userId == null) {
                userId = identity.getWcsMemberId();
            }
        }

        return userId != null ? Optional.of(userId) : Optional.empty();
    }

    private Cookie[] buildCookieArray(Object[] args, Cookie[] originalReqCookies) {
        Map<String, Cookie> cookieMap = buildResponseCookieMap(args);
        if (originalReqCookies != null) {
            for (Cookie c: originalReqCookies) {
                if (!cookieMap.containsKey(c.getName())) {
                    cookieMap.put(c.getName(), c);
                }
            }
        }

        return cookieMap.values().toArray(new Cookie[cookieMap.size()]);
    }

    private Map<String, Cookie> buildResponseCookieMap(Object[] args) {
        Map<String, Cookie> cookieMap = new HashMap<>();
        Arrays.stream(args)
                .filter(o -> o instanceof HttpServletResponse)
                .map(o -> (HttpServletResponse) o)
                .map(resp -> resp.getHeaders(SETCOOKIE))
                .flatMap(Collection::stream)
                .map(HttpCookie::parse)
                .flatMap(List::stream)
                .forEach(httpCookie -> cookieMap.put(httpCookie.getName(), new Cookie(httpCookie.getName(), httpCookie.getValue())));

        return cookieMap;
    }
}
