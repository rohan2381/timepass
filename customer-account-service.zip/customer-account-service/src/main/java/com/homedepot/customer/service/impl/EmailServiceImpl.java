package com.homedepot.customer.service.impl;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.integration.cca.CCAServiceFacade;
import com.homedepot.customer.model.EmailNotificationInfo;
import com.homedepot.customer.service.IEmailService;
import com.homedepot.customer.util.*;

import lombok.extern.slf4j.Slf4j;

import java.io.UnsupportedEncodingException;
import java.time.Instant;
import java.util.Arrays;
import java.util.Base64;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.*;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * Created by rxb1809 on Dec 26, 2016
 * This class calls CCA facade class to trigger emails. 
 * All methods operations are performed in an async mannner
 */
@Slf4j
@Service
public class EmailServiceImpl implements IEmailService {

    @Autowired
    private CCAServiceFacade ccaServiceFacade;

    @Autowired
    EnvPropertyUtil envProperty;

    @Autowired
    private Environment env;
    
    @Autowired
    private Environment environment;
    
    public static final String CUST_ID_PARAM = "custid=";
    public static final String EMAIL_PARAM = "email=";

    @Override
    @Async("emailTaskExecutor")
    public void sendRegistrationEmail(String custEmailId) {
        EmailNotificationInfo info = new EmailNotificationInfo();
        info.setEmail(custEmailId);
        info.setEmailType(EmailType.WELCOME_EMAIL);
        ccaServiceFacade.sendNotification(info);
    }

    @Override
    @Async("emailTaskExecutor")
    public void sendAccountUpdateEmail(String oldEmail, String email, String firstName) throws CustomerAccountServiceException {

        EmailNotificationInfo info = createEmailNotificationInfo(EmailType.ACCOUNT_UPDATE_EMAIL, oldEmail,
                                                                    email, firstName, null);
        ccaServiceFacade.sendNotification(info);
    }

    @Override
    @Async("emailTaskExecutor")
    public void sendResetPasswordEmail(String email, String svocId, String token) throws CustomerAccountServiceException {
        String svocIdEncoded = null;        
        String wcsHostSecure = null;
        
        try {
            svocIdEncoded = Base64.getEncoder().encodeToString(svocId.getBytes(GlobalConstants.CHARSET_UTF_8));
        } catch (UnsupportedEncodingException e) {
            log.error("Error encoding svoc id "+e); // For now absorb the exception
            svocIdEncoded = svocId;
        }

        
        if(Arrays.stream(environment.getActiveProfiles()).anyMatch(env -> GlobalConstants.SPRING_PFOFILE_DEV.equalsIgnoreCase(env))) {   
            ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if(requestAttributes!=null && requestAttributes.getRequest()!=null 
                    && requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV) !=null){
                THDEnv thdEnv =  (THDEnv)requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV);
                if(thdEnv!=null){
                    wcsHostSecure = thdEnv.getSecureUrl();
                    log.debug("WCS secure host set to "+wcsHostSecure);
                }                            
            }
        }
        
        String path = env.getProperty("resetPwdUrl") + "?"+CUST_ID_PARAM + svocIdEncoded + "&"+EMAIL_PARAM + email + "&token=" + token + "&ts=" + Instant.now().toEpochMilli();

        String resetPwdUrl = String.format("%s://%s/%s", GlobalConstants.HTTPS, wcsHostSecure!=null ? wcsHostSecure : envProperty.getWcsHostSecure(), path);

        EmailNotificationInfo info = createEmailNotificationInfo(EmailType.RESET_PASSWORD_EMAIL, null,
                                                                    email, null, resetPwdUrl);
        ccaServiceFacade.sendNotification(info);
    }
    
    @Override
    @Async("emailTaskExecutor")
    public void sendSetPasswordEmail(String email, String svocId, String token) throws CustomerAccountServiceException {
        String svocIdEncoded = null;
        String wcsHostSecure = null;
        
        try {
            svocIdEncoded = Base64.getEncoder().encodeToString(svocId.getBytes(GlobalConstants.CHARSET_UTF_8));
        } catch (UnsupportedEncodingException e) {
            log.error("Error encoding svoc id "+e); // For now absorb the exception
            svocIdEncoded = svocId;
        }
        if(Arrays.stream(environment.getActiveProfiles()).anyMatch(env -> GlobalConstants.SPRING_PFOFILE_DEV.equalsIgnoreCase(env))) {   
            ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if(requestAttributes!=null && requestAttributes.getRequest()!=null 
                    && requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV) !=null){
                THDEnv thdEnv =  (THDEnv)requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV);
                if(thdEnv!=null){
                    wcsHostSecure = thdEnv.getSecureUrl();
                    log.debug("WCS secure host set to "+wcsHostSecure);
                }                            
            }
        }

        String path = env.getProperty("setPwdUrl") + "?"+CUST_ID_PARAM + svocIdEncoded + "&"+EMAIL_PARAM + email + "&token=" + token + "&ts=" + Instant.now().toEpochMilli();

        String setPwdUrl = String.format("%s://%s/%s", GlobalConstants.HTTPS, wcsHostSecure!=null ? wcsHostSecure : envProperty.getWcsHostSecure(), path);

        EmailNotificationInfo info = createEmailNotificationInfo(EmailType.SET_PASSWORD_EMAIL, null,
                                                                    email, null, setPwdUrl);
        ccaServiceFacade.sendNotification(info);
    }

    @Override
    @Async("emailTaskExecutor")
    public void sendPasswordUpdatedEmail(String email, String firstName) throws CustomerAccountServiceException {

        EmailNotificationInfo info = createEmailNotificationInfo(EmailType.PASSWORD_UPDATED_EMAIL,null,
                                                                    email, firstName, null);
        ccaServiceFacade.sendNotification(info);
    }

    private EmailNotificationInfo createEmailNotificationInfo(EmailType emailType,
                                                              String oldEmail,
                                                              String email,
                                                              String firstName,
                                                              String resetPwdUrl) throws
            CustomerAccountServiceException {

        EmailNotificationInfo info = new EmailNotificationInfo();
        info.setOldEmail(oldEmail);
        info.setEmail(email);
        info.setEmailType(emailType);
        info.setFirstName(firstName);
        info.setResetPwdUrl(resetPwdUrl);
        return info;
    }

}
