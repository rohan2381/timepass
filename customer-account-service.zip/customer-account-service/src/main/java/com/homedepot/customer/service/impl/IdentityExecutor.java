package com.homedepot.customer.service.impl;

import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.model.UserIdentity;
import com.homedepot.customer.repository.IIdentityRepository;
import com.homedepot.customer.request.IdentityRequest;
import com.homedepot.customer.util.Resource;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by Nitin Ware on 9/15/16.
 */
@Service
@Slf4j
public class IdentityExecutor {

    @Autowired
    IIdentityRepository identityRepository;

    @Async("identityTaskExecutor")
    public Future<UserIdentity> asyncIAMAuthenticateUser(IdentityRequest authRequest) throws CustomerAccountServiceException {
        UserIdentity userIdentity = null;
        try {
            // Step 1 IAM auth call
            String sessionToken = identityRepository.authenticate(authRequest.getLogonId(),
                    authRequest.getPassword());
            // Step 2: IAM get id from session call
            String svocId = identityRepository.getSvocId(sessionToken);
            userIdentity = new UserIdentity();
            userIdentity.setCustomerAccountId(svocId);
            userIdentity.setSessionToken(sessionToken);
        } catch (RepositoryException ex) {
            ex.getErrors().setResource(Resource.DEFAULT);
            throw new CustomerAccountServiceException(ex.getErrors(), ex.getHttpStatus(), ex);
        }
        return new AsyncResult<>(userIdentity);
    }

}
