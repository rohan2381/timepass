package com.homedepot.customer.service.impl;

import com.homedepot.customer.datasync.profile.ProfileFallBackExecutor;
import com.homedepot.customer.datasync.profile.ProfileSyncExecutor;
import com.homedepot.customer.datasync.util.*;
import com.homedepot.customer.exception.AuthenticationException;
import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.exception.SVOCUnavailableException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.exception.error.IdentityErrorCode;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.integration.wcs.dto.WCSUserIdentity;
import com.homedepot.customer.model.*;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.repository.IIdentityRepository;
import com.homedepot.customer.repository.IProfileRepository;
import com.homedepot.customer.repository.IStoreSearchRepository;
import com.homedepot.customer.request.ClientAuthRequest;
import com.homedepot.customer.request.IdentityRequest;
import com.homedepot.customer.request.ProfileRequest;
import com.homedepot.customer.service.IEmailService;
import com.homedepot.customer.service.IIdentityService;
import com.homedepot.customer.util.*;
import com.homedepot.customer.validator.BaseRequestValidator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.aspectj.lang.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.servlet.http.*;

/**
 * Created by rxb1809 on Apr 27, 2016
 */
@Service
@Slf4j
public class IdentityServiceImpl implements IIdentityService {

    @Autowired
    @Qualifier(value = "identityvalidator")
    BaseRequestValidator<IdentityRequest> requestValidator;

    @Autowired
    IIdentityRepository identityRepository;

    @Autowired
    private IProfileRepository profileRepository;

    @Autowired
    IdentityExecutor identityTaskExecutor;

    @Autowired
    ProfileSyncExecutor profileSyncExecutor;

    @Autowired
    @Qualifier("iamErrorCodeMapResource")
    private ResourceBundleMessageSource errorCodeSource;

    @Autowired
    private EnvPropertyUtil envProperty;

    @Autowired
    private IEmailService emailService;

    @Autowired
    private CustomerAccountRequestContext requestContext;

    @Autowired
    private SessionHelper sessionHelper;

    @Autowired
    FeatureSwitchUtil featureSwitchUtil;

    @Autowired
    ProfileFallBackExecutor profileFallBackExecutor;

    @Autowired
    CustomerAccountLogUtil logUtil;

    @Autowired
    AccountRequestHelper accountHelper;

    @Autowired
    IStoreSearchRepository storeSearchRepository;

    @Override
    public UserIdentity authenticateUser(IdentityRequest authRequest) throws CustomerAccountServiceException {

        requestValidator.validate(authRequest, HttpMethod.POST);
        String emailAddress = authRequest.getLogonId();
        log.debug("authenticateUser, logonId: {}", emailAddress);
        UserIdentity userIdentity = null;
        WCSUserIdentity wcsUserIdentity = null;
        // Kick off asynchronous login's to IAM and WCS.
        Future<UserIdentity> iamLoginResponseFuture = identityTaskExecutor.asyncIAMAuthenticateUser(authRequest);
        Future<WCSUserIdentity> wcsLoginResponseFuture = null;
        boolean wcsBkup = featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE);
        if (wcsBkup) {
            wcsLoginResponseFuture = profileSyncExecutor.asyncWCSAuthenticateUser(authRequest, requestContext.getRequest().getCookies());
        }
        boolean iamSuccess = false;
        boolean wcsSuccess = false;
        Exception iamEx = null;
        Exception wcsEx = null;
        try {
            userIdentity = iamLoginResponseFuture.get(envProperty.getIamLoginTimeout(), TimeUnit.SECONDS);
            userIdentity.setLogonId(emailAddress);
            iamSuccess = true;
        } catch (TimeoutException | InterruptedException | ExecutionException ex) {
            iamEx = ex;
        }
        if (wcsBkup) {
            try {
                if (userIdentity == null) {
                    userIdentity = new UserIdentity();
                }
                wcsUserIdentity = wcsLoginResponseFuture.get(envProperty.getWcsLoginTimeout(), TimeUnit.SECONDS);
                userIdentity.setWcsUserIdentity(wcsUserIdentity);
                wcsSuccess = true;
            } catch (TimeoutException | InterruptedException | ExecutionException ex) {
                wcsEx = ex;
            }
        }

        // Log the various statuses for easier metrics
        logUtil.logStatus("Authentication", authRequest.getLogonId(), iamSuccess, wcsSuccess, wcsBkup, iamEx, wcsEx);

        requestContext.setLocalStore(getLocalStore(userIdentity, iamSuccess, wcsUserIdentity, wcsSuccess));

        if (!iamSuccess && !wcsSuccess) {
            handleException(iamEx, wcsEx);
        }

        return userIdentity;
    }

    private Store getLocalStore(UserIdentity userIdentity, boolean iamSuccess, WCSUserIdentity wcsUserIdentity, boolean wcsSuccess) {
        List<Store> localStoreList = new ArrayList<>();
        try {
            if (wcsSuccess) {
                // If WCS Login success, set user local Store from WCS in the request context.
                Optional.ofNullable(wcsUserIdentity.getAccount().getProfile()).ifPresent(profile -> {
                    Optional.ofNullable(profile.getLocalStoreId()).ifPresent(storeId -> {
                        Store localStore = new Store();
                        localStore.setStoreId(storeId);
                        Optional.ofNullable(profile.getLocalStoreAddress()).ifPresent(localStoreAddress -> {
                            localStore.setName(localStoreAddress.getStoreName());
                            localStore.setCity(localStoreAddress.getPostalData().getCity());
                            localStore.setState(localStoreAddress.getPostalData().getStateProvinence());
                            localStoreList.add(localStore);
                        });
                    });
                });
            } else if (iamSuccess) {
                // If Only IAM Login Success, set user local Store from SVOC in the request context.
                Account account = profileRepository.retrieve(userIdentity.getCustomerAccountId());
                String localStoreId = account.getProfile().getLocalStoreId();
                Optional.ofNullable(account.getProfile()).map(Profile::getName).map(Name::getFirstName)
                        .ifPresent(n -> requestContext.setFirstName(WordUtils.capitalizeFully(n)));
                if (StringUtils.isNotBlank(localStoreId)) {
                    Optional<Store> storeOptional = storeSearchRepository.retrieveStoreById(localStoreId);
                    storeOptional.map(localStoreList::add);
                }
            }
        } catch (CustomerAccountServiceException ex) {
            log.error("Error while setting local store in response cookies for user ", ExceptionUtils.getRootCause(ex));
        }
        return localStoreList.stream().findFirst().orElse(null);
    }

    @Override
    public LogoutInfo logOutUser() throws CustomerAccountServiceException {

        String iamAuthToken = requestContext.getAuthToken();
        log.debug("logOutUser - IAM auth token: {}", iamAuthToken);
        LogoutInfo logoutInfo = new LogoutInfo();
        boolean iamSuccess = false;
        boolean wcsSuccess = false;
        Exception iamEx = null;
        Exception wcsEx = null;
        try {
            IAMLogoutInfo iamLogoutInfo = identityRepository.logout(iamAuthToken);
            logoutInfo.setIamLogoutInfo(iamLogoutInfo);
            iamSuccess = true;
        } catch (RepositoryException ex) {
            iamEx = ex;
        }
        boolean wcsBkup = featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE);
        if (wcsBkup) {
            try {
                if (ArrayUtils.isNotEmpty(requestContext.getRequest().getCookies())) {
                    String wcsAuthToken = sessionHelper.extractWCSTokenFromCookie(requestContext.getRequest().getCookies());
                    log.debug("logOutUser - WCS auth token: {}", wcsAuthToken);
                    WCSLogoutInfo wcsLogoutInfo = identityRepository.wcsLogoutUser(wcsAuthToken);
                    logoutInfo.setWcsLogoutInfo(wcsLogoutInfo);
                    wcsSuccess = true;
                }
            } catch (Exception ex) {
                wcsEx = ex;
            }
        }

        // Log the various statuses for easier metrics
        logUtil.logStatus("Logout", null, iamSuccess, wcsSuccess, wcsBkup, iamEx, wcsEx);

        if (!iamSuccess && !wcsSuccess) {
            handleException(iamEx, wcsEx);
        }
        return logoutInfo;
    }

    private void handleException(Exception iamEx, Exception wcsEx) throws CustomerAccountServiceException {

        HttpStatus iamHttpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        HttpStatus wcsHttpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        CustomerAccountServiceException iamExCause = null;
        CustomerAccountServiceException wcsExCause = null;
        // The exception thrown from async login call is propagated to calling thread, wrapped under ExecutionException.
        // ex could be one of TimeoutException | InterruptedException | ExecutionException(CustomerAccountServiceException)
        if (iamEx != null && iamEx.getCause() instanceof CustomerAccountServiceException) {
            iamExCause = (CustomerAccountServiceException) iamEx.getCause();
            iamHttpStatus = iamExCause.getHttpStatus();
        }
        if (wcsEx != null && wcsEx.getCause() instanceof CustomerAccountServiceException) {
            wcsExCause = (CustomerAccountServiceException) wcsEx.getCause();
            wcsHttpStatus = wcsExCause.getHttpStatus();
        }
        CustomerAccountServiceException excToBeThrown;
        if (iamHttpStatus.is4xxClientError()) { // IAM is given priority over WCS
            excToBeThrown = iamExCause;
        } else if (wcsHttpStatus.is4xxClientError()) { // Fallback to WCS 400 error
            excToBeThrown = wcsExCause;
        } else { // Default to 500 error code
            Errors errors = createErrors(ErrorCode.SYSTEM_ERROR);
            excToBeThrown = new CustomerAccountServiceException(errors, HttpStatus.INTERNAL_SERVER_ERROR, iamEx);
        }
        throw excToBeThrown;
    }

    @Override
    public Identity updateIdentity(IdentityRequest updateIdentityRequest, String customerAccountId) throws CustomerAccountServiceException {

        log.debug("updateIdentity - updateIdentityRequest: {}", updateIdentityRequest);
        Identity updateIdentityResponse = null;
        requestValidator.validate(updateIdentityRequest, HttpMethod.PUT);
        if (requestContext.isWCSRequest()) {
            return profileFallBackExecutor.updateIdentity(updateIdentityRequest);
        }
        boolean emailUpdateSuccessful = false;
        boolean pwdUpdateSuccessful = false;
        Account svocUpdateResp = null;
        String iamServiceAuthToken = identityRepository.getServiceAuthToken(envProperty.getIamServiceUser(),
                                                                            envProperty.getIamServicePassword());
        if (isEmailUpdateReq(updateIdentityRequest)) {
            log.debug("Updating email in SVOC - {}", updateIdentityRequest.getNewLogonId());
            svocUpdateResp = updateEmailInSVOC(updateIdentityRequest.getNewLogonId(),
                    updateIdentityRequest.getEmailLastModifiedDate(),
                    customerAccountId);
            updateIdentityResponse = populateResponse(svocUpdateResp);
            log.debug("Updating email in IAM");
            updateEmailInIAM(updateIdentityRequest, customerAccountId, svocUpdateResp, iamServiceAuthToken);
            emailUpdateSuccessful = true;
        }
        if (isPasswordUpdateReq(updateIdentityRequest)) {
            log.debug("Updating password in IAM");
            identityRepository.updatePassword(updateIdentityRequest, customerAccountId, iamServiceAuthToken);
            pwdUpdateSuccessful = true;
        }
        boolean wcsBkup = featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE);
        log.debug("WCS backup feature is set to : " + wcsBkup);
        if (wcsBkup) {
            String wcsMemberId = accountHelper.lookUpWCSId(customerAccountId);
            log.debug("WCS Profile exists :" + (wcsMemberId != null));
            if ((wcsMemberId != null) && (isEmailUpdateReq(updateIdentityRequest) || isPasswordUpdateReq(updateIdentityRequest))) {
                log.debug("Calling WCS CSR api to update email and/or password");
                Account wcsAccount = updateWCSProfile(customerAccountId, updateIdentityRequest, svocUpdateResp);
                if (wcsAccount == null && isEmailUpdateReq(updateIdentityRequest)) {
                    log.error("WCS Email Update Failed for " + customerAccountId);
                    log.debug("Calling SVOC to revert email");
                    updateEmailInSVOC(updateIdentityRequest.getLogonId(), svocUpdateResp.getProfile().getLastModifiedDate(),
                            customerAccountId);
                    log.debug("Calling IAM to revert email");
                    revertEmailInIAM(updateIdentityRequest, customerAccountId, iamServiceAuthToken);
                    Errors errors = createErrors(ErrorCode.SYSTEM_ERROR);
                    throw new CustomerAccountServiceException(errors, HttpStatus.INTERNAL_SERVER_ERROR);
                }
                if (wcsAccount == null && isPasswordUpdateReq(updateIdentityRequest)) {
                    log.error("WCS Password Update Failed for " + customerAccountId);
                    Errors errors = createErrors(ErrorCode.SYSTEM_ERROR);
                    throw new CustomerAccountServiceException(errors, HttpStatus.INTERNAL_SERVER_ERROR);
                }
            }
        }
        log.debug("Sending notification about email and/or password update");
        sendNotification(updateIdentityRequest, emailUpdateSuccessful, pwdUpdateSuccessful);
        return updateIdentityResponse;
    }


    private void sendNotification(IdentityRequest request,
                                  boolean emailUpdateSuccess,
                                  boolean pwdUpdateSuccess) throws CustomerAccountServiceException {

        if (isEmailUpdateReq(request) && emailUpdateSuccess) {
            emailService.sendAccountUpdateEmail(request.getLogonId(), request.getNewLogonId(), request.getFirstName());
        }
        if (isPasswordUpdateReq(request) && pwdUpdateSuccess) {
            emailService.sendPasswordUpdatedEmail(request.getLogonId(), request.getFirstName());
        }
    }

    private void revertEmailInIAM(IdentityRequest updateIdentityRequest,
                                  String customerAccountId, String iamServiceAuthToken) throws RepositoryException {

        IdentityRequest identityRequest = new IdentityRequest();
        identityRequest.setNewLogonId(updateIdentityRequest.getLogonId());
        identityRepository.updateEmail(identityRequest, customerAccountId, iamServiceAuthToken);
    }

    private Account updateWCSProfile(String customerAccountId, IdentityRequest identityRequest, Account savedSvocAccount) {

        Profile profile = new Profile();
        profile.setEmailId(identityRequest.getNewLogonId());
        // if password is null then String.valueOf() will throw NullPointerException
        Optional.ofNullable(identityRequest.getNewPassword()).ifPresent(newPassword -> {
            profile.setPassword(String.valueOf(newPassword));
            profile.setConfirmPassword(String.valueOf(newPassword));
        });
        Account account = new Account();
        account.setProfile(profile);
        ProfileRequest profileRequest = new ProfileRequest();
        profileRequest.setAccount(account);
        return profileSyncExecutor.updateUserProfile(customerAccountId, profileRequest, savedSvocAccount, false);
    }

    private boolean isEmailUpdateReq(IdentityRequest req) {

        return StringUtils.isNotBlank(req.getLogonId()) &&
                StringUtils.isNotBlank(req.getNewLogonId()) &&
                !StringUtils.equalsIgnoreCase(req.getLogonId(), req.getNewLogonId());
    }

    private boolean isPasswordUpdateReq(IdentityRequest req) {

        return ArrayUtils.isNotEmpty(req.getNewPassword());
    }

    private Identity populateResponse(Account account) {

        Identity identity = new Identity();
        identity.setLogonId(account.getProfile().getEmailId());
        identity.setAccountLastModifiedDate(account.getLastModifiedDate());
        identity.setEmailLastModifiedDate(account.getProfile().getLastModifiedDate());
        return identity;
    }

    private Account updateEmailInSVOC(String email, Date emailUpdateDate, String customerAccountId)
            throws RepositoryException, SVOCUnavailableException {
        Account accountResp = null;
        try {
            Profile profile = new Profile();
            profile.setEmailId(email);
            profile.setEmailContactMethodEnumeration("EMAIL");
            profile.setLastModifiedDate(emailUpdateDate);
            Account account = new Account();
            account.setProfile(profile);
            account.setCustomerAccountId(customerAccountId);
            accountResp = profileRepository.update(customerAccountId, account);
        } catch (RepositoryException | SVOCUnavailableException ex) {
            log.error("SVOC Email Update Failed for " + customerAccountId + ", Cause -> " + ExceptionUtils.getRootCauseMessage(ex));
            throw ex;
        }

        return accountResp;
    }

    private void updateEmailInIAM(IdentityRequest updateEmailRequest, String customerAccountId,
                                  Account svocUpdateResp, String iamServiceAuthToken) throws RepositoryException, SVOCUnavailableException {

        try {
            identityRepository.updateEmail(updateEmailRequest, customerAccountId, iamServiceAuthToken);
        } catch (RepositoryException ex) {
            try {
                log.error("IAM Email Update Failed for " + customerAccountId + ", reverting the SVOC email change, Cause -> " + ExceptionUtils.getRootCauseMessage(ex));
                Account svocEmailUpdate = new Account();
                svocEmailUpdate.setCustomerAccountId(customerAccountId);
                Profile profile = new Profile();
                profile.setEmailId(updateEmailRequest.getLogonId());
                profile.setLastModifiedDate(svocUpdateResp.getProfile().getLastModifiedDate());
                profile.setEmailContactMethodEnumeration(svocUpdateResp.getProfile().getEmailContactMethodEnumeration());
                svocEmailUpdate.setProfile(profile);
                profileRepository.update(customerAccountId, svocEmailUpdate);
            } catch (RepositoryException | SVOCUnavailableException rex) {
                log.error("Failed to revert back email in SVOC, Root Cause: {}" + ExceptionUtils.getRootCauseMessage(rex));
            }
            throw ex;
        }
    }

    @Override
    public Identity validateUserSession() throws CustomerAccountServiceException {
        Identity identity = new Identity();

        boolean isSessionValid = sessionHelper.validateUserSession(requestContext.getRequest());
        if (isSessionValid) {
            switch (requestContext.getSessionAuth()) {
                case IAM:
                    identity.setSvocCustomerAccountId(requestContext.getSvocCustomerAccountId());
                    break;

                case WCS:
                    identity.setWcsMemberId(requestContext.getWcsMemberId());
                    break;

                default:
                    break;
            }
        } else {
            throw new AuthenticationException(createErrors(IdentityErrorCode.USER_NOT_AUTHORIZED.getCode()));
        }

        return identity;
    }

    private Errors createErrors(String errorCode) {
        Error error = new Error();
        error.setErrorCode(errorCodeSource.getMessage(errorCode, null, ErrorCode.SYSTEM_ERROR, null));
        Errors errors = new Errors();
        errors.setErrors(Collections.singletonList(error));
        return errors;
    }

    @Override
    public AuthEntity validateClientAuth(ClientAuthRequest clientAuthRequest) throws CustomerAccountServiceException {
        AuthEntity authEntity = new AuthEntity();

        if (! sessionHelper.validateClientAuth(clientAuthRequest)) {
            throw new AuthenticationException(createErrors(IdentityErrorCode.USER_NOT_AUTHORIZED.getCode()));
        }

        authEntity.setAuthTokenValid(Boolean.TRUE);
        return authEntity;
    }

    @Override
    public AuthEntity getClientToken(ClientAuthRequest clientAuthRequest) throws CustomerAccountServiceException {
        AuthEntity authEntity = new AuthEntity();
        authEntity.setClientAuthToken(sessionHelper.generateAuthToken(clientAuthRequest));
        return authEntity;
    }


}
