package com.homedepot.customer.service.impl;

import java.util.*;
import javax.servlet.http.*;
import org.apache.commons.lang3.exception.*;
import org.springframework.beans.factory.annotation.*;
import org.springframework.scheduling.annotation.*;
import org.springframework.stereotype.*;
import com.homedepot.customer.model.*;
import com.homedepot.customer.repository.*;
import com.homedepot.customer.response.*;
import lombok.extern.slf4j.*;

@Service
@Slf4j
public class MyListTaskExecutor {

    @Autowired
    IMyListRepository myListRepository;

    @Async("listTaskExecutor")
    public void asyncMigrateList(Object result, Cookie[] reqCookies, Cookie[] respCookies) {
        try {
            Optional<String> userIdOptional = findUserId(result);

            if (userIdOptional.isPresent()) {
                String userId = userIdOptional.get();
                log.debug("migrate list after customer login or registration for userId: {}", userId);
                myListRepository.migrateMyList(userId, reqCookies, respCookies);
            } else {
                log.debug("no user id for mylist migration");
            }
        }
        catch (Exception e) {
            Throwable rootCause = ExceptionUtils.getRootCause(e);
            log.error("async migrate list exception: ", rootCause != null ? rootCause : e);
        }
    }

    private Optional<String> findUserId(Object result) {
        String userId = null;
        // get Identity object from appropriate return object
        Identity identity = null;
        if (result instanceof ProfileResponse) {
            identity = ((ProfileResponse) result).getIdentity();
        }
        else if (result instanceof IdentityResponse) {
            identity = ((IdentityResponse) result).getIdentity();
        }

        // get svoc user id if available, otherwise use wcs user id
        if (identity != null) {
            userId = identity.getSvocCustomerAccountId();

            if (userId == null) {
                userId = identity.getWcsMemberId();
            }
        }
        return userId != null ? Optional.of(userId) : Optional.empty();
    }

}
