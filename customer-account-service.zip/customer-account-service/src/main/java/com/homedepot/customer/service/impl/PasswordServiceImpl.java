package com.homedepot.customer.service.impl;

import java.util.Random;
import java.util.UUID;

import org.apache.commons.lang3.BooleanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.homedepot.customer.datasync.profile.ProfileSyncExecutor;
import com.homedepot.customer.datasync.util.DataSyncUtil;
import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.integration.wcs.WCSProfileServiceFacade;
import com.homedepot.customer.model.Account;
import com.homedepot.customer.model.Profile;
import com.homedepot.customer.repository.IIdentityRepository;
import com.homedepot.customer.repository.IProfileRepository;
import com.homedepot.customer.request.PasswordRequest;
import com.homedepot.customer.request.ProfileRequest;
import com.homedepot.customer.service.IEmailService;
import com.homedepot.customer.service.IPasswordService;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.validator.BaseRequestValidator;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxm4390 on Jan 18, 2017
 *
 */
@Service
@Slf4j
public class PasswordServiceImpl implements IPasswordService {

    @Autowired
    @Qualifier(value="setpasswordrequestvalidator")
    BaseRequestValidator<PasswordRequest> setPasswordRequestValidator;

    @Autowired
    IIdentityRepository identityRepository;

    @Autowired
    IProfileRepository profileRepository;

    @Autowired
    CustomerAccountRequestContext reqContext;

    @Autowired
    @Qualifier(value="resetpwdrequestvalidator")
    BaseRequestValidator<PasswordRequest> resetpasswordrequestvalidator;

    @Autowired
    private IEmailService emailService;

    @Autowired
    private ProfileSyncExecutor profileSyncExecutor;

    @Autowired
    private EnvPropertyUtil envProperty;
    
    @Autowired
    WCSProfileServiceFacade wcsProfileFacade;
    
    @Autowired
    private DataSyncUtil dataSyncUtil;
    
    private static final String RANDOM = "randomgen@";

    @Override
    public void resetUserPassword(PasswordRequest resetPwdRequest) throws CustomerAccountServiceException {    
        resetpasswordrequestvalidator.validate(resetPwdRequest, HttpMethod.POST);
        log.info("Reset password for email: "+reqContext.getSvocEmailId() +" svocid: "+reqContext.getSvocId());
        
        //Step 1 - Reset User Password.
        Boolean resetPwdStatus = identityRepository.resetPassword(resetPwdRequest);
        //Step 2 - Activate/Unlock User Account.
        String serviceAuthToken = identityRepository.getServiceAuthToken(envProperty.getIamServiceUser(),
                                    envProperty.getIamServicePassword());
        // unlock account
        identityRepository.changeAccountStatus(reqContext.getSvocId(), serviceAuthToken, GlobalConstants.IAM_LOCK_ACCOUNT_ACTIVE);
        //Step 3 - Sync Password to WCS and Send email confirmation to user on successful password reset.
        if(BooleanUtils.isTrue(resetPwdStatus)) {
            //ProfileRequest profileRequest = getWCSPasswordUpdateRequest(resetPwdRequest);
            //profileSyncExecutor.updateUserProfileAsync(reqContext.getSvocId(), profileRequest, null, true);
            emailService.sendPasswordUpdatedEmail(reqContext.getSvocEmailId(), reqContext.getFirstName());
            dataSyncUtil.pauseAroundDataSync(); 
        }
    }

    @Override
    public void resetUserPasswordEmail(PasswordRequest resetPwdEmailRequest) throws CustomerAccountServiceException {
        resetpasswordrequestvalidator.validate(resetPwdEmailRequest, HttpMethod.GET);
 
        if(reqContext.isWCSRequest()){ // Takes care of duplicate merge accounts or those who dont have svoc id cross ref mapping
            log.info("Trigger password email in WCS for email: "+resetPwdEmailRequest.getEmail());
            Account wcsAccountProfile = new Account();
            Profile wcsProfile = new Profile();
            wcsProfile.setEmailId(resetPwdEmailRequest.getEmail());
            wcsAccountProfile.setProfile(wcsProfile);
            wcsProfileFacade.sendForgotPasswordEmail(wcsAccountProfile);
        }else{       
            log.info("Trigger password email in IAM for email: "+resetPwdEmailRequest.getEmail());
            // Step 1: Get Reset Password Token from IAM for given email address.
            String iamToken = identityRepository.getResetPasswordToken(reqContext.getSvocEmailId());
            
            // Step 2: Trigger CCA Email notification by passing IAM Token.
            emailService.sendResetPasswordEmail(reqContext.getSvocEmailId(), reqContext.getSvocId(), iamToken);
            dataSyncUtil.pauseAroundDataSync(); 
        }
    }
    
    @Override
    // New Set Password Email flow
    public void setPasswordEmail(PasswordRequest setPasswordRequest) throws CustomerAccountServiceException{
        log.info("Trigger password email for email: "+setPasswordRequest.getEmail());
        
        // Step 1: Validate the request
        setPasswordRequestValidator.validate(setPasswordRequest, HttpMethod.GET);
        
        // Step 2: Register the user with a dummy password in IAM
        String defaultPassRandom = new StringBuilder(RANDOM).append(String.valueOf(new Random().nextInt(1000) + 1)).toString();
        identityRepository.register(reqContext.getSvocId(), reqContext.getSvocEmailId(),defaultPassRandom.toCharArray());
        
        // Step 3: Get Reset Password Token from IAM for given email address.
        String iamToken = identityRepository.getResetPasswordToken(reqContext.getSvocEmailId());
        
        // Step 4: Trigger CCA Email notification by passing IAM Token.
        emailService.sendSetPasswordEmail(reqContext.getSvocEmailId(), reqContext.getSvocId(), iamToken);
        dataSyncUtil.pauseAroundDataSync(); 
    }
    
    @Override
    public void setPassword(PasswordRequest setPasswordRequest) throws CustomerAccountServiceException {        
        // Step 1: Validate the request
        setPasswordRequestValidator.validate(setPasswordRequest, HttpMethod.POST);
        
        log.info("Set password for email: "+reqContext.getSvocEmailId() +" svocid: "+reqContext.getSvocId());
        
        //Step 2: Update User Password.
        Boolean resetPwdStatus = identityRepository.resetPassword(setPasswordRequest);
        
        //Step 3: Sync Password to WCS and Send email confirmation to user on successful password reset.
        if(BooleanUtils.isTrue(resetPwdStatus)) {
            //ProfileRequest profileRequest = getWCSPasswordUpdateRequest(setPasswordRequest);
            //profileSyncExecutor.updateUserProfileAsync(reqContext.getSvocId(), profileRequest, null, true);
            emailService.sendPasswordUpdatedEmail(reqContext.getSvocEmailId(), reqContext.getFirstName());
            dataSyncUtil.pauseAroundDataSync(); 
        }
    }  
    
    private ProfileRequest getWCSPasswordUpdateRequest(PasswordRequest passwordRequest) {
        Profile profile = new Profile();
        profile.setPassword(String.valueOf(passwordRequest.getPassword()));
        profile.setConfirmPassword(String.valueOf(passwordRequest.getConfirmPassword()));
        Account account = new Account();
        account.setProfile(profile);
        ProfileRequest profileRequest = new ProfileRequest();
        profileRequest.setAccount(account);
        return profileRequest;
    }

}
