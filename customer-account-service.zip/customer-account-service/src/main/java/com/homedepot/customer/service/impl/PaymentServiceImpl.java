package com.homedepot.customer.service.impl;

import com.homedepot.customer.datasync.payment.PaymentFallBackExecutor;
import com.homedepot.customer.exception.*;
import com.homedepot.customer.exception.error.PaymentErrorCode;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.integration.payment.PaymentResponseErrorHandler;
import com.homedepot.customer.model.*;
import com.homedepot.customer.repository.IAddressRepository;
import com.homedepot.customer.repository.IPaymentRepository;
import com.homedepot.customer.request.AddressRequest;
import com.homedepot.customer.request.PaymentCardRequest;
import com.homedepot.customer.service.IPaymentService;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.util.PaginationUtil;
import com.homedepot.customer.util.PaymentCardBrand;
import com.homedepot.customer.util.PaymentCardType;
import com.homedepot.customer.validator.AddressRequestValidator;
import com.homedepot.customer.validator.PaymentCardValidator;
import com.homedepot.customer.validator.PaymentRequestValidator;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Created by rxb1809 on Apr 27, 2016
 */
@Service
@Slf4j
public class PaymentServiceImpl implements IPaymentService {

    @Autowired
    @Qualifier(value = "paymentvalidator")
    PaymentRequestValidator requestValidator;

    @Autowired
    @Qualifier(value = "addressvalidator")
    AddressRequestValidator addressValidator;

    @Autowired
    @Qualifier(value = "paymentCardValidator")
    PaymentCardValidator paymentCardValidator;

    @Autowired
    private PaymentResponseErrorHandler errorHandler;

    @Autowired
    IPaymentRepository paymentRepository;

    @Autowired
    IAddressRepository addressRepository;
        
    @Autowired
    CustomerAccountRequestContext reqContext;
    
    @Autowired
    private PaymentFallBackExecutor paymentFallbackExecutor;
    
    @Autowired
    PaginationUtil paginationUtil;

    /*@HystrixCommand(commandKey="getAllPaymentCardsFromXREF",
            fallbackMethod = "getAllPaymentCardsFromWCS",
            ignoreExceptions={RepositoryException.class, GenericSystemException.class, AuthenticationException.class,
                    InvalidRequestException.class, IntegrationException.class},
            commandProperties = {
                    @HystrixProperty(name = "execution.isolation.strategy", value = "SEMAPHORE"),
                    @HystrixProperty(name = "execution.timeout.enabled", value = "false")
            })*/
    @Override
    public Map<String, Object> getAllPaymentCardsWithFallback(PaymentCardRequest paymentCardRequest, String customerAccountId)
            throws CustomerAccountServiceException {
        return getAllPaymentCards(paymentCardRequest, customerAccountId);
    }

    @Override
    public Map<String, Object> getAllPaymentCards(PaymentCardRequest paymentCardRequest, String customerAccountId)
            throws CustomerAccountServiceException {

        if(reqContext.isWCSRequest()){
            return getAllPaymentCardsFromWCS(paymentCardRequest, customerAccountId, null);
        }
        
        log.debug("Calling getAllUserPaymentCards() method with customerAccountId: {}", customerAccountId);

        requestValidator.validate(paymentCardRequest, HttpMethod.GET);

        Map<String, Object> paymentCardMap = paymentRepository.retrieveAll(paymentCardRequest, customerAccountId);

        List<PaymentCard> paymentCardList = (List<PaymentCard>) paymentCardMap.get(GlobalConstants.PAYMENTCARDS);

        paymentCardList.stream().forEach(paymentCard -> paymentCard.setIsReqServedFromWCS(false));

        List<String> validSvocAddressIds = paymentCardList.stream().filter(paymentCard1 -> paymentCard1.getBillingAddress().getAddrIdentifier() != 0)
                .map(paymentCard -> String.valueOf(paymentCard.getBillingAddress().getAddrIdentifier()))
                .collect(Collectors.toList());


        List<Address> addresses = addressRepository.retrieveById(customerAccountId, validSvocAddressIds);
        for (PaymentCard paymentCard : paymentCardList) {
            boolean addressAvailable = false;
            if (paymentCard.getBillingAddress() != null) {
                Integer addressId = paymentCard.getBillingAddress().getAddrIdentifier();
                for (Address address : addresses) {
                    if (address.getAddrIdentifier().compareTo(addressId) == 0) {
                        paymentCard.setBillingAddress(address);
                        addressAvailable = true;
                        break;
                    }
                }

                if (!addressAvailable || addressId == 0) {
                    Errors errors = errorHandler
                            .createErrors(PaymentErrorCode.INVALID_BILLING_ADDRESS_MISSING.getCode());
                    paymentCard.getBillingAddress().setAddrIdentifier(null);
                    paymentCard.getBillingAddress().setErrors(errors.getErrors());

                }
            }
        }


        return paymentCardMap;
    }

    /*@HystrixCommand(commandKey="createPaymentCardInXREF",
            fallbackMethod = "createPaymentCardInWCS",
            ignoreExceptions={RepositoryException.class, GenericSystemException.class, AuthenticationException.class,
                    InvalidRequestException.class, IntegrationException.class},
            commandProperties = {
                    @HystrixProperty(name = "execution.isolation.strategy", value = "SEMAPHORE"),
                    @HystrixProperty(name = "execution.timeout.enabled", value = "false")
            })*/
    @Override
    public List<PaymentCard> createUserPaymentCard(String customerAccountId, PaymentCards paymentCards)
            throws CustomerAccountServiceException {

        log.debug("Start createUserPaymentCard() method with customerAccountId: {}", customerAccountId);

        if(reqContext.isWCSRequest()){
            return createPaymentCardInWCS(customerAccountId, paymentCards, null);
        }

        paymentCardValidator.validate(paymentCards, HttpMethod.POST);
        PaymentCard paymentCard = paymentCards.getPaymentCard().get(0);
        Address address = paymentCard.getBillingAddress();

        XRefInfo xRefInfo = paymentRepository.retrieveXRefInfo(
                StringUtils.substring(paymentCard.getCardNumber(), 0, 16), paymentCard.getPieEncryption());
        paymentCard.setXrefCardNumber(xRefInfo.getXrefNbr()); // Set the xRef number

        paymentCard.setCardType(this.getCardType(paymentCard.getCardBrand(), xRefInfo.getRptPaymtMethCd()));
        saveAddress(customerAccountId, address);
        PaymentCard savedPaymentCard = paymentRepository.save(customerAccountId, paymentCard);
        savedPaymentCard.setBillingAddress(address);
        savedPaymentCard.setIsReqServedFromWCS(false);

        return Collections.singletonList(savedPaymentCard);
    }

    @Override
    public List<PaymentCard> getUserPaymentCardById(String customerAccountId, String paymentCardId)
            throws CustomerAccountServiceException {

        log.debug("Calling getUserPaymentCardById()  with customerAccountId: {}", customerAccountId);
        List<PaymentCard> paymentCards = paymentRepository.retrieveById(customerAccountId,
                Collections.singletonList(paymentCardId));

        for (PaymentCard paymentCard : paymentCards) {
            if (paymentCard.getBillingAddress() != null) {
                String addressId = String.valueOf(paymentCard.getBillingAddress().getAddrIdentifier());
                List<Address> addresses = null;
                if(paymentCard.getBillingAddress().getAddrIdentifier() != 0) {
                    addresses = addressRepository.retrieveById(customerAccountId,
                            Collections.singletonList(addressId));
                }
                if (CollectionUtils.isNotEmpty(addresses)) {
                    paymentCard.setBillingAddress(addresses.get(0));
                } else {
                    Errors errors = errorHandler
                            .createErrors(PaymentErrorCode.INVALID_BILLING_ADDRESS_MISSING.getCode());
                    paymentCard.getBillingAddress().setAddrIdentifier(null);
                    paymentCard.getBillingAddress().setErrors(errors.getErrors());
                }
            }
        }
        return paymentCards;
    }

    /*@HystrixCommand(commandKey="updatePaymentCardInXREF",
            fallbackMethod = "updatePaymentCardInWCS",
            ignoreExceptions={RepositoryException.class, GenericSystemException.class, AuthenticationException.class,
                    InvalidRequestException.class, IntegrationException.class},
            commandProperties = {
                    @HystrixProperty(name = "execution.isolation.strategy", value = "SEMAPHORE"),
                    @HystrixProperty(name = "execution.timeout.enabled", value = "false")
            })*/
    @Override
    public List<PaymentCard> updateUserPaymentCard(String customerAccountId, PaymentCards paymentCards)
            throws CustomerAccountServiceException {

        log.debug("updateUserPaymentCard, customerAccountId: {}", customerAccountId);

        if(reqContext.isWCSRequest()){
            return updatePaymentCardInWCS(customerAccountId, paymentCards, null);
        }

        paymentCardValidator.validate(paymentCards, HttpMethod.PUT);

        PaymentCard paymentCard = paymentCards.getPaymentCard().get(0);

        log.debug("updateUserPaymentCard() method with customerAccountId: {} and paymentId : {} ", customerAccountId,
                paymentCard.getPaymentId());

        Address address = paymentCard.getBillingAddress();
        saveAddress(customerAccountId, address);

        PaymentCard paymentCardRes = paymentRepository.update(customerAccountId, paymentCard);
        paymentCardRes.setBillingAddress(address);
        paymentCardRes.setIsReqServedFromWCS(false);

        log.debug("End updateUserPaymentCard() method with customerAccountId: {} and paymentId : {} ",
                customerAccountId, paymentCard.getPaymentId());

        return Collections.singletonList(paymentCardRes);

    }



    /*@HystrixCommand(commandKey="deletePaymentCardInXREF",
            fallbackMethod = "deleteUserPaymentCardByIdFromWcs",
            ignoreExceptions={ RepositoryException.class, GenericSystemException.class, AuthenticationException.class,
                    InvalidRequestException.class, IntegrationException.class},
            commandProperties = {
                    @HystrixProperty(name = "execution.isolation.strategy", value = "SEMAPHORE"),
                    @HystrixProperty(name = "execution.timeout.enabled", value = "false")
            })*/

    @Override
    public boolean deleteUserPaymentCardById(String customerAccountId, String paymentId)
            throws CustomerAccountServiceException {
        log.debug("Start PaymentServiceImpl.deleteUserPaymentCardById, delete paymentcard, customerAccountId: {}, "
                + "paymentId: {}", customerAccountId, paymentId);
        if(reqContext.isWCSRequest()){
            log.debug("Request to be served from WCS: deleteUserPaymentCardByIdFromWcs");
           return  deleteUserPaymentCardByIdFromWcs(customerAccountId,paymentId, null);
        }
        return paymentRepository.deleteById(customerAccountId, paymentId);
    }

    /**
     * Method to get the card type
     *
     * @param cardBrand
     * @return String
     */
    private String getCardType(String cardBrand, String xRefRptPaymtMethCd) {

        log.debug("Start getCardType() method with card brand: {}   ", cardBrand);
        String cardType;
        if ((PaymentCardBrand.HDCOM.name().equals(cardBrand)) || (PaymentCardBrand.HDCON.name().equals(cardBrand))) {
            cardType = xRefRptPaymtMethCd;
        } else {
            PaymentCardType paymentCardType = PaymentCardType.getByCardBrand(cardBrand);
            cardType = paymentCardType.getShortDesc();
        }
        log.debug("End getCardType() method with card brand: {} and card type: {}  ", cardBrand, cardType);
        return cardType;
    }

    /**
     * Method to save address
     * 
     * @param customerAccountId
     * @param address
     * @return Address
     * @throws RepositoryException
     */

    private Address saveAddress(String customerAccountId, Address address) throws CustomerAccountServiceException {
        log.debug("Start saveAddress() method ");

        List<Address> addresses = Collections.singletonList(address);
        AddressRequest addressRequest = new AddressRequest();
        addressRequest.setAddress(addresses);

        // create billing address if address identifier is not on billing address
        if (address != null && address.getAddrIdentifier() == null) {
            log.debug("Start save address with  nick name : {}", address.getNickName());
            addressValidator.validate(addressRequest, HttpMethod.POST);
            List<Address> ids = addressRepository.save(customerAccountId, addresses);

            if (CollectionUtils.isNotEmpty(ids)) {
                address.setAddrIdentifier(ids.get(0).getAddrIdentifier());
            }
            log.debug("End saveAddress() method with address identifier: {}  ", address.getAddrIdentifier());
        }
        return address;
    }
    
    
    /********* Fall-back Methods *******************/
    
    private Map<String, Object> getAllPaymentCardsFromWCS(PaymentCardRequest request, String customerAccountID, Throwable originalEx) throws IntegrationException {
        log.info(reqContext.isWCSRequest() ? GlobalConstants.REQUEST_VALID_FOR_WCS : GlobalConstants.XREF_UNAVAILABLE
                +"Getting payment cards info from WCS for svoc id "+customerAccountID);
        log.info(originalEx!=null ? GlobalConstants.XREF_UNAVAILABLE_MSG+ExceptionUtils.getRootCauseMessage(originalEx) : "");
        
        HashMap<String, Object> responseData = new HashMap<>();

        List<PaymentCard> paymentCardsList = paymentFallbackExecutor.getPaymentCardsFromWCS(null);
        if(!CollectionUtils.isEmpty(paymentCardsList)){
            reqContext.setReqServedFromWCS(true);
            paymentCardsList.stream().forEach(paymentCard -> paymentCard.setIsReqServedFromWCS(true));
        }
        
        PaginationInfo respPageInfo = new PaginationInfo();
        if(request.getPaginationInfo()!=null && request.getPaginationInfo().getPageSize()!=null
                && !"0".equalsIgnoreCase(request.getPaginationInfo().getPageSize())
                && !"0".equalsIgnoreCase(request.getPaginationInfo().getPageNumber() + 1)){
            int pageNo = Integer.parseInt(request.getPaginationInfo().getPageNumber()) + 1;
            int pageSize = Integer.parseInt(request.getPaginationInfo().getPageSize());

            List<PaymentCard> pagedPaymentCardList = paginationUtil.paginate(paymentCardsList, pageNo, pageSize);
            respPageInfo.setPageNumber(request.getPaginationInfo().getPageNumber());
            respPageInfo.setPageSize(request.getPaginationInfo().getPageSize());
            respPageInfo.setTotalNumberOfRecords(String.valueOf(paymentCardsList.size()));
            respPageInfo.setTotalPages(String.valueOf(paginationUtil.getTotalPages(paymentCardsList.size(), pageSize)));
            PaymentCards sortedPaymentCards = new PaymentCards();
            sortedPaymentCards.setPaymentCard(pagedPaymentCardList);
            responseData.put(GlobalConstants.PAYMENTCARDS, sortedPaymentCards.getPaymentCard());
        }else{
            if(CollectionUtils.isEmpty(paymentCardsList)){ // Added to support Desktop FED behavior
                respPageInfo.setPageNumber("0");
                respPageInfo.setPageSize("0");
                respPageInfo.setTotalNumberOfRecords("0");
                respPageInfo.setTotalPages("0");
            }
            responseData.put(GlobalConstants.PAYMENTCARDS, paymentCardsList);
        }
        
        responseData.put("paginationInfo", respPageInfo);       
        return responseData;
        
    }

    private List<PaymentCard> createPaymentCardInWCS(String customerAccountID, PaymentCards paymentCards, Throwable originalEx) throws IntegrationException{
        log.info(reqContext.isWCSRequest() ? GlobalConstants.REQUEST_VALID_FOR_WCS : GlobalConstants.XREF_UNAVAILABLE
                +"Creating payment card in WCS for svoc id "+customerAccountID);
        log.info(originalEx!=null ? GlobalConstants.XREF_UNAVAILABLE_MSG+originalEx.getMessage() : "");

        List<PaymentCard> paymentCardsResp = paymentFallbackExecutor.createPaymentCardInWCS(paymentCards.getPaymentCard(), null);
        if(!org.springframework.util.CollectionUtils.isEmpty(paymentCardsResp)){
            reqContext.setReqServedFromWCS(true);
            paymentCardsResp.stream().forEach(paymentCard -> paymentCard.setIsReqServedFromWCS(true));
        }
        return paymentCardsResp;
    }

    private List<PaymentCard> updatePaymentCardInWCS(String customerAccountID, PaymentCards paymentCards, Throwable originalEx) throws IntegrationException{
        log.info(reqContext.isWCSRequest() ? GlobalConstants.REQUEST_VALID_FOR_WCS : GlobalConstants.XREF_UNAVAILABLE
                +"Updating payment card in WCS for svoc id "+customerAccountID);
        log.info(originalEx!=null ? GlobalConstants.XREF_UNAVAILABLE_MSG+originalEx.getMessage() : "");

        List<PaymentCard> paymentCardsResp = paymentFallbackExecutor.updatePaymentCardInWCS(paymentCards.getPaymentCard(), null);
        if(!org.springframework.util.CollectionUtils.isEmpty(paymentCardsResp)){
            reqContext.setReqServedFromWCS(true);
            paymentCardsResp.stream().forEach(paymentCard -> paymentCard.setIsReqServedFromWCS(true));
        }
        return paymentCardsResp;
    }

    public boolean deleteUserPaymentCardByIdFromWcs(String customerAccountId, String paymentId, Throwable originalEx)
            throws CustomerAccountServiceException {
        log.info(reqContext.isWCSRequest() ? GlobalConstants.REQUEST_VALID_FOR_WCS : GlobalConstants.XREF_UNAVAILABLE
                +"Deleting paymentCard from WCS");

        log.info(originalEx!=null ? GlobalConstants.XREF_UNAVAILABLE_MSG+originalEx.getMessage() : "");

        log.debug("Start PaymentServiceImpl.deleteUserPaymentCardByIdFromWCS, delete paymentcard, customerAccountId: {}, "
                + "paymentId: {}", customerAccountId, paymentId);

        return paymentFallbackExecutor.deletePaymentCardInWCS(customerAccountId, paymentId);
    }

}
