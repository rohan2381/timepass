package com.homedepot.customer.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Repository;

import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.model.Preferences;
import com.homedepot.customer.model.pvcypreferences.PrivacyPrefRequest;
import com.homedepot.customer.repository.IPreferencesRepository;
import com.homedepot.customer.service.IPreferencesService;
import com.homedepot.customer.util.Resource;
import com.homedepot.customer.validator.BaseRequestValidator;

/**
 * Created by axb4725 on 9/26/16.
 */
@Repository
public class PreferencesServiceImpl implements IPreferencesService {

    @Autowired
    @Qualifier(value = "pvcyPrefValidator") //Implementor class: PrivacyPreferencesRequestValidator
    BaseRequestValidator<PrivacyPrefRequest> requestValidator;
    
    @Autowired
    IPreferencesRepository preferencesRepository;

    @Override
    public Preferences getPreferences(String email) throws CustomerAccountServiceException{
        try {

            return preferencesRepository.retrievePreferences(email);
        }
        catch (RepositoryException ex){
            ex.getErrors().setResource(Resource.PREFERENCE);
            throw new CustomerAccountServiceException(ex.getErrors(),ex.getHttpStatus(),ex);
        }
    }

    @Override
    public Preferences setPreferences(String email, String zipCode, Preferences preferences) throws CustomerAccountServiceException {
        try {
            return preferencesRepository.setPreferences(email, zipCode, preferences);
        }
        catch (RepositoryException e) {
            e.getErrors().setResource(Resource.PREFERENCE);
            throw new CustomerAccountServiceException(e.getErrors(), e.getHttpStatus(), e);
        }
    }
    
    @Override
    public boolean updatePrivacyPreferences(PrivacyPrefRequest request) throws CustomerAccountServiceException {
        requestValidator.validate(request, HttpMethod.PUT);
        return preferencesRepository.updatePrivacyPreferences(request);
    }

}
