package com.homedepot.customer.service.impl;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.homedepot.customer.datasync.profile.ProfileFallBackExecutor;
import com.homedepot.customer.exception.AuthenticationException;
import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.exception.GenericSystemException;
import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.InvalidRequestException;
import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.model.Account;
import com.homedepot.customer.repository.IProfileRepository;
import com.homedepot.customer.request.ProfileRequest;
import com.homedepot.customer.service.IProfileService;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.validator.BaseRequestValidator;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Apr 27, 2016
 *
 */
@Service
@Slf4j
public class ProfileServiceImpl implements IProfileService {

    @Autowired
    private IProfileRepository profileRepository;

    @Autowired
    @Qualifier(value = "profilevalidator")
    BaseRequestValidator<ProfileRequest> profileRequestValidator;

    @Autowired
    ProfileFallBackExecutor profileFallBackExecutor;

    @Autowired
    CustomerAccountRequestContext reqContext;

    /*
     * (non-Javadoc)
     * 
     * @see com.homedepot.customer.service.IProfileService#updateProfile()
     */
    /*@HystrixCommand(commandKey="updateProfileInSVOC",
            fallbackMethod = "updateProfileInWCS",
            ignoreExceptions={RepositoryException.class, GenericSystemException.class, AuthenticationException.class, 
                            InvalidRequestException.class, IntegrationException.class},
            commandProperties = {
                    @HystrixProperty(name = "execution.isolation.strategy", value = "SEMAPHORE"),
                    @HystrixProperty(name = "execution.timeout.enabled", value = "false")
            })*/
    @Override
    public Account updateProfile(String customerAccountId, ProfileRequest profileRequest)
            throws CustomerAccountServiceException {
        if(reqContext.isWCSRequest()){
            return updateProfileInWCS(customerAccountId, profileRequest, null);
        }

        profileRequest.getAccount().setCustomerAccountId(customerAccountId);
        profileRequestValidator.validate(profileRequest, HttpMethod.PUT);

        return profileRepository.update(customerAccountId, profileRequest.getAccount());
    }

    private Account updateProfileInWCS(String customerAccountId, ProfileRequest profileRequest, Throwable originalEx) throws IntegrationException{
        log.debug(reqContext.isWCSRequest() ? GlobalConstants.REQUEST_VALID_FOR_WCS : GlobalConstants.SVOC_UNAVAILABLE
                +"Update profile info in WCS for customer "+customerAccountId);
        log.info(originalEx!=null ? GlobalConstants.SVOC_UNAVAILABLE_MSG+ExceptionUtils.getRootCauseMessage(originalEx) : "");
        
        Account account = profileFallBackExecutor.updateUserProfileInWCS(profileRequest.getAccount());
        if(account.getProfile() != null){
            account.setIsReqServedFromWCS(true);
            reqContext.setWCSRequest(true);
        }
        return account;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.homedepot.customer.service.IProfileService#retrieveProfile()
     */
    /*@HystrixCommand(commandKey="retrieveProfileFromSVOC",
            fallbackMethod = "retrieveProfileFromWCS",
            ignoreExceptions={RepositoryException.class, GenericSystemException.class, AuthenticationException.class, 
                    InvalidRequestException.class, IntegrationException.class},
            commandProperties = {
                    @HystrixProperty(name = "execution.isolation.strategy", value = "SEMAPHORE"),
                    @HystrixProperty(name = "execution.timeout.enabled", value = "false")
            })*/

    @Override
    public Account retrieveProfile(String customerAccountId) throws CustomerAccountServiceException {

        if(reqContext.isWCSRequest()){
            return retrieveProfileFromWCS(customerAccountId, null);
        }
        ProfileRequest request = new ProfileRequest();
        request.setAccount(new Account());
        request.getAccount().setCustomerAccountId(customerAccountId);
        profileRequestValidator.validate(request, HttpMethod.GET);

        return profileRepository.retrieve(customerAccountId);
    }

    private Account retrieveProfileFromWCS(String customerAccountId, Throwable originalEx) throws IntegrationException{
        log.debug(reqContext.isWCSRequest() ? GlobalConstants.REQUEST_VALID_FOR_WCS : GlobalConstants.SVOC_UNAVAILABLE
                +"Getting profile info from WCS for customer "+customerAccountId);
        log.info(originalEx!=null ? GlobalConstants.SVOC_UNAVAILABLE_MSG+ExceptionUtils.getRootCauseMessage(originalEx) : "");
        
        Account account = profileFallBackExecutor.getUserInfoFromWCS(null);
        if(account.getProfile() != null){
            account.setIsReqServedFromWCS(true);
            reqContext.setWCSRequest(true);
        }
        return account;
    }

}
