package com.homedepot.customer.service.impl;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.homedepot.customer.datasync.profile.ProfileSyncExecutor;
import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.exception.error.ProfileErrorCode;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.integration.wcs.dto.WCSUserIdentity;
import com.homedepot.customer.model.Account;
import com.homedepot.customer.model.Address;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;
import com.homedepot.customer.model.Name;
import com.homedepot.customer.model.Phone;
import com.homedepot.customer.model.PostalDetails;
import com.homedepot.customer.model.Profile;
import com.homedepot.customer.model.ProfilePhones;
import com.homedepot.customer.model.Store;
import com.homedepot.customer.model.UserIdentity;
import com.homedepot.customer.repository.IIdentityRepository;
import com.homedepot.customer.repository.IProfileRepository;
import com.homedepot.customer.repository.IStoreSearchRepository;
import com.homedepot.customer.request.UserRegistrationRequest;
import com.homedepot.customer.service.IEmailService;
import com.homedepot.customer.service.IRegistrationService;
import com.homedepot.customer.util.CustomerAccountLogUtil;
import com.homedepot.customer.util.FeatureSwitchUtil;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.validator.BaseRequestValidator;

import static com.homedepot.customer.util.GlobalConstants.STR_Y;

/**
 * Created by rxb1809 on Apr 27, 2016
 *
 */
@Service
@Slf4j
public class RegistrationServiceImpl implements IRegistrationService{

    @Autowired
    @Qualifier(value="registrationvalidator")
    BaseRequestValidator<UserRegistrationRequest> requestValidator;

    @Autowired
    @Qualifier(value = "userExistenceValidator")
    BaseRequestValidator<String> userExistenceValidator;

    @Autowired
    IProfileRepository profileRepository;

    @Autowired
    IIdentityRepository identityRepository;

    @Autowired
    IStoreSearchRepository storeSearchRepository;

    @Autowired
    ProfileSyncExecutor profileSyncExecutor;

    @Autowired
    @Qualifier("iamErrorCodeMapResource")
    private ResourceBundleMessageSource errorCodeSource;
    
    @Autowired
    FeatureSwitchUtil featureSwitchUtil;

    @Autowired
    IEmailService emailService;
    
    @Autowired
    CustomerAccountLogUtil logUtil;

    @Autowired
    CustomerAccountRequestContext reqContext;

    @Override
    public Map<String, Object> registerUser(UserRegistrationRequest userRegistrationRequest) throws CustomerAccountServiceException {

        Map<String, Object> registerRespMap = new HashMap<>();
        // Validate user details
        requestValidator.validate(userRegistrationRequest, HttpMethod.POST);
        Account svocResp = null;
        try{
            svocResp = createUserInSVOC(userRegistrationRequest);
        } catch (RepositoryException re) {
            if(Optional.of(re).map(er -> er.getErrors()).map(ler -> ler.getErrors()).isPresent()){
                if(re.getErrors().getErrors().stream()
                        .filter(ex -> ex.getErrorCode().equalsIgnoreCase(ProfileErrorCode.INVALID_PRIMARY_EMAIL_NOT_UNIQUE.getCode())
                                || (STR_Y.equalsIgnoreCase(userRegistrationRequest.getLoyaltyEnrollmentIndicator())
                                    && ex.getErrorCode().equalsIgnoreCase(ProfileErrorCode.INVALID_PRIMARY_PHONE_NOT_UNIQUE.getCode()))
                        )
                        .findAny()
                        .isPresent()){
                            throw re;
                        }
            } 
            log.error("SVOC Registration Failed for "+userRegistrationRequest.getEmailId()+" Cause -> "+ ExceptionUtils.getRootCauseMessage(re));
        }
        registerRespMap.put(GlobalConstants.ACCOUNT, svocResp);
        boolean iamSuccess = false;
        boolean wcsSuccess = false;
        Exception iamEx = null;
        Exception wcsEx = null;
        UserIdentity userIdentity = null;
        if (svocResp == null) {  // If SVOC call fails then mark it as IAM failure. Do not create user in IAM in this case
            iamSuccess = false;
        } else {     
            try {
                userIdentity = createUserInIAM(userRegistrationRequest, svocResp.getCustomerAccountId());
                iamSuccess = userIdentity != null;
            } catch (RepositoryException re) {
                iamEx = re;
            }
        }
        boolean wcsBkup = featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE);
        log.debug("{} feature switch value - {}", GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE, wcsBkup);
        if(wcsBkup) {
            WCSUserIdentity wcsUserIdentity = null;
            try {
                String svocId = Optional.ofNullable(svocResp).map(Account::getCustomerAccountId).orElse(null);

                Account svocSavedProfileNew = new Account();
                if(svocResp!=null) {
                    BeanUtils.copyProperties(svocResp, svocSavedProfileNew);
                    }

                wcsUserIdentity = profileSyncExecutor.wcsRegisterUser(userRegistrationRequest, svocId, svocSavedProfileNew);
                if(svocResp == null && wcsUserIdentity != null) { // Due to SVOC call failure
                    Account csrAccount = profileSyncExecutor.getUserProfileFromWCS(wcsUserIdentity.getUserId());
                    registerRespMap.put(GlobalConstants.ACCOUNT, csrAccount);
                }
            } catch (CustomerAccountServiceException re) {
                wcsEx = re;
            }
            wcsSuccess = wcsUserIdentity != null;
            userIdentity = Optional.ofNullable(userIdentity).orElse(new UserIdentity()); // IAM call might have failed
            userIdentity.setWcsUserIdentity(wcsUserIdentity);
        }
        
        // Log the various statuses for easier metrics
        logUtil.logStatus("Registration", userRegistrationRequest.getEmailId(), iamSuccess, wcsSuccess, wcsBkup, iamEx, wcsEx);
        
        if(!iamSuccess && !wcsSuccess) { // Only when both IAM and WCS failed
            handleException(iamEx, wcsEx);
        }
        registerRespMap.put(GlobalConstants.IDENTITY, userIdentity);
        
        //Making call to caa for welcome email
        if(registerRespMap.containsKey(GlobalConstants.ACCOUNT)){
            Account regAccount= (Account) registerRespMap.get(GlobalConstants.ACCOUNT);
            log.debug("Calling CCA flow to send Registration Email: {}",regAccount );
            emailService.sendRegistrationEmail(regAccount.getProfile().getEmailId());
        }
        return registerRespMap;
    }

    private void handleException(Exception iamEx, Exception wcsEx) throws CustomerAccountServiceException {

        HttpStatus iamHttpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        HttpStatus wcsHttpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        CustomerAccountServiceException iamExCause = null;
        CustomerAccountServiceException wcsExCause = null;
        if (iamEx != null && iamEx.getCause() instanceof CustomerAccountServiceException) {
            iamExCause = (CustomerAccountServiceException) iamEx.getCause();
            iamHttpStatus = iamExCause.getHttpStatus();
        }
        if (wcsEx != null && wcsEx.getCause() instanceof CustomerAccountServiceException) {
            wcsExCause = (CustomerAccountServiceException) wcsEx.getCause();
            wcsHttpStatus = wcsExCause.getHttpStatus();
        }
        CustomerAccountServiceException excToBeThrown;
        if (iamHttpStatus.is4xxClientError()) { // IAM is given priority over WCS
            excToBeThrown = iamExCause;
        } else if (wcsHttpStatus.is4xxClientError()) { // Fallback to WCS 400 error
            excToBeThrown = wcsExCause;
        } else { // Default to 500 error code
            Errors errors = createErrors(ErrorCode.SYSTEM_ERROR);
            excToBeThrown = new CustomerAccountServiceException(errors, HttpStatus.INTERNAL_SERVER_ERROR, iamEx);
        }
        throw excToBeThrown;
    }

    private Errors createErrors(String errorCode) {
        Error error = new Error();
        error.setErrorCode(errorCodeSource.getMessage(errorCode, null, ErrorCode.SYSTEM_ERROR, null));
        Errors errors = new Errors();
        errors.setErrors(Collections.singletonList(error));
        return errors;
    }

    private Account createUserInSVOC(UserRegistrationRequest regRequest) throws RepositoryException {

        log.debug("creating Account model object from UserRegistrationRequest");
        Account accountReq = new Account();
        Profile profile = new Profile();
        BeanUtils.copyProperties(regRequest, profile);
        profile.setName(new Name());
        profile.getName().setFirstName(regRequest.getFirstName());
        profile.getName().setLastName(regRequest.getLastName());

        Optional<Store> storeOptional = storeSearchRepository.findStore(profile.getZipCode());
        storeOptional.ifPresent(store -> {
            reqContext.setLocalStore(store);
            profile.setLocalStoreId(store.getStoreId());
        });
        accountReq.setProfile(profile);

        if (STR_Y.equalsIgnoreCase(regRequest.getLoyaltyEnrollmentIndicator())) {
            log.debug("setting address and phone data for pro registration");
            Address address = new Address();
            PostalDetails postalDetails = new PostalDetails();
            BeanUtils.copyProperties(regRequest.getAddress().getPostalDetails(), postalDetails);
            address.setPostalDetails(postalDetails);
            accountReq.setAddress(Collections.singletonList(address));

            // address phone, not required by svoc but checkout flow is expecting
            Phone addrPhone = new Phone();
            BeanUtils.copyProperties(regRequest.getPhone(), addrPhone);
            addrPhone.setPrimaryFlag(GlobalConstants.STR_Y);
            addrPhone.setSecondaryFlag(GlobalConstants.STR_N);
            address.setPrimaryPhone(addrPhone);

            // profile phone
            Phone phone = new Phone();
            BeanUtils.copyProperties(regRequest.getPhone(), phone);
            accountReq.setProfilePhones(new ProfilePhones(Collections.singletonList(phone)));
        }
        return profileRepository.save(accountReq);
    }

    private UserIdentity createUserInIAM(UserRegistrationRequest regRequest,
                                         String customerAccountId) throws RepositoryException {

        return identityRepository.register(customerAccountId,
                                            regRequest.getEmailId(),
                                            regRequest.getPassword());
    }

    @Override
    public Boolean emailAlreadyExists(String emailId) throws CustomerAccountServiceException {
        log.debug("Checking emailAlreadyExists for "+emailId);
        // Check user existence
        userExistenceValidator.validate(emailId, HttpMethod.GET);
        // If the user does not exist then send a success response
        return false;
    }

}
