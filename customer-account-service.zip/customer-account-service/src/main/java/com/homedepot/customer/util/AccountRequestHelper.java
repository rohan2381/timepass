package com.homedepot.customer.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerMapping;

import com.homedepot.customer.exception.AuthenticationException;
import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.exception.error.IdentityErrorCode;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.integration.wcs.WCSCrossRefServiceFacade;
import com.homedepot.customer.integration.wcs.dto.crossref.CrossRefInfo;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;
import com.homedepot.customer.repository.IIdentityRepository;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Nov 14, 2016
 * This class has 2 main functions 
 * 1. Intercept the incoming request and check if the client has sent svoc id or wcs member id
 * 2. If the request has wcs member id, look-up corresponding svoc id from the cross ref and update it back to the request
 */
@Component
@Slf4j
public class AccountRequestHelper {
    
    @Autowired
    WCSCrossRefServiceFacade wcsCrossRefServiceFacade;
    
    @Autowired
    private CustomerAccountRequestContext requestContext; 
    
    @Autowired
    private IIdentityRepository identityRepository; 
    
    @Autowired
    private EnvPropertyUtil envProperty;

    public void validateAndSetCustAcctId(HttpServletRequest request) throws CustomerAccountServiceException{
        // Step 1: Extract account id passed in the request path variable
        String accountIdFromRequest = getAccountIdFromRequest(request);
        
        // Step 2: Identify the type of account id passed in (wcs member id or svoc cust id)
        String accountIdType = identifyAccountIdType(accountIdFromRequest);
        
        // Step 3: Verify if the user is authorized to operate on this account id
        authorizeRequest(accountIdFromRequest, accountIdType);
        
        // Step 4: If the account id passed in is wcs member id then do a reverse look up to get the svoc cust id
        /*if(accountIdType.equalsIgnoreCase(GlobalConstants.WCS)){
            log.debug("Account id passed in the request is WCS member id "+accountIdFromRequest);
            String svocCustAccountId = lookUpSVOCId(accountIdFromRequest);
            log.debug("Corresponding SVOC id for wcs member id "+accountIdFromRequest+ " :: "+svocCustAccountId);
            if(svocCustAccountId != null){
                // Step 4: Replace the wcs member id with svoc cust id in the request
                setSVOCIdInRequest(request,svocCustAccountId);
            }else{
                log.error("Could not find corresponding SVOC id for wcs member id "+accountIdFromRequest);
                requestContext.setWCSRequest(true); // Set the request to be served from WCS
            }             
        } */        
        
    }
    
    public void validateAndSetCustAcctIdForPaymentCards(HttpServletRequest request) throws CustomerAccountServiceException{
        // Step 1: Extract account id passed in the request path variable
        String accountIdFromRequest = getAccountIdFromRequest(request);
        
        // Step 2: Identify the type of account id passed in (wcs member id or svoc cust id)
        String accountIdType = identifyAccountIdType(accountIdFromRequest);
        
        // Step 3: Verify if the user is authorized to operate on this account id
        authorizeRequest(accountIdFromRequest, accountIdType);
        
        // Step 4: If the account id passed in is wcs member id then do a reverse look up to get the svoc cust id
        if(accountIdType.equalsIgnoreCase(GlobalConstants.SVOC)){
            log.debug("Account id passed in the request is SVOC Cust Acct id "+accountIdFromRequest);
            String wcsMemberId = lookUpWCSId(accountIdFromRequest);
            log.debug("Corresponding WCS member id for SVOC cust id "+accountIdFromRequest+ " :: "+wcsMemberId);
            if(wcsMemberId != null){
                // Step 4: Replace the wcs member id with svoc cust id in the request
                setWCSIdInRequest(request,wcsMemberId);
            }else{
                log.error("Could not find corresponding WCS member id for SVOC Cust id "+accountIdFromRequest);
            }             
        }         
        
    }
    
    @SuppressWarnings("unchecked")
    private String getAccountIdFromRequest(HttpServletRequest request){
        Map<String, String> pathVariables = (HashMap<String, String>) request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
        String custAccountId = null;
        custAccountId = pathVariables.entrySet().stream()
                                .filter(p -> p.getKey().equalsIgnoreCase(GlobalConstants.CUST_ACCOUNT_ID))
                                .findAny()
                                .map(p -> p.getValue())
                                .get();
        
        log.debug("Account Id passed in the request is "+custAccountId);
        
        return custAccountId;
    }
    
    private String identifyAccountIdType(String accountIdFromRequest){
        String accountIdType = null;
        
        try{
            if(accountIdFromRequest.length()<18 && Integer.parseInt(accountIdFromRequest)>0){
                accountIdType = GlobalConstants.WCS;
            }else{
                accountIdType = GlobalConstants.SVOC;
            }
        }catch(NumberFormatException nEx){
            log.error("Error convertig accountIdFromRequest to int ",accountIdFromRequest);
            accountIdType = GlobalConstants.SVOC;
        }
        
        return accountIdType;
        
    }
    
    private String lookUpSVOCId(String wcsMemberId){
        String svocCustAcctId = null;
        try{
            CrossRefInfo crossRefInfo = wcsCrossRefServiceFacade.getCrossRefInfoForWCSMemberId(wcsMemberId);
            if(crossRefInfo!=null){
                requestContext.setCrossRefInfo(crossRefInfo);
                svocCustAcctId = crossRefInfo.getSvocCustAcctId();                              
            }
        }catch(IntegrationException iEx){
            log.error("Error calling the look up service to get svoc cust id", ExceptionUtils.getRootCause(iEx));
        }

        return svocCustAcctId;
    }
    
    public String lookUpWCSId(String svocCustAcctId){
        String wcsMemberId = null;
        try{
            CrossRefInfo crossRefInfo = wcsCrossRefServiceFacade.getCrossRefInfoForSVOCCustAcctId(svocCustAcctId);
            if(crossRefInfo!=null){
                wcsMemberId = crossRefInfo.getWcsMemberId();                              
            }
        }catch(IntegrationException iEx){
            log.error("Error calling the look up service to get wcs member id", ExceptionUtils.getRootCause(iEx));
        }

        return wcsMemberId;
    }
    
    private void setSVOCIdInRequest(HttpServletRequest request, String svocCustAccountId){
        Map<String, String> pathVariables = (HashMap<String, String>) request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
        pathVariables.put(GlobalConstants.CUST_ACCOUNT_ID, svocCustAccountId);
        
        request.setAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE, pathVariables);
        requestContext.setSvocCustomerAccountId(svocCustAccountId);
    }
    
    private void setWCSIdInRequest(HttpServletRequest request, String wcsMemberId){
        Map<String, String> pathVariables = (HashMap<String, String>) request.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE);
        pathVariables.put(GlobalConstants.CUST_ACCOUNT_ID, wcsMemberId);
        
        request.setAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE, pathVariables);
        requestContext.setWcsMemberId(wcsMemberId);
    }
    
    public void setRequestTypeForAddrId(String addressIdFromRequest){
        String addressIdType = null;

        if(addressIdFromRequest.length() >= 5){
            addressIdType = GlobalConstants.WCS;
            requestContext.setWCSRequest(true);
        }else{
            addressIdType = GlobalConstants.SVOC;
        }    
    } 
    
    private void authorizeRequest(String accountIdFromRequest, String accountIdType) throws AuthenticationException{
        boolean isRequestAuthorized = false;

        switch(requestContext.getSessionAuth()){
        case IAM:
            if(GlobalConstants.SVOC.equalsIgnoreCase(accountIdType)){
                if(accountIdFromRequest.equalsIgnoreCase(requestContext.getSvocCustomerAccountId())){
                    isRequestAuthorized = true;
                }else isRequestAuthorized = false;
            }
            break;

        case WCS:
            if(GlobalConstants.WCS.equalsIgnoreCase(accountIdType)){
                if(accountIdFromRequest.equalsIgnoreCase(requestContext.getWcsMemberId())) {
                    isRequestAuthorized = true;
                }else isRequestAuthorized = false;
            }
            break;

        default:
            break;
        }

        if(!isRequestAuthorized){
            log.error("Customer id "+requestContext.getWcsMemberId()+" is not authorized to operate on account "+accountIdFromRequest);
            throwAuthError();
        }
    }
    
    @Async("identityTaskExecutor")
    public Future<String> getIAMServiceAuthTokenAsync() throws RepositoryException{       
        String serviceAuthToken = identityRepository.getServiceAuthToken(envProperty.getIamServiceUser(),
                envProperty.getIamServicePassword());
        
        return new AsyncResult<>(serviceAuthToken);
    }

    private void throwAuthError() throws AuthenticationException{
        List<Error> errorList = new ArrayList<>();

        Error error = new Error();
        error.setErrorCode(IdentityErrorCode.USER_NOT_AUTHORIZED.getCode());
        errorList.add(error);
        Errors errors = new Errors();
        errors.setErrors(errorList);

        throw new AuthenticationException(errors);
    }
}
