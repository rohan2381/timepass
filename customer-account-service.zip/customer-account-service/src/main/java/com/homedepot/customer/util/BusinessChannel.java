package com.homedepot.customer.util;

/**
 * Created by rxb1809 on Aug 11, 2016
 *
 */
public enum BusinessChannel {

    MCMDESKTOP(1), MCMMOBILE(2), MCMTABLET(3), MCMPROX(4), MCMCONSUMERAPP(5), MCMPROAPP(6);

    private Integer channelId;

    private BusinessChannel(Integer channelId) {
        this.channelId = channelId;
    }

    public Integer getChannelId() {
        return channelId;
    }

    public static BusinessChannel valueOfId(Integer channelId) {
        for (BusinessChannel channel : values()) {
            if (channel.getChannelId().equals(channelId)) {
                return channel;
            }
        }
        throw new IllegalArgumentException("No enum " + BusinessChannel.class + " defined for channel Id " + channelId);
    }
}
