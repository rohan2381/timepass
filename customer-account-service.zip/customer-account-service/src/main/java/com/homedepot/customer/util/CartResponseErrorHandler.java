package com.homedepot.customer.util;

import java.io.*;
import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.context.support.*;
import org.springframework.http.*;
import org.springframework.http.client.*;
import org.springframework.stereotype.*;
import org.springframework.web.client.*;
import com.homedepot.customer.exception.*;
import com.homedepot.customer.exception.error.*;
import com.homedepot.customer.integration.cart.dto.*;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;

import lombok.extern.slf4j.*;

/**
 * Created by nxw6207 on 8/4/17.
 */
@Component
@Slf4j
public class CartResponseErrorHandler implements ResponseErrorHandler {

    private static final String CART_ERROR_MSG = "CART Response Error:: ";
    private static final String CART_UNVAIALABE_MSG = "CART Services Not Available:: ";

    @Autowired
    @Qualifier("errorMessageResource")
    private ResourceBundleMessageSource messageSource;

    @Autowired
    @Qualifier("cartErrorCodeMapResource")
    private ResourceBundleMessageSource errorMapSource;

    @Override
    public void handleError(ClientHttpResponse response) throws IOException {
        //NOSONAR
    }

    @Override
    public boolean hasError(ClientHttpResponse response) throws IOException {
        return isError(response.getStatusCode());
    }

    public boolean isError(Object respObj) {
        String status = ((CartResponse) respObj).getStatus();
        return GlobalConstants.FAIL.equalsIgnoreCase(status);
    }

    public void handleError(Object respObj, HttpStatus httpStatus) throws IntegrationException {
        String cartErrorMsg;
        if(respObj==null)
            cartErrorMsg = CART_ERROR_MSG+"Status="+httpStatus;
        else
            cartErrorMsg = CART_UNVAIALABE_MSG+"Status="+httpStatus+" Body="+respObj.toString();
        log.error(cartErrorMsg);

        List<Error> errorList = new ArrayList<>();
        Error error = new Error();
        HttpStatus httpStatusCode = httpStatus;

        if (respObj instanceof CartResponse) {

            String errorCode = ((CartResponse) respObj).getErrorCode();
            String devErrorMsg = ((CartResponse) respObj).getErrorDescription();
            error.setErrorCode(errorMapSource.getMessage(errorCode, null, ErrorCode.SYSTEM_ERROR, null));
            error.setDeveloperErrorMessage(devErrorMsg);

            try{
                httpStatusCode = CartErrorCode.valueOfHttpStatus(error.getErrorCode());
            }catch(IllegalArgumentException iLx){
                log.error("No cart error code defined..",iLx);
                httpStatusCode = HttpStatus.INTERNAL_SERVER_ERROR;
            }

            errorList.add(error);
        }
        else {
            error.setErrorMessage(httpStatusCode.getReasonPhrase());
            errorList.add(error);
        }
        Errors errors = new Errors();
        errors.setErrors(errorList);
        throw new IntegrationException(errors, httpStatusCode, cartErrorMsg);
    }

}
