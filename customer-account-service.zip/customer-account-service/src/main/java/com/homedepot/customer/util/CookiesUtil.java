package com.homedepot.customer.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.integration.cart.dto.*;
import com.homedepot.customer.integration.iam.config.IAMRestTemplateInfo;
import com.homedepot.customer.integration.wcs.dto.WCSUserIdentity;
import com.homedepot.customer.model.Identity;
import com.homedepot.customer.model.THDUserInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import java.net.HttpCookie;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * Created by admin on 10/13/16.
 */
@Component
@Slf4j
public class CookiesUtil {

    @Autowired
    EnvPropertyUtil envProperty;
    
    @Autowired
    CustomerAccountRequestContext reqContext;
    
    @Autowired
    private Environment environment;
    
    @Autowired
    @Qualifier("iamRestTemplateInfo")
    private IAMRestTemplateInfo iamRestTemplateInfo;

    public void setIAMResponseCookies(Identity identity, HttpServletResponse response) {
        // Set Aurora Cookie
        THDUserInfo userInfo = new THDUserInfo();
        BeanUtils.copyProperties(identity,userInfo);

        ObjectMapper mapper = iamRestTemplateInfo.getObjectMapper();
        String cookieValue = null;
        String cookieValueB64 = null;
        
        String iamCookieDomain = envProperty.getIamCookieDomain();
        
        if(Arrays.stream(environment.getActiveProfiles()).anyMatch(env -> GlobalConstants.SPRING_PFOFILE_DEV.equalsIgnoreCase(env))) {   
            ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if(requestAttributes!=null && requestAttributes.getRequest()!=null 
                    && requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV) !=null){
                THDEnv thdEnv =  (THDEnv)requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV);
                if(thdEnv!=null){
                    iamCookieDomain = thdEnv.getDomain();
                    log.debug("cookie domain set to "+thdEnv.getOriginUrl());
                }                            
            }
        }
        
        try {
            // Convert to json String
            cookieValue = mapper.writeValueAsString(userInfo);

            // Convert to Base64 encoded string
            cookieValueB64 = Base64.getEncoder().encodeToString(cookieValue.getBytes(GlobalConstants.CHARSET_UTF_8));

            // Set User Info cookie
            Cookie userInfoCookie = createCookie(GlobalConstants.THD_USER, cookieValueB64, 3600 * 24 * 365,
                    iamCookieDomain, "/", false);
            response.addCookie(userInfoCookie);

            // Set User session cookie
            Cookie userSessionCookie = createCookie(GlobalConstants.THD_USER_SESSION, identity.getSessionToken(), -1,
                    iamCookieDomain, "/", false);
            response.addCookie(userSessionCookie);

        } catch (Exception ex) {
            log.error("ERROR: Failed to set Aurora cookies in response for customer {} ", identity.getLogonId()
                    +", Root Cause:"+ ExceptionUtils.getRootCause(ex));
        }
    }

    public void setCartMigrateResponseCookies(CartResponse cartResponse, HttpServletResponse response) {
        List<String> cartRespCookies = cartResponse.getResponseCookies();

        Optional<String> cartActivitOptional = cartRespCookies
                .stream()
                .filter(cookie -> cookie.toUpperCase().startsWith(GlobalConstants.CART_ACTIVITY))
                .findAny();

        cartActivitOptional.ifPresent(cartActivity -> {
            log.info("Cart Migration Response Cookie: {} ", cartActivity);
            List<HttpCookie> hcList = HttpCookie.parse(cartActivity);
            hcList.forEach(hc -> {
                Cookie cookie = createCookie(hc.getName(), hc.getValue(), (int) hc.getMaxAge(), hc.getDomain(),
                        hc.getPath(), hc.getSecure());
                response.addCookie(cookie);
            });
        });
    }

    private Cookie createCookie(String cookieName, String cookieValue, int cookieExpiry, String domain, String path,
            boolean secure) {
        Cookie cookie = new Cookie(cookieName, cookieValue);
        cookie.setMaxAge(setFinalMaxAge(cookieExpiry)); 
        Optional.ofNullable(domain).ifPresent(cookie::setDomain);
        Optional.ofNullable(path).ifPresent(cookie::setPath);
        cookie.setSecure(secure);
        return cookie;
    }

    public void setFallbackWCSResponseCookies(Identity identity, HttpServletResponse response) {
        
        String iamCookieDomain = envProperty.getIamCookieDomain();
        
        if(Arrays.stream(environment.getActiveProfiles()).anyMatch(env -> GlobalConstants.SPRING_PFOFILE_DEV.equalsIgnoreCase(env))) {   
            ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if(requestAttributes!=null && requestAttributes.getRequest()!=null 
                    && requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV) !=null){
                THDEnv thdEnv =  (THDEnv)requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV);
                if(thdEnv!=null){
                    iamCookieDomain = thdEnv.getDomain();
                    log.debug("cookie domain set to "+thdEnv.getOriginUrl());
                }                            
            }
        }

        int timeInSeconds = (int) (System.currentTimeMillis() / 1000 + 3600 * 24 * 365);
        String firstName = reqContext.getFirstName()!=null ? reqContext.getFirstName() : GlobalConstants.COOKIE_CRUMB_C13_DEFAULT_VAL;
        String thdPersistStr = GlobalConstants.COOKIE_CRUMB_C13 + GlobalConstants.EQUALS + firstName +
                                GlobalConstants.THD_PERSIST_TOKEN_VAL_SEPARATOR + GlobalConstants.COOKIE_CRUMB_C13_EXP + GlobalConstants.EQUALS + timeInSeconds;

        try {
            final String C13Encode = URLEncoder.encode(GlobalConstants.COOKIE_CRUMB_C13 + GlobalConstants.EQUALS + firstName , StandardCharsets.UTF_8.name());
            final String C13ExpEncode = URLEncoder.encode(GlobalConstants.COOKIE_CRUMB_C13_EXP + GlobalConstants.EQUALS + timeInSeconds, StandardCharsets.UTF_8.name());
            String C4Encode = null;
            String C4ExpEncode = null;
            if(null != reqContext.getLocalStore()) {
                C4Encode = URLEncoder.encode(GlobalConstants.COOKIE_CRUMB_C4 + GlobalConstants.EQUALS + reqContext.getLocalStore().toString(), StandardCharsets.UTF_8.name());
                C4ExpEncode = URLEncoder.encode(GlobalConstants.COOKIE_CRUMB_C4_EXP + GlobalConstants.EQUALS + timeInSeconds, StandardCharsets.UTF_8.name());
            }
            final String thdPersistEncodedVal = URLEncoder.encode(thdPersistStr, StandardCharsets.UTF_8.name());

            String C4EncodeVal = C4Encode;
            String C4ExpEncodeVal = C4ExpEncode;

            final String iamCookieDomainFinal = iamCookieDomain;

            Optional<CustomerAccountRequestContext> optionalRequestContext = Optional.ofNullable(reqContext);

            optionalRequestContext.map(resquestContext -> resquestContext.getRequest())
                    .map(request -> request.getCookies())
                    .ifPresent(cookies -> {
                        boolean isthd_persist = Arrays.stream(cookies)
                                .filter(c -> c.getName().equals(GlobalConstants.THD_PERSIST))
                                .findFirst()
                                .isPresent();
                        if (isthd_persist) {
                            Arrays.stream(cookies)
                                    .filter(c -> c.getName().equals(GlobalConstants.THD_PERSIST))
                                    .findFirst().ifPresent(cookie ->{
                                                                String[] crumbs = GlobalConstants.THD_PERSIST_CRUMB_SPLIT_PATTERN.split(cookie.getValue());
                                                                List<String> cc=  Arrays.stream(crumbs)
                                                                                        .filter(c->(!c.contains(GlobalConstants.COOKIE_CRUMB_C13)))
                                                                                        .collect(Collectors.toList());
                                                                cc.add(C13Encode);
                                                                cc.add(C13ExpEncode);

                                                                if(StringUtils.isNotBlank(C4EncodeVal)) {

                                                                    Predicate<String> C4Predicate = new Predicate<String>() {
                                                                        @Override
                                                                        public boolean test(String crumb) {
                                                                            return (crumb.startsWith(GlobalConstants.COOKIE_CRUMB_C4+"%3d") || crumb.startsWith(GlobalConstants.COOKIE_CRUMB_C4+"%3D"));
                                                                        }
                                                                    };

                                                                    boolean C4Present = cc.stream().anyMatch(C4Predicate);

                                                                    if(C4Present) {
                                                                        cc.replaceAll(cstr -> C4Predicate.test(cstr) ? C4EncodeVal : cstr);
                                                                    } else {
                                                                        cc.add(C4EncodeVal);
                                                                    }

                                                                    boolean C4ExpPresent = cc.stream().anyMatch(cstr -> (cstr.startsWith("C4%5f") || cstr.startsWith("C4%5F") || cstr.startsWith("C4_EXP")));
                                                                    if(!C4ExpPresent)
                                                                        cc.add(C4ExpEncodeVal);
                                                                }

                                                                Cookie thd_persist_response= new Cookie(GlobalConstants.THD_PERSIST, StringUtils.join(cc,GlobalConstants.THD_PERSIST_BASE64_DELIMETER));// NOSONAR
                                                                thd_persist_response.setDomain(iamCookieDomainFinal);
                                                                thd_persist_response.setMaxAge(GlobalConstants.THD_PERSIST_MaxAge);
                                                                thd_persist_response.setHttpOnly(GlobalConstants.THD_PERSIST_HttpOnly);
                                                                thd_persist_response.setPath(GlobalConstants.THD_PERSIST_Path);
                                                                thd_persist_response.setSecure(GlobalConstants.THD_PERSIST_SECURE); 
                                                                response.addCookie(thd_persist_response);



                                    });
                        } else {
                            addCookie(response, thdPersistEncodedVal, timeInSeconds);
                        }

                    });

        } catch (Exception ex) {
        log.error("ERROR: Failed to set fallback THD_PERSIST WCS cookie for customer {}, Root Cause: {}",
                identity.getLogonId(), ExceptionUtils.getRootCauseMessage(ex));
    }


    }

    public void addCookie(HttpServletResponse response, String thdPersistEncodedVal, int timeInSeconds){
        String iamCookieDomain = envProperty.getIamCookieDomain();
        
        if(Arrays.stream(environment.getActiveProfiles()).anyMatch(env -> GlobalConstants.SPRING_PFOFILE_DEV.equalsIgnoreCase(env))) {   
            ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if(requestAttributes!=null && requestAttributes.getRequest()!=null 
                    && requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV) !=null){
                THDEnv thdEnv =  (THDEnv)requestAttributes.getRequest().getAttribute(GlobalConstants.THD_ENV);
                if(thdEnv!=null){
                    iamCookieDomain = thdEnv.getDomain();
                    log.debug("cookie domain set to "+thdEnv.getOriginUrl());
                }                            
            }
        }
        
        Cookie cookie = createCookie(GlobalConstants.THD_PERSIST, thdPersistEncodedVal, timeInSeconds,
                iamCookieDomain, "/", false);
        response.addCookie(cookie);

    }

    public void setWCSResponseCookies(Identity identity, WCSUserIdentity wcsUserIdentity, HttpServletResponse response) {
        // Set WCS cookies
        if(null != wcsUserIdentity) {
            try {
                List<String> responseCookies = wcsUserIdentity.getResponseCookies();
                String thdPersistHeaderValue = responseCookies.stream()
                                                                .filter(cookie -> cookie.startsWith(GlobalConstants.THD_PERSIST))
                                                                // Added to fix WCS returning multiple THD_PERSIST and filter the one which is just double quotes ("")
                                                                .filter(cookie -> !StringUtils.equalsIgnoreCase(GlobalConstants.THD_PERSIST_EMTPY, cookie.split(GlobalConstants.EQUALS, 2)[1].split(GlobalConstants.SEMICOLON,2)[0]))
                                                                .reduce((first, second) -> second) // Pick up the most recent copy (last) in case there are multiple copies
                                                                .map(x -> x.split(GlobalConstants.EQUALS, 2)[1])
                                                                .orElse(null);
                if(StringUtils.isNotBlank(thdPersistHeaderValue)) {
                    String thdPersistValueDecode = URLDecoder.decode(thdPersistHeaderValue, StandardCharsets.UTF_8.name());
                    log.debug("Decoded value of THD_PERSIST from WCS THD_PERSIST: {}", thdPersistValueDecode);
                    String[] thdPeristValueDecodeArr = thdPersistValueDecode.split(GlobalConstants.THD_PERSIST_TOKEN_EXPIRY_START, 2);
                    String thdPeristValuePairs = thdPeristValueDecodeArr[0];
                    Map<String, String> thdPersistKeyValueMap =
                            Arrays.stream(thdPeristValuePairs.split(GlobalConstants.THD_PERSIST_TOKEN_VAL_SEPARATOR))
                                    .map(elem -> elem.split(GlobalConstants.EQUALS))
                                    .filter(ary -> ary != null && ary.length == 2)
                                    .collect(Collectors.toMap(arr -> arr[0], arr -> arr[1]));
                    String expValue = thdPersistValueDecode.split(GlobalConstants.THD_PERSIST_TOKEN_VAL_EXP, 2)[1].split(GlobalConstants.THD_PERSIST_TOKEN_VAL_SEPARATOR)[0];
                    String thdPersistValueAdd = getUpdatedPersistValue(wcsUserIdentity, expValue, thdPersistKeyValueMap);
                    log.debug("Decoded value of THD_PERSIST after appending new values THD_PERSIST: {}", thdPersistValueAdd);
                    String thdPersistEncodedVal = GlobalConstants.THD_PERSIST + GlobalConstants.EQUALS +
                                                    URLEncoder.encode(thdPersistValueAdd, StandardCharsets.UTF_8.name());
                    String thdPersistValue = thdPersistEncodedVal + GlobalConstants.THD_PERSIST_TOKEN_EXPIRY_START + thdPeristValueDecodeArr[1];
                    responseCookies.replaceAll(cookie -> cookie.startsWith(GlobalConstants.THD_PERSIST) ? thdPersistValue : cookie);
                    responseCookies.forEach(cookieStr -> processWCSCookies(cookieStr, response));
                }
            } catch (Exception ex) {
                log.error("ERROR: Failed to set WCS cookies in response for customer {} , Root Cause: {}",
                            identity.getLogonId(), ExceptionUtils.getRootCauseMessage(ex));
            }
        }
    }

    public void processWCSCookies(String cookieStr, HttpServletResponse response) {

        List<HttpCookie> hcList = HttpCookie.parse(cookieStr);
        hcList.forEach(hc -> {
            if(GlobalConstants.WCSSESSIONID.equalsIgnoreCase(hc.getName())) {
                response.addHeader(GlobalConstants.SETCOOKIE, cookieStr);
            } else {
                Cookie cookie = createCookie(hc.getName(), hc.getValue(), (int) hc.getMaxAge(), hc.getDomain(),
                                             hc.getPath(), hc.getSecure());
                response.addCookie(cookie);
            }
        });
    }

    private String getUpdatedPersistValue(WCSUserIdentity wcsUserIdentity, String expValue, Map<String, String> thdPersistValueMap) {
        thdPersistValueMap.put(GlobalConstants.COOKIE_CRUMB_C9, Boolean.TRUE.toString());
        thdPersistValueMap.put(GlobalConstants.COOKIE_CRUMB_C9_EXP, expValue);
        thdPersistValueMap.put(GlobalConstants.COOKIE_CRUMB_C12, wcsUserIdentity.getLogonId());
        thdPersistValueMap.put(GlobalConstants.COOKIE_CRUMB_C12_EXP, expValue);
        thdPersistValueMap.put(GlobalConstants.COOKIE_CRUMB_C13, reqContext.getFirstName()!=null ? reqContext.getFirstName() : GlobalConstants.COOKIE_CRUMB_C13_DEFAULT_VAL);
        thdPersistValueMap.put(GlobalConstants.COOKIE_CRUMB_C13_EXP, expValue);
        thdPersistValueMap.put(GlobalConstants.COOKIE_CRUMB_C40, GlobalConstants.COOKIE_CRUMB_C40_VAL);
        thdPersistValueMap.put(GlobalConstants.COOKIE_CRUMB_C40_EXP, expValue);
        thdPersistValueMap.put(GlobalConstants.COOKIE_CRUMB_C43, wcsUserIdentity.getUserId());
        thdPersistValueMap.put(GlobalConstants.COOKIE_CRUMB_C43_EXP, expValue);
        thdPersistValueMap.put(GlobalConstants.COOKIE_CRUMB_C44, wcsUserIdentity.getNonTlsEncodedActivityToken());
        thdPersistValueMap.put(GlobalConstants.COOKIE_CRUMB_C44_EXP, expValue);
        thdPersistValueMap.put(GlobalConstants.COOKIE_CRUMB_C45, wcsUserIdentity.getEncodedActivityToken());
        thdPersistValueMap.put(GlobalConstants.COOKIE_CRUMB_C45_EXP, expValue);
        thdPersistValueMap.put(GlobalConstants.COOKIE_CRUMB_C46, wcsUserIdentity.getLogonId());
        thdPersistValueMap.put(GlobalConstants.COOKIE_CRUMB_C46_EXP, expValue);
        Optional.ofNullable(reqContext.getLocalStore()).ifPresent(localStore -> {
            thdPersistValueMap.put(GlobalConstants.COOKIE_CRUMB_C4, reqContext.getLocalStore().toString());
            thdPersistValueMap.put(GlobalConstants.COOKIE_CRUMB_C4_EXP, expValue);
        });

        return  thdPersistValueMap.entrySet()
                .stream()
                .sorted((rec1, rec2) ->
                {
                    int key1ToIndex = rec1.getKey().indexOf(GlobalConstants.UNDERSCORE);
                    int key2ToIndex = rec2.getKey().indexOf(GlobalConstants.UNDERSCORE);
                    Integer key1 = new Integer((key1ToIndex == -1) ? rec1.getKey().substring(1) : rec1.getKey()
                            .substring(1, key1ToIndex));
                    Integer key2 = new Integer((key2ToIndex == -1) ? rec2.getKey().substring(1): rec2.getKey()
                            .substring(1, key2ToIndex));
                    if(key1.equals(key2)) {
                        return rec1.getKey().compareTo(rec2.getKey());
                    } else {
                        return key1.compareTo(key2);
                    }
                })
                .map(entry -> entry.getKey() + GlobalConstants.EQUALS + entry.getValue())
                .collect(Collectors.joining(GlobalConstants.THD_PERSIST_TOKEN_VAL_SEPARATOR));
    }
    
    private int setFinalMaxAge(int cookieExpiry){
        int finalMaxAge = 0;
        
        if(cookieExpiry < -1){
            finalMaxAge = 0;
        }else if(cookieExpiry == -1){
            finalMaxAge = -1;
        }else {
            finalMaxAge = cookieExpiry;
        }
        
        return finalMaxAge;
    }

}
