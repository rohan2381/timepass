package com.homedepot.customer.util;

import java.util.*;

import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.homedepot.customer.integration.wcs.dto.crossref.*;
import com.homedepot.customer.integration.wcs.dto.crossref.Address;

/**
 * Created by rxb1809 on Dec 1, 2016
 * This class is serves as a helper class to extract relevant mapping ids from WCS given SVOC ids and vice-versa
 */
@Component
public class CrossReferenceHelper {
    
    public String getMappedWCSMemberId(CrossRefInfo crossRefInfo){
        return crossRefInfo.getWcsMemberId();
    }
    
    public String getMappedSVOCAccountId(CrossRefInfo crossRefInfo){
        return crossRefInfo.getSvocCustAcctId();
    }
    
    public String getMappedWCSAddressId(String svocAddressId, CrossRefInfo crossRefInfo){
        String wcsAddressId = null;
        if(crossRefInfo.getAddresses()!=null && !CollectionUtils.isEmpty(crossRefInfo.getAddresses().getAddress())){
            Optional<Address> addrOption = crossRefInfo.getAddresses().getAddress()
                                            .stream()
                                            .filter(addr -> addr.getSvocAddressId().equals(svocAddressId))
                                            .findAny();
            if(addrOption.isPresent()){
                wcsAddressId = addrOption.get().getWcsAddressId();
            }
        }
        
        return wcsAddressId;
    }
    
    public String getMappedSVOCAddressId(String wcsAddressId, CrossRefInfo crossRefInfo){
        String svocAddressId = null;
        if(crossRefInfo.getAddresses()!=null && !CollectionUtils.isEmpty(crossRefInfo.getAddresses().getAddress())){
            Optional<Address> addrOption = crossRefInfo.getAddresses().getAddress()
                                            .stream()
                                            .filter(addr -> addr.getWcsAddressId().equals(wcsAddressId))
                                            .findAny();
            if(addrOption.isPresent()){
                svocAddressId = addrOption.get().getSvocAddressId();
            }
        }
        
        return svocAddressId;        
    }
    
    public String getMappedWCSPaymentId(String xrefPaymentId, CrossRefInfo crossRefInfo){
        String wcsPaymentId = null;
        if (null != crossRefInfo && crossRefInfo.getPayments() != null && !CollectionUtils.isEmpty(crossRefInfo.getPayments().getPayment())) {
            Optional<Payment> paymentOption = crossRefInfo.getPayments().getPayment()
                                                .stream()
                                                .filter(pay -> xrefPaymentId.equals(pay.getXrefPaymentId()))
                                                .findAny();


            if (paymentOption.isPresent()) {
                wcsPaymentId = paymentOption.get().getWcsPaymentId();
            }

        }
        return wcsPaymentId;
    }
    
    public String getMappedSVOCPaymentId(){
        return null;
    }
}
