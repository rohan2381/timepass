package com.homedepot.customer.util;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Mar 16, 2017
 *
 */
@Component
@Slf4j
public class CustomerAccountLogUtil {

    public void logStatus(String operation, String logonId, boolean iamSuccess, boolean wcsSuccess, boolean wcsBkup, Exception iamEx, Exception wcsEx){
        if(iamSuccess){
            log.info("IAM "+operation+" successful "+(logonId!=null ? "for "+logonId : ""));
            if(wcsSuccess){
                log.info("WCS "+operation+" successful "+(logonId!=null ? "for "+logonId : ""));
                log.info("Both IAM AND WCS "+operation+" were successful "+(logonId!=null ? "for "+logonId : ""));
            }else{
                if(wcsBkup)
                    log.info("IAM "+operation+" was successful BUT WCS "+operation+" had failure "+(logonId!=null ? "for "+logonId : ""));
                else
                    log.info("IAM "+operation+" was successful BUT WCS "+operation+" was skipped "+(logonId!=null ? "for " + ""+logonId : ""));
            }
        }else{
            log.error("IAM "+operation+" failed "+(logonId!=null ? "for "+logonId : "")+ " Cause -> "+ ExceptionUtils.getRootCauseMessage(iamEx));
            if(wcsSuccess){
                log.info("WCS "+operation+" was successful BUT IAM "+operation+" had failure "+(logonId!=null ? "for "+logonId : ""));
            }else {
                if(wcsBkup) {
                    log.error("WCS " + operation + " failed " + (logonId != null ? "for " + logonId : "") + " Cause -> " + ExceptionUtils.getRootCauseMessage(wcsEx));
                    log.info("Both IAM AND WCS - " + operation + " had failures " + (logonId != null ? "for " + logonId : ""));
                } else
                    log.info("IAM "+operation+" failed BUT WCS "+operation+" was skipped "+(logonId!=null ? "for " + logonId : ""));
            }
        }        
    }
}

