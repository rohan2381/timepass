package com.homedepot.customer.util;

/**
 * Created by rxb1809 on Dec 26, 2016
 * Enum to store the CCA notification types
 */
public enum EmailType {

    WELCOME_EMAIL("THD_MYAC_Welcome"),
    ACCOUNT_UPDATE_EMAIL("THD_MYAC_AccountUpdated"),
    RESET_PASSWORD_EMAIL("THD_MYAC_ChangePassword"),
    SET_PASSWORD_EMAIL("THD_MYAC_SetPassword"),
    PASSWORD_UPDATED_EMAIL("THD_MYAC_PasswordChanged");

    private String ccaCode;

    private EmailType(String ccaCode) {
        this.ccaCode = ccaCode;
    }

    public String getCcaCode() {
        return ccaCode;
    }

    public static EmailType valueOfCode(String ccaCode) {

        for (EmailType notificationType : values()) {
            if (notificationType.getCcaCode().equalsIgnoreCase(ccaCode)) {
                return notificationType;
            }
        }
        throw new IllegalArgumentException("No enum " + EmailType.class + " defined for code " + ccaCode);
    }

}
