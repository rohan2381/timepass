package com.homedepot.customer.util;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Created by rxb1809 on Jun 11, 2016
 *
 */
@Data
@Component
public class EnvPropertyUtil {

    @Value("${cca.host.name}")
    private String ccaHost;

    @Value("${iam.service.userName}")
    private String iamServiceUser;

    @Value("${iam.service.password}")
    private String iamServicePassword;

    @Value("${iam.host.name}")
    private String iamHost;

    @Value("${iam.host.apiKey}")
    private String iamApiKey;

    @Value("${iam.host.timeout.connection}")
    private String iamConnectionTimeout;

    @Value("${iam.host.timeout.socket}")
    private String iamSocketTimeout;

    @Value("${iam.login.timeout}")
    private Integer iamLoginTimeout;

    @Value("${iam.cookie.domain}")
    private String iamCookieDomain;

    @Value("${svoc.host.name}")
    private String svocHost;

    @Value("${svoc.host.apiKey}")
    private String svocApiKey;

    @Value("${svoc.host.timeout.connection}")
    private String svocConnectionTimeout;

    @Value("${svoc.host.timeout.socket}")
    private String svocSocketTimeout;

    @Value("${svoc.client.id}")
    private String svocClientId;

    @Value("${svoc.user.id}")
    private String svocUserId;

    @Value("${svoc.auth.token}")
    private String svocAuthToken;

    @Value("${wcs.host.name.origin}")
    private String wcsHost;

    @Value("${wcs.host.name.secure}")
    private String wcsHostSecure;

    @Value("${wcs.login.timeout}")
    private Integer wcsLoginTimeout;

    @Value("${payment.host.name}")
    private String paymentHost;

    @Value("${payment.apiKey}")
    private String paymentApiKey;

    @Value("${payment.host.env}")
    private String paymentHostEnv;

    @Value("${payment.timeout.connection}")
    private String paymentConnectionTimeout;

    @Value("${payment.timeout.socket}")
    private String paymentSocketTimeout;

    @Value("${payment.user.id}")
    private String paymentUserId;

    @Value("${payment.source}")
    private String paymentSource;

    @Value("${prox.host.name}")
    private String proxHost;

    @Value("${passport.host.name}")
    private String passportHost;

    @Value("${passport.user.id}")
    private String passportUsr;

    @Value("${passport.user.pwd}")
    private String passPortUsrPwd;

    @Value("${taxware.host.name}")
    private String taxwareHost;

    @Value("${taxware.key}")
    private String taxwareKey;

    @Value("${taxware.apiKey}")
    private String taxwareApiKey;

    @Value("${taxware.timeout.connection}")
    private String taxwareConnectionTimeout;

    @Value("${taxware.timeout.socket}")
    private String taxwareSocketTimeout;

    @Value("${beehive.host.name}")
    private String beehiveHost;

    @Value("${beehive.host.apiKey}")
    private String beehiveApiKey;

    @Value("${beehive.auth.token}")
    private String beehiveAuthToken;

    @Value("${acxiom.host.name}")
    private String acxiomHost;

    @Value("${acxiom.username}")
    private String acxiomUsername;

    @Value("${acxiom.password}")
    private String acxiomPassword;

    @Value("${storesearch.host.name}")
    private String storesearchHostName;

    @Value("${storesearch.radius}")
    private String storesearchRadius;

    @Value("${thdapigateway.ssl.keystore.path}")
    private String thdApiGatewayKeyStore;

    @Value("${thdapigateway.ssl.keystore.password}")
    private String thdApiGatewayKeyStorePass;

    @Value("${thdapigateway.ssl.truststore.path}")
    private String thdApiGatewayTrustStore;

    @Value("${thdapigateway.ssl.truststore.password}")
    private String thdApiGatewayTrustStorePass;

    @Value("${cart.host.name}")
    private String cartHostName;

    @Value("${cart.gcphost.name}")
    private String cartGcpHostName;

    @Value("${cart.migration.enabled}")
    private Boolean cartMigrationEnabled;
    
    @Value("${hmac.client.secret}")
    private String clientHmacSecret;
    
    @Value("${hmac.client.token.expiry}")
    private Integer hmacTokenExpiry;
    
    @Value("${hmac.algorithm}")
    private String hmacAlgorithm;

    @Value("${hmac.client.token.networkDelay}")
    private String networkDelay;

    @Value("${hmac.client.token.tokenValidationBuffer}")
    private String tokenValidationBuffer;
    
    @Value("${registry.host.name}")
    private String registryHostName;
    
    @Value("${registry.context.path}")
    private String registryContextPath;

    @Value("${registry.context.cartpath}")
    private String registryContextCartPath;
    
    @Value("${registry.host.env}")
    private String registryHostEnv;
    
    @Value("${project.name}")
    private String appName;

    @Value("${cartactivity.cookie.domain}")
    private String cartActivityCookieDomain;

    @Value("${mylist.host.name}")
    private String mylistHostName;

    @Value("${registry.context.listpath}")
    private String registryContextListPath;

}
