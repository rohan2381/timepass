package com.homedepot.customer.util;

import java.util.HashMap;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.homedepot.customer.integration.registry.dto.Feature;

/**
 * Created by vxg6469 on 12/22/16.
 */
@Slf4j
@Service
public class FeatureSwitchUtil {
    
    @Autowired
    @Qualifier("registryFeaturesMap")
    HashMap<String, Feature> registryFeaturesMap;
    
    public String getFeatureValueByFeatureName(String featureName) {
        
        String strFeatureValue = null;
            
        if(null != registryFeaturesMap){
            Feature feature = registryFeaturesMap.get(featureName);
            strFeatureValue = (null != feature && StringUtils.isNotBlank(feature.getCharacterValue())) ? feature.getCharacterValue() : null;
        }
        log.debug("Feature switch value in Registry -- FeatureName: {}, Feature Value: {}", featureName , strFeatureValue);
        
        return strFeatureValue;
        
    }

    public boolean getFeatureValueByFeatureNameBoolean(String featureName) {
        
        boolean featureValue = false;
        
        if(null != registryFeaturesMap){
            Feature feature = registryFeaturesMap.get(featureName);
            featureValue = (null != feature && null != feature.getIntegerValue() && feature.getIntegerValue() == 1) ? true : false; 
        }
        log.debug("Feature key loaded from Registry Service -- FeatureName: {}, Feature Value: {}", featureName , featureValue);
        
        return featureValue;
        
    }

    public Feature getFeature(String featureName) {
        return registryFeaturesMap.get(featureName);
    }
    
}
