package com.homedepot.customer.util;

import java.util.regex.*;

import org.springframework.stereotype.Component;

/**
 * Created by rxb1809 on Jun 18, 2016
 *
 */
@Component
public class GlobalConstants {
    
    // Spring profiles
    public static final String SPRING_PFOFILE_DEV = "dev";
    public static final String SPRING_PFOFILE_STAGE = "stage";
    public static final String SPRING_PFOFILE_BETA = "beta";
    public static final String SPRING_PFOFILE_PROD = "prod";

    //THD_PERSIST cookie properties
    public static final int THD_PERSIST_MaxAge = 3600 * 24 * 365;
    public static final boolean THD_PERSIST_HttpOnly = false;
    public static final String THD_PERSIST_Path = "/";
    public static final boolean THD_PERSIST_SECURE = false;

    
    public static final String APPLICATION_ID = "customeraccountapi";
    public static final String ONLINE_STORE = "8119";
    
    public static final String CUST_ACCT_CLIENT_ID = "Cust-Acct-Client-ID";
    public static final String CUST_ACCT_CLIENT_TOKEN = "Cust-Acct-Client-Token";
    public static final String CUST_ACCT_CLIENT_TS = "Cust-Acct-Client-Timestamp";
    public static final String CUST_DELAY_FOR_TOKEN_VALIDATION = "Cust-Acct-Client-Delay-Token-Validation";
    
    public static final String HTTP = "http";
    public static final String HTTPS = "https";
    public static final String STR_Y = "Y";
    public static final String STR_N = "N";
    public static final String JSON = "json";
    public static final String XML = "xml";

    public static final String ACTION_TYPE_INSERT = "INSERT";
    public static final String ACTION_TYPE_UPDATE = "UPDATE";
    public static final String ACTION_TYPE_DELETE = "DELETE";

    public static final String REQUEST_STATUS_SUCCESS = "SUCCESS";
    public static final String REQUEST_STATUS_FAIL = "FAIL";

    public static final String SUCCESS = "SUCCESS";
    public static final String FAIL = "FAIL";

    public static final String TRADE_TYPE_OTHER = "Other";
    
    public static final String CHANNEL_ID = "channelId";

    public static final short TYPE_CODE_PREFERRED_STORE = 101;

    public static final String SOURCE_SYSTEM = "sourceSystem";
    public static final String PROGRAM = "program";
    public static final String USER_ID = "userId";
    public static final String HDCOM = "HDCOM";
    public static final String API_KEY = "api_key";

    public static final String CHARSET_UTF_8 = "UTF-8";
    public static final String THD_USER_SESSION = "THD_USER_SESSION";
    public static final String THD_USER = "THD_USER";
    
    public static final String THD_AUTH_TOKEN = "Authorization";

    public static final String CUSTOMER_ACCOUNT_API = "CUSTOMER_ACCOUNT_API";

    public static final String CLIENT_AUTH_TOKEN = "clientToken";
    public static final String CLIENT_SUPPLIED_TIMESTAMP = "timestamp";
    public static final String CLIENT_ID = "clientId";

    // WCS cookies/headers
    public static final String THD_SESSION= "THD_SESSION";
    public static final String WC_AUTHENTICATION = "WC_AUTHENTICATION";
    public static final String WC_USERACTIVITY = "WC_USERACTIVITY";
    public static final String WCSSESSIONID = "WCSSESSIONID";
    public static final String XWCSSESSIONID = "X-WCSSESSIONID";
    public static final String WC_PERSISTENT = "WC_PERSISTENT";
    public static final String THD_ONLINE_CHANNEL = "THD_ONLINE_CHANNEL";
    public static final String THD_ONLINE_CHANNEL_SEPARATOR = "::";

    // Constants for WCS THD_PERSIST cookie.
    public static final String THD_PERSIST = "THD_PERSIST";
    public static final String THD_PERSIST_BASE64_DELIMETER="%3A%3B";
    public static final String THD_PERSIST_EMTPY = "\"\"";
    public static final String THD_PERSIST_TOKEN_VAL_EXP = "_EXP=";
    public static final String THD_PERSIST_TOKEN_VAL_SEPARATOR = ":;";
    public static final String THD_PERSIST_TOKEN_EXPIRY_START = "; Expires=";
    public static final String EQUALS = "=";
    public static final String SEMICOLON = ";";
    public static final String COLON = ":";
    public static final String UNDERSCORE = "_";
    public static final String SETCOOKIE = "Set-Cookie";
    public static final String COOKIE_CRUMB_C4 = "C4";
    public static final String COOKIE_CRUMB_C4_EXP = "C4_EXP";
    public static final String COOKIE_CRUMB_C9 = "C9";
    public static final String COOKIE_CRUMB_C9_EXP = "C9_EXP";
    public static final String COOKIE_CRUMB_C12 = "C12";
    public static final String COOKIE_CRUMB_C12_EXP = "C12_EXP";
    public static final String COOKIE_CRUMB_C13 = "C13";
    public static final String COOKIE_CRUMB_C13_EXP = "C13_EXP";
    public static final String COOKIE_CRUMB_C13_DEFAULT_VAL = "self";
    public static final String COOKIE_CRUMB_C40 = "C40";
    public static final String COOKIE_CRUMB_C40_EXP = "C40_EXP";
    public static final String COOKIE_CRUMB_C40_VAL = "C";
    public static final String COOKIE_CRUMB_C43 = "C43";
    public static final String COOKIE_CRUMB_C43_EXP = "C43_EXP";
    public static final String COOKIE_CRUMB_C44 = "C44";
    public static final String COOKIE_CRUMB_C44_EXP = "C44_EXP";
    public static final String COOKIE_CRUMB_C45 = "C45";
    public static final String COOKIE_CRUMB_C45_EXP = "C45_EXP";
    public static final String COOKIE_CRUMB_C46 = "C46";
    public static final String COOKIE_CRUMB_C46_EXP = "C46_EXP";
    public static final String XCLIENT = "X-client";
    public static final String CART_ACTIVITY = "CART_ACTIVITY";

    public static final String ACCOUNT = "account";
    public static final String IDENTITY = "identity";

    public static final String PHONE_TYPE_MOBILE = "MOBILE";

    public static final String WCS_PHONE_TYPE_MOBILE = "MOBILEPHONE";

    public static final String STR_P = "P";

    public static  enum ACTION_TYPE {
        ACTION_TYPE_DELETE,
        ACTION_TYPE_INSERT,
        ACTION_TYPE_RETRIEVE,
        ACTION_TYPE_UPDATE

    }
    
    public static final String WCS = "WCS";
    public static final String IAM = "IAM";
    public static final String SVOC = "SVOC";
    public static final String XREF = "XREF";
    public static final String WCS_REGISTERED_USER_TYPE = "R";
    public static final String APPLICATION = "application";

    public static final String CUST_ACCOUNT_ID = "custAccountId";
    public static final String ADDRESS_ID = "addressId";

    public static final String PAYMENTCARDS = "paymentCards";

    // This list will grow as and when we roll-out various phases
    public static final String[] PROTECTED_REQUEST_PATHS = { "/addresses", "/addresses/", "/profile", "/profile/","/preferences","/preferences/", "/paymentcards", "/paymentcards/"}; // NOSONAR
    public static final String[] HMAC_PROTECTED_REQUEST_PATHS = {"/signIn","/signUp", "/checkCustomerExists"}; //NOSONAR
    
    public static final String EMAIL_KEY = "EMAIL";
    public static final String PASSWORD_KEY = "PASSWORD"; // NOSONAR
    public static final String CONFIRM_PASSWORD_KEY = "CONFIRM_PASSWORD"; // NOSONAR
    
    public static final String SVOC_UNAVAILABLE = "*** SVOC UNAVAILABLE ***: ";
    public static final String XREF_UNAVAILABLE = "*** XREF UNAVAILABLE ***: ";
    public static final String SVOC_UNAVAILABLE_MSG = "Svoc Unavailablity Message: ";
    public static final String XREF_UNAVAILABLE_MSG = "Xref Unavailablity Message: ";
    public static final String REQUEST_VALID_FOR_WCS = " *** Request valid for WCS system ***: ";
    public static final String HOMEDEPOT_EMAIL_DOMAIN="homedepot.com";
    
    // Feature Switches
    public static final String MCM_CUST_PRIMARY_AUTH = "MCM_CUST_PRIMARY_AUTH";
    public static final String MCM_CUST_WCS_BACKUP_FEATURE = "MCM_CUST_WCS_BACKUP_FEATURE";
    public static final String MCM_CUST_WCS_RETIREMENT_FEATURE = "MCM_CUST_WCS_RETIREMENT_FEATURE";
    public static final String MCM_XREF_FEATURE = "MCM_XREF_FEATURE";
    public static final String MCC_CART_MIGRATE_GCP_FEATURE = "GCP_FEATURE";

    // SSL info
    public static final String KEY_MANAGER_FACTORY_ALGORITHM = "SunX509";
    public static final String KEY_STORE_TYPE = "JKS";
    public static final String SSL_CONTEXT = "TLS";
    public static final String[] SSL_PROTOCOLS = {"TLSv1.2","TLSv1.1","TLSv1","SSLv3"}; // NOSONAR
    public static final String TRUST_MANAGER_FACTORY_ALGORITHM = "SunX509";
    public static final String TRUST_MANAGER_FACTORY_ALGORITHM_PROVIDER = "SunJSSE";
    

    public static final String IAM_LOCK_ACCOUNT_ACTIVE = "Active";

    public static final String LOCALHOST = "localhost";

    public static final Pattern THD_PERSIST_CRUMB_SPLIT_PATTERN = Pattern.compile(THD_PERSIST_BASE64_DELIMETER, Pattern.CASE_INSENSITIVE);
    
    public static final String THD_ENV = "THD_ENV";
    
    public static final String THREAD_SLEEP_DATA_SYNC_MSG ="Pausing for few seconds to allow request context to be available in the async child threads. Only for DEV env";

    public static final String GUEST_LIST_MIGRATE_GCP_FEATURE = "GUESTLIST_ENABLED";

}
