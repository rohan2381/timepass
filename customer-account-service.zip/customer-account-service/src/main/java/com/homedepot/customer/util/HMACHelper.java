package com.homedepot.customer.util;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Jun 5, 2017
 *
 */
@Component
@Slf4j
public class HMACHelper {
    
    @Autowired
    EnvPropertyUtil envProperty;

    /**
     * Generates an encoded HMAC token
     * @return
     */
    public String generateEncodedHMACToken(String timestamp, String clientId){
        String encodedToken = null;

        try {
            log.debug("Client timestamp passed: "+timestamp);

            String message = timestamp + clientId;

            Mac sha256HMAC = Mac.getInstance(envProperty.getHmacAlgorithm());
            SecretKeySpec secretKey = new SecretKeySpec(envProperty.getClientHmacSecret().getBytes(), envProperty.getHmacAlgorithm());
            sha256HMAC.init(secretKey);

            encodedToken = Base64.encodeBase64String(sha256HMAC.doFinal(message.getBytes()));
            log.debug("Client token passed: "+encodedToken);
        }
        catch (Exception e){
            log.error("Error generating Client Token: "+e);
        }

        return encodedToken;
    }
}
