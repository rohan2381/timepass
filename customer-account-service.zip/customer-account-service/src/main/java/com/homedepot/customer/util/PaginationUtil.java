package com.homedepot.customer.util;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

/**
 * Created by rxb1809 on Dec 18, 2016
 *
 */
@Component
public class PaginationUtil {

    public <T> List<T> paginate(List<T> objList, int pageNo, int pageSize){
        return objList.stream()
                .skip((long)pageSize * (pageNo - 1))
                .limit(pageSize)
                .collect(Collectors.toCollection(ArrayList::new));
    }
    
    public int getTotalPages(int totalRecords, int pageSize ){
        if (totalRecords % pageSize == 0) {
            return totalRecords / pageSize;
          } else {
              return totalRecords / pageSize + 1;
          }
    }
}
