package com.homedepot.customer.util;

import java.util.Arrays;

public enum PaymentCardBrand {
    AMEX, DISC, HDCOM, HDCON, MA, VISA, MC;

    /**
     * Method to check if payment card brand name is valid
     * 
     * @param name
     * @return boolean
     */
    public static boolean isValidPaymentCardBrand(String name) {
        return Arrays.stream(PaymentCardBrand.values()).anyMatch(e -> e.name().equals(name));
    }
}
