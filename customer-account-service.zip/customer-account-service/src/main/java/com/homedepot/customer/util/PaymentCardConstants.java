package com.homedepot.customer.util;

/**
 * Created by rxm4390mbp on 9/2/16.
 */
public class PaymentCardConstants {

    public static final String PAYMENT_CARD_MASK="************";
}
