package com.homedepot.customer.util;

public enum PaymentCardType {

    AMEX(PaymentCardBrand.AMEX, PaymentCardBrand.AMEX, "AX", "American Express"),
    DISC(PaymentCardBrand.DISC, PaymentCardBrand.DISC, "DS", "Discover"),
    MASTERCARD(PaymentCardBrand.MA, PaymentCardBrand.MC, "MA", "Master Card"),
    VISA(PaymentCardBrand.VISA, PaymentCardBrand.VISA, "VI", "Visa"),

    REWARDSMC(PaymentCardBrand.HDCOM, PaymentCardBrand.HDCOM, "CC", "Rewards MasterCard"),
    BUSINESSREWARDS(PaymentCardBrand.HDCOM, PaymentCardBrand.HDCOM, "CM", "Business Rewards MasterCard"),
    EXPOHIL(PaymentCardBrand.HDCOM, PaymentCardBrand.HDCOM, "EH", "Expo Hil"),
    HDHYBRIDRPL(PaymentCardBrand.HDCOM, PaymentCardBrand.HDCOM, "HA", "Hybrid RPL"),
    HDLINKED(PaymentCardBrand.HDCOM, PaymentCardBrand.HDCOM, "HB", "Hybrid Linked RPL"),
    HDPL(PaymentCardBrand.HDCOM, PaymentCardBrand.HDCOM, "HD", "Home Depot Private Label"),

    THDHIL(PaymentCardBrand.HDCOM, PaymentCardBrand.HDCOM, "HH", "THD Hil"),
    HOMEIMPROVER(PaymentCardBrand.HDCOM, PaymentCardBrand.HDCOM, "HI", "Home Improver"),
    HDMASTERCARD(PaymentCardBrand.HDCOM, PaymentCardBrand.HDCOM, "HM", "Hybrid General Purpose"),
    PROX(PaymentCardBrand.HDCOM, PaymentCardBrand.HDCOM, "HP", "Commercial Account"),
    CRC(PaymentCardBrand.HDCOM, PaymentCardBrand.HDCOM, "HR", "Commercial Revolving Charge"),

    EXPOCON(PaymentCardBrand.HDCON, PaymentCardBrand.HDCON, "EC", "Expo Consumer"),
    HDCON(PaymentCardBrand.HDCON, PaymentCardBrand.HDCON, "HC", "HD Consumer Credit Card");

    PaymentCardBrand cardBrand;
    PaymentCardBrand wcsCardBrand;
    private String shortDesc;
    private String description;

    private PaymentCardType(PaymentCardBrand cardBrand, PaymentCardBrand wcsCardBrand, String shortDesc, String description) {
        this.cardBrand = cardBrand;
        this.wcsCardBrand = wcsCardBrand;
        this.shortDesc = shortDesc;
        this.description = description;
    }

    public PaymentCardBrand getCardBrand() {
        return cardBrand;
    }

    public PaymentCardBrand getWCSCardBrand() {
        return wcsCardBrand;
    }

    public String getShortDesc() {
        return shortDesc;
    }

    public String getDescription() {
        return description;
    }

    public static PaymentCardType getByShortDesc(String abbreviation) {
        for (PaymentCardType cardType : PaymentCardType.values()) {
            if (cardType.shortDesc.equalsIgnoreCase(abbreviation)) {
                return cardType;
            }
        }
        throw new TypeNotPresentException("Value not found", new Throwable("Value not found"));
    }

    public static PaymentCardType getByCardBrand(String cardBrand) {
        for (PaymentCardType cardType : PaymentCardType.values()) {
            if (cardType.cardBrand.name().equalsIgnoreCase(cardBrand)) {
                return cardType;
            }
        }
        throw new TypeNotPresentException("Value not found", new Throwable("Value not found"));
    }

    public static PaymentCardType getByWCSCardBrand(String cardBrand) {
        for (PaymentCardType cardType : PaymentCardType.values()) {
            if (cardType.wcsCardBrand.name().equalsIgnoreCase(cardBrand)) {
                return cardType;
            }
        }
        throw new TypeNotPresentException("Value not found", new Throwable("Value not found"));
    }

}
