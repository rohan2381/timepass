package com.homedepot.customer.util;

/**
 * Created by rxb1809 on Aug 11, 2016
 *
 */
public enum Resource {

    ACCOUNT, ADDRESS, PAYMENT, IDENTITY, PREFERENCE, DEFAULT

}
