package com.homedepot.customer.util;

/**
 * Created by rxb1809 on Nov 13, 2016
 * Enum to denote the 2 auth systems available
 */
public enum SessionAuth {
    IAM, WCS;
}
