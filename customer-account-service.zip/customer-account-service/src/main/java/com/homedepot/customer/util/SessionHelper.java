package com.homedepot.customer.util;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.homedepot.customer.datasync.profile.SessionSyncExecutor;
import com.homedepot.customer.datasync.util.DataSyncUtil;
import com.homedepot.customer.exception.AuthenticationException;
import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.exception.GenericSystemException;
import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.exception.error.IdentityErrorCode;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.integration.iam.config.IAMRestTemplateInfo;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;
import com.homedepot.customer.model.THDUserInfo;
import com.homedepot.customer.repository.IIdentityRepository;
import com.homedepot.customer.request.ClientAuthRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.time.StopWatch;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Created by rxb1809 on Nov 9, 2016
 */
@Component
@Slf4j
public class SessionHelper {

    @Autowired
    IIdentityRepository identityRepository;

    @Autowired
    private CustomerAccountRequestContext requestContext;

    @Autowired
    SessionSyncExecutor sessionSyncExecutor;

    @Autowired
    FeatureSwitchUtil featureSwitchUtil;

    @Autowired
    EnvPropertyUtil envProperty;

    @Autowired
    private DataSyncUtil dataSyncUtil;

    @Autowired
    @Qualifier("iamRestTemplateInfo")
    private IAMRestTemplateInfo iamRestTemplateInfo;

    @Autowired
    @Qualifier("iamErrorCodeMapResource")
    private ResourceBundleMessageSource errorCodeSource;

    public boolean validateUserSession(HttpServletRequest request) throws CustomerAccountServiceException {
        boolean isUserSessionValid = false;
        boolean isIAMSessionValid = false;
        boolean isWCSSessionValid = false;

        String svocCustomerAccountId = null;
        String wcsMemberId = null;

        String primaryAuthSystem = featureSwitchUtil.getFeatureValueByFeatureName(GlobalConstants.MCM_CUST_PRIMARY_AUTH) != null ?
                featureSwitchUtil.getFeatureValueByFeatureName(GlobalConstants.MCM_CUST_PRIMARY_AUTH) : GlobalConstants.IAM;

        boolean wcsBkUpOn = featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE);

        if (GlobalConstants.IAM.equalsIgnoreCase(primaryAuthSystem.trim())) {
            log.debug("The primary auth system is IAM");
            String iamUserToken = request.getHeader(GlobalConstants.THD_AUTH_TOKEN);

            svocCustomerAccountId = validateIAMToken(request, iamUserToken);
            isIAMSessionValid = svocCustomerAccountId != null ? true : false;

            if (!isIAMSessionValid && wcsBkUpOn) {
                log.debug("IAM session invalid");
                log.debug("WCS fallback available");
                wcsMemberId = validateWCSToken(request, null);
                isWCSSessionValid = wcsMemberId != null ? true : false;
            }

        } else if (GlobalConstants.WCS.equalsIgnoreCase(primaryAuthSystem.trim())) {
            log.debug("The primary auth system is WCS");
            String wcsUserToken = request.getHeader(GlobalConstants.THD_AUTH_TOKEN);
            wcsMemberId = validateWCSToken(request, wcsUserToken);
            isWCSSessionValid = wcsMemberId != null ? true : false;
        }

        if (isIAMSessionValid) {
            log.debug("The request is validated using IAM auth");
            requestContext.setSessionAuth(SessionAuth.IAM);
            requestContext.setSvocCustomerAccountId(svocCustomerAccountId);
            isUserSessionValid = true;
            // If WCS is still around validate in wcs too to keep session alive
            if (wcsBkUpOn) {
                sessionSyncExecutor.validateWCSTokenAsync(request.getCookies());
                //dataSyncUtil.pauseAroundDataSync(); 
            }

        } else if (isWCSSessionValid) {
            log.debug("The request is validated using WCS auth");
            requestContext.setSessionAuth(SessionAuth.WCS);
            requestContext.setWcsMemberId(wcsMemberId);
            isUserSessionValid = true;
        }

        if (!isIAMSessionValid && !isWCSSessionValid) {
            log.debug("The request cannot be validated using neither IAM nor WCS auth");
            isUserSessionValid = false;
        }

        return isUserSessionValid;
    }

    public String validateWCSToken(HttpServletRequest request, String userAuthToken) throws RepositoryException, GenericSystemException {
        String wcsMemberId = null;
        String wcsUserToken = null;

        Cookie[] cookies = null;
        try {
            // Check if WCS session cookie is present
            cookies = request.getCookies();
            if (cookies != null && !Arrays.asList(cookies).stream().filter(c -> c.getName().equalsIgnoreCase(GlobalConstants.THD_SESSION)).findAny().isPresent()) {
                return null;
            }

            if (userAuthToken != null) {
                wcsUserToken = userAuthToken;
            } else {
                log.debug("WCS token not present. Trying to get it from C45 crumb in the THD_PERSIST cookie");
                wcsUserToken = extractWCSTokenFromCookie(cookies);
            }

            if (wcsUserToken == null) {
                log.debug("WCS token missing in the request. Hence returning");
                return null;
            }

            // Make the call to validate WCS session
            wcsMemberId = identityRepository.validateWCSSession(wcsUserToken, false, null);
        } catch (RepositoryException rEx) {
            if (rEx.getHttpStatus().equals(HttpStatus.UNAUTHORIZED) || rEx.getHttpStatus().equals(HttpStatus.INTERNAL_SERVER_ERROR)) {
                wcsMemberId = null;
            } else {
                log.error("Error validating WCS token {}", ExceptionUtils.getRootCause(rEx));
                throw rEx;
            }
        } catch (UnsupportedEncodingException uEx) {
            log.error("Error validating WCS token {}", ExceptionUtils.getRootCause(uEx));
            throwGenericError();
        }

        return wcsMemberId;
    }

    public String validateIAMToken(HttpServletRequest request, String userAuthToken) throws RepositoryException, GenericSystemException {
        String svocCustAccountIdFromSession = null;
        String svocCustAccountIdFromCookie = null;
        try {
            // Check if IAM THD_USER cookie is present 
            Cookie[] cookies = request.getCookies();
            if (cookies != null && !Arrays.asList(cookies).stream()
                    .filter(c -> c.getName().equalsIgnoreCase(GlobalConstants.THD_USER))
                    .findFirst().isPresent()) {
                return null;
            }

            // Extract svoc id from the cookie
            svocCustAccountIdFromCookie = extractSVOCIdFromCookie(Arrays.asList(cookies).stream()
                    .filter(c -> c.getName().equalsIgnoreCase(GlobalConstants.THD_USER))
                    .findFirst().orElse(null));
            // svoc id from the iam token
            svocCustAccountIdFromSession = identityRepository.validateSession(userAuthToken);

        } catch (RepositoryException rEx) {
            if (rEx.getHttpStatus().equals(HttpStatus.UNAUTHORIZED)) {
                svocCustAccountIdFromSession = null;
            } else {
                log.error("Error validating IAM token {}", userAuthToken, ExceptionUtils.getRootCause(rEx));
                throw rEx;
            }
        } catch (Exception ex) {
            log.error("Error validating IAM token {}", userAuthToken, ExceptionUtils.getRootCause(ex));
            throwGenericError();
        }

        if (svocCustAccountIdFromSession != null && svocCustAccountIdFromCookie != null
                && svocCustAccountIdFromSession.equalsIgnoreCase(svocCustAccountIdFromCookie)) {
            return svocCustAccountIdFromSession;
        } else {
            return null;
        }
    }

    private void throwGenericError() throws GenericSystemException {
        Error error = new Error();
        error.setErrorCode(ErrorCode.SYSTEM_ERROR);
        Errors errors = new Errors();
        errors.setErrors(Collections.singletonList(error));
        throw new GenericSystemException(errors);
    }

    public String extractWCSTokenFromCookie(Cookie[] cookies) throws UnsupportedEncodingException {
        String wcsUserToken = null;
        Optional<Cookie> thdPersistCookie = Arrays.asList(cookies).stream().filter(c -> c.getName().equalsIgnoreCase(GlobalConstants.THD_PERSIST)).findFirst();

        if (thdPersistCookie.isPresent() && thdPersistCookie.get() != null) {
            String thdPersistValueEncoded = thdPersistCookie.get().getValue();
            Optional<String> thdPersistValue = Optional.of(URLDecoder.decode(thdPersistValueEncoded, GlobalConstants.CHARSET_UTF_8));

            if (thdPersistValue.isPresent()) {
                log.debug("extractWCSTokenFromCookie - THD_PERSIST : {}", thdPersistValue);
                wcsUserToken = Arrays
                        .asList(thdPersistValue.map(p -> p.split(";"))
                                .get())
                        .stream()
                        .filter(c -> c.contains(GlobalConstants.COOKIE_CRUMB_C45 + GlobalConstants.EQUALS))
                        .findFirst()
                        .map(s -> s.substring(s.lastIndexOf(GlobalConstants.EQUALS) + 1, s.length() - 1))
                        .orElse(null);
                log.debug("WCS Token - " + wcsUserToken);

            }
        }

        return wcsUserToken;
    }

    public boolean wcsCallRequired(HttpServletRequest request) {
        boolean wcsRequired = true;
        String wcsReqValue = request.getHeader(GlobalConstants.XCLIENT);
        log.debug("Header: {} Value: {} ", GlobalConstants.XCLIENT, wcsReqValue);
        if (!StringUtils.isEmpty(wcsReqValue)) {
            wcsRequired = (wcsReqValue.equalsIgnoreCase("mcc")) ? false : true;
        }
        return wcsRequired;
    }

    public String extractSVOCIdFromCookie(Cookie cookie) throws JsonParseException, JsonMappingException, IOException {
        String svocIdFromCookie = null;

        if (cookie != null && cookie.getName().equalsIgnoreCase(GlobalConstants.THD_USER)) {
            String thdUserDecoded = new String(java.util.Base64.getDecoder().decode(cookie.getValue()), GlobalConstants.CHARSET_UTF_8);

            THDUserInfo thdUser = iamRestTemplateInfo.getObjectMapper().readValue(thdUserDecoded, THDUserInfo.class);

            if (thdUser != null) {
                svocIdFromCookie = thdUser.getSvocCustomerAccountId();
            }
        }

        return svocIdFromCookie;
    }

    public String generateAuthToken(ClientAuthRequest clientAuthRequest) throws RepositoryException, GenericSystemException {
        String hash = null;
        String clientSuppliedTimeStamp = null;
        String clientId = null;

        long timestamp = 0L;

        try {

            clientSuppliedTimeStamp = clientAuthRequest.getTimestamp();
            clientId = clientAuthRequest.getClientId();

            StopWatch watch = new StopWatch();
            watch.start();

            if (StringUtils.isNoneBlank(clientSuppliedTimeStamp, clientId)) {

                timestamp = Long.valueOf(clientAuthRequest.getTimestamp());

                String message = Long.valueOf(clientAuthRequest.getTimestamp()) + clientAuthRequest.getClientId();
                Mac hmacSha = Mac.getInstance(envProperty.getHmacAlgorithm());
                SecretKeySpec secretKey = new SecretKeySpec(envProperty.getClientHmacSecret().getBytes(), envProperty.getHmacAlgorithm());
                hmacSha.init(secretKey);

                hash = Base64.encodeBase64String(hmacSha.doFinal(message.getBytes()));

                log.debug("Token_HASH/TIMESTAMP" + hash + "/" + clientAuthRequest.getTimestamp());
                watch.stop();
                log.debug("Time taken for Token Generation - [" + (watch.getTime()) + "]ms");
            }

        } catch (Exception e) {
            log.error("Token Generation Error : generateAuthToken " + ExceptionUtils.getRootCause(e));
            throwGenericError();
        }

        return hash;
    }

    public String generateTimestamp() {
        return String.valueOf(System.currentTimeMillis());
    }

    public boolean validateClientAuth(ClientAuthRequest clientAuthRequest) throws AuthenticationException, GenericSystemException {

        String clientSuppliedSecureToken = null;
        String clientSuppliedTimeStamp = null;
        String clientId = null;
        String clientSuppliedDelayforValidatingToken = null;

        long totalTimestampWithDelays = 0L;

        // Prevent Replay Attacks ...

        try {
            clientSuppliedSecureToken = clientAuthRequest.getClientAuthToken();
            clientSuppliedTimeStamp = clientAuthRequest.getTimestamp();
            clientId = clientAuthRequest.getClientId();
            clientSuppliedDelayforValidatingToken = clientAuthRequest.getClientDelayForTokenValidation();

            if (StringUtils.isNoneBlank(clientSuppliedSecureToken, clientSuppliedTimeStamp, clientId, clientSuppliedDelayforValidatingToken )) {
                //timestampWithDelay = Long.valueOf(clientSuppliedTimeStamp) + TimeUnit.MINUTES.toMillis(Long.valueOf(clientSuppliedDelayforValidatingToken));

                //clientAuthRequest.setTimestamp(String.valueOf(timestampWithDelay));

                totalTimestampWithDelays = Long.valueOf(clientSuppliedTimeStamp) + TimeUnit.MINUTES.toMillis(Long.valueOf(clientSuppliedDelayforValidatingToken)) + Long.valueOf(envProperty.getTokenValidationBuffer()) + Long.valueOf(envProperty.getNetworkDelay());

                if (generateAuthToken(clientAuthRequest).equalsIgnoreCase(
                        clientSuppliedSecureToken)) {
                    log.debug("Validated the token successfully");
                    return true;
                }
            }
        } catch (Exception ex) {
            log.error("Error validating client token {}", clientSuppliedSecureToken, ExceptionUtils.getRootCause(ex));
            throwGenericError();
        }

        return false;
    }

    private void throwAuthError() throws AuthenticationException {
        List<Error> errorList = new ArrayList<>();

        Error error = new Error();
        error.setErrorCode(IdentityErrorCode.USER_NOT_AUTHORIZED.getCode());
        errorList.add(error);
        Errors errors = new Errors();
        errors.setErrors(errorList);

        throw new AuthenticationException(errors);
    }
}
