package com.homedepot.customer.util;

/**
 * Created by rxb1809 on Apr 20, 2017
 *
 */
public enum THDEnv {

    ST71(".hd-st71.homedepotdev.com","origin.api.hd-st71.homedepotdev.com","secure.hd-st71.homedepotdev.com"), 
    ST72(".hd-st72.homedepotdev.com","origin.api.hd-st72.homedepotdev.com","secure.hd-st72.homedepotdev.com"), 
    ST73(".hd-st73.homedepotdev.com","origin.api.hd-st73.homedepotdev.com","secure.hd-st73.homedepotdev.com"), 
    ST74(".hd-st74.homedepotdev.com","origin.api.hd-st74.homedepotdev.com","secure.hd-st74.homedepotdev.com"),
    QA71(".hd-qa71.homedepotdev.com","origin.api.hd-qa71.homedepotdev.com","secure.hd-qa71.homedepotdev.com"), 
    QA72(".hd-qa72.homedepotdev.com","origin.api.hd-qa72.homedepotdev.com","secure.hd-qa72.homedepotdev.com"), 
    QA73(".hd-qa73.homedepotdev.com","origin.api.hd-qa73.homedepotdev.com","secure.hd-qa73.homedepotdev.com"),
    QA74(".hd-qa74.homedepotdev.com","origin.api.hd-qa74.homedepotdev.com","secure.hd-qa74.homedepotdev.com");
    
    private String domain;
    private String originUrl;
    private String secureUrl;
    
    private THDEnv(String domain, String originUrl, String secureUrl){
        this.domain = domain;
        this.originUrl = originUrl;
        this.secureUrl = secureUrl;
    }

    public String getDomain() {
        return domain;
    }

    public String getOriginUrl() {
        return originUrl;
    }

    public String getSecureUrl() {
        return secureUrl;
    }
}
