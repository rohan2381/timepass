package com.homedepot.customer.util;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpInputMessage;
import org.springframework.http.HttpOutputMessage;
import org.springframework.http.MediaType;
import org.springframework.http.converter.GenericHttpMessageConverter;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.util.StreamUtils;
import org.springframework.web.client.RestClientException;

/**
 * Catch all Message Converter to log body response from integration point in case where response cannot be converted by JSON converter.
 * The read methods log response body then throw RestClientException to preserve error handling flow as if there are no matching converters.
 * This is needed because http error status 500 from gateway is in HTML format and RestTemplate's JSON converter does not expect that.
 * Log can be turn on/off by setting log level in application.yml
 *
 * Created by jirapat on 3/3/17.
 */
@Slf4j
public class TextHtmlMessageConverter<T> implements GenericHttpMessageConverter<T> {
    public static final Charset DEFAULT_CHARSET = Charset.forName("ISO-8859-1");
    private ArrayList<MediaType> supportedMediaTypes = new ArrayList<>();

    public TextHtmlMessageConverter() {
        supportedMediaTypes.add(MediaType.TEXT_HTML);
    }

    @Override
    public boolean canRead(Type type, Class<?> aClass, MediaType mediaType) {
        return true;
    }

    /**
     * Logs response body then throw RestClientException to preserve error handling flow as if there are no matching converters.
     * @param type
     * @param aClass
     * @param httpInputMessage
     * @return
     * @throws IOException
     * @throws HttpMessageNotReadableException
     */
    @Override
    public T read(Type type, Class<?> aClass, HttpInputMessage httpInputMessage) throws IOException, HttpMessageNotReadableException {
        Charset charset = this.getContentTypeCharset(httpInputMessage.getHeaders().getContentType());
        String s = StreamUtils.copyToString(httpInputMessage.getBody(), charset);
        log.error("Could not convert response to {}: body {}", type, s);

        throw new RestClientException("Could not convert response, body is logged by " + this.getClass().getName());
    }

    @Override
    public boolean canWrite(Type type, Class<?> aClass, MediaType mediaType) {
        // not support
        return false;
    }

    @Override
    public void write(T t, Type type, MediaType mediaType, HttpOutputMessage httpOutputMessage) throws IOException, HttpMessageNotWritableException {
        // not support
    }

    @Override
    public boolean canRead(Class<?> aClass, MediaType mediaType) {
        return true;
    }

    @Override
    public boolean canWrite(Class<?> aClass, MediaType mediaType) {
        // not support
        return false;
    }

    @Override
    public List<MediaType> getSupportedMediaTypes() {
        return supportedMediaTypes;
    }

    @Override
    public T read(Class<? extends T> aClass, HttpInputMessage httpInputMessage) throws IOException, HttpMessageNotReadableException {
        Charset charset = this.getContentTypeCharset(httpInputMessage.getHeaders().getContentType());
        String s = StreamUtils.copyToString(httpInputMessage.getBody(), charset);
        log.error("Could not convert response: body {}", s);

        throw new RestClientException("Could not convert response, body text is logged by " + this.getClass().getName());
    }

    @Override
    public void write(T t, MediaType mediaType, HttpOutputMessage httpOutputMessage) throws IOException, HttpMessageNotWritableException {
        // not support
    }

    private Charset getContentTypeCharset(MediaType contentType) {
        return contentType != null && contentType.getCharSet() != null ? contentType.getCharSet(): StandardCharsets.UTF_8;
    }
}
