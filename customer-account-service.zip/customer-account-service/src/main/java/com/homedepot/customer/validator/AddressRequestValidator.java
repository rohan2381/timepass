package com.homedepot.customer.validator;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.homedepot.customer.exception.error.AddressErrorCode;
import com.homedepot.customer.model.Address;
import com.homedepot.customer.model.Phone;
import com.homedepot.customer.model.PostalDetails;
import com.homedepot.customer.request.AddressRequest;
import com.homedepot.customer.validator.rule.impl.EmailRule;
import com.homedepot.customer.validator.rule.impl.NameRule;
import com.homedepot.customer.validator.rule.impl.PaginationParameterRule;
import com.homedepot.customer.validator.rule.impl.PhoneRule;
import com.homedepot.customer.validator.rule.impl.PoBoxAddressRule;
import com.homedepot.customer.validator.rule.impl.PostalDetailsRule;
import com.homedepot.customer.validator.rule.impl.ZipCodeRule;

import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpMethod.PUT;

/**
 * Created by rxb1809 on Jun 21, 2016
 *
 */
@Component("addressvalidator")
@Slf4j
public class AddressRequestValidator extends BaseRequestValidator<AddressRequest> {

    @Autowired
    PostalDetailsRule postalDetailsRule;

    @Autowired
    NameRule nameRule;

    @Autowired
    EmailRule emailRule;

    @Autowired
    PhoneRule phoneRule;

    @Autowired
    PoBoxAddressRule poBoxAddressRule;

    @Autowired
    PaginationParameterRule paginationParameterRule;

    @Autowired
    ZipCodeRule zipCodeRule;

    @Override
    protected List<AddressErrorCode> validateRequest(AddressRequest request, HttpMethod actionType) {
        List<AddressErrorCode> errors = new ArrayList<>();
        switch (actionType) {
        case PUT:
            request.getAddress().stream().forEach(address -> {
                if (address.getAddrIdentifier() == null || address.getAddrIdentifier() == 0)
                    errors.add(AddressErrorCode.INVALID_ADDRESS_ID_MISSING);
                if (address.getLastModifiedDate() == null)
                    errors.add(AddressErrorCode.INVALID_ADDRESS_LASUPDATETIMESTAMP_MISSING);
            });
            validateUpdateOrCreateParameters(actionType, request, errors);
            break;

        case GET:
            errors.addAll(paginationParameterRule.check(request.getPaginationInfo()).stream()
                    .map(AddressErrorCode::valueOf).collect(Collectors.toList()));
            break;

        case POST:
            validateUpdateOrCreateParameters(actionType, request, errors);
            break;

        default:
            break;
        }

        return errors;
    }

    private void validateUpdateOrCreateParameters(HttpMethod actionType, AddressRequest request,
            List<AddressErrorCode> errors) {

        request.getAddress().forEach(
                addr -> {
                    if (addr.getIsDefault() != null && addr.getPostalDetails() != null && addr.getIsDefault()) {
                        if (StringUtils.isNoneBlank(addr.getPostalDetails().getAddressLine1())) {
                            errors.addAll(poBoxAddressRule.check(addr.getPostalDetails().getAddressLine1()).stream()
                                    .map(AddressErrorCode::valueOf).collect(Collectors.toList()));
                        }
                        if (StringUtils.isNoneBlank(addr.getPostalDetails().getAddressLine2())) {
                            errors.addAll(poBoxAddressRule.check(addr.getPostalDetails().getAddressLine2()).stream()
                                    .map(AddressErrorCode::valueOf).collect(Collectors.toList()));
                        }
                    }

                    validateName(addr, errors);
                    validateEmail(addr, errors);
                    validatePrimaryPhone(addr.getPrimaryPhone(), errors);
                    validateAlternatePhone(addr.getAlternatePhone(), errors, actionType);
                    validatePostalDetails(addr, errors);
                });
    }

    private void validateName(Address addr, List<AddressErrorCode> errors) {
        if (addr.getName() != null) {
            if (StringUtils.isBlank(addr.getName().getFirstName())) {
                errors.add(AddressErrorCode.INVALID_FIRST_NAME_MISSING);
            }

            if (StringUtils.isBlank(addr.getName().getLastName())) {
                errors.add(AddressErrorCode.INVALID_LAST_NAME_MISSING);
            }

            errors.addAll(nameRule.check(addr.getName()).stream().map(AddressErrorCode::valueOf)
                    .collect(Collectors.toList()));
        } else {
            errors.add(AddressErrorCode.INVALID_FIRST_NAME_MISSING);
            errors.add(AddressErrorCode.INVALID_LAST_NAME_MISSING);
        }

    }

    private void validateEmail(Address addr, List<AddressErrorCode> errors) {
        // address level email is optional
        if (StringUtils.isNotBlank(addr.getEmailId())) {
            errors.addAll(emailRule.check(addr.getEmailId()).stream().map(error -> AddressErrorCode.valueOf(error))
                    .collect(Collectors.toList()));
        }

    }

    private void validatePrimaryPhone(Phone phone, List<AddressErrorCode> errors) {
        if (phone == null || StringUtils.isBlank(phone.getNumber())) {
            errors.add(AddressErrorCode.INVALID_PRIMARY_PHONE_MISSING);
        } else if (!phoneRule.check(phone).isEmpty()) {
            errors.add(AddressErrorCode.INVALID_PRIMARY_PHONE);
        }
    }

    private void validateAlternatePhone(Phone phone, List<AddressErrorCode> errors, HttpMethod actionType) {
        if (phone != null) {
            if (actionType == POST) {
                // crete address
                if (StringUtils.isBlank(phone.getNumber())) {
                    // phone number should not be blank
                    errors.add(AddressErrorCode.INVALID_ALTERNATE_PHONE_MISSING);
                } else if (!phoneRule.check(phone).isEmpty()) {
                    // phone number format should be valid
                    errors.add(AddressErrorCode.INVALID_ALTERNATE_PHONE);
                }
            } else if (actionType == PUT) {
                // update address, can have insert/update/delete alternate phone
                // action
                // to delete alternate phone, request is sent with phone id but
                // empty/null phone number
                if (StringUtils.isNotBlank(phone.getNumber())) {
                    if (!phoneRule.check(phone).isEmpty()) {
                        // phone number is not blank, it mast be valid format
                        errors.add(AddressErrorCode.INVALID_ALTERNATE_PHONE);
                    }
                } else if (phone.getId() == null || phone.getId() < 1) {
                    // phone number is blank, needs phone id to be a valid
                    // delete action
                    errors.add(AddressErrorCode.INVALID_ALTERNATE_PHONE_MISSING);
                }
            }
        }
    }

    private void validatePostalDetails(Address addr, List<AddressErrorCode> errors) {

		if (addr.getPostalDetails() == null) {
			// check empty object will report all elements of postal details as missing
			// so we don't have to add  individual error codes here
			errors.addAll(postalDetailsRule.check(new PostalDetails()).stream()
					.map(AddressErrorCode::valueOf)
					.collect(Collectors.toList()));
		} else {
			errors.addAll(postalDetailsRule.check(addr.getPostalDetails()).stream()
					.map(AddressErrorCode::valueOf)
					.collect(Collectors.toList()));
		}
	}
}
