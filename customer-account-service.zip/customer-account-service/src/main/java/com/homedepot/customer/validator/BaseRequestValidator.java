package com.homedepot.customer.validator;

import com.homedepot.customer.exception.AuthenticationException;
import com.homedepot.customer.exception.CustomerAccountServiceException;
import com.homedepot.customer.exception.GenericSystemException;
import com.homedepot.customer.exception.InvalidRequestException;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.exception.error.IdentityErrorCode;
import com.homedepot.customer.model.Error;
import com.homedepot.customer.model.Errors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Created by rxb1809 on Jun 21, 2016 This is a base request validator class.
 * All specific validators will need to extend this and override their own
 * validateRequest logic. This class will govern the steps by virtue of the
 * template method (validate)
 */
@Component
@Slf4j
public abstract class BaseRequestValidator<T> {

    protected abstract List<? extends ErrorCode> validateRequest(T request, HttpMethod action_type);

    public final void validate(T request, HttpMethod actionType) throws CustomerAccountServiceException {
        try {
            log.debug("Begin request validation " +this.getClass().getName());
            List<? extends ErrorCode> errors = validateRequest(request, actionType);

            log.debug("End request validation " +this.getClass().getName());
            if (!CollectionUtils.isEmpty(errors)) {
                log.debug("Customer Account Request has validation errors, {}", errors);
                throwError(errors);
            }
        }
        catch (CustomerAccountServiceException e) {
            throw e;
        }
        catch (Exception e) {
            throw new GenericSystemException(HttpStatus.INTERNAL_SERVER_ERROR, e);
        }
    }

    private void throwError(List<? extends ErrorCode> validationErrors) throws CustomerAccountServiceException {
        List<Error> errorList = new ArrayList<>();
        validationErrors.forEach(rError -> {
            Error error = new Error();
            error.setErrorCode(rError.getCode());
            errorList.add(error);
        });

        Errors errors = new Errors();
        errors.setErrors(errorList);
        
        Optional<Error> systemError = errors.getErrors().stream().filter(e -> e.getErrorCode().equalsIgnoreCase(ErrorCode.SYSTEM_ERROR)).findAny();
        
        Optional<Error> authError = errors.getErrors().stream().filter(e -> e.getErrorCode().equalsIgnoreCase(IdentityErrorCode.USER_NOT_AUTHORIZED.getCode())).findAny();
        
        if(systemError.isPresent()){
            throw new GenericSystemException(errors);
        }else if(authError.isPresent()){
            throw new AuthenticationException(errors);
        }else{
            throw new InvalidRequestException(errors);
        }      
    }
}
