package com.homedepot.customer.validator;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.homedepot.customer.exception.error.AddressErrorCode;
import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.validator.rule.impl.ZipCodeRule;

/**
 * Created by jirapat on 10/31/16.
 */
@Component("citystatevalidator")
@Slf4j
public class CityStateRequestValidator extends BaseRequestValidator<String> {

    @Autowired
    ZipCodeRule zipCodeRule;

    @Override
    protected List<? extends ErrorCode> validateRequest(String zipCode, HttpMethod actionType) {
        List<AddressErrorCode> errors = new ArrayList<>();
        errors.addAll(zipCodeRule.check(zipCode).stream()
                .map(AddressErrorCode::valueOf)
                .collect(Collectors.toList()));

        return errors;
    }
}
