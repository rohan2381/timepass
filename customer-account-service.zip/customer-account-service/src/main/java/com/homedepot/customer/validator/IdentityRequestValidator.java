package com.homedepot.customer.validator;

import com.homedepot.customer.exception.error.IdentityErrorCode;
import com.homedepot.customer.request.IdentityRequest;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.validator.rule.impl.EmailRule;
import com.homedepot.customer.validator.rule.impl.PasswordRule;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

import static com.homedepot.customer.util.GlobalConstants.STR_Y;

/**
 * Created by rxb1809 on Aug 17, 2016
 *
 */
@Component("identityvalidator")
public class IdentityRequestValidator extends BaseRequestValidator<IdentityRequest> {

    private static final Map<String, IdentityErrorCode> ERROR_CODE_MAP;

    /*
     * Create a map of oldEmail, newEmail and newPassword existence check
     * The map is used for input validation on update identity api
     */
    static {
        // oldEmail | newEmail | newPassword
        ERROR_CODE_MAP = new HashMap<>();
        ERROR_CODE_MAP.put("false|false|false", IdentityErrorCode.INVALID_IDENTITY_MISSING);
        ERROR_CODE_MAP.put("false|false|true", null); // Password change
        ERROR_CODE_MAP.put("false|true|false", IdentityErrorCode.INVALID_IDENTITY_MISSING);
        ERROR_CODE_MAP.put("false|true|true", IdentityErrorCode.INVALID_IDENTITY_MISSING);
        ERROR_CODE_MAP.put("true|false|false", IdentityErrorCode.INVALID_IDENTITY_MISSING);
        ERROR_CODE_MAP.put("true|false|true", null); // Password change
        ERROR_CODE_MAP.put("true|true|false", null); // Email change
        ERROR_CODE_MAP.put("true|true|true,", null); // Email and Password change
    }

    @Autowired
    EmailRule emailRule;

    @Autowired
    PasswordRule pwdRule;

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.homedepot.customer.validator.BaseRequestValidator#validateRequest
     * (java.lang.Object)
     */
    @Override
    protected List<IdentityErrorCode> validateRequest(IdentityRequest request, HttpMethod actionType) {
        List<IdentityErrorCode> errors = new ArrayList<>();
        switch (actionType) {
        case POST:
            // MANDATORY FIELDS
            if (StringUtils.isBlank(request.getLogonId())) {
                errors.add(IdentityErrorCode.INVALID_USER_ID_MISSING);
            }
            if (ArrayUtils.isEmpty(request.getPassword())) {
                errors.add(IdentityErrorCode.INVALID_PASSWORD_MISSING);
            }
            break;
        case PUT:
            if(STR_Y.equalsIgnoreCase(request.getLoyaltyEnrollmentIndicator())){
                if(StringUtils.containsIgnoreCase(request.getLogonId(), GlobalConstants.HOMEDEPOT_EMAIL_DOMAIN)){
                    errors.add(IdentityErrorCode.HOMEDEPOTID_NOT_ALLOWED_FOR_PRO_USER);
                }

            }
            String logonId = request.getLogonId();
            String newLogonId = request.getNewLogonId();
            char[] newPassword = request.getNewPassword();
            IdentityErrorCode errorCode = validateInput(logonId, newLogonId, newPassword);
            Optional.ofNullable(errorCode).ifPresent(errors::add);

            if (StringUtils.isNotBlank(newLogonId)) {
                errors.addAll(emailRule.check(newLogonId).stream()
                                                         .map(IdentityErrorCode::valueOf)
                                                         .collect(Collectors.toList()));
            }
            if (!ArrayUtils.isEmpty(newPassword)) {
                errors.addAll(pwdRule.check(String.valueOf(newPassword)).stream()
                                                                        .map(IdentityErrorCode::valueOf)
                                                                        .collect(Collectors.toList()));
            }
            break;
        }
        return errors;
    }

    private IdentityErrorCode validateInput(String oldEmail, String newEmail, char[] newPwd) {

        String key = String.format("%s|%s|%s", StringUtils.isNotBlank(oldEmail), StringUtils.isNotBlank(newEmail), ArrayUtils.isNotEmpty(newPwd));
        IdentityErrorCode errorCode = ERROR_CODE_MAP.get(key);
        if(errorCode != null) {
            return errorCode;
        }
        // Check for old email and new email being equal
        if(StringUtils.isNotBlank(oldEmail) &&
            StringUtils.isNotBlank(newEmail) &&
            ArrayUtils.isEmpty(newPwd) && // for update email request only
            StringUtils.equalsIgnoreCase(oldEmail, newEmail)) {
            errorCode = IdentityErrorCode.INVALID_NEW_EMAIL_ID;
        }
        return errorCode;
    }

}
