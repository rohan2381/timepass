package com.homedepot.customer.validator;

import com.homedepot.customer.exception.error.PaymentErrorCode;
import com.homedepot.customer.model.PaymentCard;
import com.homedepot.customer.model.PaymentCards;
import com.homedepot.customer.model.PieEncryption;
import com.homedepot.customer.validator.rule.impl.PaymentCardRule;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Class to validate payment card
 * 
 * @author pxk3659
 *
 */
@Component("paymentCardValidator")
public class PaymentCardValidator extends BaseRequestValidator<PaymentCards> {


    @Autowired
    @Qualifier("rulesMessageResource")
    ResourceBundleMessageSource messageSource;

    @Autowired
    PaymentCardRule paymentCardRule;

    @Override
    protected List<PaymentErrorCode> validateRequest(PaymentCards paymentCards, HttpMethod actionType) {

        List<PaymentErrorCode> errors = new ArrayList<>();
        List<PaymentCard> cardsList = paymentCards.getPaymentCard();

        if (CollectionUtils.isEmpty(cardsList)) {
            errors.add(PaymentErrorCode.ERROR_CODE_INVALID_REQUEST);
            return errors;
        } else if(cardsList.size() > 1){
            errors.add(PaymentErrorCode.ERRORCODE_PYMTCARD_ERROR_MULTIPLE_CARD);
            return errors;
        }

        PaymentCard paymentCard = paymentCards.getPaymentCard().get(0);

        switch (actionType) {
            case POST:
                validateCardNumber(paymentCard, errors);
                validatePaymentCard(paymentCard, errors);
                validatePieEncryptionInfo(paymentCard.getPieEncryption(), errors);
                break;
            case PUT:
                validatePaymentCardId(paymentCard, errors);
                validatePaymentCard(paymentCard, errors);
                validateXrefNumber(paymentCard, errors);
                break;
            default:
                break;
        }
        return errors;
    }

    /**
     * Method to validate payment card id
     * 
     * @param paymentCard
     * @param errors
     */
    private void validatePaymentCardId(PaymentCard paymentCard, List<PaymentErrorCode> errors) {
        if (paymentCard.getPaymentId() == null) {
            errors.add(PaymentErrorCode.PAYMENT_ID_NOT_FOUND);
        }
    }

    /**
     * Method to validate payment card
     * 
     * @param paymentCard
     * @param errors
     */
    private void validatePaymentCard(PaymentCard paymentCard, List<PaymentErrorCode> errors) {
        if(paymentCard != null) {
            errors.addAll(paymentCardRule.check(paymentCard)
                    .stream()
                    .map(PaymentErrorCode::valueOf)
                    .collect(Collectors.toList()));
        }

    }

    private void validatePieEncryptionInfo(PieEncryption pieEncryptionInfo, List<PaymentErrorCode> errors) {
        if (pieEncryptionInfo != null) {
            if (StringUtils.isAnyBlank(pieEncryptionInfo.getPieIntegrityCheck(), pieEncryptionInfo.getPieKeyId(),
                    pieEncryptionInfo.getPiePhaseBit())) {
                errors.add(PaymentErrorCode.INVALID_PIE_ENCRYPTION_VALUES);
            }
        }
    }

    private void validateXrefNumber(PaymentCard paymentCard, List<PaymentErrorCode> errors) {
        if (paymentCard.getXrefCardNumber() == null) {
            errors.add(PaymentErrorCode.ERROR_CODE_INVALID_XREF_NUMBER);
        }
    }


    private void validateCardNumber(PaymentCard paymentCard, List<PaymentErrorCode> errors) {

        if (!isCardNumberPassedLuhnCheck(paymentCard.getCardNumber())) {
            errors.add(PaymentErrorCode.ERRORCODE_PYMTCARD_INVALID_CARD_NUMBER);
        }

    }


    /**
     * This method checks payment card validity using Luhn Algorithm
     *
     * @param cardNumber
     *
     * @return boolean
     */


    public static boolean isCardNumberPassedLuhnCheck(String cardNumber) {

        boolean valid = false;
        if ((cardNumber == null) || (cardNumber.trim().length() == 0)) {
            return false;
        }
        int weight = 2;
        int sum = 0;
        for (int position = cardNumber.length() - 2; position >= 0; position--) {
            int digit = weight * Character.digit(cardNumber.charAt(position), 10);
            if (digit < 0) {
                valid = false;
            }
            sum = sum + digit / 10 + digit % 10;
            weight = weight == 2 ? 1 : 2;
        }
        int last_digit = Character.digit(cardNumber.charAt(cardNumber.length() - 1), 10);
        if (last_digit == (10 - sum % 10) % 10) {
            valid = true;
        }
        return valid;
    }



}
