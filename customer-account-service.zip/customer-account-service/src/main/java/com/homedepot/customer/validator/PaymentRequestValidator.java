package com.homedepot.customer.validator;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.homedepot.customer.exception.error.PaymentErrorCode;
import com.homedepot.customer.request.PaymentCardRequest;
import com.homedepot.customer.validator.rule.impl.PaymentPaginationParameterRule;

/**
 * Created by rxb1809 on Jun 21, 2016
 *
 */
@Component("paymentvalidator")
public class PaymentRequestValidator extends BaseRequestValidator<PaymentCardRequest>{

    @Autowired
    PaymentPaginationParameterRule paginationParameterRule;

    @Override
    protected List<PaymentErrorCode> validateRequest(PaymentCardRequest request, HttpMethod actionType) {
        List<PaymentErrorCode> errors = new ArrayList<>();
        switch (actionType) {
            case GET:
                errors.addAll(paginationParameterRule.check(request.getPaginationInfo())
                        .stream()
                        .map(PaymentErrorCode::valueOf)
                        .collect(Collectors.toList()));
                break;
            default:
                break;
        }
        return errors;
    }

}
