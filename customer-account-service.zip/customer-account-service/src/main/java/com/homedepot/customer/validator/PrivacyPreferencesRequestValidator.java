package com.homedepot.customer.validator;

import static com.homedepot.customer.exception.error.PreferencesErrorCode.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.regex.Pattern;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.homedepot.customer.exception.error.PreferencesErrorCode;
import com.homedepot.customer.model.Phone;
import com.homedepot.customer.model.pvcypreferences.PrivacyPrefRequest;
import com.homedepot.customer.model.pvcypreferences.UpdateEmail;
import com.homedepot.customer.model.pvcypreferences.UpdateMail;
import com.homedepot.customer.model.pvcypreferences.UpdatePhone;
import com.homedepot.customer.validator.rule.impl.EmailRule;
import com.homedepot.customer.validator.rule.impl.PhoneRule;

@Component("pvcyPrefValidator")
@Slf4j
public class PrivacyPreferencesRequestValidator extends BaseRequestValidator<PrivacyPrefRequest>{
    
    private static final String NO_CHANGES = "-1";
    private static final String FLAG_VALUES = "-1|0|1";
    private static final String POSITIVE_FLAG = "0|1";
    
    
    @Autowired
    EmailRule emailRule;

    @Autowired
    PhoneRule phoneRule;
    
    Predicate<String> invalidMatch = value -> !Pattern.compile(FLAG_VALUES).matcher(value).matches();
    Predicate<String> positiveChoice = value -> Pattern.compile(POSITIVE_FLAG).matcher(value).matches();
    
    Predicate<String> noChanges = flag -> NO_CHANGES.equals(flag);
    
    Predicate<String> inValidEmailId = emailId -> !emailRule.check(emailId).isEmpty();
    
    Predicate<String> inValidPhoneNo = phoneNo -> {
                                                    Phone phone = new Phone();
                                                    phone.setNumber(phoneNo);
                                                    
                                                    return !phoneRule.check(phone).isEmpty();
                                                };
    
    Predicate<String> invalidState = state ->  StringUtils.isNotBlank(state) && (state.length() > 2 || StringUtils.isNumeric(state));
    Predicate<String> invalidZipCode = zip ->  StringUtils.isNotBlank(zip) && (!StringUtils.isNumeric(zip) || zip.length() != 5);

    @Override
    public List<PreferencesErrorCode> validateRequest(PrivacyPrefRequest request, HttpMethod actionType) {

        List<PreferencesErrorCode> errors = new ArrayList<>();
        
        if(actionType.equals(HttpMethod.PUT)){
            validateUpdatePrefParameters(request, errors);
        }

        return errors;
    }

    private void validateUpdatePrefParameters(PrivacyPrefRequest request, List<PreferencesErrorCode> errors) {
        
        Optional<PrivacyPrefRequest> optRequest = Optional.of(request);
        
        optRequest.map(PrivacyPrefRequest :: getShareInfo).filter(invalidMatch).ifPresent(invalidValue -> {
            log.error("Validation Error: Invalid value for shareInfo: {}", invalidValue);
            errors.add(INVALID_VALUE_SHARE_INFO);
        });
        
        validateEmail(optRequest, errors);
        validatePhone(optRequest, errors);
        validateMail(optRequest, errors);
    }
    
    private void validateEmail(Optional<PrivacyPrefRequest> optRequest, List<PreferencesErrorCode> errors) {

        optRequest.map(PrivacyPrefRequest :: getUpdateEmail).map(UpdateEmail :: getSubscribeEmail).filter(noChanges)
        .ifPresent(noSelection -> optRequest.get().setUpdateEmail(null));
        
        optRequest.map(PrivacyPrefRequest :: getUpdateEmail).map(UpdateEmail :: getSubscribeEmail).filter(invalidMatch).ifPresent(invalidValue -> {
            log.error("Validation Error: Invalid value for SubscribeEmail: {}", invalidValue);
            errors.add(INVALID_VALUE_SUBSCRIBE_EMAIL);
        });
        
        if(optRequest.map(PrivacyPrefRequest :: getUpdateEmail).map(UpdateEmail :: getSubscribeEmail).filter(positiveChoice).isPresent()
                && (StringUtils.isBlank(optRequest.map(PrivacyPrefRequest :: getUpdateEmail).get().getEmailAddress()) 
                || optRequest.map(PrivacyPrefRequest :: getUpdateEmail).map(UpdateEmail :: getEmailAddress).filter(inValidEmailId).isPresent())){
                
                log.error("Validation Error: Email Id field is Blank");
                errors.add(INVALID_EMAIL_ID);
        }
        
        
    }
    
    private void validatePhone(Optional<PrivacyPrefRequest> optRequest, List<PreferencesErrorCode> errors) {
        
        optRequest.map(PrivacyPrefRequest :: getUpdatePhone).map(UpdatePhone :: getSubscribePhone).filter(noChanges)
        .ifPresent(noSelection -> optRequest.get().setUpdatePhone(null));
        
        optRequest.map(PrivacyPrefRequest :: getUpdatePhone).map(UpdatePhone :: getSubscribePhone).filter(invalidMatch).ifPresent(invalidValue -> {
            log.error("Validation Error: Invalid value for SubscribePhone: {}", invalidValue);
            errors.add(INVALID_VALUE_SUBSCRIBE_PHONE);
        });
        
        if(optRequest.map(PrivacyPrefRequest :: getUpdatePhone).map(UpdatePhone :: getSubscribePhone).filter(positiveChoice).isPresent() 
                && (StringUtils.isBlank(optRequest.map(PrivacyPrefRequest :: getUpdatePhone).get().getPhoneNo())
                || optRequest.map(PrivacyPrefRequest :: getUpdatePhone).map(UpdatePhone :: getPhoneNo).filter(inValidPhoneNo).isPresent())){
            
            log.error("Validation Error: Invalid Phone No: {}", optRequest.map(PrivacyPrefRequest :: getUpdatePhone).map(UpdatePhone :: getPhoneNo));
            errors.add(INVALID_PHONE);
        }
        
        
    }
    
    private void validateMail(Optional<PrivacyPrefRequest> optRequest, List<PreferencesErrorCode> errors) {
        
        optRequest.map(PrivacyPrefRequest :: getUpdateMail).map(UpdateMail :: getSubscribeMail)
        .filter(noChanges).ifPresent(noSelection -> optRequest.get().setUpdateMail(null));
        
        optRequest.map(PrivacyPrefRequest :: getUpdateMail).map(UpdateMail :: getState).filter(invalidState).ifPresent(state -> {
            log.error("Validation Error: Invalid value for State: {}. Has to be of length 2 and only characters.", state);
            errors.add(INVALID_STATE);
        });
        
        optRequest.map(PrivacyPrefRequest :: getUpdateMail).map(UpdateMail :: getZip).filter(invalidZipCode).ifPresent(zip -> {
            log.error("Validation Error: Invalid ZipCode: {}", zip);
            errors.add(INVALID_ZIP_CODE);
        });
        
        optRequest.map(PrivacyPrefRequest :: getUpdateMail).map(UpdateMail :: getSubscribeMail).filter(invalidMatch).ifPresent(invalidValue -> {
            log.error("Validation Error: Invalid value for SubscribeMail: {}", invalidValue);
            errors.add(INVALID_VALUE_SUBSCRIBE_MAIL);
        });
        
        
        optRequest.map(PrivacyPrefRequest :: getUpdateMail).map(UpdateMail :: getState).ifPresent(state -> {
            optRequest.get().getUpdateMail().setState(StringUtils.upperCase(state));
        });
        
    }
    
}
