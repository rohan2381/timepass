package com.homedepot.customer.validator;

import com.homedepot.customer.exception.error.ProfileErrorCode;
import com.homedepot.customer.model.*;
import com.homedepot.customer.request.ProfileRequest;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.validator.rule.impl.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.homedepot.customer.util.GlobalConstants.STR_Y;
import static com.homedepot.customer.util.GlobalConstants.TRADE_TYPE_OTHER;

/**
 * Created by rxb1809 on Jun 21, 2016
 */
@Component("profilevalidator")
public class ProfileRequestValidator extends BaseRequestValidator<ProfileRequest> {
    @Autowired
    NameRule nameRule;

    @Autowired
    EmailRule emailRule;

    @Autowired
    PhoneRule phoneRule;

    @Autowired
    ZipCodeRule zipCodeRule;

    @Autowired
    TaxExemptIdRule taxExemptIdRule;

    @Autowired
    LocalStoreIdRule localStoreIdRule;

    @Autowired
    OtherTradeTypeRule otherTradeTypeRule;

    @Autowired
    PostalDetailsRule postalDetailsRule;


    @Override
    protected List<ProfileErrorCode> validateRequest(ProfileRequest request, HttpMethod actionType) {
        Optional<ProfileRequest> profileRequestOpt = Optional.ofNullable(request);
        List<ProfileErrorCode> errors = new ArrayList<>();
        profileRequestOpt.map(profile->profile.getAccount()).ifPresent(account->{
            if(actionType!=null)
                validateActionType(actionType,request,errors);
        });

        //Check for Account fields only if the request is Create or update
        if(HttpMethod.POST.equals(actionType) || HttpMethod.PUT.equals(actionType)) {

        profileRequestOpt.map(ProfileRequest::getAccount)
                .map(Account::getProfilePhones)
                .map(ProfilePhones::getPhone)
                .filter(j -> j.size() > 0)
                .ifPresent(profilePhones -> profilePhones.forEach(phone -> errors.addAll(validatePhone(phone))));

        profileRequestOpt.map(ProfileRequest::getAccount)
                .map(Account::getProfile)
                .map(Profile::getTaxExemptId)
                .filter(taxID-> StringUtils.isNoneBlank(taxID))
                .ifPresent(taxExemptId ->
                    errors.addAll(taxExemptIdRule.check(taxExemptId).stream()
                            .map(ProfileErrorCode::valueOf)
                            .collect(Collectors.toList())));

        profileRequestOpt.map(ProfileRequest::getAccount)
                .map(Account::getProfile)
                .map(Profile::getLocalStoreId)
                .ifPresent(localStoreId -> 
                    errors.addAll(localStoreIdRule.check(localStoreId).stream()
                            .map(ProfileErrorCode::valueOf)
                            .collect(Collectors.toList())));



            validateZipCode(profileRequestOpt.map(ProfileRequest::getAccount)
                    .map(Account::getProfile)
                    .map(Profile::getZipCode)
                    .orElse(""), errors);

            validateName(profileRequestOpt.map(ProfileRequest::getAccount)
                    .map(Account::getProfile)
                    .map(Profile::getName)
                    .orElse(new Name()), errors);

//            validateProUpgradeFields(profileRequestOpt, errors);
        }

        return errors;
    }

    private List<ProfileErrorCode> validatePhone(Phone phone) {
        List<ProfileErrorCode> errors = new ArrayList<>();

        if (StringUtils.isNotEmpty(phone.getNumber())) {
            // TODO: validate here or let SVOC validate ???
            // profile phone must have primary flag (Y/N)
            if (!(GlobalConstants.STR_Y.equals(phone.getPrimaryFlag()) || GlobalConstants.STR_N.equals(phone.getPrimaryFlag()))) {
                errors.add(ProfileErrorCode.INVALID_PRIMARY_PHONE_FLAG);
            }
            errors.addAll(phoneRule.check(phone).stream()
                    .map(ProfileErrorCode::valueOf)
                    .collect(Collectors.toList()));

            // TODO: update must have id and timestamp, insert do not have neither
        }
        else {
            // TODO: validate here or let SVOC validate ???
            // blank phone number, must be deletion, check that request has both id and timestamp

        }

        return errors;
    }

    private void validateActionType(HttpMethod actionType,ProfileRequest request, List<ProfileErrorCode> errors ){

        if (HttpMethod.GET.equals(actionType) && StringUtils.isBlank(request.getAccount().getCustomerAccountId())) {
            errors.add(ProfileErrorCode.INVALID_CUSTOMERID_MISSING);          
        }

        if (HttpMethod.PUT.equals(actionType)) {
            if (StringUtils.isBlank(request.getAccount().getCustomerAccountId())) {
                errors.add(ProfileErrorCode.INVALID_CUSTOMERID_MISSING);
            }

            if (request.getAccount().getLastModifiedDate() == null) {
                errors.add(ProfileErrorCode.INVALID_ACCOUNT_LASTUPDATE_TIMESTAMP_MISSING);
            }

            if (request.getAccount().getProfile().getLastModifiedDate() == null) {
                errors.add(ProfileErrorCode.INVALID_PROFILE_LASTUPDATE_TIMESTAMP_MISSING);
            }

            // Do not allow update addresses, except upgradeing to pro
            if (!STR_Y.equalsIgnoreCase(request.getAccount().getProfile().getLoyaltyEnrollmentIndicator())
                    && request.getAccount().getAddress() != null) {
                errors.add(ProfileErrorCode.INVALID_UPDATE_ADDRESS_NOT_ALLOWED);
            }

            // Do not allow update email
            if (request.getAccount().getProfile().getEmailId() != null) {
                errors.add(ProfileErrorCode.INVALID_UPDATE_EMAIL_NOT_ALLOWED);
            }

            // Do not allow update password
            if (request.getAccount().getProfile().getPassword() != null) {
                errors.add(ProfileErrorCode.INVALID_UPDATE_PASSWORD_NOT_ALLOWED);
            }
        }
    }

    private void validateZipCode(String zipCode, List<ProfileErrorCode> errors) {

        if (StringUtils.isBlank(zipCode)) {
            errors.add(ProfileErrorCode.INVALID_ZIPCODE_MISSING);
        }
        else {
            errors.addAll(zipCodeRule.check(zipCode).stream()
                    .map(ProfileErrorCode::valueOf).collect(Collectors.toList()));
        }
    }

    private void validateName(Name name, List<ProfileErrorCode> errors) {
        errors.addAll(nameRule.check(name).stream()
                .map(ProfileErrorCode::valueOf)
                .collect(Collectors.toList()));
    }

    private void validateProUpgradeFields(Optional<ProfileRequest> requestOptional, List<ProfileErrorCode> errors) {
        requestOptional.map(ProfileRequest::getAccount).map(Account::getProfile).ifPresent(profile -> {
            if (STR_Y.equalsIgnoreCase(profile.getLoyaltyEnrollmentIndicator())) {
                errors.addAll(validateTradeType(profile));
                errors.addAll(validateAddress(requestOptional.map(ProfileRequest::getAccount)));
                // TODO: add validate businessName field
            }
        });
    }

    private List<ProfileErrorCode> validateTradeType(Profile profile) {
        List<ProfileErrorCode> errors = new ArrayList<>();
        if (StringUtils.isBlank(profile.getTradeType())) {
            errors.add(ProfileErrorCode.INVALID_TRADE_TYPE_MISSING);
        }
        else if (TRADE_TYPE_OTHER.equalsIgnoreCase(profile.getTradeType())) {
            if (StringUtils.isBlank(profile.getOtherTradeDescription())) {
                errors.add(ProfileErrorCode.INVALID_TRADE_TYPE_OTHER_MISSING);
            }
            else {
                errors.addAll(otherTradeTypeRule.check(profile.getOtherTradeDescription()).stream()
                        .map(ProfileErrorCode::valueOf)
                        .collect(Collectors.toList()));
            }
        }
        return errors;
    }

    private List<ProfileErrorCode> validateAddress(Optional<Account> accountOptional) {
        List<ProfileErrorCode> errors = new ArrayList<>();
        accountOptional.map(Account::getAddress)
                .ifPresent(addressList -> addressList.forEach(address ->
                        errors.addAll(postalDetailsRule.check(address.getPostalDetails()).stream()
                        .map(ProfileErrorCode::valueOf)
                        .collect(Collectors.toList()))
        ));

        return errors;
    }

}
