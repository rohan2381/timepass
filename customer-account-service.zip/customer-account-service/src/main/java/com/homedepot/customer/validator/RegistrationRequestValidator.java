package com.homedepot.customer.validator;

import com.homedepot.customer.exception.error.ProfileErrorCode;
import com.homedepot.customer.model.Name;
import com.homedepot.customer.request.UserRegistrationRequest;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.validator.rule.impl.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.homedepot.customer.util.GlobalConstants.STR_Y;
import static com.homedepot.customer.util.GlobalConstants.TRADE_TYPE_OTHER;

/**
 * Created by rxb1809 on Jul 19, 2016
 *
 */
@Component("registrationvalidator")
@Slf4j
public class RegistrationRequestValidator extends BaseRequestValidator<UserRegistrationRequest>{

    @Autowired
    NameRule nameRule;

    @Autowired
    EmailRule emailRule;

    @Autowired
    ZipCodeRule zipCodeRule;

    @Autowired
    PasswordRule pwdRule;

    @Autowired
    PasswordMatchRule pwdMatchRule;

    @Autowired
    PhoneRule phoneRule;

    @Autowired
    OtherTradeTypeRule otherTradeTypeRule;

    @Autowired
    PostalDetailsRule postalDetailsRule;

    @Override
    protected List<ProfileErrorCode> validateRequest(UserRegistrationRequest request, HttpMethod actionType) {

        List<ProfileErrorCode> errors = new ArrayList<>();

        // MANDATORY FIELDS
        if(StringUtils.isBlank(request.getEmailId())){
            errors.add(ProfileErrorCode.INVALID_EMAIL_MISSING);
        }else{
            errors.addAll(emailRule.check(request.getEmailId()).stream()
                    .map(error -> ProfileErrorCode.valueOf(error))
                    .collect(Collectors.toList()));
        }

        if (ArrayUtils.isEmpty(request.getPassword())) {
            errors.add(ProfileErrorCode.INVALID_PASSWORD_MISSING);
        } else {
            errors.addAll(pwdRule.check(String.valueOf(request.getPassword()))
                    .stream().map(ProfileErrorCode::valueOf).collect(Collectors.toList()));
        }

        if(ArrayUtils.isEmpty(request.getConfirmPassword())){
            errors.add(ProfileErrorCode.INVALID_CONFIRM_PASSWORD_MISSING);
        }

        if (ArrayUtils.isNotEmpty(request.getPassword()) && ArrayUtils.isNotEmpty(request.getConfirmPassword())) {
            Map<String, String> reqMap = new HashMap<>();
            reqMap.put(GlobalConstants.EMAIL_KEY, request.getEmailId());
            reqMap.put(GlobalConstants.PASSWORD_KEY, new String(request.getPassword()));
            reqMap.put(GlobalConstants.CONFIRM_PASSWORD_KEY, new String(request.getConfirmPassword()));
            errors.addAll(pwdMatchRule.check(reqMap).stream()
                                                    .map(ProfileErrorCode::valueOf)
                                                    .collect(Collectors.toList()));
        }

        if(StringUtils.isBlank(request.getZipCode())){
            errors.add(ProfileErrorCode.INVALID_ZIPCODE_MISSING);
        }else{
            errors.addAll(zipCodeRule.check(request.getZipCode()).stream()
                    .map(error -> ProfileErrorCode.valueOf(error))
                    .collect(Collectors.toList()));
        }

        // OPTIONAL FIELDS
        errors.addAll(nameRule.check(new Name(request.getFirstName(),request.getLastName())).stream()
                .map(error -> ProfileErrorCode.valueOf(error))
                .collect(Collectors.toList()));


        // Pro Xtra mandatory fields
        if (STR_Y.equalsIgnoreCase(request.getLoyaltyEnrollmentIndicator())) {
            // register as pro
            errors.addAll(validateProXtra(request));
        }
        else if (StringUtils.isNotEmpty(request.getLoyaltyEnrollmentIndicator())) {
            // reject non Y value for this flag
            errors.add(ProfileErrorCode.INVALID_ENROLL_IN_LOYALTY_FLAG);
        }

        return errors;
    }

    
    private List<ProfileErrorCode> validateProXtra(UserRegistrationRequest request) {
        List<ProfileErrorCode> errors = new ArrayList<>();
        errors.addAll(validateTradeType(request));
        errors.addAll(validatePhone(request));
        errors.addAll(validateAddress(request));
        errors.addAll(validateEmailForPRO(request));
        return errors;
    }

    private List<ProfileErrorCode> validateEmailForPRO(UserRegistrationRequest request) {
        List<ProfileErrorCode> errors = new ArrayList<>();
        if(StringUtils.containsIgnoreCase(request.getEmailId(),GlobalConstants.HOMEDEPOT_EMAIL_DOMAIN)){
            errors.add(ProfileErrorCode.HOMEDEPOTID_NOT_ALLOWED_FOR_PRO_USER);
        }
        return errors;
    }



    private List<ProfileErrorCode> validatePhone(UserRegistrationRequest request) {
        List<ProfileErrorCode> errors = new ArrayList<>();
        if (request.getPhone() == null || request.getPhone().getNumber() == null) {
            errors.add(ProfileErrorCode.INVALID_PRIMARY_PHONE_MISSING);
        }
        else {
            // check for primary flag, pro account needs a primary phone
            if (!STR_Y.equals(request.getPhone().getPrimaryFlag())) {
                log.debug("pro account needs a primary phone");
                errors.add(ProfileErrorCode.INVALID_PRIMARY_PHONE_MISSING);
            }

            errors.addAll(phoneRule.check(request.getPhone()).stream()
                    .map(ProfileErrorCode::valueOf)
                    .collect(Collectors.toList()));
        }

        return errors;
    }

    private List<ProfileErrorCode> validateAddress(UserRegistrationRequest request) {
        List<ProfileErrorCode> errors = new ArrayList<>();
        if (request.getAddress() == null || request.getAddress().getPostalDetails() == null) {
            errors.add(ProfileErrorCode.INVALID_ADDRESSLINE1_MISSING);
        }
        else {
            errors.addAll(postalDetailsRule.check(request.getAddress().getPostalDetails()).stream()
                    .map(ProfileErrorCode::valueOf)
                    .collect(Collectors.toList()));
        }

        return errors;
    }

    private List<ProfileErrorCode> validateTradeType(UserRegistrationRequest request) {
        List<ProfileErrorCode> errors = new ArrayList<>();
        if (StringUtils.isBlank(request.getTradeType())) {
            errors.add(ProfileErrorCode.INVALID_TRADE_TYPE_MISSING);
        }
        else if (TRADE_TYPE_OTHER.equals(request.getTradeType())) {
            if (StringUtils.isBlank(request.getOtherTradeDescription())) {
                errors.add(ProfileErrorCode.INVALID_TRADE_TYPE_OTHER_MISSING);
            }
            else {
                errors.addAll(otherTradeTypeRule.check(request.getOtherTradeDescription()).stream()
                        .map(ProfileErrorCode::valueOf)
                        .collect(Collectors.toList()));
            }
        }
        return errors;
    }

}
