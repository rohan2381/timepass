package com.homedepot.customer.validator;

import com.homedepot.customer.exception.error.IdentityErrorCode;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.validator.rule.impl.BusinessChannelRule;
import com.homedepot.customer.validator.rule.impl.SessionRule;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by rxb1809 on Aug 13, 2016
 *
 */
@Component("requestheadervalidator")
@Slf4j
public class RequestHeaderValidator extends BaseRequestValidator<HttpServletRequest> {

    @Autowired
    BusinessChannelRule channelRule;

    @Autowired
    SessionRule sessionRule;
    
    private static final String[] REQUEST_PATHS = 
        { "/addresses", "/addresses/", 
        "/profile", "/profile/",
        "/session/validate","/paymentcards","/paymentcards/"};

    @Override
    protected List<IdentityErrorCode> validateRequest(HttpServletRequest request, HttpMethod actionType) {
        List<IdentityErrorCode> errors = new ArrayList<>();

        errors.addAll(channelRule.check(request.getHeader(GlobalConstants.CHANNEL_ID)).stream()
                .map(error -> IdentityErrorCode.valueOf(error)).collect(Collectors.toList()));
        
        // Disabled currently (Rohan)
        if(Arrays.stream(REQUEST_PATHS).anyMatch(request.getServletPath()::contains)){
            String thdAuthToken = request.getHeader(GlobalConstants.THD_AUTH_TOKEN);
            if(StringUtils.isBlank(thdAuthToken)){
                errors.add(IdentityErrorCode.MISSING_USER_TOKEN);
            }
        }

        return errors;
    }

}
