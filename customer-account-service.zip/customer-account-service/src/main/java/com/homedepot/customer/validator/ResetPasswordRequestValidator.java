package com.homedepot.customer.validator;

import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.exception.SVOCUnavailableException;
import com.homedepot.customer.exception.error.IdentityErrorCode;
import com.homedepot.customer.exception.error.PasswordErrorCode;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.integration.wcs.WCSProfileServiceFacade;
import com.homedepot.customer.model.Account;
import com.homedepot.customer.repository.IIdentityRepository;
import com.homedepot.customer.repository.IProfileRepository;
import com.homedepot.customer.request.PasswordRequest;
import com.homedepot.customer.util.AccountRequestHelper;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.FeatureSwitchUtil;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.validator.rule.impl.EmailRule;
import com.homedepot.customer.validator.rule.impl.PasswordMatchRule;
import com.homedepot.customer.validator.rule.impl.PasswordRule;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;

/**
 * Created by nxw6207 on 12/22/16.
 */
@Component("resetpwdrequestvalidator")
@Slf4j
public class ResetPasswordRequestValidator extends BaseRequestValidator<PasswordRequest> {

    @Autowired
    PasswordRule pwdRule;

    @Autowired
    PasswordMatchRule pwdMatchRule;

    @Autowired
    private IProfileRepository profileRepository;

    @Autowired
    private IIdentityRepository identityRepository;

    @Autowired
    private EnvPropertyUtil envProperty;

    @Autowired
    CustomerAccountRequestContext reqContext;
    
    @Autowired
    EmailRule emailRule;
    
    @Autowired
    AccountRequestHelper accountHelper;
    
    @Autowired
    FeatureSwitchUtil featureSwitchUtil;

    // @Autowired
    // private WCSProfileServiceFacade profileFacade;

    @Override
    protected List<PasswordErrorCode> validateRequest(PasswordRequest resetPasswordRequest, HttpMethod actionType) {
        List<PasswordErrorCode> errors = new ArrayList<>();
        switch (actionType) {
            case POST:
                // MANDATORY FIELDS
                if (ArrayUtils.isEmpty(resetPasswordRequest.getPassword())) {
                    errors.add(PasswordErrorCode.INVALID_PASSWORD_MISSING);
                } else {
                    errors.addAll(pwdRule.check(String.valueOf(resetPasswordRequest.getPassword())).stream()
                            .map(PasswordErrorCode::valueOf).collect(Collectors.toList()));
                }

                if(ArrayUtils.isEmpty(resetPasswordRequest.getConfirmPassword())){
                    errors.add(PasswordErrorCode.INVALID_CONFIRM_PASSWORD_MISSING);
                }

                if (ArrayUtils.isNotEmpty(resetPasswordRequest.getPassword()) && ArrayUtils.isNotEmpty(resetPasswordRequest.getConfirmPassword())) {
                    Map<String, String> reqMap = new HashMap<>();
                    reqMap.put(GlobalConstants.PASSWORD_KEY, new String(resetPasswordRequest.getPassword()));
                    reqMap.put(GlobalConstants.CONFIRM_PASSWORD_KEY, new String(resetPasswordRequest.getConfirmPassword()));
                    errors.addAll(pwdMatchRule.check(reqMap).stream()
                            .map(PasswordErrorCode::valueOf)
                            .collect(Collectors.toList()));
                }
                if(StringUtils.isEmpty(resetPasswordRequest.getToken())) {
                    errors.add(PasswordErrorCode.INVALID_RESET_PASSWORD_TOKEN_MISSING);
                }
                
                if(errors.isEmpty()){
                    try {
                        String svocIdDecoded = new String(java.util.Base64.getDecoder().decode(resetPasswordRequest.getSvocId()),GlobalConstants.CHARSET_UTF_8);
                        Account account = profileRepository.retrieve(svocIdDecoded);
                        if (account != null && account.getProfile() != null && StringUtils.isNotBlank(account.getProfile().getEmailId())){
                            if(!account.getProfile().getEmailId().equalsIgnoreCase(resetPasswordRequest.getEmail())){
                                errors.add(PasswordErrorCode.INVALID_SVOC_ID_EMAIL_COMBO);
                                break;
                            }
                            reqContext.setSvocEmailId(account.getProfile().getEmailId());
                            reqContext.setSvocId(svocIdDecoded);
                            if(null != account.getProfile().getName()) {
                                reqContext.setFirstName(account.getProfile().getName().getFirstName());
                            }
                        } else {
                            errors.add(PasswordErrorCode.CUST_ID_NOT_FOUND_IN_SVOC);
                        }
                    } catch (RepositoryException | SVOCUnavailableException | UnsupportedEncodingException ex) {
                        log.error("Error validating reset password request ", ExceptionUtils.getRootCause(ex));
                        errors.add(PasswordErrorCode.SYSTEM_ERROR);
                    }
                }

                break;
            case GET:
                // MANDATORY FIELDS
                if(StringUtils.isEmpty(resetPasswordRequest.getEmail())) {
                    errors.add(PasswordErrorCode.INVALID_EMAIL);
                } else {
                    errors.addAll(emailRule.check(String.valueOf(resetPasswordRequest.getEmail())).stream()
                            .map(error -> PasswordErrorCode.valueOf(error)).collect(Collectors.toList()));
                }
                
                if(errors.isEmpty()){
                    try {
                        //Asyncronous call to check email in WCS
                        //Future<Boolean> emailExistsInWCSFuture = profileFacade.checkEmailExists(resetPasswordRequest.getEmail());
                        String svocId = profileRepository.userExists(resetPasswordRequest.getEmail());
                        if (StringUtils.isNotBlank(svocId)) {
                            String serviceAuthToken =
                                    identityRepository.getServiceAuthToken(envProperty.getIamServiceUser(),
                                            envProperty.getIamServicePassword());
                            if (!identityRepository.userExists(svocId, serviceAuthToken)) {
                                
//                                boolean wcsBkUpOn = featureSwitchUtil.getFeatureValueByFeatureNameBoolean(GlobalConstants.MCM_CUST_WCS_BACKUP_FEATURE);
//                                String wcsMemberId = null;
//                                if(wcsBkUpOn){
//                                    // Check if a cross-ref entry exists in WCS (duplicate accounts not migrated yet)
//                                    wcsMemberId = accountHelper.lookUpWCSId(svocId);
//                                }
//                                
//                                if(wcsMemberId != null){
//                                    // Customer exists in SVOC and WCS but not in IAM
//                                    errors.add(PasswordErrorCode.USER_QUALIFIES_FOR_SET_PASSWORD);
//                                }else{
//                                    //if wcs then yes else "USER_EXIST_IN_SVOC_WCS_ONLY"
//                                    if(emailExistsInWCSFuture.get(envProperty.getWcsLoginTimeout(), TimeUnit.SECONDS)){
//                                        log.info("User exists in both svoc and wcs"+": "+resetPasswordRequest.getEmail());
//                                        reqContext.setWCSRequest(true);// Request will be served from WCS forgot password flow
//                                    }
//                                    else {
//                                        errors.add(PasswordErrorCode.USER_QUALIFIES_FOR_SET_PASSWORD);
//                                    }
//                                }
                                
                                errors.add(PasswordErrorCode.USER_QUALIFIES_FOR_SET_PASSWORD);

                            } else {
                                reqContext.setSvocId(svocId);
                                reqContext.setSvocEmailId(resetPasswordRequest.getEmail());
                            }
                        } 
                        else {
                            // Customer does not exists in SVOC
                            errors.add(PasswordErrorCode.CUST_ID_NOT_FOUND_IN_SVOC);
                        }
                    //} catch (RepositoryException | TimeoutException | InterruptedException | ExecutionException ex) {
                    } catch (RepositoryException ex) {
                        log.error("Error validating reset password request ", ExceptionUtils.getRootCause(ex));
                        errors.add(PasswordErrorCode.SYSTEM_ERROR);
                    }
                }
                break;
        }
        return errors;
    }
}
