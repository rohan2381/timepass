package com.homedepot.customer.validator;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.exception.error.IdentityErrorCode;
import com.homedepot.customer.repository.IIdentityRepository;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.SessionHelper;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Nov 6, 2016
 * This is used for session validation
 */
@Component("sessionvalidator")
@Slf4j
public class SessionValidator extends BaseRequestValidator<HttpServletRequest>{
    
    @Autowired
    EnvPropertyUtil envUtil;
    
    @Autowired
    IIdentityRepository identityRepository;
    
    @Autowired
    SessionHelper sessionHelper;

    /**
     * Refer https://confluence.homedepot.com/display/Aurora/WCS+to+IAM+transition for the flow
     */
    @Override
    protected List<? extends ErrorCode> validateRequest(HttpServletRequest request, HttpMethod type) {
        List<IdentityErrorCode> errors = new ArrayList<>();
        
        try{
            if(!sessionHelper.validateUserSession(request)){                
                errors.add(IdentityErrorCode.USER_NOT_AUTHORIZED);
            }
        }catch(Exception ex){
            log.error("Error validating user token ",ExceptionUtils.getRootCause(ex));
            errors.add(IdentityErrorCode.SYSTEM_ERROR);
        }
        
        return errors;
    }
}
