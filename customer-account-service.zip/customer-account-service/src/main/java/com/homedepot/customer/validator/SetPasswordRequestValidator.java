package com.homedepot.customer.validator;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.exception.SVOCUnavailableException;
import com.homedepot.customer.exception.error.PasswordErrorCode;
import com.homedepot.customer.framework.CustomerAccountRequestContext;
import com.homedepot.customer.model.Account;
import com.homedepot.customer.repository.IIdentityRepository;
import com.homedepot.customer.repository.IProfileRepository;
import com.homedepot.customer.request.PasswordRequest;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.validator.rule.impl.EmailRule;
import com.homedepot.customer.validator.rule.impl.PasswordMatchRule;
import com.homedepot.customer.validator.rule.impl.PasswordRule;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxm4390 on 1/18/17.
 */
@Component("setpasswordrequestvalidator")
@Slf4j
public class SetPasswordRequestValidator extends BaseRequestValidator<PasswordRequest>{

    @Autowired
    PasswordRule pwdRule;


    @Autowired
    PasswordMatchRule pwdMatchRule;

    @Autowired
    EmailRule emailRule;

    @Autowired
    private IProfileRepository profileRepository;

    @Autowired
    private IIdentityRepository identityRepository;

    @Autowired
    private EnvPropertyUtil envProperty;

    @Autowired
    CustomerAccountRequestContext reqContext;

    /*
     * (non-Javadoc)
     *
     * @see
     * com.homedepot.customer.validator.BaseRequestValidator#validateRequest
     * (java.lang.Object)
     */
    @Override
    protected List<PasswordErrorCode> validateRequest(PasswordRequest setPasswordRequest, HttpMethod actionType) {
        List<PasswordErrorCode> errors = new ArrayList<>();
        switch (actionType) {
            case POST:
                if (ArrayUtils.isEmpty(setPasswordRequest.getPassword())) {
                    errors.add(PasswordErrorCode.INVALID_PASSWORD_MISSING);
                } else {
                    errors.addAll(pwdRule.check(String.valueOf(setPasswordRequest.getPassword())).stream()
                            .map(error -> PasswordErrorCode.valueOf(error)).collect(Collectors.toList()));
                }
                if(ArrayUtils.isEmpty(setPasswordRequest.getConfirmPassword())){
                    errors.add(PasswordErrorCode.INVALID_CONFIRM_PASSWORD_MISSING);
                }
                if (StringUtils.isBlank(setPasswordRequest.getSvocId())){
                    errors.add(PasswordErrorCode.INVALID_CUST_ID_MISSING);
                }
                if(StringUtils.isEmpty(setPasswordRequest.getEmail())) {
                    errors.add(PasswordErrorCode.INVALID_EMAIL);
                }
                if (ArrayUtils.isNotEmpty(setPasswordRequest.getPassword()) && ArrayUtils.isNotEmpty(setPasswordRequest.getConfirmPassword())) {
                    Map<String, String> reqMap = new HashMap<>();
                    reqMap.put(GlobalConstants.PASSWORD_KEY, new String(setPasswordRequest.getPassword()));
                    reqMap.put(GlobalConstants.CONFIRM_PASSWORD_KEY, new String(setPasswordRequest.getConfirmPassword()));
                    errors.addAll(pwdMatchRule.check(reqMap).stream()
                            .map(PasswordErrorCode::valueOf)
                            .collect(Collectors.toList()));
                }
                
                if(StringUtils.isEmpty(setPasswordRequest.getToken())) {
                    errors.add(PasswordErrorCode.INVALID_RESET_PASSWORD_TOKEN_MISSING);
                }
                if(errors.isEmpty()){
                    try {
                        String svocIdDecoded = new String(java.util.Base64.getDecoder().decode(setPasswordRequest.getSvocId()),GlobalConstants.CHARSET_UTF_8);
                        Account account = profileRepository.retrieve(svocIdDecoded);
                        if (account != null && account.getProfile() != null && StringUtils.isNotBlank(account.getProfile().getEmailId())){
                            if(!account.getProfile().getEmailId().equalsIgnoreCase(setPasswordRequest.getEmail())){
                                errors.add(PasswordErrorCode.INVALID_SVOC_ID_EMAIL_COMBO);
                                break;
                            }
                            reqContext.setSvocEmailId(account.getProfile().getEmailId());
                            reqContext.setSvocId(svocIdDecoded);
                            if(null != account.getProfile().getName()) {
                                reqContext.setFirstName(account.getProfile().getName().getFirstName());
                            }
                        } else {
                            errors.add(PasswordErrorCode.CUST_ID_NOT_FOUND_IN_SVOC);
                        }
                    } catch (RepositoryException | SVOCUnavailableException | UnsupportedEncodingException ex) {
                        log.error("Error validating set password request ", ExceptionUtils.getRootCause(ex));
                        errors.add(PasswordErrorCode.SYSTEM_ERROR);
                    }
                }
                break;
            case GET:
                if(StringUtils.isEmpty(setPasswordRequest.getEmail())) {
                    errors.add(PasswordErrorCode.INVALID_EMAIL);
                } else {
                    errors.addAll(emailRule.check(String.valueOf(setPasswordRequest.getEmail())).stream()
                            .map(error -> PasswordErrorCode.valueOf(error)).collect(Collectors.toList()));
                }
                if(errors.isEmpty()){
                    try {
                        String svocId = profileRepository.userExists(setPasswordRequest.getEmail());
                        if (StringUtils.isNotBlank(svocId)) {
                            String serviceAuthToken =
                                    identityRepository.getServiceAuthToken(envProperty.getIamServiceUser(),
                                    envProperty.getIamServicePassword());
                            if (identityRepository.userExists(svocId, serviceAuthToken)) {
                                errors.add(PasswordErrorCode.CUST_ID_FOUND_IN_IAM);
                            } else {
                                reqContext.setSvocId(svocId);
                                reqContext.setSvocEmailId(setPasswordRequest.getEmail());
                            }
                        } else {
                            errors.add(PasswordErrorCode.CUST_ID_NOT_FOUND_IN_SVOC);
                        }
                    } catch (RepositoryException ex) {
                        log.error("Error validating set password request ", ExceptionUtils.getRootCause(ex));
                        errors.add(PasswordErrorCode.SYSTEM_ERROR);
                    }
                }
                break;
        }
        return errors;
    }
}
