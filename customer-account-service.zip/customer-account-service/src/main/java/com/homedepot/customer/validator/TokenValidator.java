package com.homedepot.customer.validator;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import com.homedepot.customer.exception.error.ErrorCode;
import com.homedepot.customer.exception.error.IdentityErrorCode;
import com.homedepot.customer.util.EnvPropertyUtil;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.util.HMACHelper;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Jun 5, 2017
 * This validator class is used to validate client application token. 
 * Currently supports HMAC based auth
 */
@Component("tokenvalidator")
@Slf4j
public class TokenValidator extends BaseRequestValidator<HttpServletRequest>{
    
    @Autowired
    private HMACHelper hmacHelper;
    
    @Autowired
    EnvPropertyUtil envProperty;

    @Override
    protected List<? extends ErrorCode> validateRequest(HttpServletRequest request, HttpMethod type) {
        List<IdentityErrorCode> errors = new ArrayList<>();
        long totalTimestampWithDelays;

        try{            
            String clientId = request.getHeader(GlobalConstants.CUST_ACCT_CLIENT_ID);
            String clientReqToken = request.getHeader(GlobalConstants.CUST_ACCT_CLIENT_TOKEN);
            String clientTs = request.getHeader(GlobalConstants.CUST_ACCT_CLIENT_TS);
            String clientSuppliedDelayforValidatingToken = request.getHeader(GlobalConstants.CUST_DELAY_FOR_TOKEN_VALIDATION);
            
            if(StringUtils.isNoneBlank(clientId,clientReqToken,clientTs)){
                
                // Check if the token is expired
                totalTimestampWithDelays = Long.valueOf(clientTs) + TimeUnit.MINUTES.toMillis(Long.valueOf(clientSuppliedDelayforValidatingToken)) + Long.valueOf(envProperty.getTokenValidationBuffer()) + Long.valueOf(envProperty.getNetworkDelay());

                long milliseconds = System.currentTimeMillis() - Long.valueOf(totalTimestampWithDelays);

                int seconds = (int) milliseconds;
                
                if(seconds > envProperty.getHmacTokenExpiry()){
                    log.error("Client application token expired");
                    errors.add(IdentityErrorCode.USER_NOT_AUTHORIZED);
                    
                    return errors;
                }
                
                // Generate and check if the token passed is same
                String clientHmacToken = hmacHelper.generateEncodedHMACToken(clientTs, clientId);               
                if(!StringUtils.equalsIgnoreCase(clientHmacToken, clientReqToken)){
                    log.error("Invalid client application token");
                    errors.add(IdentityErrorCode.USER_NOT_AUTHORIZED);
                }
            }else{
                log.error("Invalid client token params");
                errors.add(IdentityErrorCode.USER_NOT_AUTHORIZED);
            }
        }catch(NumberFormatException nEx){
            log.error("Invalid client token params ",ExceptionUtils.getRootCause(nEx));
            errors.add(IdentityErrorCode.USER_NOT_AUTHORIZED);
        }
        catch(Exception ex){
            log.error("Error validating client application token ",ExceptionUtils.getRootCause(ex));
            errors.add(IdentityErrorCode.SYSTEM_ERROR);
        }
        
        return errors;
    }
}
