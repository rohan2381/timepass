package com.homedepot.customer.validator;

import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.exception.error.IdentityErrorCode;
import com.homedepot.customer.integration.wcs.WCSProfileServiceFacade;
import com.homedepot.customer.repository.IIdentityRepository;
import com.homedepot.customer.repository.IProfileRepository;
import com.homedepot.customer.util.AccountRequestHelper;
import com.homedepot.customer.util.EnvPropertyUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Component("userExistenceValidator")
@Slf4j
public class UserExistenceValidator extends BaseRequestValidator<String> {

    @Autowired
    private IProfileRepository profileRepository;

    @Autowired
    private IIdentityRepository identityRepository;
    
    @Autowired
    private AccountRequestHelper accountHelper;
    
    @Autowired
    private EnvPropertyUtil envProperty;
    
    @Autowired
    private WCSProfileServiceFacade profileFacade;

    @Override
    protected List<IdentityErrorCode> validateRequest(String emailId, HttpMethod actionType) {
        List<IdentityErrorCode> identityErrorCodes = new ArrayList<>();
        
        if(StringUtils.isBlank(emailId)){
            identityErrorCodes.add(IdentityErrorCode.INVALID_EMAIL);
            return identityErrorCodes;
        }
                     
        try {
            // Async call to IAM to get service auth token
            Future<String> iamRespFuture = accountHelper.getIAMServiceAuthTokenAsync();
            // Async call to WCS to check email exists
            //Future<Boolean> emailExistsInWCSFuture = profileFacade.checkEmailExists(emailId);
            
            // Check email exists in SVOC
            String svocId = profileRepository.userExists(emailId);   
            if (svocId != null) { 
                log.info("SVOC record found for "+emailId+ " - svocId="+svocId);
                String serviceAuthToken = iamRespFuture.get(envProperty.getIamLoginTimeout(), TimeUnit.SECONDS);
                
                // Check if a cross-ref entry exists in WCS (duplicate accounts not migrated yet)
                //String wcsMemberId = accountHelper.lookUpWCSId(svocId);
                
                //if(StringUtils.isNotBlank(wcsMemberId)){
                    //log.info("Cross reference entry exists for "+emailId+ " - svocId="+svocId+", wcsMemberId="+wcsMemberId);
                    // Check if the user is in IAM
                    if (identityRepository.userExists(svocId, serviceAuthToken)) {
                        log.info("User exists in both svoc and iam"+": "+emailId);
                        identityErrorCodes.add(IdentityErrorCode.USER_EXIST_IN_SVOC_IAM);
                    } else {
                        log.info("User exists in svoc only"+": "+emailId);
                        identityErrorCodes.add(IdentityErrorCode.USER_EXIST_IN_SVOC_ONLY);
                    }
                /*}else{
                    log.info("Cross reference entry does not exists for "+emailId);
                    // Check email Exists in WCS
                    if(emailExistsInWCSFuture.get(envProperty.getWcsLoginTimeout(), TimeUnit.SECONDS)){
                        log.info("User exists in both svoc and wcs"+": "+emailId);
                        identityErrorCodes.add(IdentityErrorCode.USER_EXIST_IN_SVOC_IAM);
                    }else{
                        // Belongs to ProX exclusive list of store users which are in SVOC
                        log.info("User is either a ProX exclusive or a store customer"+": "+emailId);
                        if (identityRepository.userExists(svocId, serviceAuthToken)) {
                            log.info("User exists in both svoc and iam"+": "+emailId);
                            identityErrorCodes.add(IdentityErrorCode.USER_EXIST_IN_SVOC_IAM);
                        }else{                         
                            log.info("User exists in svoc only"+": "+emailId);
                            identityErrorCodes.add(IdentityErrorCode.USER_EXIST_IN_SVOC_ONLY);
                        }                        
                    }                    
                }*/
            }
        } catch (RepositoryException | TimeoutException | InterruptedException | ExecutionException e) {
            log.error("Error while checking user existence : "+ ExceptionUtils.getRootCause(e));
            identityErrorCodes.add(IdentityErrorCode.SYSTEM_ERROR);
        }
        return identityErrorCodes;
    }

}