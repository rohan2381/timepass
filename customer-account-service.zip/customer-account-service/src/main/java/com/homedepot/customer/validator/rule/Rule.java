package com.homedepot.customer.validator.rule;

import java.util.List;

import org.springframework.stereotype.Component;

/**
 * Created by rxb1809 on Jun 22, 2016
 *
 */
@Component
public interface Rule<T> {

    public List<String> check(T value);

}
