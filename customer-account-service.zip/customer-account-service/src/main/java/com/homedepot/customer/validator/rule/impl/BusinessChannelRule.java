package com.homedepot.customer.validator.rule.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.homedepot.customer.util.BusinessChannel;
import com.homedepot.customer.validator.rule.Rule;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Aug 13, 2016
 *
 */
@Component
@Slf4j
public class BusinessChannelRule implements Rule<String> {

    private static final String INVALID_CHANNEL_ID = "INVALID_CHANNEL_ID";

    @Override
    public List<String> check(String channel) {
        List<String> violations = new ArrayList<>();

        try {
            int channelId = Integer.parseInt(channel);
            log.debug("Channel Id passed in the request: "+channelId);
            BusinessChannel.valueOfId(channelId);

        } catch (IllegalArgumentException iEx) {
            log.error("Invalid channel id " + channel + " " + iEx); 
            violations.add(INVALID_CHANNEL_ID);
        }

        return violations;
    }

}
