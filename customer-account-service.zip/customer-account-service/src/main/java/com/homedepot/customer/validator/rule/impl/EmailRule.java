package com.homedepot.customer.validator.rule.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;

import com.homedepot.customer.validator.rule.Rule;

/**
 * Created by rxb1809 on Jun 22, 2016
 *
 */
@Component
public class EmailRule implements Rule<String> {

    private static final String INVALID_EMAIL = "INVALID_EMAIL";

    private static final String RULE_EMAIL = "rule.email";

    @Autowired
    @Qualifier("rulesMessageResource")
    ResourceBundleMessageSource messageSource;

    @Override
    public List<String> check(String value) {
        List<String> violations = new ArrayList<>();
        boolean valid = Pattern.compile(messageSource.getMessage(RULE_EMAIL, null, null)).matcher(value).matches();

        if (!valid) {
            violations.add(INVALID_EMAIL);
        }

        return violations;
    }

}
