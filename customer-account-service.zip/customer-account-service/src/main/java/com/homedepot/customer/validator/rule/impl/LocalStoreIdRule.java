package com.homedepot.customer.validator.rule.impl;

import com.homedepot.customer.validator.rule.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Created by axb4725 on 8/24/16.
 */
@Component
public class LocalStoreIdRule implements Rule<String>{

        private static final String INVALID_STORE = "INVALID_STORE";

        private static final String RULE_STOREID = "rule.storeid";

        @Autowired
        @Qualifier("rulesMessageResource")
        ResourceBundleMessageSource messageSource;

        @Override
        public List<String> check(String value) {
        List<String> violations = new ArrayList<>();
        boolean valid = Pattern.compile(messageSource.getMessage(RULE_STOREID, null, null)).matcher(value).matches();

        if(!valid){
            violations.add(INVALID_STORE);
        }

        return violations;
    }
}
