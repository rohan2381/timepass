package com.homedepot.customer.validator.rule.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;

import com.homedepot.customer.model.Name;
import com.homedepot.customer.validator.rule.Rule;

/**
 * Created by rxb1809 on Jun 22, 2016
 *
 */
@Component
@Slf4j
public class NameRule implements Rule<Name> {

    private static final String INVALID_FIRST_NAME = "INVALID_FIRST_NAME";
    private static final String INVALID_LAST_NAME = "INVALID_LAST_NAME";
    private static final String RULE_NAME = "rule.name";

    @Autowired
    @Qualifier("rulesMessageResource")
    ResourceBundleMessageSource messageSource;

    @Override
    public List<String> check(Name value) {
        List<String> violations = new ArrayList<>();

        Optional<Name> optionalNameObj = Optional.of(value);

        log.debug("Validating FirstName field");
        optionalNameObj.map(Name::getFirstName).ifPresent(
                s -> {
                    String trimmedFiratname = s.trim();
                    if (trimmedFiratname.length() > 40) {
                        log.debug("firstname is too long");
                        violations.add(INVALID_FIRST_NAME);
                    } else if (!Pattern.compile(messageSource.getMessage(RULE_NAME, null, null))
                            .matcher(trimmedFiratname).matches()) {
                        log.debug("firstname is invalid");
                        violations.add(INVALID_FIRST_NAME);
                    }
                });

        log.debug("Validating Lastname field");
        optionalNameObj.map(Name::getLastName).ifPresent(
                s -> {
                    String trimmedName = s.trim();
                    if (trimmedName.length() > 60) {
                        log.debug("lastname is too long");
                        violations.add(INVALID_LAST_NAME);
                    } else if (!Pattern.compile(messageSource.getMessage(RULE_NAME, null, null))
                            .matcher(trimmedName).matches()) {
                        log.debug("lastname is invalid");
                        violations.add(INVALID_LAST_NAME);
                    }
                });

        return violations;
    }

}
