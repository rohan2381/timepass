package com.homedepot.customer.validator.rule.impl;

import com.homedepot.customer.validator.rule.Rule;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Created by jirapat on 8/8/16.
 */
@Component
@Slf4j
public class OtherTradeTypeRule  implements Rule<String> {
    private static final String INVALID_TRADE_TYPE_OTHER = "INVALID_TRADE_TYPE_OTHER";

    private static final String RULE_OTHERTRADETYPE = "rule.othertradetype";

    @Autowired
    @Qualifier("rulesMessageResource")
    ResourceBundleMessageSource messageSource;

    @Override
    public List<String> check(String value) {
        List<String> violations = new ArrayList<>();

        if (!Pattern.compile(messageSource.getMessage(RULE_OTHERTRADETYPE, null, null)).matcher(value).matches()) {
            violations.add(INVALID_TRADE_TYPE_OTHER);
        }

        return violations;
    }
}
