package com.homedepot.customer.validator.rule.impl;

import com.homedepot.customer.model.PaginationInfo;
import com.homedepot.customer.validator.rule.Rule;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Created by axb4725 on 9/9/16.
 */
@Component
public class PaginationParameterRule implements Rule<PaginationInfo> {
    private static final String INVALID_ADDRESS_PAGENUMBER="INVALID_ADDRESS_PAGENUMBER";
    private static final String INVALID_ADDRESS_PAGESIZE_MISSING = "INVALID_ADDRESS_PAGESIZE_MISSING";
    private static final String INVALID_ADDRESS_PAGESIZE = "INVALID_ADDRESS_PAGESIZE";
    private static final String INVALID_ADDRESS_PAGENUMBER_MISSING ="INVALID_ADDRESS_PAGENUMBER_MISSING";
    private static final String Pagination_Param_REGEX = "([0-9]{1,2})$";


    @Autowired
    @Qualifier("rulesMessageResource")
    ResourceBundleMessageSource messageSource;

    @Override
    public List<String> check(PaginationInfo value) {
        List<String> violations = new ArrayList<>();

        if (!StringUtils.isBlank(value.getPageNumber()) && StringUtils.isBlank(value.getPageSize())) {
            if(!Pattern.compile(Pagination_Param_REGEX).matcher(value.getPageNumber()).matches())
            violations.add(INVALID_ADDRESS_PAGENUMBER);
            violations.add(INVALID_ADDRESS_PAGESIZE_MISSING);
        }
        //Test case to check if Page number is missing and Page size is Present
        if (StringUtils.isBlank(value.getPageNumber()) && !StringUtils.isBlank(value.getPageSize())) {
            if(!Pattern.compile(Pagination_Param_REGEX).matcher(value.getPageSize()).matches())
                violations.add(INVALID_ADDRESS_PAGESIZE);
            violations.add(INVALID_ADDRESS_PAGENUMBER_MISSING);
        }
        //Test case when both parameters present
        if (!StringUtils.isBlank(value.getPageNumber()) && !StringUtils.isBlank(value.getPageSize())) {
            if(!Pattern.compile(Pagination_Param_REGEX).matcher(value.getPageNumber()).matches())
                violations.add(INVALID_ADDRESS_PAGENUMBER);
            if(!Pattern.compile(Pagination_Param_REGEX).matcher(value.getPageSize()).matches())
                violations.add(INVALID_ADDRESS_PAGESIZE);
        }
        return violations;
    }
}
