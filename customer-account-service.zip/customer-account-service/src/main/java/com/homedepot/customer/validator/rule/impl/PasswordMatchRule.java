package com.homedepot.customer.validator.rule.impl;

import com.homedepot.customer.exception.error.ProfileErrorCode;
import com.homedepot.customer.util.GlobalConstants;
import com.homedepot.customer.validator.rule.Rule;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by rxb1809 on Aug 02, 2016
 */
@Component
public class PasswordMatchRule implements Rule<Map<String, String>> {

    private static final String INVALID_PASSWORD_CONFIRMPASSWORD_MATCH = ProfileErrorCode.INVALID_PASSWORD_CONFIRMPASSWORD_MATCH.toString();
    private static final String PASSWORD_AND_EMAIL_MATCH = ProfileErrorCode.PASSWORD_AND_EMAIL_MATCH.toString();

    @Override
    public List<String> check(Map<String, String> requestMap) {

        List<String> violations = new ArrayList<>();
        if (!requestMap.get(GlobalConstants.PASSWORD_KEY).equals(requestMap.get(GlobalConstants.CONFIRM_PASSWORD_KEY))) { // password and confirm password are not same
            violations.add(INVALID_PASSWORD_CONFIRMPASSWORD_MATCH);
        } else if (requestMap.get(GlobalConstants.PASSWORD_KEY).equals(requestMap.get(GlobalConstants.EMAIL_KEY))) { // password is same as email address
            violations.add(PASSWORD_AND_EMAIL_MATCH);
        }
        return violations;
    }

}
