package com.homedepot.customer.validator.rule.impl;

import com.homedepot.customer.exception.error.ProfileErrorCode;
import com.homedepot.customer.validator.rule.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Created by rxb1809 on Jun 22, 2016
 *
 */
@Component
public class PasswordRule implements Rule<String> {

    private static final String PASSWORD_IN_DICTIONARY = ProfileErrorCode.PASSWORD_IN_DICTIONARY.toString();
    private static final String PASSWORD_REPEATING_CHAR = ProfileErrorCode.PASSWORD_REPEATING_CHAR.toString();
    private static final String PASSWORD_LENGTH_INVALID = ProfileErrorCode.PASSWORD_LENGTH_INVALID.toString();

    private static final int PASSWORD_MIN_LEN = 8;
    private static final int PASSWORD_MAX_LEN = 70;

    @Autowired
    @Qualifier("repeatedPwdCharPattern")
    private Pattern repeatedPwdCharPattern;

    @Resource // since @Autowired does not work with collections
    private Set<String> dictionaryPwdWords;

    @Override
    public List<String> check(String password) {

        List<String> violations = new ArrayList<>();
        if (password.length() < PASSWORD_MIN_LEN ||
                    password.length() > PASSWORD_MAX_LEN) { // length check
            violations.add(PASSWORD_LENGTH_INVALID);
        } else if (dictionaryPwdWords.contains(password)) { // dictionary check
            violations.add(PASSWORD_IN_DICTIONARY);
        } else if (repeatedPwdCharPattern.matcher(password).find()) { // repeated char check
            violations.add(PASSWORD_REPEATING_CHAR);
        }
        return violations;
    }

}
