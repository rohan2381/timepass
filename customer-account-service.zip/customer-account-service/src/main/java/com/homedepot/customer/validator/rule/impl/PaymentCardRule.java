package com.homedepot.customer.validator.rule.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;

import com.homedepot.customer.exception.error.PaymentErrorCode;
import com.homedepot.customer.model.PaymentCard;
import com.homedepot.customer.util.PaymentCardBrand;
import com.homedepot.customer.validator.rule.Rule;

/**
 * Created by rxm4390 on 10/11/16.
 */
@Component
public class PaymentCardRule implements Rule<PaymentCard> {

    private static final String ERROR_CODE_INVALID_NICK_NAME = PaymentErrorCode.ERROR_CODE_INVALID_NICK_NAME.toString();
    private static final String ERROR_CODE_ERRORS_NICK_NAME_EXCEED = PaymentErrorCode.ERROR_CODE_ERRORS_NICK_NAME_EXCEED
            .toString();
    private static final String ERRORCODE_PYMTCARD_INVALID_CARD_HOLDER_NAME = PaymentErrorCode.ERRORCODE_PYMTCARD_INVALID_CARD_HOLDER_NAME
            .toString();
    private static final String ERRORCODE_PYMTCARD_CARD_HOLDER_NAME_LENGTH_MAX = PaymentErrorCode.ERRORCODE_PYMTCARD_CARD_HOLDER_NAME_LENGTH_MAX
            .toString();
    private static final String ERRORCODE_PYMTCARD_INVALID_CARD_BRAND = PaymentErrorCode.ERRORCODE_PYMTCARD_INVALID_CARD_BRAND
            .toString();
    private static final String ERRORCODE_PYMTCARD_INVALID_CARD_EXPIRY_YEAR = PaymentErrorCode.ERRORCODE_PYMTCARD_INVALID_CARD_EXPIRY_YEAR
            .toString();
    private static final String ERRORCODE_PYMTCARD_ERRORS_EXPIRY_YEAR_EXCEED = PaymentErrorCode.ERRORCODE_PYMTCARD_ERRORS_EXPIRY_YEAR_EXCEED
            .toString();
    private static final String ERRORCODE_PYMTCARD_INVALID_CARD_EXPIRY_MONTH = PaymentErrorCode.ERRORCODE_PYMTCARD_INVALID_CARD_EXPIRY_MONTH
            .toString();
    private static final String ERRORCODE_PYMTCARD_ERRORS_EXPIRY_MONTH_NOT_APPL = PaymentErrorCode.ERRORCODE_PYMTCARD_ERRORS_EXPIRY_MONTH_NOT_APPL
            .toString();
    private static final String ERRORCODE_PYMTCARD_ERRORS_EXPIRY_YEAR_NOT_APPL = PaymentErrorCode.ERRORCODE_PYMTCARD_ERRORS_EXPIRY_YEAR_NOT_APPL
            .toString();
    private static final String ERROR_CODE_INVALID_GSA_RANGE = PaymentErrorCode.ERROR_CODE_INVALID_GSA_RANGE.toString();
    private static final List<String> GSA_RANGE = Arrays.asList("4486", "4614", "4716", "5565", "5568");
    private static final String RULE_NAME = "rule.name";

    @Autowired
    @Qualifier("rulesMessageResource")
    ResourceBundleMessageSource messageSource;

    @Override
    public List<String> check(PaymentCard paymentCard) {
        List<String> violations = new ArrayList<>();

        validateCardNickName(paymentCard, violations);
        validateCardHolderName(paymentCard, violations);
        validateCardBrand(paymentCard, violations);
        validateCardExpiry(paymentCard, violations);
        validateCardGSA(paymentCard, violations);

        return violations;

    }

    /**
     * Method to validate payment nick name
     *
     * @param paymentCard
     * @param violations
     */
    private void validateCardNickName(PaymentCard paymentCard, List<String> violations) {

        if (StringUtils.isNotBlank(paymentCard.getCardNickName())) {
            if (paymentCard.getCardNickName().trim().length() > 100) {
                violations.add(ERROR_CODE_ERRORS_NICK_NAME_EXCEED);
            } else if (!Pattern.compile(messageSource.getMessage(RULE_NAME, null, null))
                    .matcher(paymentCard.getCardNickName().trim()).matches()) {
                violations.add(ERROR_CODE_INVALID_NICK_NAME);
            }
        }
    }

    /**
     * Method to validate payment card holder name
     *
     * @param paymentCard
     * @param violations
     */
    private void validateCardHolderName(PaymentCard paymentCard, List<String> violations) {
        if (StringUtils.isBlank(paymentCard.getCardHolderName())) {
            violations.add(ERRORCODE_PYMTCARD_INVALID_CARD_HOLDER_NAME);
        } else if (paymentCard.getCardHolderName().trim().length() > 120) {
            violations.add(ERRORCODE_PYMTCARD_CARD_HOLDER_NAME_LENGTH_MAX);
        } else if (!Pattern.compile(messageSource.getMessage(RULE_NAME, null, null))
                .matcher(paymentCard.getCardHolderName().trim()).matches()) {
            violations.add(ERRORCODE_PYMTCARD_INVALID_CARD_HOLDER_NAME);
        }
    }

    /**
     * Method to validate card brand and number
     *
     * @param paymentCard
     * @param violations
     */

    private void validateCardBrand(PaymentCard paymentCard, List<String> violations) {

        if (!PaymentCardBrand.isValidPaymentCardBrand(paymentCard.getCardBrand())) {
            violations.add(ERRORCODE_PYMTCARD_INVALID_CARD_BRAND);
        }

    }

    /**
     * Method to validate card expiry month and year
     *
     * @param paymentCard
     * @param violations
     */
    private void validateCardExpiry(PaymentCard paymentCard, List<String> violations) {
        if (PaymentCardBrand.isValidPaymentCardBrand(paymentCard.getCardBrand())) {

            if (PaymentCardBrand.HDCOM != PaymentCardBrand.valueOf(paymentCard.getCardBrand())
                    && PaymentCardBrand.HDCON != PaymentCardBrand.valueOf(paymentCard.getCardBrand())) {
                if (paymentCard.getCardExpiryMonth() != null && paymentCard.getCardExpiryYear() != null) {
                    int currentYear = LocalDate.now().getYear();
                    int currentMonth = LocalDate.now().getMonthValue();

                    boolean validExpiration = true;
                    // parse expiration year
                    int cardExpiryYear = 0;
                    try {
                        cardExpiryYear = Integer.parseInt(paymentCard.getCardExpiryYear());
                    }
                    catch (NumberFormatException e) {
                        violations.add(ERRORCODE_PYMTCARD_INVALID_CARD_EXPIRY_YEAR);
                        validExpiration = false;
                    }

                    // parse expiration month
                    int cardExpiryMonth = 0;
                    try {
                        cardExpiryMonth = Integer.parseInt(paymentCard.getCardExpiryMonth());
                    }
                    catch (NumberFormatException e) {
                        violations.add(ERRORCODE_PYMTCARD_INVALID_CARD_EXPIRY_MONTH);
                        validExpiration = false;
                    }

                    if (validExpiration) {
                        if (cardExpiryYear < currentYear) {
                            violations.add(ERRORCODE_PYMTCARD_INVALID_CARD_EXPIRY_YEAR);
                        }
                        else if (!(cardExpiryYear <= currentYear + 19)) {
                            violations.add(ERRORCODE_PYMTCARD_ERRORS_EXPIRY_YEAR_EXCEED);
                        }

                        if (cardExpiryYear == currentYear && cardExpiryMonth < currentMonth) {
                            violations.add(ERRORCODE_PYMTCARD_INVALID_CARD_EXPIRY_MONTH);
                        }
                        else if (cardExpiryMonth < 1 || cardExpiryMonth > 12) {
                            violations.add(ERRORCODE_PYMTCARD_INVALID_CARD_EXPIRY_MONTH);
                        }
                    }
                }

                if (paymentCard.getCardExpiryMonth() == null) {
                    violations.add(ERRORCODE_PYMTCARD_ERRORS_EXPIRY_MONTH_NOT_APPL);
                }
                if (paymentCard.getCardExpiryYear() == null) {
                    violations.add(ERRORCODE_PYMTCARD_ERRORS_EXPIRY_YEAR_NOT_APPL);
                }
            }
        }
    }

    /**
     * Method to validate if payment card is GSA
     *
     * @param paymentCard
     * @param violations
     */
    private void validateCardGSA(PaymentCard paymentCard, List<String> violations) {
        if (paymentCard != null && paymentCard.getIsCardGSA() != null && paymentCard.getCardNumber() != null) {
            if (paymentCard.getIsCardGSA()) {
                String paymentCardFirstFourDigits = paymentCard.getCardNumber().substring(0, 4);
                if (!GSA_RANGE.contains(paymentCardFirstFourDigits)) {
                    violations.add(ERROR_CODE_INVALID_GSA_RANGE);
                }
            }
        }
    }

}
