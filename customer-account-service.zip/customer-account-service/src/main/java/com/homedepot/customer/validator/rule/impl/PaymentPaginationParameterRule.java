package com.homedepot.customer.validator.rule.impl;

import com.homedepot.customer.model.PaginationInfo;
import com.homedepot.customer.validator.rule.Rule;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Created by rxm4390mbp on 9/15/16.
 */
@Component
public class PaymentPaginationParameterRule implements Rule<PaginationInfo> {

    private static final String INVALID_PAYMENT_PAGENUMBER="INVALID_PAYMENT_PAGENUMBER";
    private static final String INVALID_PAYMENT_PAGESIZE_MISSING = "INVALID_PAYMENT_PAGESIZE_MISSING";
    private static final String INVALID_PAYMENT_PAGESIZE = "INVALID_PAYMENT_PAGESIZE";
    private static final String INVALID_PAYMENT_PAGENUMBER_MISSING ="INVALID_PAYMENT_PAGENUMBER_MISSING";
    private static final String Pagination_Param_REGEX = "([0-9]{1,3})$";

    @Override
    public List<String> check(PaginationInfo value) {
        List<String> violations = new ArrayList<>();

        if (!StringUtils.isBlank(value.getPageNumber()) && StringUtils.isBlank(value.getPageSize())) {
            if(!Pattern.compile(Pagination_Param_REGEX).matcher(value.getPageNumber()).matches())
                violations.add(INVALID_PAYMENT_PAGENUMBER);
            violations.add(INVALID_PAYMENT_PAGESIZE_MISSING);
        }
        //Test case to check if Page number is missing and Page size is Present
        if (StringUtils.isBlank(value.getPageNumber()) && !StringUtils.isBlank(value.getPageSize())) {
            if(!Pattern.compile(Pagination_Param_REGEX).matcher(value.getPageSize()).matches())
                violations.add(INVALID_PAYMENT_PAGESIZE);
            violations.add(INVALID_PAYMENT_PAGENUMBER_MISSING);
        }
        //Test case when both parameters present
        if (!StringUtils.isBlank(value.getPageNumber()) && !StringUtils.isBlank(value.getPageSize())) {
            if(!Pattern.compile(Pagination_Param_REGEX).matcher(value.getPageNumber()).matches())
                violations.add(INVALID_PAYMENT_PAGENUMBER);
            if(!Pattern.compile(Pagination_Param_REGEX).matcher(value.getPageSize()).matches())
                violations.add(INVALID_PAYMENT_PAGESIZE);
        }
        return violations;
    }
}
