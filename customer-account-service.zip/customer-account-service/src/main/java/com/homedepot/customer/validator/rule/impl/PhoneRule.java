package com.homedepot.customer.validator.rule.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;

import com.homedepot.customer.model.Phone;
import com.homedepot.customer.validator.rule.Rule;

/**
 * Created by rxb1809 on Jun 22, 2016
 *
 */
@Component
@Slf4j
public class PhoneRule implements Rule<Phone>{
    private static final String INVALID_PHONE = "INVALID_PHONE";

    private static final String RULE_PHONE = "rule.phone";

    @Autowired
    @Qualifier("rulesMessageResource")
    ResourceBundleMessageSource messageSource;

    @Override
    public List<String> check(Phone value) {
        List<String> violations = new ArrayList<>();

        Optional<Phone> phoneOptionalObj = Optional.of(value);
        boolean valid = phoneOptionalObj.map(i -> i.getNumber())
                .filter(i -> Pattern.compile(messageSource.getMessage(RULE_PHONE, null, null)).matcher(i).matches())
                .isPresent();

        if (!valid) {
            log.debug("primary phone is not valid: {}", value);
            violations.add(INVALID_PHONE);
        }

        return violations;
    }

}
