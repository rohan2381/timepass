package com.homedepot.customer.validator.rule.impl;

import com.homedepot.customer.validator.rule.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Created by axb4725 on 8/18/16.
 */
@Component
public class PoBoxAddressRule implements Rule<String> {

    private static final String INVALID_POBOXADDRESS_CANNOT_BE_PRIMARY= "INVALID_POBOXADDRESS_CANNOT_BE_PRIMARY";

    private static final String RULE_POBOX = "rule.pobox";

    @Autowired
    @Qualifier("rulesMessageResource")
    ResourceBundleMessageSource messageSource;

    @Override
    public List<String> check(String value) {
        List<String> violations = new ArrayList<>();
        boolean valid = Pattern.compile(messageSource.getMessage(RULE_POBOX, null, null)).matcher(value).matches();

        if(valid){
            violations.add(INVALID_POBOXADDRESS_CANNOT_BE_PRIMARY);
        }

        return violations;
    }
}
