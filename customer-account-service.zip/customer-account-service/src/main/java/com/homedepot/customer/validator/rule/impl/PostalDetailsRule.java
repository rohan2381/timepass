package com.homedepot.customer.validator.rule.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;

import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.model.PostalDetails;
import com.homedepot.customer.repository.IAddressRepository;
import com.homedepot.customer.validator.rule.Rule;

/**
 * Created by rxb1809 on Jun 22, 2016
 *
 */
@Component
@Slf4j
public class   PostalDetailsRule implements Rule<PostalDetails>{

	private static final String INVALID_ADDRESSLINE1_MISSING="INVALID_ADDRESSLINE1_MISSING";
	private static final String INVALID_ADDRESSLINE1="INVALID_ADDRESSLINE1";
	private static final String INVALID_COUNTRY_MISSING="INVALID_COUNTRY_MISSING";
	private static final String INVALID_COUNTRY="INVALID_COUNTRY";
	private static final String INVALID_STATE_MISSING="INVALID_STATE_MISSING";
	private static final String INVALID_STATE="INVALID_STATE";
	private static final String INVALID_ADDRESSLINE2="INVALID_ADDRESSLINE2";
	private static final String INVALID_ZIPCODE_MISSING="INVALID_ZIPCODE_MISSING";
	private static final String INVALID_ADDRESS_CITY_STATE_ZIPCODE_MATCH = "INVALID_ADDRESS_CITY_STATE_ZIPCODE_MATCH";

	private static final String RULE_STATE = "rule.state";

	@Autowired
	@Qualifier("rulesMessageResource")
	ResourceBundleMessageSource messageSource;

	@Autowired
	ZipCodeRule zipCodeRule;

    @Autowired
    IAddressRepository addressRepository;

    @Override
    public List<String> check(PostalDetails value) {

	/*TODO remove all hard coded values & add 3rd party address validations */
		List<String> violations = new ArrayList<>();
		 log.debug("Validating PostalDetails: "+value);
			Optional<PostalDetails> optionalPostalDetailObj = Optional.of(value);
			log.debug("Validate AddressLine1 field");

			if(!optionalPostalDetailObj.map(i->i.getAddressLine1()).isPresent())
				violations.add(INVALID_ADDRESSLINE1_MISSING);
			else
			{
			if(!optionalPostalDetailObj.map(i -> i.getAddressLine1())
										.filter(i->i.length()>1 && i.length()<=60)
					 					.isPresent())
				violations.add(INVALID_ADDRESSLINE1);
			}

			log.debug("Validating Country field");

		     if(!optionalPostalDetailObj.map(i->i.getCountry()).isPresent())
				 violations.add(INVALID_COUNTRY_MISSING);
			else {
				 if(!optionalPostalDetailObj.map(i -> i.getCountry())
						 .filter(i -> "US".equals(i))
						 .isPresent())
					 violations.add(INVALID_COUNTRY);
			 }

			log.debug("Validating State field");
			if(!optionalPostalDetailObj.map(i->i.getState()).isPresent())
				violations.add(INVALID_STATE_MISSING);
		else{
				if(!optionalPostalDetailObj.map(i -> i.getState())
						.filter(i->Pattern.compile(messageSource.getMessage(RULE_STATE, null, null)).matcher(i).matches())
						.isPresent())
					violations.add(INVALID_STATE);
			}

		if(StringUtils.isBlank(optionalPostalDetailObj.map(i->i.getZipCode()).orElse("")))
			violations.add(INVALID_ZIPCODE_MISSING);
		else
		{

				violations.addAll(zipCodeRule.check(optionalPostalDetailObj.map(i->i.getZipCode()).orElse("")));
		}

		/*Check if non required fields are valid */
			 if (optionalPostalDetailObj.map(i -> i.getAddressLine2())
					 			.filter(i -> i.length() > 60 || i.length() < 1)
					 			.isPresent())
				violations.add(INVALID_ADDRESSLINE2);

        optionalPostalDetailObj.ifPresent(postalDetails -> validateCityStateZipCode(postalDetails, violations));

        return violations;
	}

    private void validateCityStateZipCode(PostalDetails postalDetails, List<String> violations) {
        try {
            if (!addressRepository.isCityStateZipValid(postalDetails)) {
                violations.add(INVALID_ADDRESS_CITY_STATE_ZIPCODE_MATCH);
            }
        }
        catch (RepositoryException e) {
            violations.add(INVALID_ADDRESS_CITY_STATE_ZIPCODE_MATCH);

            // due to method signature constraint, exception can't be thrown
            // set as validation error and log message, API call from front end UI likely capture the same error
            log.error("RepositoryException from isCityStateZipValid()", e);
        }
    }
}
