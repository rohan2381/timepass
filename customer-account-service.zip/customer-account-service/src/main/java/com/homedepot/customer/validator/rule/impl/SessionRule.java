package com.homedepot.customer.validator.rule.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.repository.IIdentityRepository;
import com.homedepot.customer.validator.rule.Rule;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by Nitin Ware on 9/12/16.
 */
@Component
@Slf4j
public class SessionRule implements Rule<String> {

    private static final String INVALID_SESSION = "INVALID_SESSION";

    @Autowired
    IIdentityRepository identityRepository;

    @Override
    public List<String> check(String value) {
        List<String> violations = new ArrayList<>();
        boolean valid = false;
        try {
            String setSvocCustomerAccountId = identityRepository.validateSession(value);
            valid = setSvocCustomerAccountId!=null?true:false;
        } catch (RepositoryException ex) {
            //Digest this exception as this exception cannot be re-thrown.
            log.error("Error validating User Session, root cause", ExceptionUtils.getRootCause(ex));
        }
        if(!valid){
            log.debug("Invalid User Session - auth-token: {}", value);
            violations.add(INVALID_SESSION);
        }
        return violations;
    }
}
