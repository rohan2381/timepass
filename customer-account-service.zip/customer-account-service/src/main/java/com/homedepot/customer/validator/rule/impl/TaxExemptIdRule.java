package com.homedepot.customer.validator.rule.impl;

import com.homedepot.customer.validator.rule.Rule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Created by axb4725 on 8/24/16.
 */
@Component
public class TaxExemptIdRule implements Rule<String> {
    private static final String INVALID_TAX_EXEMPT_ID = "INVALID_TAX_EXEMPT_ID";

    private static final String RULE_TAXEXEMPTID = "rule.taxexemptid";

    @Autowired
    @Qualifier("rulesMessageResource")
    ResourceBundleMessageSource messageSource;

    @Override
    public List<String> check(String value) {
        List<String> violations = new ArrayList<>();
        boolean valid = Pattern.compile(messageSource.getMessage(RULE_TAXEXEMPTID, null, null)).matcher(value).matches();

        if(!valid){
            violations.add(INVALID_TAX_EXEMPT_ID);
        }

        return violations;
    }
}
