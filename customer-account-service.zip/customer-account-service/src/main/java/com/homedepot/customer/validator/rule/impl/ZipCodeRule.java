package com.homedepot.customer.validator.rule.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Component;

import com.homedepot.customer.validator.rule.Rule;

import java.util.regex.Pattern;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Created by rxb1809 on Jun 22, 2016
 *
 */
@Component
public class ZipCodeRule implements Rule<String> {
	
	private static final String INVALID_ZIPCODE = "INVALID_ZIPCODE";

	private static final String RULE_ZIPCODE = "rule.zipcode";

	@Autowired
	@Qualifier("rulesMessageResource")
	ResourceBundleMessageSource messageSource;
	
	@Override
	public List<String> check(String value) {
		List<String> violations = new ArrayList<>();
		
		Optional<String> zipCodeOptionalObj = Optional.of(value);
		boolean valid = zipCodeOptionalObj.filter(i-> Pattern.compile(messageSource.getMessage(RULE_ZIPCODE, null, null)).matcher(i).matches())
				.isPresent();

		if(!valid){
        	violations.add(INVALID_ZIPCODE);
        }
        
        return violations;
	}
}
