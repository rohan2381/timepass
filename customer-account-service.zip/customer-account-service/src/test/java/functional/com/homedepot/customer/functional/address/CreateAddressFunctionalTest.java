package com.homedepot.customer.functional.address;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.homedepot.customer.CustomerAccountService;
import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.functional.config.AddressServiceDataProvider;
import com.homedepot.customer.integration.wcs.WCSProfileServiceFacade;
import com.homedepot.customer.integration.wcs.dto.WCSUserIdentity;
import com.homedepot.customer.model.Address;
import com.homedepot.customer.request.AddressRequest;
import com.homedepot.customer.response.AddressResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.boot.test.WebIntegrationTest;
import org.springframework.http.*;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Date;
import java.util.List;

import static org.testng.Assert.*;

/**
 * Created by rxb1809 on Jun 25, 2016 This test class is used to test create
 * address API functionalities It runs on a random available port on the same VM
 * where the actual API runs. Please create a separate test method for each of
 * the major testing scenarios
 */
@WebIntegrationTest(randomPort = true)
@SpringApplicationConfiguration(CustomerAccountService.class)
@Slf4j
public class CreateAddressFunctionalTest extends
		AbstractTestNGSpringContextTests {

	@Value("${local.server.port}")
	private int port;

	@Value("${mcmfunctionaltest.address.emailId}")
	private String emailId;

	@Value("${mcmfunctionaltest.address.password}")
	private String password;

	private RestTemplate restTemplate;
	private String BASE_URL;
	private ObjectMapper mapper;
	private HttpHeaders headers;
	private String wcsMemberId;


	@Autowired
	WCSProfileServiceFacade wcsProfileFacade;

	private static final String CREATE_ADDRESS = "/customer/account/v1/";

	@BeforeClass
	public void setUp() {
		if (port != 0) {
			BASE_URL = "http://localhost:" + port;
		} else {
			BASE_URL = "http://localhost:8080";
		}
		restTemplate = new TestRestTemplate();

		mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, true);


		WCSUserIdentity wcsIdentity = null;

		try {
			wcsIdentity = wcsProfileFacade.authenticateUser(emailId,password.toCharArray(),null);
			wcsMemberId = wcsIdentity.getUserId();
			headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("Authorization", wcsIdentity.getEncodedActivityToken());
			headers.put("Cookie", wcsIdentity.getResponseCookies());
			headers.set("channelId", "1");
		} catch (IntegrationException e) {
			log.error("Error Signing in WCS "+e);
		}
	}

	/**
	 * Cleans old/stray test addreses to avoid 50 address limits on test user
	 * Structured as a test to have access to the customerAccountId being used for testing
	 * @param customerAccountId
	 * @param addressRequest
	 * @param context
	 */
	@Test(dataProvider="createCustomerAddress", dataProviderClass=AddressServiceDataProvider.class, groups =
			"cleanOldTestData.addresses")
	public void cleanOldTestAddresses(String customerAccountId, AddressRequest addressRequest, ITestContext context) {
		System.out.println("cleaning old test address");
		String url = BASE_URL + CREATE_ADDRESS+ wcsMemberId + "/addresses";
		System.out.println("GET_ALL_ADDRESS" + url);
		context.setAttribute("headers_address",headers);
		context.setAttribute("wcsMemberId_address",wcsMemberId);

		HttpEntity<String> requestEntity = new HttpEntity<>(headers);
		ResponseEntity<AddressResponse> responseEntity = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
				AddressResponse.class);
		if (responseEntity.getStatusCode().is2xxSuccessful()) {
			List<Address> addressList = responseEntity.getBody().getAddresses().getAddress();
			if (addressList != null && !addressList.isEmpty()) {

				HttpEntity<String> deleteRequestEntity = new HttpEntity<>(headers);



				addressList.stream()
						.filter(address -> !address.getIsDefault())
						.forEach(address -> {
							String deleteUrl = BASE_URL +CREATE_ADDRESS+ wcsMemberId + "/addresses/" +
									address.getAddrIdentifier();
							MultiValueMap<String, String> deleteParams = new LinkedMultiValueMap<String, String>();
							deleteParams.add("lastModifiedDate", "" + address.getLastModifiedDate().getTime());
							UriComponents deleteUriComponents = UriComponentsBuilder.fromHttpUrl(deleteUrl).queryParams(deleteParams).build();
							System.out.println("---------- Deleting: " + deleteUriComponents.toString());

							ResponseEntity<AddressResponse> response = restTemplate.exchange(deleteUriComponents.toString(), HttpMethod.DELETE, deleteRequestEntity, AddressResponse.class);
						});
			}
		}
	}


	@Test(dataProvider="createCustomerAddress",dataProviderClass=AddressServiceDataProvider.class, groups = { "createAddress.success" }, dependsOnMethods = "cleanOldTestAddresses")
	public void testAddAddressesSuccess(String customerAccountId, AddressRequest addressRequest, ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		log.debug("Start testAddAddressesSuccess..");

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";

		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jshttps://webapps-q1.homedepot.com/SingleViewOfCustomerServices/rs/v2/customer/address/createonRequest: " + jsonRequest);

		
		
		
		 HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest, headers);


		ResponseEntity<AddressResponse> response = restTemplate.exchange(url,
				HttpMethod.POST,requestEntity,AddressResponse.class);

		System.out.println(response.getStatusCode());
		System.out.println("response body:" + response.getBody());

		assertEquals(response.getStatusCode(), HttpStatus.OK);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(200));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8");

		assertNotNull(response);

		List<Address> addressList = response.getBody().getAddresses().getAddress();
		assertNotNull(addressList);
		assertEquals(addressList.size(), 1);
		assertTrue(addressList.get(0).getAddrIdentifier() > 0);

		Address address = addressList.get(0);
		assertNotNull(address.getAddrIdentifier().toString());

		System.out.println("created addressId:" + address.getAddrIdentifier());
		context.setAttribute("addressId", address.getAddrIdentifier());

		context.setAttribute("customerAccountId",customerAccountId);
		context.setAttribute("port",port);

		log.debug("addressId:"+address.getAddrIdentifier());
		log.debug("ENd testAddAddressesSuccess..");

	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass =
			AddressServiceDataProvider.class, groups = "createAddress")
	public void
	testAddAddressesFirstName_Blank(String customerAccountId, AddressRequest
			addressRequest, ITestContext context) throws Exception { if
			(context.getAttribute("customerAccountId") != null) { customerAccountId =
			context.getAttribute("customerAccountId").toString(); }

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getName().setFirstName("");

		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		addressRequest.getAddress().get(0).getName().setFirstName("");

		
		
		
		 HttpEntity<String> requestEntity = new
				HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String,
				String>(); params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST,requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+
				response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "First Name is required");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_117");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");

	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesFirstName_WithSpace(String customerAccountId,
													AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getName().setFirstName("Rev   athy");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST,requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.OK);
	  /*assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
	  assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
	  response.getStatusCode()); System.out.println("Response body = "+ response);

	  assertEquals(response.getBody().getAddresses().getErrors().get(0).
	  getErrorMessage(), "Invalid First Name");
	  assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_110");
	  assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");*/



	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesFirstName_WithNumbers(String customerAccountId,
													  AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getName().setFirstName("23123213213");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST,requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.OK);
		//assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		  /*assertEquals(response.getBody().getAddresses().getErrors().get(0).
		  getErrorMessage(), "Invalid First Name");
		  assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_110");
		  assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");*/
	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesFirstName_WithAlphaNumeric(String customerAccountId,
														   AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getName().setFirstName("Revathy3213213");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST,requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.OK);
		//assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode()); System.out.println("Response body = "+ response);

		  /*assertEquals(response.getBody().getAddresses().getErrors().get(0).
		  getErrorMessage(), "Invalid First Name");
		  assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_110");
		  assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");*/
	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesFirstName_WithSpecialChar(String customerAccountId,
														  AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getName().setFirstName("!@$%");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);




		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST,requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.OK);
		  /*assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		  assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
		  response.getStatusCode()); System.out.println("Response body = "+ response);

		  assertEquals(response.getBody().getAddresses().getErrors().get(0).
		  getErrorMessage(), "Invalid First Name");
		  assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_110");
		  assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");*/
	}
	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesFirstName_WithMoreThan60Chars(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null)
		{customerAccountId = context.getAttribute("customerAccountId").toString();

		}
		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getName().setFirstName("RevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathy");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);

		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Invalid First Name");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_110");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");

	}

	// ==============================================Error validation for Last Name==================================
	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesBlankLastNameErrorValidation(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getName().setLastName("");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);

		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" + response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Last Name is required");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_118");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");

	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesLastName_WithSpace(String customerAccountId,
												   AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getName().setLastName("Sella durai");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);

		assertEquals(response.getStatusCode(), HttpStatus.OK);
		  /*assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		  assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
		  response.getStatusCode()); System.out.println("Response body = "+ response);

		  assertEquals(response.getBody().getAddresses().getErrors().get(0).
		  getErrorMessage(), "Invalid Last Name");
		  assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_111");
		  assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");*/

	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesLastName_WithSpecialChar(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";

		addressRequest.getAddress().get(0).getName().setLastName("Sella@durai");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.OK);
		  /*assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		  assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
		  response.getStatusCode()); System.out.println("Response body = "+ response);

		  assertEquals(response.getBody().getAddresses().getErrors().get(0).
		  getErrorMessage(), "Invalid Last Name");
		  assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_111");
		  assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");*/


	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesLastName_WithNumber(String customerAccountId,
													AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getName().setLastName("23213213");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.OK);
		  /*assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		  assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
		  response.getStatusCode()); System.out.println("Response body = "+ response);

		  assertEquals(response.getBody().getAddresses().getErrors().get(0).
		  getErrorMessage(), "Invalid Last Name");
		  assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_111");
		  assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");*/

	}
	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesLastName_WithAlphaNum(String customerAccountId,
													  AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getName().setLastName("asasas23213213");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.OK);
		  /*assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		  assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
		  response.getStatusCode()); System.out.println("Response body = "+ response);

		  assertEquals(response.getBody().getAddresses().getErrors().get(0).
		  getErrorMessage(), "Invalid Last Name");
		  assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_111");
		  assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");*/

	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesLastName_MoreThan60Chars(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getName().setLastName("SelladuraiSelladuraiSelladuraiSelladuraiSelladuraiSelladuraiSelladuraiSelladuraiSelladuraiSelladuraiSelladuraiSelladuraiSelladuraiSelladurai");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Invalid Last Name");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_111");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
	}
	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesLastName_SpecialChar(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getName().setLastName("!@$%");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.OK);
		  /*assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		  assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
		  response.getStatusCode()); System.out.println("Response body = "+ response);

		  assertEquals(response.getBody().getAddresses().getErrors().get(0).
		  getErrorMessage(), "Invalid Last Name");
		  assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_111");
		  assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");*/
	}



	// ==============================================Primary Phone Error Validation=====================================
	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesBlankPrimaryPhone(String customerAccountId,
												  AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPrimaryPhone().setNumber("");

		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage(), "Primary Phone is required");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_114");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");


	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesPrimaryPhone_WithSpace(
			String customerAccountId, AddressRequest addressRequest,ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPrimaryPhone().setNumber("2323 3232137");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Invalid Primary Phone number");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_115");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");

	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesPrimaryPhone_WithSpecialChar(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPrimaryPhone().setNumber("asa((**(#090");

		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);



		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Invalid Primary Phone number");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_115");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");

	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesPrimaryPhone_LessThan10Digits(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPrimaryPhone().setNumber("404899090");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Invalid Primary Phone number");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_115");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");

	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesPrimaryPhone_GreaterThan10Digits(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPrimaryPhone().setNumber("40489909000");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Invalid Primary Phone number");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_115");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");

	}

	// ==============================================Alternate Phone Error Validation=====================================

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesBlankAlternatePhone(String customerAccountId,
													AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getAlternatePhone().setNumber("");

		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Alternate Phone is missing");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_119");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");


	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesAlternatePhone_WithSpace(String customerAccountId, AddressRequest addressRequest,ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getAlternatePhone().setNumber("2323 3232137");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Invalid Alternate Phone number");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_116");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");

	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesAlternatePhone_WithSpecialChar(String customerAccountId, AddressRequest addressRequest,
															   ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getAlternatePhone().setNumber("asa((**(#090");

		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);



		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Invalid Alternate Phone number");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_116");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");

	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesAlternatePhone_LessThan10Digits(String customerAccountId, AddressRequest addressRequest,ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getAlternatePhone().setNumber("404899090");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Invalid Alternate Phone number");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_116");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");

	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesAlternatePhone_GreaterThan10Digits(String customerAccountId, AddressRequest addressRequest,
																   ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getAlternatePhone().setNumber("40489909000");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Invalid Alternate Phone number");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_116");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");

	}

	// ==============================================Address Line1 Error Validation=====================================
	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesAddressLine1_Blank(String customerAccountId,
												   AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPostalDetails().setAddressLine1("");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Length of AddressLine1 should be more than 1 and less than 60");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_104");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesAddressLine1_NoreThan60Chars(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPostalDetails().setAddressLine1("Atlanta1 323232^*&^*&^*&^*&^&^*&^*&^*&^ Atlanta1 Atlanta1 Atlanta1 Atlanta1 Atlanta1 Atlanta1 Atlanta1 Atlanta1 Atlanta1 Atlanta1 Atlanta1 Atlanta1");

		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.POST, requestEntity,
				AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Length of AddressLine1 should be more than 1 and less than 60");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_104");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");

	}

	// ==============================================Address Line2 Error Validation=====================================
	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesAddressLine2_Blank(String customerAccountId,
												   AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";

		addressRequest.getAddress().get(0).getPostalDetails().setAddressLine2("");

		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Length of AddressLine2 should be more than 1 and less than 60");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_109");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");


	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesAddressLine2_MoreThan60Chars(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPostalDetails().setAddressLine2("Atlanta1 232321 &&(*&&09-090-9#%@%@ Atlanta1 Atlanta1 Atlanta1 Atlanta1 Atlanta1 Atlanta1 Atlanta1 Atlanta1 Atlanta1 Atlanta1 Atlanta1 Atlanta1");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);



		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.POST, requestEntity,
				AddressResponse.class);

		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Length of AddressLine2 should be more than 1 and less than 60");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_109");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");	}

	//=============================================Email Id Validation=======================================================

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesEmailID_InvalidFormat(String customerAccountId,
													  AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).setEmailId("revathy...com");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Please provide a valid email id");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_101");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesEmailID_InvalidFormat1(String customerAccountId,
													   AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).setEmailId("revathy@.com.com");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Please provide a valid email id");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_101");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesEmailID_InvalidFormatSpChar(String customerAccountId,
															AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).setEmailId("revathy#$#$@s.com");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Please provide a valid email id");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_101");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
	}



	// ==============================================City Name Error Validation=====================================
	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesCityName_Blank(String customerAccountId,
											   AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPostalDetails().setCity("");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);

		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Invalid City Name, City Name should not be empty or exceed 60 characters");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_145");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "4023 : Invalid City Name, City Name should not be empty or null");
	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesCityName_MoreThan60Chars(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPostalDetails().setCity("AtlantaAtlantaAtlantaAtlantaAtlantaAtlantaAtlantaAtlantaAtlantaAtlantaAtlantaAtlantaAtlanta");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);

		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage(), "The ZIP code, City, and State combination do not match");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_163");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesCityName_WithJunk(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPostalDetails().setCity("$%$^$^$23213dssadsad");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);

		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage(), "The ZIP code, City, and State combination do not match");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_163");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");	}


	// ==============================================State Name Error Validation=====================================
	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesStateName_Blank(String customerAccountId,
												AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPostalDetails().setState("");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Invalid State code");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_108");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesStateName_Invalidcase(String customerAccountId,
													  AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPostalDetails().setState("@$#@$ h122");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Invalid State code");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_108");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
	}

	// ==============================================ZipCode Error Validation===========================================
	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesZipCode_Blank(String customerAccountId,
											  AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPostalDetails().setZipCode("");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "ZipCode is required");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_112");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesZipCode_LessThan5Digits(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPostalDetails().setZipCode("3033");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Invalid ZipCode");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_113");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");

	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesZipCode_MoreThan5Digits(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPostalDetails().setZipCode("303339");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Invalid ZipCode");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_113");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");

	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesZipCode_Junk(String customerAccountId,
											 AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPostalDetails().setZipCode("3033%$ha");

		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).
				getErrorMessage(), "Invalid ZipCode");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_113");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");

	}

	// ==============================================Country Name Error Validation======================================
	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesCountryName_Blank(String customerAccountId,
												  AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPostalDetails().setCountry("");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage(), "Invalid Country code.");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_106");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesCountryName_OtherThanUS(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPostalDetails().setCountry("UK");
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage(), "Invalid Country code.");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_106");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");

	}

	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesCountryName_Invalid(String customerAccountId,
													AddressRequest addressRequest, ITestContext context)
			throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";
		addressRequest.getAddress().get(0).getPostalDetails().setCountry("UK#$");

		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);


		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.POST, requestEntity,AddressResponse.class);

		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage(), "Invalid Country code.");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_106");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
	}

	// ===========================Invalid ZipCode/City Combination Error Validation=======================================
	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesInvalidZipCodeCityErrorValidation(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {customerAccountId = context.getAttribute("customerAccountId")
				.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";

		addressRequest.getAddress().get(0).getPostalDetails().setCity("New York");
		addressRequest.getAddress().get(0).getPostalDetails().setZipCode("30339");

		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);


		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.POST, requestEntity,
				AddressResponse.class);

		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage(), "The ZIP code, City, and State combination do not match");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_163");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
	}

	// ===========================Invalid City/State Combination Error Validation=======================================
	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesInvalidCityStateErrorValidation(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";

		addressRequest.getAddress().get(0).getPostalDetails().setCity("New York");
		addressRequest.getAddress().get(0).getPostalDetails().setState("GA");

		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);



		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.POST, requestEntity,
				AddressResponse.class);

		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage(), "The ZIP code, City, and State combination do not match");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_163");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
	}

	// ===========================Invalid ZipCode/State Combination Error Validation=======================================
	@Test(dataProvider = "createCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "createAddress")
	public void testAddAddressesInvalidZipCodeStateErrorValidation(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		String url = BASE_URL +CREATE_ADDRESS+ wcsMemberId+"/addresses";

		addressRequest.getAddress().get(0).getPostalDetails().setZipCode("30339");
		addressRequest.getAddress().get(0).getPostalDetails().setState("CA");

		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);


		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.POST, requestEntity,
				AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8"); System.out.println("Responsecode =" +
				response.getStatusCode()); System.out.println("Response body = "+ response);

		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage(), "The ZIP code, City, and State combination do not match");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_163");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");


	}

}
