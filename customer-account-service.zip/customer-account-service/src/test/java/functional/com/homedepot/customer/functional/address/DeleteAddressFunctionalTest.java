package com.homedepot.customer.functional.address;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.boot.test.WebIntegrationTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.homedepot.customer.CustomerAccountService;
import com.homedepot.customer.integration.svoc.dto.AddressRequest;
import com.homedepot.customer.response.AddressResponse;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

/**
 * Created by rxb1809 on Jun 25, 2016
 */
@WebIntegrationTest(randomPort = true)
@SpringApplicationConfiguration(CustomerAccountService.class)
public class DeleteAddressFunctionalTest {

    @Value("${local.server.port}")
    private int port;

    private RestTemplate restTemplate;
    private String BASE_URL;
    private ObjectMapper mapper;

    //    private static final String DELETE_ADDRESS = "/customer/account/v1/addresses";
    static final String DELETE_ADDRESS_BY_ID = "/addresses/";
    HttpHeaders headers;
    String wcsMemberId;

    @BeforeClass
    public void setUp() {
        if (port != 0) {
            BASE_URL = "http://localhost:" + port +"/customer/account/v1/";
        }
        restTemplate = new TestRestTemplate();

        mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, true);
    }

    @Test(groups = "deleteAddress.success", dependsOnGroups = "updateAddress.success", priority = 10)
    public void testDeleteAddressSuccess(ITestContext context) throws Exception {

        String customerAccountId = null;
        if (port == 0) BASE_URL = "http://localhost:" + context.getAttribute("port") +"/customer/account/v1/";
        if (context.getAttribute("customerAccountId") != null) {
            customerAccountId = context.getAttribute("customerAccountId").toString();
        }
        else {
            customerAccountId = "03D52E6CFFFBB8D00S";
        }
        String getUrl = BASE_URL +wcsMemberId+"/addresses/" + context.getAttribute("addressId");

        System.out.println("testRetrieveAddressesByAddrIdSuccess URL address service by ID"+ getUrl);


        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<AddressResponse> getResponseEntity = restTemplate.exchange(
                getUrl, HttpMethod.GET, requestEntity,
                AddressResponse.class);

        String url = BASE_URL +wcsMemberId + DELETE_ADDRESS_BY_ID +context.getAttribute("addressId")
                .toString();



        Date lastModifiedDate = getResponseEntity.getBody().getAddresses().getAddress().get(0).getLastModifiedDate();

        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        params.add("lastModifiedDate", "" + lastModifiedDate.getTime());

        UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

        System.out.println("Delete URL:"+url);

        ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(),
                HttpMethod.DELETE, requestEntity, AddressResponse.class);
        assertNotNull(response);
        assertEquals(response.getStatusCode(), HttpStatus.OK);
    }
    @Test(groups = "deleteAddress.fail", dependsOnGroups = "updateAddress.success", priority = 1)
    public void testDeleteAddresswithoutAddressID (ITestContext context) throws Exception {
        headers = (HttpHeaders) context.getAttribute("headers_address");
        wcsMemberId = (String) context.getAttribute("wcsMemberId_address");

        String customerAccountId = null;
        if (port == 0) BASE_URL = "http://localhost:" + context.getAttribute("port") +"/customer/account/v1/";
        if (context.getAttribute("customerAccountId") != null) {
            customerAccountId = context.getAttribute("customerAccountId").toString();
        }
        else {
            customerAccountId = "03D52E6CFFFBB8D00S";
        }

        String url = BASE_URL +wcsMemberId+ DELETE_ADDRESS_BY_ID + "";





        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        Date lastModifiedDate = (Date) context.getAttribute("lastModifiedDate");

        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        params.add("lastModifiedDate", "" + lastModifiedDate.getTime());

        UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

        System.out.println("Delete URL:" +url);

        ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(),
                HttpMethod.DELETE, requestEntity, AddressResponse.class);
        assertNotNull(response);
        assertEquals(response.getStatusCode(), HttpStatus.METHOD_NOT_ALLOWED);
        assertEquals(response.getStatusCode(), HttpStatus.valueOf(405));

    }

    @Test(groups = "deleteAddress.fail", dependsOnGroups = "updateAddress.success", priority = 2)
    public void testDeleteAddressWithInvalidAddressID(ITestContext context) throws Exception {

        String customerAccountId = null;
        if (port == 0) BASE_URL = "http://localhost:" + context.getAttribute("port")+"/customer/account/v1/";
        if (context.getAttribute("customerAccountId") != null) {
            customerAccountId = context.getAttribute("customerAccountId").toString();
        }
        else {
            customerAccountId = "03D52E6CFFFBB8D00S";
        }

        String url = BASE_URL +wcsMemberId +DELETE_ADDRESS_BY_ID + "300";

        
        
        
        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        Date lastModifiedDate = (Date) context.getAttribute("lastModifiedDate");

        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        params.add("customerAccountId", customerAccountId);
        params.add("lastModifiedDate", "" + lastModifiedDate.getTime());

        UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

        System.out.println("Delete URL:" +url);

        ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(),
                HttpMethod.DELETE, requestEntity, AddressResponse.class);
        assertNotNull(response);
        assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
        assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
        assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode().toString(), "ADDR_ERR_133");
        assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage().toString(), "Address Id in request not available");


    }

    @Test(groups = "deleteAddress.fail", dependsOnGroups = "updateAddress.success", priority = 3)
    public void testDeleteAddressWithJunkCharsInAddressID(ITestContext context) throws Exception {

        String customerAccountId = null;
        if (port == 0) BASE_URL = "http://localhost:" + context.getAttribute("port") +"/customer/account/v1/";;
        if (context.getAttribute("customerAccountId") != null) {
            customerAccountId = context.getAttribute("customerAccountId").toString();
        }
        else {
            customerAccountId = "03D52E6CFFFBB8D00S";
        }

        String url = BASE_URL +wcsMemberId + DELETE_ADDRESS_BY_ID + "3A";

        
        
        
        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        Date lastModifiedDate = (Date) context.getAttribute("lastModifiedDate");

        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        params.add("customerAccountId", customerAccountId);
        params.add("lastModifiedDate", "" + lastModifiedDate.getTime());

        UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

        System.out.println("Delete URL:" +url);

        ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(),
                HttpMethod.DELETE, requestEntity, AddressResponse.class);
        assertNotNull(response);
        assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
        assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));

    }

    @Test(groups = "deleteAddress.fail", dependsOnGroups = "updateAddress.success", priority = 4)
    public void testDeleteAddressWithBlankCustomerAddressID(ITestContext context) throws Exception {

        String customerAccountId = null;
        if (port == 0) BASE_URL = "http://localhost:" + context.getAttribute("port");

        //  customerAccountId = context.getAttribute("customerAccountId").toString();
        //  context.setAttribute(customerAccountId, "");

        customerAccountId = "";

        String url = BASE_URL +  customerAccountId + DELETE_ADDRESS_BY_ID + context.getAttribute("addressId")
                .toString();

        
        
        
        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        Date lastModifiedDate = (Date) context.getAttribute("lastModifiedDate");

        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        params.add("lastModifiedDate", "" + lastModifiedDate.getTime());

        UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

        System.out.println("Delete URL:" +url);

        ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(),
                HttpMethod.DELETE, requestEntity, AddressResponse.class);
        assertNotNull(response);
        assertEquals(response.getStatusCode(), HttpStatus.NOT_FOUND);
    }

    @Test(groups = "deleteAddress.fail", dependsOnGroups = "updateAddress.success", priority = 5)
    public void testDeleteAddressWithInvalidCustomerAddressID(ITestContext context) throws Exception {

        String customerAccountId = null;
        if (port == 0) BASE_URL = "http://localhost:" + context.getAttribute("port") +"/customer/account/v1/";;

        //  customerAccountId = context.getAttribute("customerAccountId").toString();
        //  context.setAttribute(customerAccountId, "");

        customerAccountId = "3477329874ahg";

        String url = BASE_URL +customerAccountId +DELETE_ADDRESS_BY_ID + context.getAttribute("addressId").toString();

        
        
        
        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        Date lastModifiedDate = (Date) context.getAttribute("lastModifiedDate");

        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        params.add("lastModifiedDate", "" + lastModifiedDate.getTime());

        UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

        System.out.println("Delete URL:" +url);

        ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(),
                HttpMethod.DELETE, requestEntity, AddressResponse.class);
        assertNotNull(response);
        assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
        assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));

    }

    @Test(groups = "deleteAddress.fail", dependsOnGroups = "updateAddress.success", priority = 6)
    public void testDeleteAddressWithoutLastModifiedDateParam(ITestContext context) throws Exception {

        String customerAccountId = null;
        if (port == 0) BASE_URL = "http://localhost:" + context.getAttribute("port")+"/customer/account/v1/";
        if (context.getAttribute("customerAccountId") != null) {
            customerAccountId = context.getAttribute("customerAccountId").toString();
        }
        else {
            customerAccountId = "03D52E6CFFFBB8D00S";
        }

        //  customerAccountId = context.getAttribute("customerAccountId").toString();
        //  context.setAttribute(customerAccountId, "");

        String url = BASE_URL +  wcsMemberId + DELETE_ADDRESS_BY_ID + context.getAttribute("addressId").toString();

        
        
        
        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        //Date lastModifiedDate = (Date) context.getAttribute("lastModifiedDate");


        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        //  params.add("lastModifiedDate", "" + lastModifiedDate.getTime());

        UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

        System.out.println("Delete URL:" +url);

        ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(),
                HttpMethod.DELETE, requestEntity, AddressResponse.class);
        assertNotNull(response);
        assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
        assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
    }

    @Test(groups = "deleteAddress.fail", dependsOnGroups = "updateAddress.success", priority = 7)
    public void testDeleteAddressWithJunkLastModifiedDate(ITestContext context) throws Exception {

        String customerAccountId = null;
        if (port == 0) BASE_URL = "http://localhost:" + context.getAttribute("port")+"/customer/account/v1/";
        if (context.getAttribute("customerAccountId") != null) {
            customerAccountId = context.getAttribute("customerAccountId").toString();
        }
        else {
            customerAccountId = "03D52E6CFFFBB8D00S";
        }

        String url = BASE_URL +  wcsMemberId +DELETE_ADDRESS_BY_ID + context.getAttribute("addressId").toString();

        
        
        
        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        params.add("lastModifiedDate", "42347239dsfdsfsdf");

        UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

        System.out.println("Delete URL:" +url);

        ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(),
                HttpMethod.DELETE, requestEntity, AddressResponse.class);
        assertNotNull(response);
        assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
        assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
    }

    @Test(groups = "deleteAddress.fail", dependsOnGroups = "updateAddress.success", priority = 8)
    public void testDeleteAddressWithBlankLastModifiedDate(ITestContext context) throws Exception {

        String customerAccountId = null;
        if (port == 0) BASE_URL = "http://localhost:" + context.getAttribute("port")+"/customer/account/v1/";
        if (context.getAttribute("customerAccountId") != null) {
            customerAccountId = context.getAttribute("customerAccountId").toString();
        }
        else {
            customerAccountId = "03D52E6CFFFBB8D00S";
        }

        String url = BASE_URL +  wcsMemberId + DELETE_ADDRESS_BY_ID + context.getAttribute("addressId").toString();

        
        
        
        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
        params.add("lastModifiedDate", "");

        UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

        System.out.println("Delete URL:" +url);

        ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(),
                HttpMethod.DELETE, requestEntity, AddressResponse.class);
        assertNotNull(response);
        assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
        assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
    }

    @Test(groups = "deleteAddress.fail", dependsOnGroups = "updateAddress.success", priority = 9)
    public void testDeleteAddressWithInvalidLastModifiedDate(ITestContext context) throws Exception {

        String customerAccountId = null;
        if (port == 0) BASE_URL = "http://localhost:" + context.getAttribute("port")+"/customer/account/v1/";
        if (context.getAttribute("customerAccountId") != null) {
            customerAccountId = context.getAttribute("customerAccountId").toString();
        }
        else {
            customerAccountId = "03D52E6CFFFBB8D00S";
        }

        String url = BASE_URL +  wcsMemberId + DELETE_ADDRESS_BY_ID + context.getAttribute("addressId").toString();




        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();

        Calendar cal = Calendar.getInstance();
        cal.set(2015,Calendar.DECEMBER,31);
        params.add("lastModifiedDate", cal.getTime().toString());


        UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();

        System.out.println("Delete URL:" +url);

        ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(),
                HttpMethod.DELETE, requestEntity, AddressResponse.class);
        assertNotNull(response);
        assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);

    }

}
