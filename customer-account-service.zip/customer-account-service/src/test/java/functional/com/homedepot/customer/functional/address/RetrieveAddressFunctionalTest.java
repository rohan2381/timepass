package com.homedepot.customer.functional.address;

import java.util.List;

import com.homedepot.customer.model.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.boot.test.WebIntegrationTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.springframework.web.client.RestTemplate;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.homedepot.customer.CustomerAccountService;
import com.homedepot.customer.functional.config.AddressServiceDataProvider;
import com.homedepot.customer.response.AddressResponse;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

/**
 * Created by rxb1809 on Jun 25, 2016 This test class is used to test retrieve
 * address API functionalities It runs on a random available port on the same VM
 * where the actual API runs. Ensure we create a separate test method for each
 * of the major test cases
 */
@WebIntegrationTest(randomPort = true)
@SpringApplicationConfiguration(CustomerAccountService.class)
@Slf4j
public class RetrieveAddressFunctionalTest extends
		AbstractTestNGSpringContextTests {

	@Value("${local.server.port}")
	private int port;

	private RestTemplate restTemplate;
	private String BASE_URL;

	static final String GET_ALL_ADDRESS = "/addresses";
	private static final String GET_ALL_ADDRESS_BY_ID = "/addresses/";
	HttpHeaders headers;
	String wcsMemberId;



	@BeforeClass
	public void setUp() {
		BASE_URL = "http://localhost:" + port +"/customer/account/v1/";
		restTemplate = new TestRestTemplate();
	}

	@Test(dataProvider = "retrieveCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, dependsOnGroups = "createAddress.success", groups = "retrieveAddress", priority = 1)
	public void testRetrieveAllAddressesSuccess(String customerAccountId,
												ITestContext context) {
		log.debug("Start testRetrieveAllAddressesSuccess..");
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}
		headers = (HttpHeaders) context.getAttribute("headers_address");
		wcsMemberId = (String) context.getAttribute("wcsMemberId_address");

		String url = BASE_URL +wcsMemberId+GET_ALL_ADDRESS;

		log.debug("GET_ALL_ADDRESS" + url);


		HttpEntity<String> requestEntity = new HttpEntity<>(headers);

		ResponseEntity<AddressResponse> responseEntity = restTemplate.exchange(
				url, HttpMethod.GET, requestEntity,
				AddressResponse.class);

		assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
		assertEquals(responseEntity.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println(responseEntity.getStatusCode());

		List<Address> addressList = responseEntity.getBody().getAddresses()
				.getAddress();

		Integer addrId = (Integer) context.getAttribute("addressId");
		log.debug("testRetrieveAllAddressesSuccess addrId" + addrId);
		Address address = null;
		for (Address addressTemp : addressList){
			if (addressTemp.getAddrIdentifier() != null && addrId != null
					&& addrId == addressTemp.getAddrIdentifier()){
				address = addressTemp;
				break;
			}
		}
		assertTrue(addressList.size() > 0);

		// context.setAttribute("addressIdentifier",
		// addressList.get(0).getAddrIdentifier());
		// System.out.println("context address 1 " +
		// context.getAttribute("addressIdentifier"));
		// System.out.println("all context attribute name 1: " +
		// context.getAttributeNames());

		// assertEquals(addressList.get(0).getAddrIdentifier().toString(),
		// "50");
		assertTrue(address.getAddrIdentifier() > 0);
		assertEquals(address.getName().getFirstName().toString(),
				"BENEDICT");
		//assertEquals(address.getEmailId(),
		//		"TEST_EMAIL_1@FUNCTIONAL.TEST.COM");
		assertEquals(address.getPostalDetails().getAddressLine1()
				.toString(), "8899 NYAWO STREET");
		assertEquals(address.getPostalDetails().getAddressLine2()
				.toString(), "SUITE B");
		assertEquals(
				address.getPostalDetails().getCity().toString(),
				"AURORA");
		assertEquals(address.getPostalDetails().getState()
				.toString(), "CO");
		assertEquals(address.getPostalDetails().getCountry()
				.toString(), "US");
		assertEquals(address.getPostalDetails().getZipCode()
				.toString(), "80011");
		assertEquals(address.getPrimaryPhone().getNumber()
				.toString(), "9999999933");
		assertEquals(address.getAlternatePhone().getNumber(),
				"9999999934");
		assertEquals(address.getIsDefault().toString(), "false");

		//context.setAttribute("addressId", address.getAddrIdentifier());
		//context.setAttribute("customerAccountId",customerAccountId);

		// assertNull(address.getAddressLine2());
		log.debug("End testRetrieveAllAddressesSuccess..");

	}

	@Test(dataProvider = "retrieveCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "retrieveAddressById.success", dependsOnGroups = "createAddress.success", priority = 2)
	public void testRetrieveAddressesByAddrIdSuccess(String customerAccountId,
													 ITestContext context) {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}
		System.out.println("all context attribute name: "
				+ context.getAttributeNames());
		String addressId = context.getAttribute("addressId").toString();

		System.out.println("context address " + addressId);

		String url = BASE_URL +wcsMemberId+GET_ALL_ADDRESS_BY_ID + addressId;

		System.out.println("testRetrieveAddressesByAddrIdSuccess URL address service by ID"+ url);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);

		ResponseEntity<AddressResponse> responseEntity = restTemplate.exchange(
				url, HttpMethod.GET, requestEntity,
				AddressResponse.class);
		assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
		assertEquals(responseEntity.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println(responseEntity.getStatusCode());
		System.out.println("response body: " + responseEntity.getBody());

		Addresses addresses = responseEntity.getBody().getAddresses();

		assertNotNull(addresses);
		assertThat(addresses.getAddress(), hasSize(1));

		Address address = addresses.getAddress().get(0);

		// save last modified date for using in update flow
		context.setAttribute("lastModifiedDate", address.getLastModifiedDate());

		assertEquals(address.getName().getFirstName(), "BENEDICT");
		assertEquals(address.getName().getLastName(), "BRANSFORD");
		assertEquals(address.getAddrIdentifier().toString(), addressId);
		//assertEquals(address.getEmailId(), "TEST_EMAIL_1@FUNCTIONAL.TEST.COM");
		assertNotNull(address.getLastModifiedDate());

		Phone phone = address.getPrimaryPhone();
		assertEquals(phone.getNumber(), "9999999933");
		assertEquals(phone.getId().toString(), "1");

		phone = address.getAlternatePhone();
		assertEquals(phone.getNumber(), "9999999934");
		assertEquals(phone.getId().toString(), "2");

		PostalDetails postalDetails = address.getPostalDetails();
		assertEquals(postalDetails.getAddressLine1(), "8899 NYAWO STREET");
		assertEquals(postalDetails.getAddressLine2(), "SUITE B");
		assertEquals(postalDetails.getCity(), "AURORA");
		assertEquals(postalDetails.getState(), "CO");
		assertEquals(postalDetails.getZipCode(), "80011");
		assertEquals(postalDetails.getCountry(), "US");

		assertEquals(address.getIsDefault().toString(), "false");
	}

	@Test(dataProvider = "retrieveCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, priority = 3)
	public void testRetrieveAddressesByInvalidAddrIdAlphabets(
			String customerAccountId, ITestContext context) {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		// String addressId = context.getAttribute("addressId").toString();

		String addressIdAlphabets = "ffdfsdzxZXzxzxZxzxsfdsadsada";

		String url = BASE_URL +wcsMemberId +GET_ALL_ADDRESS_BY_ID + addressIdAlphabets;


		System.out.println("URL address service by ID" + url);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);

		ResponseEntity<AddressResponse> responseEntity = restTemplate.exchange(
				url, HttpMethod.GET, requestEntity,
				AddressResponse.class);

		assertEquals(responseEntity.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(responseEntity.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println(responseEntity.getStatusCode());

		// Need to add proper error response message for this invalid case

	}

	@Test(dataProvider = "retrieveCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, priority = 4)
	public void testRetrieveAddressesByInvalidAddrIdAlphanum(
			String customerAccountId, ITestContext context) {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		// String addressId = context.getAttribute("addressId").toString();
		String addressIdAlphanum = "sdasdasd43243434234";

		String url = BASE_URL +wcsMemberId+GET_ALL_ADDRESS_BY_ID + addressIdAlphanum;


		System.out.println("URL address service by ID"
				+ url);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);

		ResponseEntity<AddressResponse> responseEntity = restTemplate.exchange(
				url, HttpMethod.GET, requestEntity,
				AddressResponse.class);

		assertEquals(responseEntity.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(responseEntity.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println(responseEntity.getStatusCode());

		// Need to add proper error message for this invalid case

	}

	@Test(dataProvider = "retrieveCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, priority = 5)
	public void testRetrieveAddressesByInvalidAddrIdwithSpch(
			String customerAccountId, ITestContext context) {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		// String addressId = context.getAttribute("addressId").toString();

		String addressIdwithSpecialch = "asasaSa_";
		String url = BASE_URL +wcsMemberId+GET_ALL_ADDRESS_BY_ID + addressIdwithSpecialch;

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(headers);

		System.out.println("URL address service by ID"
				+ url);

		AddressResponse addresses = restTemplate.getForObject(
				url, AddressResponse.class);

		ResponseEntity<AddressResponse> getResponseById = restTemplate
				.getForEntity(url, AddressResponse.class);

		assertEquals(getResponseById.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(getResponseById.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println(getResponseById.getStatusCode());

		// Need to add proper error message for this invalid case
		// FAILED:
		// testRetrieveAddressesByInvalidAddrIdwithSpch("03D40DEDF6FBB8D00S",
		// org.testng.TestRunner@1acf18d)
		// java.lang.IllegalArgumentException:
		// [http://localhost:49565/customer/account/v1/addresses/id/asasaSa!@#`$%^&*()_-=+[]{}\|';:;./,<>?]
		// is not a valid HTTP URL

	}

	@Test(dataProvider = "retrieveCustomerAddress", dataProviderClass = AddressServiceDataProvider.class, priority = 5)
	public void testRetrieveAddressesByInvalidAddrIdwithBlank(
			String customerAccountId, ITestContext context) {
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		// String addressId = context.getAttribute("addressId").toString();

		String addressIdwithSpecialch = "";
		String url = BASE_URL +wcsMemberId+GET_ALL_ADDRESS_BY_ID + addressIdwithSpecialch;

		/*AddressResponse addresses = restTemplate.getForObject(
				url, AddressResponse.class);*/

		ResponseEntity<AddressResponse> getResponseById = restTemplate
				.getForEntity(url, AddressResponse.class);

		assertEquals(getResponseById.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(getResponseById.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println(getResponseById.getStatusCode());

		// Need to add proper error message for this invalid case
		// FAILED:
		// testRetrieveAddressesByInvalidAddrIdwithSpch("03D40DEDF6FBB8D00S",
		// org.testng.TestRunner@1acf18d)
		// java.lang.IllegalArgumentException:
		// [http://localhost:49565/customer/account/v1/addresses/id/asasaSa!@#`$%^&*()_-=+[]{}\|';:;./,<>?]
		// is not a valid HTTP URL

	}

}
