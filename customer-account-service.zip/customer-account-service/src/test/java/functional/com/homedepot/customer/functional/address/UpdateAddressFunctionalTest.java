package com.homedepot.customer.functional.address;

import java.util.Date;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.boot.test.WebIntegrationTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.homedepot.customer.CustomerAccountService;
import com.homedepot.customer.functional.config.AddressServiceDataProvider;
import com.homedepot.customer.model.Address;
import com.homedepot.customer.request.AddressRequest;
import com.homedepot.customer.response.AddressResponse;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

/**
 * Created by rxb1809 on Jun 25, 2016
 *
 */
@WebIntegrationTest(randomPort = true)
@SpringApplicationConfiguration(CustomerAccountService.class)
public class UpdateAddressFunctionalTest extends
		AbstractTestNGSpringContextTests {

	@Value("${local.server.port}")
	private int port;

	private RestTemplate restTemplate;
	private String BASE_URL;
	private ObjectMapper mapper;

	private static final String UPDATE_ADDRESS = "/customer/account/v1/";
	HttpHeaders headers;
	String wcsMemberId;


	@BeforeClass
	public void setUp() {
		if (port != 0) {
			BASE_URL = "http://localhost:" + port;
		} else {
			BASE_URL = "http://localhost:8080";
		}
		restTemplate = new TestRestTemplate();

		mapper = new ObjectMapper();
		mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, true);
	}


	@Test(dataProvider = "updateCustomerAddress", dataProviderClass = AddressServiceDataProvider.class,
			groups = "updateAddress.success", dependsOnGroups = "retrieveAddressById.success", priority = 1)
	public void testUpdateAddressesSuccess(String customerAccountId, AddressRequest addressRequest, ITestContext context) throws Exception {
		headers = (HttpHeaders) context.getAttribute("headers_address");
		wcsMemberId = (String) context.getAttribute("wcsMemberId_address");
		System.out.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if(context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).setLastModifiedDate((Date)context.getAttribute("lastModifiedDate"));
		addressRequest.getAddress().get(0).setIsDefault(false);

		addressRequest.getAddress().get(0).getName().setFirstName("Rahul");
		addressRequest.getAddress().get(0).getName().setLastName("Erram");
		addressRequest.getAddress().get(0).setEmailId("rahul_erram@homedepot.com");
		addressRequest.getAddress().get(0).getPrimaryPhone().setNumber("4948983434");
		addressRequest.getAddress().get(0).getAlternatePhone().setNumber("7848444944");
		addressRequest.getAddress().get(0).getPostalDetails().setAddressLine1("Deerfield");
		addressRequest.getAddress().get(0).getPostalDetails().setAddressLine2("Deerfield");
		addressRequest.getAddress().get(0).getPostalDetails().setCity("Alpharetta"); // TODO: should be Alpharetta
		addressRequest.getAddress().get(0).getPostalDetails().setState("GA");
		addressRequest.getAddress().get(0).getPostalDetails().setZipCode("30004");
		addressRequest.getAddress().get(0).getPostalDetails().setCountry("US");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses"; String jsonRequest = mapper.writeValueAsString(addressRequest);

		System.out.println("jsonRequest: " + jsonRequest);

		
		
		 HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest, headers);

		UriComponents uriComponents =UriComponentsBuilder.fromHttpUrl(url).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(),HttpMethod.PUT,requestEntity, AddressResponse.class);

		System.out.println("===============>>>>>>>>>>> 1. " + response );

		assertNotNull(response); assertEquals(response.getStatusCode(),HttpStatus.OK);

		// retrieve profile back to verify changes and also latest update
		ResponseEntity<AddressResponse> retrieveResponseEntity = restTemplate.exchange(uriComponents.toString()+"/"+addressId, HttpMethod.GET,requestEntity, AddressResponse.class);
		assertEquals(retrieveResponseEntity.getStatusCode(), HttpStatus.OK);

		Address address =  retrieveResponseEntity.getBody().getAddresses().getAddress().get(0);
		context.setAttribute("lastModifiedDate", address.getLastModifiedDate());
		context.setAttribute("addressId", address.getAddrIdentifier());
	}

	// ========================================== FIRSTNAME FIELD VALIDATIONS==============================================
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_BlankFirstName(String customerAccountId,
												   AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getName().setFirstName("");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "First Name is required");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_117");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}

//@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "updateAddress.success", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
//	public void testUpdateAddresses_FirstNameWithSpace(
//			String customerAccountId, AddressRequest addressRequest,
//			ITestContext context) throws Exception {
//		System.out.println("context attributes: " + context.getAttributeNames());
//		System.out.println("context: " + context.toString());
//		if (context.getAttribute("customerAccountId") != null) {
//			customerAccountId = context.getAttribute("customerAccountId").toString();
//		}
//
//		Integer addressId = (Integer) context.getAttribute("addressId");
//		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
//		addressRequest.getAddress().get(0).setLastModifiedDate((Date) context.getAttribute("lastModifiedDate"));
//		addressRequest.getAddress().get(0).getName().setFirstName("Reva  thy");
//
//		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
//		String jsonRequest = mapper.writeValueAsString(addressRequest);
//
//		System.out.println("jsonRequest: " + jsonRequest);
//
//		
//		
//		
//		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);
//
//		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
//		params.add("customerAccountId", customerAccountId);
//
//		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();
//
//		System.out.println(uriComponents.toString());
//
//		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.PUT, requestEntity,AddressResponse.class);
//
//		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
//		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
//		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8");
//		System.out.println("Responsecode =" + response.getStatusCode());
//		System.out.println("Response body = " + response);
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage(), "Invalid First Name");
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_110");
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
//	}

//@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "updateAddress.success", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
//	public void testUpdateAddresses_FirstNameWithSpecialChar(String customerAccountId, AddressRequest addressRequest,
//			ITestContext context) throws Exception {
//		System.out.println("context attributes: " + context.getAttributeNames());
//		System.out.println("context: " + context.toString());
//		if (context.getAttribute("customerAccountId") != null)
//		{customerAccountId = context.getAttribute("customerAccountId").toString();
//		}
//
//		Integer addressId = (Integer) context.getAttribute("addressId");
//		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
//		addressRequest.getAddress().get(0).setLastModifiedDate(
//						(Date) context.getAttribute("lastModifiedDate"));
//		addressRequest.getAddress().get(0).getName().setFirstName("Reva#$%$thy");
//		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
//		String jsonRequest = mapper.writeValueAsString(addressRequest);
//
//		System.out.println("jsonRequest: " + jsonRequest);
//
//		
//		
//		
//		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);
//
//		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
//		params.add("customerAccountId", customerAccountId);
//
//		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();
//
//		System.out.println(uriComponents.toString());
//
//		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.PUT, requestEntity,AddressResponse.class);
//		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
//		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
//		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8");
//		System.out.println("Responsecode =" + response.getStatusCode());
//		System.out.println("Response body = " + response);
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage(), "Invalid First Name");
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_110");
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
//
//			}

//@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "updateAddress.success", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
//	public void testUpdateAddresses_FirstNameWithNumber(
//			String customerAccountId, AddressRequest addressRequest,
//			ITestContext context) throws Exception {
//		System.out.println("context attributes: " + context.getAttributeNames());
//		System.out.println("context: " + context.toString());
//		if (context.getAttribute("customerAccountId") != null) {
//			customerAccountId = context.getAttribute("customerAccountId").toString();
//		}
//
//		Integer addressId = (Integer) context.getAttribute("addressId");
//		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
//		addressRequest.getAddress().get(0).setLastModifiedDate((Date) context.getAttribute("lastModifiedDate"));
//		addressRequest.getAddress().get(0).getName().setFirstName("232434234");
//		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
//		String jsonRequest = mapper.writeValueAsString(addressRequest);
//
//		System.out.println("jsonRequest: " + jsonRequest);
//		
//		
//		
//		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);
//
//		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
//		params.add("customerAccountId", customerAccountId);
//
//		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();
//
//		System.out.println(uriComponents.toString());
//
//		ResponseEntity<AddressResponse> response = restTemplate.exchange(
//				uriComponents.toString(), HttpMethod.PUT, requestEntity,
//				AddressResponse.class);
//
//		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
//		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
//		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8");
//		System.out.println("Responsecode =" + response.getStatusCode());
//		System.out.println("Response body = " + response);
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage(), "Invalid First Name");
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_110");
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
//		}

	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_FirstNameWithMoreThan60Chars(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).setLastModifiedDate((Date) context.getAttribute("lastModifiedDate"));
		addressRequest.getAddress().get(0).getName().setFirstName("RevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathyRevathy");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);

		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.PUT, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage(), "Invalid First Name");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_110");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");

	}
	//@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
//	public void testUpdateAddresses_FirstNameAlphanumeric(
//			String customerAccountId, AddressRequest addressRequest,
//			ITestContext context) throws Exception {
//		System.out
//				.println("context attributes: " + context.getAttributeNames());
//		System.out.println("context: " + context.toString());
//		if (context.getAttribute("customerAccountId") != null) {
//			customerAccountId = context.getAttribute("customerAccountId").toString();
//		}
//
//		Integer addressId = (Integer) context.getAttribute("addressId");
//		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
//		addressRequest.getAddress().get(0).setLastModifiedDate((Date) context.getAttribute("lastModifiedDate"));
//		addressRequest.getAddress().get(0).getName().setFirstName("Revathy23233");
//
//		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
//		String jsonRequest = mapper.writeValueAsString(addressRequest);
//
//		System.out.println("jsonRequest: " + jsonRequest);
//
//		
//		
//		
//		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
//				headers);
//
//		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
//		params.add("customerAccountId", customerAccountId);
//
//		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
//				.queryParams(params).build();
//
//		System.out.println(uriComponents.toString());
//
//		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.PUT, requestEntity,AddressResponse.class);
//		assertEquals(response.getStatusCode(), HttpStatus.OK);
//		assertEquals(response.getStatusCode(), HttpStatus.valueOf(200));
//		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8");
//		System.out.println("Responsecode =" + response.getStatusCode());
//		System.out.println("Response body = " + response);
//
//		//code refactor, TODO firstname accepts alphanumeric?
//		//assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage(), "Invalid First Name");
//		//assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_110");
//		//assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
//	context.setAttribute("lastModifiedDate", response.getBody().getAddresses().getAddress().get(0).getLastModifiedDate());
//
//			}
// ========================================== LASTNAME FIELD VALIDATIONS==============================================
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_BlankLastName(String customerAccountId,
												  AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getName().setLastName("");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Last Name is required");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_118");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}

//@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "updateAddress.success", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
//	public void testUpdateAddresses_LastNameWithSpace(
//			String customerAccountId, AddressRequest addressRequest,
//			ITestContext context) throws Exception {
//		System.out
//				.println("context attributes: " + context.getAttributeNames());
//		System.out.println("context: " + context.toString());
//		if (context.getAttribute("customerAccountId") != null) {
//			customerAccountId = context.getAttribute("customerAccountId")
//					.toString();
//		}
//
//		Integer addressId = (Integer) context.getAttribute("addressId");
//		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
//		addressRequest.getAddress().get(0).setLastModifiedDate((Date) context.getAttribute("lastModifiedDate"));
//		addressRequest.getAddress().get(0).getName().setLastName("Sella durai");
//
//		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
//		String jsonRequest = mapper.writeValueAsString(addressRequest);
//
//		System.out.println("jsonRequest: " + jsonRequest);
//
//		
//		
//		
//		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);
//
//		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
//		params.add("customerAccountId", customerAccountId);
//
//		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();
//
//		System.out.println(uriComponents.toString());
//
//		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.PUT, requestEntity,AddressResponse.class);
//
//		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
//		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
//		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8");
//		System.out.println("Responsecode =" + response.getStatusCode());
//		System.out.println("Response body = " + response);
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage(), "Invalid Last Name");
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_111");
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
//	}

//@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "updateAddress.success", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
//	public void testUpdateAddresses_LastNameWithSpecialChar(String customerAccountId, AddressRequest addressRequest,
//			ITestContext context) throws Exception {
//		System.out.println("context attributes: " + context.getAttributeNames());
//		System.out.println("context: " + context.toString());
//		if (context.getAttribute("customerAccountId") != null)
//		{customerAccountId = context.getAttribute("customerAccountId").toString();
//		}
//
//		Integer addressId = (Integer) context.getAttribute("addressId");
//		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
//		addressRequest.getAddress().get(0).setLastModifiedDate(
//						(Date) context.getAttribute("lastModifiedDate"));
//		addressRequest.getAddress().get(0).getName().setLastName("Sella#$$#2durai");
//		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
//		String jsonRequest = mapper.writeValueAsString(addressRequest);
//
//		System.out.println("jsonRequest: " + jsonRequest);
//
//		
//		
//		
//		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);
//
//		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
//		params.add("customerAccountId", customerAccountId);
//
//		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url).queryParams(params).build();
//
//		System.out.println(uriComponents.toString());
//
//		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.PUT, requestEntity,AddressResponse.class);
//		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
//		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
//		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8");
//		System.out.println("Responsecode =" + response.getStatusCode());
//		System.out.println("Response body = " + response);
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage(), "Invalid Last Name");
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_111");
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
//
//	}

//@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "updateAddress.success", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
//	public void testUpdateAddresses_LastNameWithNumber(
//			String customerAccountId, AddressRequest addressRequest,
//			ITestContext context) throws Exception {
//		System.out
//				.println("context attributes: " + context.getAttributeNames());
//		System.out.println("context: " + context.toString());
//		if (context.getAttribute("customerAccountId") != null) {
//			customerAccountId = context.getAttribute("customerAccountId")
//					.toString();
//		}
//
//		Integer addressId = (Integer) context.getAttribute("addressId");
//		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
//		addressRequest.getAddress().get(0).setLastModifiedDate((Date) context.getAttribute("lastModifiedDate"));
//		addressRequest.getAddress().get(0).getName().setLastName("232434234");
//		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
//		String jsonRequest = mapper.writeValueAsString(addressRequest);
//
//		System.out.println("jsonRequest: " + jsonRequest);
//		
//		
//		
//		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,headers);
//
//		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
//		params.add("customerAccountId", customerAccountId);
//
//		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
//				.queryParams(params).build();
//
//		System.out.println(uriComponents.toString());
//
//		ResponseEntity<AddressResponse> response = restTemplate.exchange(
//				uriComponents.toString(), HttpMethod.PUT, requestEntity,
//				AddressResponse.class);
//
//		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
//		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
//		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8");
//		System.out.println("Responsecode =" + response.getStatusCode());
//		System.out.println("Response body = " + response);
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage(), "Invalid Last Name");
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_111");
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
//
//	}

	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_LastNameWithMoreThan60Chars(
			String customerAccountId, AddressRequest addressRequest,
			ITestContext context) throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId").toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).setLastModifiedDate((Date) context.getAttribute("lastModifiedDate"));
		addressRequest.getAddress().get(0).getName().setLastName("SelladuraSelladuraSelladuraSelladuraSelladuraSelladuraSelladuraSelladuraSelladuraSelladuraSelladuraSelladuraSelladuraSelladuraSelladuraSelladura");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);

		System.out.println("jsonRequest: " + jsonRequest);

		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);

		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);

		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();

		System.out.println(uriComponents.toString());

		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.PUT, requestEntity,AddressResponse.class);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage(), "Invalid Last Name");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_111");
		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");

	}
//@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "updateAddress.success", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
//	public void testUpdateAddresses_LastNameAlphanumeric(
//			String customerAccountId, AddressRequest addressRequest,
//			ITestContext context) throws Exception {
//		System.out
//				.println("context attributes: " + context.getAttributeNames());
//		System.out.println("context: " + context.toString());
//		if (context.getAttribute("customerAccountId") != null) {
//			customerAccountId = context.getAttribute("customerAccountId").toString();
//		}
//
//		Integer addressId = (Integer) context.getAttribute("addressId");
//		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
//		addressRequest.getAddress().get(0).setLastModifiedDate((Date) context.getAttribute("lastModifiedDate"));
//		addressRequest.getAddress().get(0).getName().setLastName("Selladura#@#@#");
//
//		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
//		String jsonRequest = mapper.writeValueAsString(addressRequest);
//
//		System.out.println("jsonRequest: " + jsonRequest);
//
//		
//		
//		
//		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
//				headers);
//
//		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
//		params.add("customerAccountId", customerAccountId);
//
//		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
//				.queryParams(params).build();
//
//		System.out.println(uriComponents.toString());
//
//		ResponseEntity<AddressResponse> response = restTemplate.exchange(uriComponents.toString(), HttpMethod.PUT, requestEntity,AddressResponse.class);
//		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
//		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
//		assertEquals(response.getHeaders().getContentType().toString(),"application/json;charset=UTF-8");
//		System.out.println("Responsecode =" + response.getStatusCode());
//		System.out.println("Response body = " + response);
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorMessage(), "Invalid Last Name");
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getErrorCode(), "ADDR_ERR_111");
//		assertEquals(response.getBody().getAddresses().getErrors().get(0).getDeveloperErrorMessage(), "TODO");
//
//	}

	// ==========================================PRIMARY PHONE FIELD VALIDATIONS==============================================
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_BlankPrimaryPhoneNumber(String customerAccountId,
															AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPrimaryPhone().setNumber("");
		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Primary Phone is required");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_114");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_PrimaryPhoneWithSpace(String customerAccountId,
														  AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPrimaryPhone().setNumber("555 345222");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Invalid Primary Phone number");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_115");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_PrimaryPhoneWithSpecialChars(String customerAccountId,
																 AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPrimaryPhone().setNumber("555#%#$$22");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Invalid Primary Phone number");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_115");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_PrimaryPhoneWithLessThan10Digits(String customerAccountId,
																	 AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPrimaryPhone().setNumber("555345222");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Invalid Primary Phone number");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_115");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}

	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_PrimaryPhoneWithGreaterThan10Digits(String customerAccountId,
																		AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPrimaryPhone().setNumber("55533452223");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Invalid Primary Phone number");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_115");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}

	//==========================================ALTERNATE PHONE FIELD VALIDATIONS==============================================
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_BlankAlternatePhoneNumber(String customerAccountId,
															  AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getAlternatePhone().setNumber("");
		addressRequest.getAddress().get(0).getAlternatePhone().setId((short) 0);

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Alternate Phone is missing");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_119");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_AlternatePhoneWithSpace(String customerAccountId,
															AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getAlternatePhone().setNumber("444 8484848");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Invalid Alternate Phone number");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_116");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_AlternatePhoneWithSpecialChars(String customerAccountId,
																   AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getAlternatePhone().setNumber("453#$^3446");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Invalid Alternate Phone number");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_116");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_AlternatePhoneWithLessThan10Digits(String customerAccountId,
																	   AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getAlternatePhone().setNumber("456346345");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Invalid Alternate Phone number");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_116");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}

	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_AlternatePhoneWithGreaterThan10Digits(String customerAccountId,
																		  AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getAlternatePhone().setNumber("40455520202");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Invalid Alternate Phone number");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_116");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	//==========================================ADDRESS LINE1 FIELD VALIDATIONS==============================================
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_BlankAddressLine1(String customerAccountId,
													  AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPostalDetails().setAddressLine1("");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Length of AddressLine1 should be more than 1 and less than 60");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_104");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_AddressLine1MoreThan60Chars(String customerAccountId,
																AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPostalDetails().setAddressLine1("Atlanta1Atlanta1Atlanta1Atlanta1Atlanta1Atlanta1Atlanta1Atlanta1Atlanta1Atlanta1Atlanta1");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Length of AddressLine1 should be more than 1 and less than 60");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_104");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}

	//==========================================ADDRESS LINE2 FIELD VALIDATIONS==============================================
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_BlankAddressLine2(String customerAccountId,
													  AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPostalDetails().setAddressLine2("");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Length of AddressLine2 should be more than 1 and less than 60");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_109");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_AddressLine2MoreThan60Chars(String customerAccountId,
																AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPostalDetails().setAddressLine2("Atlanta1Atlanta1Atlanta1Atlanta1Atlanta1Atlanta1Atlanta1Atlanta1Atlanta1Atlanta1Atlanta1Atlanta1");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Length of AddressLine2 should be more than 1 and less than 60");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_109");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	//==========================================EMAIL ID FIELD VALIDATIONS==============================================
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_InvalidEmailFormat1(String customerAccountId,
														AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).setEmailId("revathy...com");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Please provide a valid email id");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_101");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}

	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_InvalidEmailFormat2(String customerAccountId,
														AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).setEmailId("revathy@.com.com");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Please provide a valid email id");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_101");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}


	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_EmailIdWithSpecialChars(String customerAccountId,
															AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).setEmailId("revathy#$#$@s.com");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Please provide a valid email id");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_101");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}

	//==========================================CITY NAME FIELD VALIDATIONS==============================================
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_BlankCityName(String customerAccountId,
												  AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPostalDetails().setCity("");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Invalid City Name, City Name should not be empty or exceed 60 characters");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_145");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "4023 : Invalid City Name, City Name should not be empty or null");

	}

	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_CityNameMoreThan60Chars(String customerAccountId,
															AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPostalDetails().setCity("AtlantaAtlantaAtlantaAtlantaAtlantaAtlantaAtlantaAtlantaAtlantaAtlantaAtlantaAtlantaAtlantaAtlanta");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "The ZIP code, City, and State combination do not match");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_163");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}

	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_CityNameWithJunkChars(String customerAccountId,
														  AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPostalDetails().setCity("At@#$#@223");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "The ZIP code, City, and State combination do not match");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_163");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	// ==========================================STATE NAME FIELD VALIDATIONS==============================================
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_BlankStateName(String customerAccountId,
												   AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPostalDetails().setState("");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Invalid State code");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_108");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_InvalidStateName(String customerAccountId,
													 AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPostalDetails().setState("GAA@##@12");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Invalid State code");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_108");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	//==========================================ZIPCODE FIELD VALIDATIONS==============================================
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_BlankZipcode(String customerAccountId,
												 AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPostalDetails().setZipCode("");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "ZipCode is required");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_112");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_ZipcodeLessThan5Digits(String customerAccountId,
														   AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPostalDetails().setZipCode("3003");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Invalid ZipCode");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_113");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}

	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_ZipcodeMoreThan5Digits(String customerAccountId,
														   AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPostalDetails().setZipCode("303399");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Invalid ZipCode");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_113");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_ZipcodeWithJunkChars(String customerAccountId,
														 AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPostalDetails().setZipCode("3#$399");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Invalid ZipCode");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_113");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	//==========================================COUNTRY NAME FIELD VALIDATIONS==============================================
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_BlankCountryName(String customerAccountId,
													 AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPostalDetails().setCountry("");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Invalid Country code.");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_106");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_CountryNameOtherThanUS(String customerAccountId,
														   AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPostalDetails().setCountry("UK");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Invalid Country code.");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_106");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_InvalidCountryName(String customerAccountId,
													   AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPostalDetails().setCountry("@#$#@$12");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "Invalid Country code.");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_106");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	//==========================================INVALID ZIPCODE/CITY COMBINATION==============================================
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_InvalidZipCodeCityErrorValidation(String customerAccountId,
																	  AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPostalDetails().setCity("New York");
		addressRequest.getAddress().get(0).getPostalDetails().setZipCode("30339");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "The ZIP code, City, and State combination do not match");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_163");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}
	//==========================================INVALID CITY/STATE COMBINATION==============================================
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_InvalidCityStateErrorValidation(String customerAccountId,
																	AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPostalDetails().setCity("New York");
		addressRequest.getAddress().get(0).getPostalDetails().setState("GA");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "The ZIP code, City, and State combination do not match");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_163");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}

	//==========================================INVALID ZIPCODE/STATE COMBINATION==============================================
	@Test(dataProvider = "updateCustomerAddress", dependsOnGroups = "retrieveAddress", dataProviderClass = AddressServiceDataProvider.class, groups = "updateAddress", priority = 2)
	public void testUpdateAddresses_InvalidZipCodeStateErrorValidation(String customerAccountId,
																	   AddressRequest addressRequest, ITestContext context)
			throws Exception {
		System.out
				.println("context attributes: " + context.getAttributeNames());
		System.out.println("context: " + context.toString());
		if (context.getAttribute("customerAccountId") != null) {
			customerAccountId = context.getAttribute("customerAccountId")
					.toString();
		}

		Integer addressId = (Integer) context.getAttribute("addressId");
		addressRequest.getAddress().get(0).setAddrIdentifier(addressId);
		addressRequest.getAddress().get(0).getPostalDetails().setZipCode("30339");
		addressRequest.getAddress().get(0).getPostalDetails().setState("CA");

		String url = BASE_URL + UPDATE_ADDRESS+wcsMemberId+"/addresses";
		String jsonRequest = mapper.writeValueAsString(addressRequest);
		System.out.println("jsonRequest: " + jsonRequest);
		
		
		
		HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest,
				headers);
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		params.add("customerAccountId", customerAccountId);
		UriComponents uriComponents = UriComponentsBuilder.fromHttpUrl(url)
				.queryParams(params).build();
		System.out.println(uriComponents.toString());
		ResponseEntity<AddressResponse> response = restTemplate.exchange(
				uriComponents.toString(), HttpMethod.PUT, requestEntity,
				AddressResponse.class);
		System.out.println("===============>>>>>>>>>>> 1. " + response);
		assertEquals(response.getStatusCode(), HttpStatus.BAD_REQUEST);
		assertEquals(response.getStatusCode(), HttpStatus.valueOf(400));
		assertEquals(response.getHeaders().getContentType().toString(),
				"application/json;charset=UTF-8");
		System.out.println("Responsecode =" + response.getStatusCode());
		System.out.println("Response body = " + response);
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorMessage(), "The ZIP code, City, and State combination do not match");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getErrorCode(), "ADDR_ERR_163");
		assertEquals(response.getBody().getAddresses().getErrors().get(0)
				.getDeveloperErrorMessage(), "TODO");

	}

}
