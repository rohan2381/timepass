package com.homedepot.customer.functional.address;

import java.util.Collections;
import java.util.List;

import com.homedepot.customer.integration.passport.THDPassportServiceFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.WebIntegrationTest;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.homedepot.customer.CustomerAccountService;
import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.functional.config.AddressServiceDataProvider;
import com.homedepot.customer.integration.wcs.WCSAddressServiceFacade;
import com.homedepot.customer.model.Address;
import com.homedepot.customer.model.Name;
import com.homedepot.customer.model.Phone;
import com.homedepot.customer.model.PostalDetails;
import com.homedepot.customer.request.AddressRequest;

/**
 * Created by rxb1809 on Aug 28, 2016
 *
 */
@WebIntegrationTest(randomPort = true)
@SpringApplicationConfiguration(CustomerAccountService.class)
public class WCSAddressFunctionalTest extends AbstractTestNGSpringContextTests{
    
    @Autowired
    WCSAddressServiceFacade wcsAddressFacade;

    @Autowired
    private THDPassportServiceFacade passportServiceFacade;

    @BeforeClass
    public void setUp() throws IntegrationException {
        ssoToken = passportServiceFacade.getToken();
    }

    String ssoToken = null;
    
    @Test(dataProvider="createCustomerAddress", dataProviderClass=AddressServiceDataProvider.class)
    public void testCreateAddress(String customerAccountId, AddressRequest addressRequest) throws IntegrationException{
        //String ssoToken = "Hv3LREk3YYz150jpBLumLmNTMC2njYPwj1C1vdvKEP8XboQyySSiFDaWH3bFC2LTR8pljRattFvwPkdkAs9Tk71ZXsro1kRMtDW1bOTZFgbliT7LhtZ4Oqarm9UouOPKWbXFBSepevaby40QHsYxag9QlFwoCm55ThPcrBYFSC7OHw9fJKIkaa3Wvjvka5alHfDNj1jqgJ0fTr8wS8dsz7bCkoUWMB7s4W8ujj5SOW7Kty6fk3ZmM5z9QXMPn19lvRWZK132z52a7j3hH0WMlYdDT1MYKJpihT3DyhdxxaDy3sNK0DtvwYyrBkYeoLPyTCNFRr17jde5UAhV28vMvblI7kCHE4ljERg620lAYhh7V52HBFfiiYL0qnQZfRbTYfzAkNT6YcmaZd9ajxCDPYrPnGarsn3p3hkHsTXjQbO6PIUQQxwknDtogGTebYiSFUP6DLmUU1rjYlfsSyFrTYQbV4yTD3hlmcSIZGW9pluk7gcLBkYlZ5MVCzwN1uUejaD3gSeIyl1dWjpSW2akYjy1wq2tS3fNPtzN2eCnFqIkjzyBsJFb9Hp82xQljn3BpqOWf7hHflxM3sDCbjmdSpKwNz4PepSDVg7RV8OTtbYiGIcYBxVUQEqVUYIhoWluXc912OdoRCxFvCqvorzJP3nttD2CKbQnBjhE9gXp9PrhTjfRVI6Sz3JnOjtFSKFZzLUriJCiEtFgscL5UI9IxBjBX4wWOpTv7dCZNRIiORzOJDzkexE2UMofTAxfZcUOKAWQQpTIb77lBaFVOKlilmWkUoPu11McdXHB0BMkXNLNeIiRAX8ZAk2Y17DhmiEZ7";

        Address address = new Address();
        address.setIsDefault(false);

        Name name = new Name();
        name.setFirstName("Rohan");
        name.setLastName("Test NG 2");
        address.setName(name);

        Phone phone = new Phone();
        phone.setNumber("3337770001");
        address.setPrimaryPhone(phone);

        phone = new Phone();
        phone.setNumber("3337770002");
        address.setAlternatePhone(phone);

        PostalDetails postalDetails = new PostalDetails();
        postalDetails.setAddressLine1("123 Nariman Point");
        postalDetails.setCity("IRVING");
        postalDetails.setState("TX");
        postalDetails.setZipCode("75038");
        postalDetails.setCountry("US");
        address.setPostalDetails(postalDetails);
        
        List<Address> response = wcsAddressFacade.createCustomerAddressCSR("1066102358", Collections.singletonList(address), ssoToken);
    }
    

}
