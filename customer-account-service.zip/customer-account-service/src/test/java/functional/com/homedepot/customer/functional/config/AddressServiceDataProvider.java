package com.homedepot.customer.functional.config;

import com.homedepot.customer.model.Address;
import com.homedepot.customer.model.Name;
import com.homedepot.customer.model.Phone;
import com.homedepot.customer.model.PostalDetails;
import com.homedepot.customer.request.AddressRequest;
import org.testng.ITestContext;
import org.testng.annotations.DataProvider;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;

/**
 * Created by rxb1809 on Jun 19, 2016
 *
 */
public class AddressServiceDataProvider {
    //private static final String customerAccountId = "03D9617906B3B8D01S";
	private static final String customerAccountId = "03E13E13508FCE200S";
    @DataProvider(name = "createCustomerAddress")
	public static Object[][] createCustomerAddressRequest() {
        AddressRequest addressRequest = new AddressRequest();
        Address address = new Address();
        address.setIsDefault(false);

        Name name = new Name();
        name.setFirstName("Benedict");
        name.setLastName("Bransford");
        address.setName(name);

        Phone phone = new Phone();
        phone.setNumber("9999999933");
        phone.setPrimaryFlag("Y");
        phone.setSecondaryFlag("N");
        phone.setId((short) 1);
        phone.setContactMethodEnumeration("PHN");
        address.setPrimaryPhone(phone);

        phone = new Phone();
        phone.setNumber("9999999934");
        phone.setPrimaryFlag("N");
        phone.setId((short) 2);
        phone.setContactMethodEnumeration("PHN");
        phone.setSecondaryFlag("Y");
        address.setAlternatePhone(phone);

        PostalDetails postalDetails = new PostalDetails();
        postalDetails.setAddressLine1("8899 Nyawo Street");
        postalDetails.setAddressLine2("Suite B");
        postalDetails.setCity("Aurora");
        postalDetails.setState("CO");
        postalDetails.setZipCode("80011");
        postalDetails.setCountry("US");
        address.setPostalDetails(postalDetails);

        addressRequest.setAddress(Collections.singletonList(address));

        return new Object[][]{{customerAccountId, addressRequest}};
    }

    @DataProvider(name = "updateCustomerAddress")
    public static Object[][] updateCustomerAddressRequest() throws ParseException {
    	
    	AddressRequest addressRequest = new AddressRequest();
        Address address = new Address();
        address.setIsDefault(true);
        address.setEmailId("test_email_1@functional.test.com");
        address.setAddrIdentifier(8);
        SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(Long.parseLong("1346524199000"));
        String temp = df2.format(calendar.getTime());
        Date d =df2.parse(temp);
        address.setLastModifiedDate(d);
        Name name = new Name();
        name.setFirstName("Benedict");
        name.setLastName("Bransford");
        address.setName(name);
       //Primary Phone Number
        Phone phone = new Phone();
        phone.setNumber("5556661111");
        phone.setId((short) 1);   
        //SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        //Calendar calendar = Calendar.getInstance();
         calendar.setTimeInMillis(Long.parseLong("1346524199000"));
         String temp1 = df2.format(calendar.getTime());
         Date d1 =df2.parse(temp1);
        //address.setLastModifiedDate(d1);
        phone.setLastModifiedDate(d1);
        address.setPrimaryPhone(phone);
     // Alternate Phone Number
        Phone phone1 = new Phone();
        phone1.setNumber("5556661111");
        phone1.setId((short) 2);   
       //  SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
       // Calendar calendar = Calendar.getInstance();
         calendar.setTimeInMillis(Long.parseLong("1346524199000"));
         String temp2 = df2.format(calendar.getTime());
         Date d2 =df2.parse(temp2);
        // address.setLastModifiedDate(d1);
        phone1.setLastModifiedDate(d2);
        address.setAlternatePhone(phone1);
        PostalDetails postalDetails = new PostalDetails();
        postalDetails.setAddressLine1("8899 Nyawo Street");
        postalDetails.setAddressLine2("Suite B");
        postalDetails.setCity("Aurora");
        postalDetails.setState("CO");
        postalDetails.setZipCode("80011");
        postalDetails.setCountry("US");
        address.setPostalDetails(postalDetails);
        addressRequest.setAddress(Collections.singletonList(address));
        return new Object[][]{{customerAccountId, addressRequest}};
    }

    @DataProvider(name = "deleteCustomerAddress")
    public static Object[][] deleteCustomerAddressRequest(ITestContext context) {
        Integer addressId = (Integer) context.getAttribute("addressId");

        AddressRequest addressRequest = new AddressRequest();
        Address address = new Address();
        address.setAddrIdentifier(addressId);


        return new Object[][]{{customerAccountId, addressRequest}};
    }

    @DataProvider(name = "retrieveCustomerAddress")
    public static Object[][] retrieveCustomerAddressRequest() {

        return new Object[][]{{customerAccountId}};
    }
	

  }
