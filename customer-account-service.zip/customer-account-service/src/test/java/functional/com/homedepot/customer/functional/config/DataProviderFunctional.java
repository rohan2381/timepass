package com.homedepot.customer.functional.config;

import java.util.Arrays;
import java.util.Collections;

import org.testng.annotations.DataProvider;

import com.homedepot.customer.integration.svoc.dto.Address;
import com.homedepot.customer.integration.svoc.dto.AddressPhone;
import com.homedepot.customer.integration.svoc.dto.AddressPhones;
import com.homedepot.customer.integration.svoc.dto.AddressRequest;
import com.homedepot.customer.integration.svoc.dto.Addresses;
import com.homedepot.customer.integration.svoc.dto.Customer;
import com.homedepot.customer.integration.svoc.dto.DeleteAddressRequest;
import com.homedepot.customer.integration.svoc.dto.Email;
import com.homedepot.customer.integration.svoc.dto.Emails;
import com.homedepot.customer.integration.svoc.dto.Phone;
import com.homedepot.customer.integration.svoc.dto.Phones;
import com.homedepot.customer.integration.svoc.dto.RetrieveAddressRequest;

import static com.homedepot.customer.util.GlobalConstants.ACTION_TYPE_INSERT;

/**
 * TODO Rohan: PLEASE DELETE THIS CLASS 
 * Created by rxb1809 on May 7, 2016
 *
 */
@Deprecated
public class DataProviderFunctional {
	
	@DataProvider(name="createCustomer")
	public static Object[][] getCreateCustomerRequest() {
		Customer customer = new Customer();
		customer.setTypeEnumeration("INDIVIDUAL");
		customer.setFirstName("Rohan");
		customer.setLastName("Borse");
		customer.setLocalizationPostalCode("75034");
		customer.setRegisteredCustomerFlag("N");
		
		Email email = new Email();
		email.setEmailAddress("rohan"+String.valueOf((long)(Math.random()*1000 + 2000L))+"@gmail.com");
		email.setPrimaryFlag("Y");
		email.setMyAccountFlag("Y");
		
		Emails emails = new Emails();
		emails.setEmail(Collections.singletonList(email));
		
		customer.setEmails(emails);
		
		return new Object[][]{{customer}};
	}
	
	
	@DataProvider(name="deleteCustomerAddress")
	public static Object[][] getDeleteCustomerAddressRequest() {
		DeleteAddressRequest DAQ= new DeleteAddressRequest();
		return new Object[][]{{DAQ}};
	}
	
	@DataProvider(name="retrieveCustomerAddress")
	public static Object[][] getRetrieveCustomerAddressRequest() {
		RetrieveAddressRequest RAQ= new RetrieveAddressRequest();
		return new Object[][]{{RAQ}};
	}
	
	@DataProvider(name="createCustomerAddress")
	public static Object[][] getCreateCustomerAddressRequest() {
		AddressRequest addressRequest = new AddressRequest();
		
		Address address = new Address();
		address.setActionType(ACTION_TYPE_INSERT);
		address.setFirstName("Rohan");
		address.setLastName("Work");
		address.setAddressLine1("2951 KINWEST PARKWAY");
		address.setCityName("IRVING");
		address.setStateCode("TX");
		address.setPostalCode("75063");
		address.setCountyName("DALLAS");
		address.setCountryCode("US");
		address.setPrimaryFlag("N");
		address.setDisplayCustomerEmailAddress("rohan@test.com");
		
		AddressPhone addressPhone1 = new AddressPhone();
		addressPhone1.setPhoneNumber("2148624879");
		addressPhone1.setCountryCode("1");
		addressPhone1.setPrimaryFlag("Y");
		addressPhone1.setSecondaryFlag("N");
		addressPhone1.setActionType(ACTION_TYPE_INSERT);
		
		AddressPhone addressPhone2 = new AddressPhone();
		addressPhone2.setPhoneNumber("3123428722");
		addressPhone2.setCountryCode("1");
		addressPhone2.setPrimaryFlag("N");
		addressPhone2.setSecondaryFlag("Y");
		addressPhone2.setActionType(ACTION_TYPE_INSERT);
		
		AddressPhones addressPhones = new AddressPhones();
		
		addressPhones.setAddressPhone(Arrays.asList(new AddressPhone[]{addressPhone1,addressPhone2}));
		
		address.setAddressPhones(addressPhones);
		
		Addresses addresses = new Addresses();
		addresses.setAddress(Collections.singletonList(address));
		
		addressRequest.setAddresses(addresses);
		
		return new Object[][]{{addressRequest}};
	}
	
	

	@DataProvider(name="createCustomerFull")
	public static Object[][] getCreateCustomerFullRequest() {
		Customer customer = new Customer();
		customer.setTypeEnumeration("INDIVIDUAL");
		customer.setFirstName("Rohan");
		customer.setLastName("Borse");
		customer.setManagedAccountFlag("N");
		customer.setNationalAccountFlag("N");
		customer.setPreferredLanguageCode("en_US");
		
		Phone phone = new Phone();
		phone.setActionType(ACTION_TYPE_INSERT);
		phone.setContactMethodEnumeration("PHN");
		phone.setTypeEnumeration("MOBILE");
		phone.setPhoneNumber(String.valueOf((long)(Math.random()*100000 + 2148600000L)));
		phone.setCountryCode("US");
		phone.setPrimaryFlag("Y");
		
		Phones phones = new Phones();
		phones.setPhone(Collections.singletonList(phone));
		
		customer.setPhones(phones);
		
		Address address = new Address();
		address.setActionType(ACTION_TYPE_INSERT);
		address.setContactMethodEnumeration("ADDR");
		address.setAddressLine1("2951 KINWEST PARKWAY");
		address.setCityName("IRVING");
		address.setStateCode("TX");
		address.setPostalCode("75063");
		address.setCountyName("DALLAS");
		address.setCountryCode("US");
		address.setPrimaryFlag("Y");
		
		Addresses addresses = new Addresses();
		addresses.setAddress(Collections.singletonList(address));
		
		customer.setAddresses(addresses);
		
		Email email = new Email();
		email.setActionType(ACTION_TYPE_INSERT);
		email.setContactMethodEnumeration("EMAIL");
		email.setEmailAddress("rohan"+String.valueOf((long)(Math.random()*100 + 200L))+"@gmail.com");
		email.setPrimaryFlag("Y");
		email.setEmailReceiptOptInFlag("N");
		
		Emails emails = new Emails();
		emails.setEmail(Collections.singletonList(email));
		
		customer.setEmails(emails);
		
		return new Object[][]{{customer}};
	}

}
