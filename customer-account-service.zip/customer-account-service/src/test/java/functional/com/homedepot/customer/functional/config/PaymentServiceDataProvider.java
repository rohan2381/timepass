package com.homedepot.customer.functional.config;

import com.homedepot.customer.model.Address;
import com.homedepot.customer.model.PaymentCard;
import com.homedepot.customer.model.PaymentCards;
import org.testng.annotations.DataProvider;

import java.util.Collections;

/**
 * Created by rxb1809 on Jun 19, 2016
 *
 */
public class PaymentServiceDataProvider {

    private static final String emailId = "qa74testing@test.com";
    private static final String password = "qa74testing";
    private static final String svocId = "0310A237541938740S";
    private static final String paymentId = "8127833";

    @DataProvider(name = "retrieveLogonDetails")
    public static Object[][] retrieveLoginDetails() {

        return new Object[][]{{emailId, password}};
    }


    @DataProvider(name = "updatePaymentRequest")
    public static Object[][] updatePaymentRequest() {

        PaymentCards paymentCards = new PaymentCards();
        Address address = new Address();
        address.setAddrIdentifier(1);
        PaymentCard paymentCard = new PaymentCard();
        paymentCard.setBillingAddress(address);
        String newNickName = Long.toString(System.currentTimeMillis());
        paymentCard.setCardNickName(newNickName);
        paymentCard.setCardHolderName("Homer Depot");
        paymentCard.setCardType("VI");
        paymentCard.setCardBrand("VISA");
        paymentCard.setCardExpiryMonth("01");
        paymentCard.setCardExpiryYear("2021");
        //paymentCard.setCardNumber("4387751111111038");
        paymentCard.setXrefCardNumber("1010000405591038");
        paymentCard.setPaymentId(paymentId);
        paymentCards.setPaymentCard(Collections.singletonList(paymentCard));

        return new Object[][]{{newNickName, paymentCards}};
    }

}
