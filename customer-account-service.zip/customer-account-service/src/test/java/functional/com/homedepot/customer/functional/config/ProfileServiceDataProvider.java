package com.homedepot.customer.functional.config;

import java.util.Date;

import org.testng.annotations.DataProvider;

import com.homedepot.customer.model.Account;
import com.homedepot.customer.model.Name;
import com.homedepot.customer.model.Profile;
import com.homedepot.customer.request.UserRegistrationRequest;

/**
 * Created by rxb1809 on Jun 19, 2016
 *
 */
public class ProfileServiceDataProvider {

    @DataProvider(name = "createCustomerProfile")
    public static Object[][] createCustomerProfileRequest() {
        UserRegistrationRequest userRegistrationRequest = new UserRegistrationRequest();
        userRegistrationRequest.setEmailId("qafunctional"+new Date().getTime()+"@test.com");
        userRegistrationRequest.setPassword("cowboy@1234".toCharArray());
        userRegistrationRequest.setConfirmPassword(userRegistrationRequest.getPassword());
        userRegistrationRequest.setZipCode("10004");

        return new Object[][]{{userRegistrationRequest}};

    }



    @DataProvider(name = "updateCustomerProfile")
    public static Object[][] updateCustomerProfileRequest() {
        Account account = new Account();

        Profile profile = new Profile();
        account.setProfile(profile);

        Name name = new Name("Rohan12345","Borse");
        profile.setName(name);

        profile.setZipCode("75034");
        profile.setIsTradesman(true);
        profile.setLocalStoreId("0121");

        account.setIsReqServedFromWCS(false);

        return new Object[][]{{account}};
        
    }
}
