package com.homedepot.customer.functional.crossref;

import com.homedepot.customer.integration.passport.THDPassportServiceFacade;
import com.homedepot.customer.util.GlobalConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.WebIntegrationTest;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.homedepot.customer.CustomerAccountService;
import com.homedepot.customer.exception.IntegrationException;
import com.homedepot.customer.integration.wcs.WCSCrossRefServiceFacade;
import com.homedepot.customer.integration.wcs.dto.crossref.CrossRefInfo;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

/**
 * Created by rxb1809 on Oct 15, 2016
 *
 */
@WebIntegrationTest(randomPort = true)
@SpringApplicationConfiguration(CustomerAccountService.class)
public class WCSCrossRefServiceFunctionalTest extends AbstractTestNGSpringContextTests{

    @Autowired
    WCSCrossRefServiceFacade serviceFacade;

    @Autowired
    private THDPassportServiceFacade passportServiceFacade;

    @Value("${mcmfunctionaltest.profile.svocId}")
    private String svocId;

    private String wcsId;

    @BeforeClass
    public void setUp() throws IntegrationException {
        ssoToken = passportServiceFacade.getToken();
    }

    String ssoToken = null;

    @Test
    public void testGetCrossRefInfoSvocId() throws IntegrationException{
        CrossRefInfo crossRefInfo = serviceFacade.getCrossRefInfoForSVOCCustAcctId(svocId);
        assertEquals(crossRefInfo.getSvocCustAcctId(), svocId);
        wcsId = crossRefInfo.getWcsMemberId();
    }

    @Test
    public void testGetCrossRefInfoWcsId() throws IntegrationException{
        CrossRefInfo crossRefInfo = serviceFacade.getCrossRefInfoForWCSMemberId(wcsId);
        assertEquals(crossRefInfo.getWcsMemberId(), wcsId);
    }
    
    @Test
    public void testAddCrossRefInfo() throws IntegrationException{
        CrossRefInfo crossRefInfoRequest = new CrossRefInfo();
        crossRefInfoRequest.setSvocCustAcctId(svocId);
        crossRefInfoRequest.setWcsMemberId(wcsId);
        crossRefInfoRequest.setLastUpdUser(GlobalConstants.APPLICATION_ID);
        CrossRefInfo crossRefInfo = serviceFacade.saveCrossRefInfo(crossRefInfoRequest,ssoToken);
        assertEquals(crossRefInfo.getStatus(), "FAILED");
    }

    @Test
    public void testUpdateCrossRefInfo() throws IntegrationException{
        CrossRefInfo crossRefInfoRequest = new CrossRefInfo();
        crossRefInfoRequest.setSvocCustAcctId(svocId);
        crossRefInfoRequest.setWcsMemberId(wcsId);
        crossRefInfoRequest.setLastUpdUser(GlobalConstants.APPLICATION_ID);
        CrossRefInfo crossRefInfo = serviceFacade.updateCrossRefInfo(crossRefInfoRequest,ssoToken);
        assertEquals(crossRefInfo.getSvocCustAcctId(), svocId);
        assertEquals(crossRefInfo.getWcsMemberId(), wcsId);
    }
}
