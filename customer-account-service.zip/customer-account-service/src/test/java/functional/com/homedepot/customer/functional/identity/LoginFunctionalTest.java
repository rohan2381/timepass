package com.homedepot.customer.functional.identity;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;

import java.util.Collections;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.boot.test.WebIntegrationTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.springframework.web.client.RestTemplate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.homedepot.customer.CustomerAccountService;
import com.homedepot.customer.request.IdentityRequest;
import com.homedepot.customer.request.UserRegistrationRequest;
import com.homedepot.customer.response.IdentityResponse;
import com.homedepot.customer.response.ProfileResponse;

import lombok.extern.slf4j.Slf4j;

/**
 * Created by rxb1809 on Jun 11, 2017
 *
 */
@WebIntegrationTest(randomPort = true)
@SpringApplicationConfiguration(CustomerAccountService.class)
@Slf4j
public class LoginFunctionalTest extends
AbstractTestNGSpringContextTests{

    @Value("${local.server.port}")
    private int port;
    
    private RestTemplate restTemplate;
    private String BASE_URL;
    private HttpHeaders headers;
    private String loginUrl;
    private String registrationUrl;
    
    private static final String LOGIN_URL = "/customer/account/v1/login";
    private static final String REGISTRATION_URL = "/customer/account/v1/register";
    
    @BeforeClass
    public void setUp() {
        if (port != 0) {
            BASE_URL = "http://localhost:" + port;
        } else {
            BASE_URL = "http://localhost:8080";
        }
        
        loginUrl = BASE_URL + LOGIN_URL;
        registrationUrl = BASE_URL + REGISTRATION_URL;
        restTemplate = new TestRestTemplate();
        
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, true);
        mapper.setSerializationInclusion(Include.NON_NULL);
        mapper.configure(DeserializationFeature.UNWRAP_ROOT_VALUE, false);
        
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        converter.setObjectMapper(mapper);
        
        for (int i = 0; i < restTemplate.getMessageConverters().size(); i++) {
            final HttpMessageConverter<?> httpMessageConverter = restTemplate.getMessageConverters().get(i);
            if (httpMessageConverter instanceof MappingJackson2HttpMessageConverter) {
                restTemplate.getMessageConverters().set(i, converter);
            }
        }

        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set("channelId", "1");
    }
    
    @Test
    public void testLogin_IAM_WCS_Success(){
        IdentityRequest identityReq = new IdentityRequest();
        identityReq.setLogonId("rohan2381@qa74.com");
        identityReq.setPassword("Password@1234".toCharArray());
        HttpEntity<IdentityRequest> requestEntity = new HttpEntity<>(identityReq,headers);
        ResponseEntity<IdentityResponse> responseEntity = restTemplate.exchange(loginUrl, HttpMethod.POST, requestEntity,
                IdentityResponse.class);
        
        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
        assertNotNull(responseEntity.getBody());
        IdentityResponse identityResp = (IdentityResponse)responseEntity.getBody();
        assertEquals(identityResp.getIdentity().getLogonId(), "rohan2381@qa74.com");
        assertEquals(identityResp.getIdentity().getSvocCustomerAccountId(), "03F7313C8C8B90100S");
        assertEquals(identityResp.getIdentity().getWcsMemberId(), "1068328171");
    }
    
    @Test
    public void testLogin_IAM_WCS_Invalid(){
        UserRegistrationRequest registrationReq = new UserRegistrationRequest();
        String emailId = "test"+new Date().getTime()+"@qa74.com";
        registrationReq.setEmailId(emailId);
        registrationReq.setPassword("Password@123".toCharArray());
        registrationReq.setConfirmPassword("Password@123".toCharArray());
        registrationReq.setZipCode("75063");
        
        HttpEntity<UserRegistrationRequest> regReqEntity = new HttpEntity<>(registrationReq,headers);
        ResponseEntity<ProfileResponse> regResponseEntity = restTemplate.exchange(registrationUrl, HttpMethod.POST, regReqEntity,
                ProfileResponse.class);
        
        if(HttpStatus.OK.equals(regResponseEntity.getStatusCode()) && regResponseEntity.getBody()!=null
                && regResponseEntity.getBody().getIdentity()!=null && regResponseEntity.getBody().getIdentity().getSvocCustomerAccountId()!=null){
            
            String incorrectPassword = "Password@12";
            ResponseEntity<IdentityResponse> responseEntity = null;
            
            IdentityRequest identityReq = new IdentityRequest();
            identityReq.setLogonId(emailId);
            identityReq.setPassword(incorrectPassword.toCharArray());
            HttpEntity<IdentityRequest> requestEntity = new HttpEntity<>(identityReq,headers);
            responseEntity = restTemplate.exchange(loginUrl, HttpMethod.POST, requestEntity,
                    IdentityResponse.class);

            assertEquals(responseEntity.getStatusCode(), HttpStatus.UNAUTHORIZED);
            assertNotNull(responseEntity.getBody());
            IdentityResponse identityResp = (IdentityResponse)responseEntity.getBody();
            assertNotNull(identityResp.getIdentity().getErrors());
            assertEquals(identityResp.getIdentity().getErrors().get(0).getErrorCode(), "AUTH_ERR_102"); 
            
        }
    }
    
    @Test
    public void testLogin_IAM_WCS_Invalid_LockedOut_Warning(){       
        UserRegistrationRequest registrationReq = new UserRegistrationRequest();
        String emailId = "test"+new Date().getTime()+"@qa74.com";
        registrationReq.setEmailId(emailId);
        registrationReq.setPassword("Password@123".toCharArray());
        registrationReq.setConfirmPassword("Password@123".toCharArray());
        registrationReq.setZipCode("75063");
        
        HttpEntity<UserRegistrationRequest> regReqEntity = new HttpEntity<>(registrationReq,headers);
        ResponseEntity<ProfileResponse> regResponseEntity = restTemplate.exchange(registrationUrl, HttpMethod.POST, regReqEntity,
                ProfileResponse.class);
        
        if(HttpStatus.OK.equals(regResponseEntity.getStatusCode()) && regResponseEntity.getBody()!=null
                && regResponseEntity.getBody().getIdentity()!=null && regResponseEntity.getBody().getIdentity().getSvocCustomerAccountId()!=null){
            
            String incorrectPassword = "Password@12";
            ResponseEntity<IdentityResponse> responseEntity = null;
            
            for(int i = 0; i<5; i++){
                IdentityRequest identityReq = new IdentityRequest();
                identityReq.setLogonId(emailId);
                identityReq.setPassword(incorrectPassword.toCharArray());
                HttpEntity<IdentityRequest> requestEntity = new HttpEntity<>(identityReq,headers);
                responseEntity = restTemplate.exchange(loginUrl, HttpMethod.POST, requestEntity,
                        IdentityResponse.class);
                
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            assertEquals(responseEntity.getStatusCode(), HttpStatus.UNAUTHORIZED);
            assertNotNull(responseEntity.getBody());
            IdentityResponse identityResp = (IdentityResponse)responseEntity.getBody();
            assertNotNull(identityResp.getIdentity().getErrors());
            assertEquals(identityResp.getIdentity().getErrors().get(0).getErrorCode(), "AUTH_ERR_110"); 
            
        }
    }
    
    @Test
    public void testLogin_IAM_WCS_Invalid_LockedOut(){
        UserRegistrationRequest registrationReq = new UserRegistrationRequest();
        String emailId = "test"+new Date().getTime()+"@qa74.com";
        registrationReq.setEmailId(emailId);
        registrationReq.setPassword("Password@123".toCharArray());
        registrationReq.setConfirmPassword("Password@123".toCharArray());
        registrationReq.setZipCode("75063");
        
        HttpEntity<UserRegistrationRequest> regReqEntity = new HttpEntity<>(registrationReq,headers);
        ResponseEntity<ProfileResponse> regResponseEntity = restTemplate.exchange(registrationUrl, HttpMethod.POST, regReqEntity,
                ProfileResponse.class);
        
        if(HttpStatus.OK.equals(regResponseEntity.getStatusCode()) && regResponseEntity.getBody()!=null
                && regResponseEntity.getBody().getIdentity()!=null && regResponseEntity.getBody().getIdentity().getSvocCustomerAccountId()!=null){
            
            String incorrectPassword = "Password@12";
            ResponseEntity<IdentityResponse> responseEntity = null;
            
            for(int i = 0; i<=5; i++){
                IdentityRequest identityReq = new IdentityRequest();
                identityReq.setLogonId(emailId);
                identityReq.setPassword(incorrectPassword.toCharArray());
                HttpEntity<IdentityRequest> requestEntity = new HttpEntity<>(identityReq,headers);
                responseEntity = restTemplate.exchange(loginUrl, HttpMethod.POST, requestEntity,
                        IdentityResponse.class);
                
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            assertEquals(responseEntity.getStatusCode(), HttpStatus.UNAUTHORIZED);
            assertNotNull(responseEntity.getBody());
            IdentityResponse identityResp = (IdentityResponse)responseEntity.getBody();
            assertNotNull(identityResp.getIdentity().getErrors());
            assertEquals(identityResp.getIdentity().getErrors().get(0).getErrorCode(), "AUTH_ERR_103"); 
            
        }
    }
    
    @Test
    public void testLogin_IAM_WCS_Invalid_ForcedReset_Password_Independent(){
        String incorrectPassword = "password@12";
        IdentityRequest identityReq = new IdentityRequest();
        identityReq.setLogonId("testpwdreset2@forced.com");
        identityReq.setPassword(incorrectPassword.toCharArray());
        HttpEntity<IdentityRequest> requestEntity = new HttpEntity<>(identityReq,headers);
        ResponseEntity<IdentityResponse> responseEntity = restTemplate.exchange(loginUrl, HttpMethod.POST, requestEntity,
                IdentityResponse.class);
        
        assertEquals(responseEntity.getStatusCode(), HttpStatus.UNAUTHORIZED);
        assertNotNull(responseEntity.getBody());
        IdentityResponse identityResp = (IdentityResponse)responseEntity.getBody();
        assertNotNull(identityResp.getIdentity().getErrors());
        assertEquals(identityResp.getIdentity().getErrors().get(0).getErrorCode(), "AUTH_ERR_PWD_RESET_120");
    }
    
    @Test
    public void testLogin_IAM_WCS_Invalid_ForcedReset_Password_Dependent(){
        String correctPassword = "password@1234";
        IdentityRequest identityReq = new IdentityRequest();
        identityReq.setLogonId("testpwdreset3@forced.com");
        identityReq.setPassword(correctPassword.toCharArray());
        HttpEntity<IdentityRequest> requestEntity = new HttpEntity<>(identityReq,headers);
        ResponseEntity<IdentityResponse> responseEntity = restTemplate.exchange(loginUrl, HttpMethod.POST, requestEntity,
                IdentityResponse.class);
        
        assertEquals(responseEntity.getStatusCode(), HttpStatus.UNAUTHORIZED);
        assertNotNull(responseEntity.getBody());
        IdentityResponse identityResp = (IdentityResponse)responseEntity.getBody();
        assertNotNull(identityResp.getIdentity().getErrors());
        assertEquals(identityResp.getIdentity().getErrors().get(0).getErrorCode(), "AUTH_ERR_PWD_RESET_120");
    }
}
