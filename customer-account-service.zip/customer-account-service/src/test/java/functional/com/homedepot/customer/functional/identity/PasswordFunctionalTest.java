package com.homedepot.customer.functional.identity;

import java.util.Collections;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.boot.test.WebIntegrationTest;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.springframework.web.client.RestTemplate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.homedepot.customer.CustomerAccountService;
import com.homedepot.customer.exception.RepositoryException;
import com.homedepot.customer.integration.iam.IamServiceHelper;
import com.homedepot.customer.repository.IIdentityRepository;
import com.homedepot.customer.request.PasswordRequest;
import com.homedepot.customer.util.EnvPropertyUtil;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

/**
 * Created by jirapat on 6/12/17.
 */
@WebIntegrationTest(randomPort = true)
@SpringApplicationConfiguration(CustomerAccountService.class)
@Slf4j
@PropertySource("iam/iam-integration.properties")
public class PasswordFunctionalTest extends AbstractTestNGSpringContextTests {
    @Value("${local.server.port}")
    private int port;

    private RestTemplate restTemplate;
    private String BASE_URL;
    private HttpHeaders headers;
    private ObjectMapper mapper;

    @Autowired
    IIdentityRepository identityRepository;

    @Autowired
    EnvPropertyUtil envProperty;

    @Autowired
    private Environment env;

    @Autowired
    private IamServiceHelper iamServiceHelper;

    private static final String RESET_PASSWORD_EMAIL_URL = "/customer/account/v1/resetPasswordEmail";
    private static final String RESET_PASSWORD_URL = "/customer/account/v1/resetPassword";
    private static final String SET_PASSWORD_EMAIL_URL = "/customer/account/v1/setPasswordEmail";
    private static final String SET_PASSWORD_URL = "/customer/account/v1/setPassword";

    private static final String RESET_PWD_TEST_EMAIL = "pwd_functional_test@homedepot.com";
    private static final String SET_PWD_TEST_EMAIL = "setpwd_functional_test@homedepot.com";

    @BeforeClass
    public void setUp() {
        if (port != 0) {
            BASE_URL = "http://localhost:" + port;
        } else {
            BASE_URL = "http://localhost:8080";
        }
        restTemplate = new TestRestTemplate();

        mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, true);

        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set("channelId", "1");
    }

    @Test
    public void resetPasswordEmail() throws Exception {
        String setPwdEmailUrl = BASE_URL + RESET_PASSWORD_EMAIL_URL + "?email=" + RESET_PWD_TEST_EMAIL;
        HttpEntity requestEntity = new HttpEntity(headers);

        ResponseEntity<Boolean> responseEntity = restTemplate.exchange(setPwdEmailUrl, HttpMethod.GET, requestEntity, Boolean.class);
        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
        assertTrue(responseEntity.getBody());
    }

    @Test
    public void resetPassword() throws Exception {
        String password = "Unit" + System.currentTimeMillis();

        PasswordRequest resetPwdRequest = new PasswordRequest();
        resetPwdRequest.setSvocId("MDMxMDU1NjhCQjQ0Qjg3NDBT"); // base64 encoded svoc id 03105568BB44B8740S
        resetPwdRequest.setPassword(password.toCharArray());
        resetPwdRequest.setConfirmPassword(password.toCharArray());
        resetPwdRequest.setEmail(RESET_PWD_TEST_EMAIL);
        resetPwdRequest.setToken(getResetPasswordToken());

        String jsonRequest = mapper.writeValueAsString(resetPwdRequest);
        System.out.println("jsonRequest: " + jsonRequest);

        HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest, headers);

        ResponseEntity<Boolean> responseEntity = restTemplate.exchange(BASE_URL + RESET_PASSWORD_URL, HttpMethod.POST, requestEntity, Boolean.class);
        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
        assertTrue(responseEntity.getBody());
    }

    @Test
    public void setPasswordEmail() throws Exception {
        // for set password flow, user should be in WCS and SVOC with cross-ref, but not in IAM
        deleteIAMAccount("0310566405C4B8740S");

        String setPwdEmailUrl = BASE_URL + SET_PASSWORD_EMAIL_URL + "?email=" + SET_PWD_TEST_EMAIL;
        HttpEntity requestEntity = new HttpEntity(headers);

        ResponseEntity<Boolean> responseEntity = restTemplate.exchange(setPwdEmailUrl, HttpMethod.GET, requestEntity, Boolean.class);
        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
        assertTrue(responseEntity.getBody());
    }

    @Test(dependsOnMethods = "setPasswordEmail")
    public void setPassword() throws Exception {
        String password = "Unit" + System.currentTimeMillis();

        PasswordRequest resetPwdRequest = new PasswordRequest();
        resetPwdRequest.setSvocId("MDMxMDU2NjQwNUM0Qjg3NDBT"); // base64 encoded svoc id 0310566405C4B8740S
        resetPwdRequest.setPassword(password.toCharArray());
        resetPwdRequest.setConfirmPassword(password.toCharArray());
        resetPwdRequest.setEmail(SET_PWD_TEST_EMAIL);
        resetPwdRequest.setToken(getResetPasswordToken());

        String jsonRequest = mapper.writeValueAsString(resetPwdRequest);
        System.out.println("jsonRequest: " + jsonRequest);

        HttpEntity<String> requestEntity = new HttpEntity<>(jsonRequest, headers);

        ResponseEntity<Boolean> responseEntity = restTemplate.exchange(BASE_URL + SET_PASSWORD_URL, HttpMethod.POST, requestEntity, Boolean.class);
        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
        assertTrue(responseEntity.getBody());

    }

    private String getResetPasswordToken() throws RepositoryException {
        return identityRepository.getResetPasswordToken(RESET_PWD_TEST_EMAIL);
    }

    private void deleteIAMAccount(String svocId) {
        try {
            String serviceAuthToken = identityRepository.getServiceAuthToken(envProperty.getIamServiceUser(), envProperty.getIamServicePassword());

            String delIAMAccountURL = env.getProperty("iamBaseUrl") + "/users/" + svocId + "?_fields=hdOriginID";
            HttpHeaders delHeaders = new HttpHeaders();
            delHeaders.setContentType(MediaType.APPLICATION_JSON);
            delHeaders.add("THDIAMUnified", serviceAuthToken);

            Object delResponse = iamServiceHelper.sendRequest(HttpMethod.DELETE, delIAMAccountURL, delHeaders, null, Object.class);
            System.out.println("delete user account in iam response: " + delResponse);
        }
        catch(Exception e) {
            // ignore, user may already not in iam
            System.out.println("ignore delete iam account error: " + e.getMessage());
        }
    }
}
