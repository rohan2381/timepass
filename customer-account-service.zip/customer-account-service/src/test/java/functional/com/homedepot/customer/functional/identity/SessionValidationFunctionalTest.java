package com.homedepot.customer.functional.identity;

import static org.testng.Assert.*;
import java.util.*;
import java.util.Optional;
import org.springframework.beans.factory.annotation.*;
import org.springframework.boot.test.*;
import org.springframework.http.*;
import org.springframework.http.converter.*;
import org.springframework.http.converter.json.*;
import org.springframework.test.context.testng.*;
import org.springframework.web.client.*;
import org.testng.annotations.*;
import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.*;
import com.homedepot.customer.*;
import com.homedepot.customer.model.*;
import com.homedepot.customer.request.*;
import com.homedepot.customer.response.*;
import com.homedepot.customer.util.*;
import lombok.extern.slf4j.*;

/**
 * Created by nxw6207 on 6/12/17.
 */
@WebIntegrationTest(randomPort = true)
@SpringApplicationConfiguration(CustomerAccountService.class)
@Slf4j
public class SessionValidationFunctionalTest extends AbstractTestNGSpringContextTests {

    @Value("${local.server.port}")
    private int port;

    private RestTemplate restTemplate;
    private String BASE_URL;
    private HttpHeaders headers;
    private String loginUrl;
    private String validateUrl;
    private String logoutUrl;

    private List<String> responseCookies;

    private String iamToken;
    private String wcsToken;

    public static final String SET_COOKIE = "Set-Cookie";

    private static final String LOGIN_URL = "/customer/account/v1/login";
    private static final String VALIDATE_URL = "/customer/account/v1/session/validate";
    private static final String LOGOUT_URL = "/customer/account/v1/session/logout";

    @BeforeClass
    public void setUp() {
        if (port != 0) {
            BASE_URL = "http://localhost:" + port;
        } else {
            BASE_URL = "http://localhost:8080";
        }

        loginUrl = BASE_URL + LOGIN_URL;
        validateUrl = BASE_URL + VALIDATE_URL;
        logoutUrl = BASE_URL + LOGOUT_URL;
        restTemplate = new TestRestTemplate();

        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, true);
        mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        mapper.configure(DeserializationFeature.UNWRAP_ROOT_VALUE, false);

        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        converter.setObjectMapper(mapper);

        for (int i = 0; i < restTemplate.getMessageConverters().size(); i++) {
            final HttpMessageConverter<?> httpMessageConverter = restTemplate.getMessageConverters().get(i);
            if (httpMessageConverter instanceof MappingJackson2HttpMessageConverter) {
                restTemplate.getMessageConverters().set(i, converter);
            }
        }

        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set("channelId", "1");

        HttpHeaders loginResponseHeaders = getUserLoginHeaders();

        responseCookies = loginResponseHeaders.get(SET_COOKIE);

        Optional<String> thd_user_session = responseCookies.stream().filter(p -> p.contains("THD_USER_SESSION")).findAny();

        if(thd_user_session.isPresent()){
            String iamTokenPair = Arrays.asList(thd_user_session.map(p -> p.split(";")).get())
                    .stream().filter(p -> p.contains("THD_USER_SESSION")).findAny()
                    .get();
            iamToken = iamTokenPair.substring(iamTokenPair.lastIndexOf("=")+1);
        }

        Optional<String> thd_persist = responseCookies.stream().filter(p -> p.contains("THD_PERSIST")).findAny();

        if(thd_persist.isPresent()){
            String wcsTokenPair = Arrays.asList(thd_persist.map(p -> p.split(";")).get())
                    .stream().filter(p -> p.contains("THD_PERSIST")).findAny()
                    .get();
            wcsToken = wcsTokenPair.substring(wcsTokenPair.lastIndexOf("=")+1);
        }
    }

    private HttpHeaders getUserLoginHeaders() {
        IdentityRequest identityReq = new IdentityRequest();
        identityReq.setLogonId("qa74_user164@qa74.com");
        identityReq.setPassword("hdpwd1234".toCharArray());
        HttpEntity<IdentityRequest> requestEntity = new HttpEntity<>(identityReq,headers);
        ResponseEntity<IdentityResponse> responseEntity = restTemplate.exchange(loginUrl, HttpMethod.POST, requestEntity,
                IdentityResponse.class);
        return responseEntity.getHeaders();
    }

    @Test
    public void testValidateSession_IAM_Success(){

        headers.set(GlobalConstants.THD_AUTH_TOKEN, iamToken);
        headers.set("Cookie", responseCookies.toString());

        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<Identity> responseEntity = restTemplate.exchange(validateUrl, HttpMethod.GET, requestEntity, Identity.class);

        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
        assertEquals(responseEntity.getHeaders().getContentType().toString(),
                "application/json;charset=UTF-8");
        System.out.println(responseEntity.getStatusCode());

        assertEquals(responseEntity.getBody().getSvocCustomerAccountId(), "03105559EEBAB8740S");

    }

    @Test
    public void testValidateSession_WCS_Success(){

        headers.set(GlobalConstants.THD_AUTH_TOKEN, wcsToken);
        headers.set("Cookie", responseCookies.toString());

        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<Identity> responseEntity = restTemplate.exchange(validateUrl, HttpMethod.GET, requestEntity, Identity.class);

        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
        assertEquals(responseEntity.getHeaders().getContentType().toString(),
                "application/json;charset=UTF-8");
        System.out.println(responseEntity.getStatusCode());

        assertEquals(responseEntity.getBody().getWcsMemberId(), "1068865803");

    }

    @Test
    public void testLogoutSession_Success(){

        headers.set(GlobalConstants.THD_AUTH_TOKEN, iamToken);
        headers.set("Cookie", responseCookies.toString());

        HttpEntity<String> requestEntity = new HttpEntity<>(headers);

        ResponseEntity<Boolean> responseEntity = restTemplate.exchange(logoutUrl, HttpMethod.GET, requestEntity, Boolean.class);

        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
        assertEquals(responseEntity.getHeaders().getContentType().toString(),
                "application/json;charset=UTF-8");
        System.out.println(responseEntity.getStatusCode());

        assertEquals(responseEntity.getBody(), Boolean.TRUE);

    }

}
