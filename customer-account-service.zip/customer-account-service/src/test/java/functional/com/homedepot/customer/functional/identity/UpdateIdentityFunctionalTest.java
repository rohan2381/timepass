package com.homedepot.customer.functional.identity;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.homedepot.customer.CustomerAccountService;
import com.homedepot.customer.model.Identity;
import com.homedepot.customer.request.IdentityRequest;
import com.homedepot.customer.request.UserRegistrationRequest;
import com.homedepot.customer.response.ErrorResponse;
import com.homedepot.customer.response.IdentityResponse;
import com.homedepot.customer.response.ProfileResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.boot.test.WebIntegrationTest;
import org.springframework.http.*;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.springframework.web.client.RestTemplate;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.net.HttpCookie;
import java.util.*;

import static org.testng.Assert.*;

@WebIntegrationTest(randomPort = true)
@SpringApplicationConfiguration(CustomerAccountService.class)
@Slf4j
public class UpdateIdentityFunctionalTest extends AbstractTestNGSpringContextTests {

    private static final String API_URL = "/customer/account/v1";
    private static final String LOGIN_URL = API_URL + "/login";
    private static final String REGISTRATION_URL = API_URL + "/register";
    private static final String GET_PROFILE_URL = API_URL + "/{svoc_id}/profile";
    private static final String UPDATE_ID_URL = API_URL + "/{svoc_id}/profile/identity";

    @Value("${local.server.port}")
    private int port;
    
    private RestTemplate restTemplate;
    private String BASE_URL;
    private HttpHeaders headers;
    private String updateIdUrl;
    private String getProfileUrl;
    private String loginUrl;
    private String registrationUrl;

    @BeforeClass
    public void setUp() {

        if (port != 0) {
            BASE_URL = "http://localhost:" + port;
        } else {
            BASE_URL = "http://localhost:8080";
        }

        loginUrl = BASE_URL + LOGIN_URL;
        registrationUrl = BASE_URL + REGISTRATION_URL;
        getProfileUrl = BASE_URL + GET_PROFILE_URL;
        updateIdUrl = BASE_URL + UPDATE_ID_URL;
        restTemplate = new TestRestTemplate();
        
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, true);
        mapper.setSerializationInclusion(Include.NON_NULL);
        mapper.configure(DeserializationFeature.UNWRAP_ROOT_VALUE, false);
        
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        converter.setObjectMapper(mapper);
        
        for (int i = 0; i < restTemplate.getMessageConverters().size(); i++) {
            final HttpMessageConverter<?> httpMessageConverter = restTemplate.getMessageConverters().get(i);
            if (httpMessageConverter instanceof MappingJackson2HttpMessageConverter) {
                restTemplate.getMessageConverters().set(i, converter);
            }
        }

        headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set("channelId", "1");
    }
    
    @Test
    public void test_UpdateEmail_Success() {

        String emailId = "test_" + new Date().getTime() + "@qa74.com";
        String password = "Pass@123";
        // Register new user
        ResponseEntity<ProfileResponse> regResponseEntity = registerNewUser(emailId, password);
        Optional<String> svocIdOpt = Optional.ofNullable(regResponseEntity.getBody())
                                                .map(ProfileResponse::getIdentity)
                                                .map(Identity::getSvocCustomerAccountId);
        if(HttpStatus.OK.equals(regResponseEntity.getStatusCode()) && svocIdOpt.isPresent()) {
            // Login
            ResponseEntity<IdentityResponse> loginResponseEntity = login(emailId, password);
            Optional<String> loginSvocIdOpt = Optional.ofNullable(loginResponseEntity.getBody())
                                                        .map(IdentityResponse::getIdentity)
                                                        .map(Identity::getSvocCustomerAccountId);
            if(HttpStatus.OK.equals(loginResponseEntity.getStatusCode()) && loginSvocIdOpt.isPresent()) {
                // Get user profile
                ResponseEntity<ProfileResponse> profileRespEntity = getProfile(loginSvocIdOpt.get(), loginResponseEntity);
                Date emailLastModifiedDate = profileRespEntity.getBody().getAccount().getProfile().getLastModifiedDate();
                // Update password
                IdentityRequest updateIdentityReq = new IdentityRequest();
                updateIdentityReq.setLogonId(emailId);
                String newEmail = "test_" + new Date().getTime() + "@qa74.com";
                updateIdentityReq.setLogonId(emailId);
                updateIdentityReq.setNewLogonId(newEmail);
                updateIdentityReq.setEmailLastModifiedDate(emailLastModifiedDate);
                HttpEntity<IdentityRequest> updateIdRequestEntity = new HttpEntity<>(updateIdentityReq, headers);
                ResponseEntity<IdentityResponse> updateIdRespEntity = restTemplate.exchange(updateIdUrl, HttpMethod.PUT, updateIdRequestEntity,
                                                                                            IdentityResponse.class, loginSvocIdOpt.get());
                assertEquals(updateIdRespEntity.getStatusCode(), HttpStatus.OK);
            } else {
                log.error("Login Response = {}", loginResponseEntity);
                fail("test_UpdateEmail_Success() failure - reason: User Login failure or SVOC id not found");
            }
        } else {
            log.error("Registration Response = {}", regResponseEntity);
            fail("test_UpdateEmail_Success() failure - reason: User Registration failure or SVOC id not found");
        }
    }

    @Test
    public void test_UpdatePassword_Success() {

        String emailId = "test_" + new Date().getTime() + "@qa74.com";
        String password = "Pass@123";
        // Register new user
        ResponseEntity<ProfileResponse> regResponseEntity = registerNewUser(emailId, password);
        Optional<String> svocIdOpt = Optional.ofNullable(regResponseEntity.getBody())
                                                .map(ProfileResponse::getIdentity)
                                                .map(Identity::getSvocCustomerAccountId);
        if(HttpStatus.OK.equals(regResponseEntity.getStatusCode()) && svocIdOpt.isPresent()) {
            // Login
            ResponseEntity<IdentityResponse> loginResponseEntity = login(emailId, password);
            Optional<String> loginSvocIdOpt = Optional.ofNullable(loginResponseEntity.getBody())
                                                        .map(IdentityResponse::getIdentity)
                                                        .map(Identity::getSvocCustomerAccountId);
            if(HttpStatus.OK.equals(loginResponseEntity.getStatusCode()) && loginSvocIdOpt.isPresent()) {
                // Get user profile
                ResponseEntity<ProfileResponse> profileRespEntity = getProfile(loginSvocIdOpt.get(), loginResponseEntity);
                Date emailLastModifiedDate = profileRespEntity.getBody().getAccount().getProfile().getLastModifiedDate();
                // Update password
                IdentityRequest updateIdentityReq = new IdentityRequest();
                updateIdentityReq.setLogonId(emailId);
                String newPassword = "Pass#1234";
                updateIdentityReq.setNewPassword(newPassword.toCharArray());
                updateIdentityReq.setEmailLastModifiedDate(emailLastModifiedDate);
                HttpEntity<IdentityRequest> updateIdRequestEntity = new HttpEntity<>(updateIdentityReq, headers);
                ResponseEntity<IdentityResponse> updateIdRespEntity = restTemplate.exchange(updateIdUrl, HttpMethod.PUT, updateIdRequestEntity,
                                                                                            IdentityResponse.class, loginSvocIdOpt.get());
                assertEquals(updateIdRespEntity.getStatusCode(), HttpStatus.OK);
            } else {
                log.error("Login Response = {}", loginResponseEntity);
                fail("test_UpdatePassword_Success() failure - reason: User Login failure or SVOC id not found");
            }
        } else {
            log.error("Registration Response = {}", regResponseEntity);
            fail("test_UpdatePassword_Success() failure - reason: User Registration failure or SVOC id not found");
        }
    }

    @Test
    public void test_UpdateEmail_AuthTokenMissing_Error() {

        IdentityRequest identityReq = new IdentityRequest();
        identityReq.setLogonId("update_test@depot.com");
        identityReq.setNewLogonId("update_test_1@depot.com");
        identityReq.setEmailLastModifiedDate(Calendar.getInstance().getTime());
        HttpEntity<IdentityRequest> requestEntity = new HttpEntity<>(identityReq, headers);
        ResponseEntity<ErrorResponse> responseEntity = restTemplate.exchange(updateIdUrl, HttpMethod.PUT, requestEntity,
                                                                            ErrorResponse.class, "031054C67315B8740S");
        assertEquals(responseEntity.getStatusCode(), HttpStatus.BAD_REQUEST);
        ErrorResponse errorResponse = responseEntity.getBody();
        assertNotNull(errorResponse);
        assertEquals(errorResponse.getErrors().get(0).getErrorCode(), "AUTH_ERR_101");
    }

    private ResponseEntity<ProfileResponse> registerNewUser(String emailId, String password) {

        UserRegistrationRequest registrationReq = new UserRegistrationRequest();
        registrationReq.setEmailId(emailId);
        registrationReq.setPassword(password.toCharArray());
        registrationReq.setConfirmPassword(password.toCharArray());
        registrationReq.setZipCode("75063");
        HttpEntity<UserRegistrationRequest> regReqEntity = new HttpEntity<>(registrationReq, headers);
        return restTemplate.exchange(registrationUrl, HttpMethod.POST, regReqEntity, ProfileResponse.class);
    }

    private ResponseEntity<IdentityResponse> login(String emailId, String password) {

        IdentityRequest identityReq = new IdentityRequest();
        identityReq.setLogonId(emailId);
        identityReq.setPassword(password.toCharArray());
        HttpEntity<IdentityRequest> requestEntity = new HttpEntity<>(identityReq, headers);
        return restTemplate.exchange(loginUrl, HttpMethod.POST, requestEntity, IdentityResponse.class);
    }

    private ResponseEntity<ProfileResponse> getProfile(String svocId, ResponseEntity<IdentityResponse> loginResponseEntity) {

        List<String> loginRespCookies = loginResponseEntity.getHeaders().get("Set-Cookie");
        String thdUserSession = loginRespCookies.stream().filter(c -> c.contains("THD_USER_SESSION"))
                                                         .findAny().orElse(null);
        List<HttpCookie> cookies = HttpCookie.parse(thdUserSession);
        String iamToken = cookies.get(0).getValue();
        headers.add("Authorization", iamToken);
        loginRespCookies.forEach(c -> headers.add("Cookie", c));
        return restTemplate.exchange(getProfileUrl, HttpMethod.GET, new HttpEntity<>(headers), ProfileResponse.class, svocId);
    }

}
