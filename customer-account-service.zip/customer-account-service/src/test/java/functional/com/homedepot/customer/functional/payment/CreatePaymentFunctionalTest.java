package com.homedepot.customer.functional.payment;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.testng.Assert.assertEquals;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.homedepot.customer.exception.error.PaymentErrorCode;
import com.homedepot.customer.model.PaymentCards;
import com.homedepot.customer.response.PaymentResponse;

/**
 * Functional test class for create payment card
 * 
 * @author pxk3659
 * 
 */
public class CreatePaymentFunctionalTest extends PaymentFunctionalBaseTest {

    private static ResponseEntity<PaymentResponse> response = null;

    @BeforeMethod
    public void beforMethod() {
    }

    @Test
    public void testCreateVisaCard() {
        PaymentCards paymentCards = jsonToJava("create-card-visa.json");
        response = createPaymentCard(paymentCards);
        assertEquals(response.getStatusCode(), HttpStatus.OK);
        assertEquals(response.getHeaders().getContentType().toString(), "application/json;charset=UTF-8");
        assertNotNull(response.getBody().getPaymentCards().getPaymentCard().get(0).getPaymentId());
        // Validate if address is added and address identifier is present in response
        assertNotNull(
                response.getBody().getPaymentCards().getPaymentCard().get(0).getBillingAddress().getAddrIdentifier());

        ResponseEntity<PaymentResponse> paymentResponse = getAllPaymentCards();
        assertThat(paymentResponse.getBody().getPaymentCards().getPaymentCard().size(), is(1));
    }

    @Test
    public void testCreateAmexCard() {
        PaymentCards paymentCards = jsonToJava("create-card-amex.json");
        response = createPaymentCard(paymentCards);
        assertEquals(response.getStatusCode(), HttpStatus.OK);
        assertEquals(response.getHeaders().getContentType().toString(), "application/json;charset=UTF-8");
        assertNotNull(response.getBody().getPaymentCards().getPaymentCard().get(0).getPaymentId());
     
    }

    @Test
    public void testCreateMasterCard() {
        PaymentCards paymentCards = jsonToJava("create-card-master.json");
        response = createPaymentCard(paymentCards);
        assertEquals(response.getStatusCode(), HttpStatus.OK);
        assertEquals(response.getHeaders().getContentType().toString(), "application/json;charset=UTF-8");
        assertNotNull(response.getBody().getPaymentCards().getPaymentCard().get(0).getPaymentId());

    }

    @Test
    public void testCreateDuplicateMasterCard() {
        PaymentCards paymentCards = jsonToJava("create-card-master-no-address.json");
        response = createPaymentCard(paymentCards);
        assertEquals(response.getStatusCode(), HttpStatus.OK);
        assertEquals(response.getHeaders().getContentType().toString(), "application/json;charset=UTF-8");
        assertNotNull(response.getBody().getPaymentCards().getPaymentCard().get(0).getPaymentId());

        // Create same card again
        ResponseEntity<PaymentResponse> response2 = createPaymentCard(paymentCards);
        assertEquals(response2.getStatusCode(), HttpStatus.BAD_REQUEST);
        assertEquals(response2.getBody().getPaymentCards().getErrors().get(0).getErrorCode(),
                PaymentErrorCode.ERROR_CODE_CARD_EXISTS.getCode());

     
    }

    @AfterMethod
    public void afterMethod() {
        deletePaymentCards(response);
    }

}
